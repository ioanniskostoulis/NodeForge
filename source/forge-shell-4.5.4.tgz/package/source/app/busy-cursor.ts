// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The window's busy cursor (GUIDELINES-SHELL.md, Cursors). A busy shell part (a busy button, a running Terminal command,
// a building preview) shows progress over itself without a call; this marks the whole window.

/** `progress`: work runs and the window still takes input. `wait`: the window takes no input until it is done. */
export type WindowBusy = "progress" | "wait" | null;

/**
 * Show that the application is working: `progress` for work the user can carry on beside, `wait` for heavy work that
 * blocks the window (a transparent shield takes the clicks and shows the wait cursor), `null` when it is done.
 * Pair every call with a `null` in a `finally`.
 */
export function setWindowBusy(mode: WindowBusy, doc: Document = document): void {
  const root = doc.documentElement;
  if (mode) root.dataset.busy = mode; else delete root.dataset.busy;
  let shield = doc.querySelector<HTMLElement>(".busy-shield");
  if (mode === "wait" && !shield) {
    shield = doc.createElement("div");
    shield.className = "busy-shield";
    shield.setAttribute("aria-hidden", "true");
    doc.body.append(shield);
  } else if (mode !== "wait") shield?.remove();
}

/** Run `work` with the window busy, and restore it however the work ends. */
export async function whileBusy<T>(mode: Exclude<WindowBusy, null>, work: () => Promise<T>, doc: Document = document): Promise<T> {
  setWindowBusy(mode, doc);
  try { return await work(); } finally { setWindowBusy(null, doc); }
}
