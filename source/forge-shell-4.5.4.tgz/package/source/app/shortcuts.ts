// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Keyboard shortcut tiers. The shell owns the universal shortcuts (Cmd or Ctrl and a key); an application's own
// commands take two modifiers and a letter; a tool may take a bare key. `checkShortcuts` tests a registry against them.

/** universal: the shell's standard commands. app: Shift with Cmd or Ctrl. secondary: Option with Cmd, macOS only.
 * tool: a bare key, for canvas tools while no text field has the focus. invalid: anything else. */
export type ShortcutTier = "universal" | "app" | "secondary" | "tool" | "invalid";

/** The standard commands and their accelerators, owned by the shell. An application uses these ids and never rebinds the keys. */
export const UNIVERSAL_SHORTCUTS: Record<string, string> = {
  new: "CmdOrCtrl+N", open: "CmdOrCtrl+O", save: "CmdOrCtrl+S", saveAs: "CmdOrCtrl+Shift+S", close: "CmdOrCtrl+W",
  print: "CmdOrCtrl+P", quit: "CmdOrCtrl+Q", preferences: "CmdOrCtrl+,",
  undo: "CmdOrCtrl+Z", redo: "CmdOrCtrl+Shift+Z", cut: "CmdOrCtrl+X", copy: "CmdOrCtrl+C", paste: "CmdOrCtrl+V", selectAll: "CmdOrCtrl+A",
  find: "CmdOrCtrl+F", findNext: "CmdOrCtrl+G", findPrevious: "CmdOrCtrl+Shift+G", gotoLine: "CmdOrCtrl+L", toggleComment: "CmdOrCtrl+/",
  // Fit on Cmd+0 and Actual size on Cmd+1, as in Photoshop and Illustrator: every application has one Fit key.
  zoomIn: "CmdOrCtrl+=", zoomOut: "CmdOrCtrl+-", fit: "CmdOrCtrl+0", actualSize: "CmdOrCtrl+1",
  showInspector: "CmdOrCtrl+I", showBottomPanel: "CmdOrCtrl+J",
  // The keys every application uses the same way: Finder, Keynote, Figma and Illustrator for objects, browsers for windows and tabs.
  newWindow: "CmdOrCtrl+Shift+N", duplicate: "CmdOrCtrl+D",
  bringForward: "CmdOrCtrl+]", sendBackward: "CmdOrCtrl+[", bringToFront: "CmdOrCtrl+Shift+]", sendToBack: "CmdOrCtrl+Shift+[",
  nextTab: "Ctrl+Tab", previousTab: "Ctrl+Shift+Tab",
};
/** The standard action identifier (`STANDARD_ACTIONS`) of each universal command that has one. */
export const STANDARD_SHORTCUT_IDS: Record<string, string> = {
  "file.new": "new", "file.newWindow": "newWindow", "file.open": "open", "file.save": "save", "file.saveAs": "saveAs", "file.print": "print", "file.close": "close",
  "app.settings": "preferences",
  "edit.undo": "undo", "edit.redo": "redo", "edit.cut": "cut", "edit.copy": "copy", "edit.paste": "paste", "edit.duplicate": "duplicate", "edit.selectAll": "selectAll",
  "edit.find": "find", "edit.findNext": "findNext", "edit.findPrevious": "findPrevious", "edit.goToLine": "gotoLine", "edit.toggleComment": "toggleComment",
  "arrange.bringForward": "bringForward", "arrange.sendBackward": "sendBackward", "arrange.bringToFront": "bringToFront", "arrange.sendToBack": "sendToBack",
  "view.zoomIn": "zoomIn", "view.zoomOut": "zoomOut", "view.fit": "fit", "view.actualSize": "actualSize",
  "view.inspector": "showInspector", "view.bottomPanel": "showBottomPanel", "tab.next": "nextTab", "tab.prev": "previousTab",
};
/** Replace has no common key: Option+Cmd+F on macOS (as in Xcode and Pages) and Ctrl+H on Windows (as in Word and VS Code). */
export const replaceShortcut = (mac: boolean): string => (mac ? "Alt+CmdOrCtrl+F" : "CmdOrCtrl+H");

// Keys the system takes before an application sees them, written as normalized keys (see `normalizeKey`).
const MAC_RESERVED = [
  "Cmd+H", "Alt+Cmd+H", "Cmd+M", "Alt+Cmd+M", "Cmd+Tab", "Cmd+Space", "Cmd+`", "Ctrl+Cmd+F", "Ctrl+Cmd+Q", "Ctrl+Cmd+Space",
  "Shift+Cmd+3", "Shift+Cmd+4", "Shift+Cmd+5", "Shift+Cmd+Q", "Alt+Cmd+Escape", "Alt+Cmd+D", "Shift+Cmd+/",
];
const WIN_RESERVED = ["Alt+F4", "Alt+Tab", "Ctrl+Escape", "Ctrl+Shift+Escape", "Alt+Ctrl+Delete", "Alt+Space", "F10", "Alt"];
const MODIFIER_ORDER = ["Ctrl", "Alt", "Shift", "Cmd"];

/**
 * An accelerator in one canonical form for a platform: `CmdOrCtrl` becomes Cmd on macOS and Ctrl elsewhere, the
 * modifiers come in the order Control, Option or Alt, Shift, Command, and the key is upper case ("Shift+Cmd+B").
 */
export function normalizeKey(key: string, mac: boolean): string {
  const parts = key.split(/\+(?!$)/);
  const last = parts.pop()!;
  const names = parts.map((part) => (part === "CmdOrCtrl" || part === "CommandOrControl" ? (mac ? "Cmd" : "Ctrl") : part === "Command" || part === "Meta" ? "Cmd" : part === "Control" ? "Ctrl" : part === "Option" ? "Alt" : part));
  const modifiers = MODIFIER_ORDER.filter((name) => names.includes(name));
  return [...modifiers, last.length === 1 ? last.toUpperCase() : last].join("+");
}

/** The tier of an accelerator on a platform. */
export function shortcutTier(key: string, mac: boolean): ShortcutTier {
  const parts = normalizeKey(key, mac).split("+");
  const modifiers = parts.slice(0, -1).join("+");
  const primary = mac ? "Cmd" : "Ctrl";
  if (!modifiers) return "tool";
  if (modifiers === primary) return "universal";
  if (modifiers === (mac ? "Shift+Cmd" : "Ctrl+Shift")) return Object.values(UNIVERSAL_SHORTCUTS).some((item) => normalizeKey(item, mac) === normalizeKey(key, mac)) ? "universal" : "app";
  if (mac && modifiers === "Alt+Cmd") return "secondary";
  return "invalid";
}

/**
 * The accelerator of an application command on a letter: `app` is Shift+Cmd on macOS and Ctrl+Shift on Windows;
 * `secondary` is Option+Cmd on macOS and has no default on Windows, where Ctrl+Alt is AltGr and types characters.
 */
export function appShortcut(letter: string, tier: "app" | "secondary", mac: boolean): string | undefined {
  if (!/^[A-Z0-9]$/i.test(letter)) throw new Error(`An application shortcut is a letter or a digit, not "${letter}".`);
  if (tier === "app") return `CmdOrCtrl+Shift+${letter.toUpperCase()}`;
  return mac ? `Alt+CmdOrCtrl+${letter.toUpperCase()}` : undefined;
}

/**
 * Shortcuts that other applications have made conventional for one meaning. An application command with that meaning
 * may keep the conventional key, outside the tiers, by naming the convention (`ShortcutEntry.convention`); any other
 * command follows the tiers. `replaces` names a universal command whose key the convention takes, which the
 * application then gives the convention's partner key (Fit takes Cmd+0, and Actual size moves to Cmd+1, as in
 * Photoshop and Illustrator).
 */
export const CONVENTIONAL_SHORTCUTS: Record<string, { keys: readonly string[]; usedBy: string; replaces?: string }> = {
  group: { keys: ["CmdOrCtrl+G"], usedBy: "Keynote, Figma and Illustrator", replaces: "findNext" },
  ungroup: { keys: ["CmdOrCtrl+Shift+G"], usedBy: "Keynote, Figma and Illustrator", replaces: "findPrevious" },
  bold: { keys: ["CmdOrCtrl+B"], usedBy: "every text editor" },
  italic: { keys: ["CmdOrCtrl+I"], usedBy: "every text editor", replaces: "showInspector" },
  underline: { keys: ["CmdOrCtrl+U"], usedBy: "every text editor" },
  run: { keys: ["CmdOrCtrl+Enter", "CmdOrCtrl+Return", "CmdOrCtrl+R"], usedBy: "notebooks (Cmd or Ctrl+Return) and Xcode (Cmd+R)" },
  reload: { keys: ["CmdOrCtrl+R"], usedBy: "browsers and Finder previews (reload or restart)" },
  build: { keys: ["CmdOrCtrl+B"], usedBy: "Xcode, Visual Studio Code and TeX editors" },
};

export interface ShortcutEntry {
  id: string; key: string; owner?: "shell" | "app";
  /** The convention the key follows (a name of `CONVENTIONAL_SHORTCUTS`); its key is then checked against the convention, not the tiers. */
  convention?: string;
}

/**
 * The problems of a shortcut registry on a platform, as sentences: two commands on one key, a key the system takes, an
 * application command on a universal key, and keys that type characters (Option alone on macOS; Alt, Ctrl+Alt, which
 * is AltGr, and Alt+Shift, which switches the keyboard language, on Windows; Shift alone anywhere).
 */
export function checkShortcuts(entries: readonly ShortcutEntry[], mac: boolean): string[] {
  const problems: string[] = [];
  const platform = mac ? "macOS" : "Windows";
  const seen = new Map<string, string>();
  const reserved = new Set(mac ? MAC_RESERVED : WIN_RESERVED);
  const universal = new Map(Object.entries(UNIVERSAL_SHORTCUTS).map(([id, key]) => [normalizeKey(key, mac), id]));
  universal.set(normalizeKey(replaceShortcut(mac), mac), "replace");
  for (const { id, key, owner = "app", convention } of entries) {
    const shown = normalizeKey(key, mac);
    const modifiers = shown.split("+").slice(0, -1);
    const other = seen.get(shown);
    if (other && other !== id) problems.push(`${other} and ${id} share ${shown} on ${platform}.`);
    seen.set(shown, id);
    if (reserved.has(shown)) { problems.push(`${id} uses ${shown}, which ${platform} keeps for itself.`); continue; }
    if (convention !== undefined) {
      const rule = CONVENTIONAL_SHORTCUTS[convention];
      if (!rule) problems.push(`${id} names the convention ${convention}, which is not one of CONVENTIONAL_SHORTCUTS.`);
      else if (!rule.keys.some((item) => normalizeKey(item, mac) === shown)) problems.push(`${id} uses ${shown}, but the ${convention} convention is ${rule.keys.map((item) => normalizeKey(item, mac)).join(" or ")}.`);
      else {
        // The universal command the convention takes must not keep the same key.
        const taken = universal.get(shown);
        if (taken && taken !== rule.replaces && taken !== (STANDARD_SHORTCUT_IDS[id] ?? id)) problems.push(`${id} uses ${shown}, the shell's key for ${taken}, which the ${convention} convention does not replace.`);
      }
      continue;
    }
    const standard = universal.get(shown);
    // A standard action on its own key (`view.fit` on Cmd+0) is the shell's command, wherever it is registered.
    const own = id === "edit.replace" ? "replace" : STANDARD_SHORTCUT_IDS[id] ?? id;
    // A standard action takes its standard key and no other.
    const expected = id === "edit.replace" ? replaceShortcut(mac) : STANDARD_SHORTCUT_IDS[id] ? UNIVERSAL_SHORTCUTS[STANDARD_SHORTCUT_IDS[id]] : undefined;
    if (expected && normalizeKey(expected, mac) !== shown) problems.push(`${id} uses ${shown}; its standard key is ${normalizeKey(expected, mac)}.`);
    if (owner === "app" && standard && standard !== own) problems.push(`${id} uses ${shown}, the shell's key for ${standard}.`);
    if (owner === "app" && !standard && shortcutTier(key, mac) === "universal") problems.push(`${id} uses ${shown}; an application command takes ${mac ? "Shift+Cmd or Option+Cmd" : "Ctrl+Shift"} and a letter.`);
    if (modifiers.length === 1 && modifiers[0] === "Shift") problems.push(`${id} uses ${shown}, which types a capital letter.`);
    if (mac && modifiers.length === 1 && modifiers[0] === "Alt") problems.push(`${id} uses ${shown}, which types a character on macOS.`);
    if (!mac && modifiers.includes("Ctrl") && modifiers.includes("Alt")) problems.push(`${id} uses ${shown}; Ctrl+Alt is AltGr on Windows and types characters on many keyboards.`);
    if (!mac && modifiers.length === 1 && modifiers[0] === "Alt") problems.push(`${id} uses ${shown}, which opens a menu on Windows.`);
    if (!mac && modifiers.length === 2 && modifiers.includes("Alt") && modifiers.includes("Shift")) problems.push(`${id} uses ${shown}, which switches the keyboard language on Windows.`);
  }
  return problems;
}
