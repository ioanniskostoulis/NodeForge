// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Exporting from the page, the same in every application: one file goes through the export dialog, several go into a
// folder, and a taken name is asked about (Replace, Keep both or Cancel), written under a free name, or replaced after
// a confirmation, as the application's overwrite choice says. The browser preview downloads the files instead.
import { askToChoose } from "./dialogs";
import { conflictList, conflictTitle, exportFileName, fileNameOf, formatOf, listFormats, planExport, resolveAsk, type ExportFormat, type OverwriteChoice, type PlannedWrite } from "./export-plan";

/** What the export needs of the desktop bridge (`ForgeDesktopBridge` has it). */
export interface ExportBridge {
  exportDialog(suggestedName: string, formatIds?: readonly string[]): Promise<string | null>;
  exportFolder(title?: string): Promise<{ folder: string; names: string[] } | null>;
  exportFolderNames(path: string): Promise<string[]>;
  writeExport(path: string, bytes: Uint8Array, originals?: readonly string[], replace?: boolean): Promise<void>;
}

/** One file to export: its name (the extension is made the format's) and its bytes, made only once it is written. */
export interface ExportItem { name: string; format: ExportFormat; bytes(): Promise<Uint8Array> | Uint8Array }

export interface ExportHost {
  /** The desktop bridge, or null in the browser preview, which downloads the files. */
  bridge: ExportBridge | null;
  /** The application's export formats. */
  formats: readonly ExportFormat[];
  /** What happens when a name is taken in the chosen folder. */
  overwrite: OverwriteChoice;
  /** The originals the open document reads: never written. */
  protectedPaths(): readonly string[];
  /** The folder dialog's title for several files: `Export images to a folder`. */
  folderTitle?: string;
  /** The browser preview's download of one file; an `<a download>` click when not given. */
  download?(name: string, bytes: Uint8Array, mime: string): void;
}

/** The outcome: the paths written (names in the browser preview), or null when the person cancelled. */
export type ExportResult = { written: string[] } | null;

/** The Replace, Keep both or Cancel question for taken names; Keep both is the primary answer. */
export function askReplace(conflicts: readonly string[]): Promise<"replace" | "keep-both" | "cancel"> {
  return askToChoose({
    title: conflictTitle(conflicts),
    detail: `Replace ${conflictList(conflicts)}, or keep both by writing the new ${conflicts.length === 1 ? "file under a new name" : "files under new names"}. Originals are never replaced.`,
    buttons: [{ id: "replace", label: "Replace", role: "destructive" }, { id: "keep-both", label: "Keep both", role: "primary" }, { id: "cancel", label: "Cancel", role: "cancel" }],
  });
}

/** The confirmation of an export set to replace taken names. */
export function confirmReplace(conflicts: readonly string[]): Promise<"replace" | "cancel"> {
  return askToChoose({
    title: conflictTitle(conflicts),
    detail: `Replace ${conflictList(conflicts)}? Originals are never replaced.`,
    buttons: [{ id: "replace", label: "Replace", role: "destructive" }, { id: "cancel", label: "Cancel", role: "cancel" }],
    focus: "cancel",
  });
}

/** Export `items`: one through the export dialog, several into a folder. Throws a sentence when a write fails. */
export async function exportFiles(host: ExportHost, items: readonly ExportItem[]): Promise<ExportResult> {
  if (!items.length) return { written: [] };
  const names = items.map((item) => exportFileName(item.name, item.format));
  if (!host.bridge) {
    const download = host.download ?? browserDownload;
    for (const [index, item] of items.entries()) download(names[index], await item.bytes(), item.format.mime);
    return { written: names };
  }
  const bridge = host.bridge;
  const originals = host.protectedPaths();
  if (items.length === 1) {
    const ids = host.formats.map((format) => format.id);
    // The format of the item first, so the dialog opens on it.
    const path = await bridge.exportDialog(names[0], [items[0].format.id, ...ids.filter((id) => id !== items[0].format.id)]);
    if (!path) return null;
    if (!formatOf(path, host.formats)) throw new Error(`Exports are written as ${listFormats(host.formats)} files only.`);
    // The dialog asked before replacing a file, so its path is written as chosen.
    await bridge.writeExport(path, await items[0].bytes(), originals, true);
    return { written: [path] };
  }
  const chosen = await bridge.exportFolder(host.folderTitle);
  if (!chosen) return null;
  const writes = await decide(names, chosen.names, host.overwrite);
  if (!writes) return null;
  const written: string[] = [];
  for (const [index, item] of items.entries()) {
    const path = joinPath(chosen.folder, writes[index].name);
    await bridge.writeExport(path, await item.bytes(), originals, writes[index].replaces);
    written.push(path);
  }
  return { written };
}

/** The writes for `names` in a folder holding `existing`, after asking or confirming as `choice` says; null when cancelled. */
export async function decide(names: readonly string[], existing: readonly string[], choice: OverwriteChoice): Promise<PlannedWrite[] | null> {
  const plan = planExport(names, existing, choice);
  if (plan.ask) {
    const answer = await askReplace(plan.conflicts);
    return answer === "cancel" ? null : resolveAsk(names, existing, answer);
  }
  if (plan.confirm && (await confirmReplace(plan.conflicts)) === "cancel") return null;
  return plan.writes;
}

/** A folder and a name, with the folder's own kind of slash. */
export function joinPath(folder: string, name: string): string {
  const slash = folder.includes("\\") && !folder.includes("/") ? "\\" : "/";
  return folder.endsWith(slash) ? `${folder}${fileNameOf(name)}` : `${folder}${slash}${fileNameOf(name)}`;
}

function browserDownload(name: string, bytes: Uint8Array, mime: string): void {
  const url = URL.createObjectURL(new Blob([bytes as BlobPart], { type: mime }));
  const link = Object.assign(document.createElement("a"), { href: url, download: name });
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
