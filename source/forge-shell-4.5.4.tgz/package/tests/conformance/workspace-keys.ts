import assert from "node:assert/strict";
import { test } from "node:test";
import { DOUBLE_SPACE_MS, installWorkspaceKeys } from "../../source/app/workspace-keys.js";

test("workspace keys route shell shortcuts and leave canvas navigation to app callbacks", () => {
  const previousDocument = globalThis.document;
  const previousElement = globalThis.Element;
  const previousHTMLElement = globalThis.HTMLElement;
  const listeners = new Map<string, (event: KeyboardEvent) => void>();
  globalThis.document = {
    addEventListener: (name: string, listener: (event: KeyboardEvent) => void) => { listeners.set(name, listener); },
    removeEventListener: (name: string) => { listeners.delete(name); },
  } as unknown as Document;
  globalThis.Element = class {} as typeof Element;
  globalThis.HTMLElement = class {} as typeof HTMLElement;
  try {
    const events: string[] = [];
    let hasDocuments = true;
    const dispose = installWorkspaceKeys({
      desktop: false, hasDocuments: () => hasDocuments, typingInField: () => false,
      shortcuts: () => [], run: (id) => { events.push(id); },
      escape: () => { events.push("escape"); },
      domainKeyDown: (event) => {
        if (event.key === " " && !event.repeat) events.push("space down");
        if (event.key === "ArrowLeft") events.push(`ArrowLeft ${event.shiftKey ? 4 : 1}`);
        if (event.key === "r") events.push("tool:Resistor");
        return [" ", "ArrowLeft", "r"].includes(event.key);
      },
      domainKeyUp: (event) => { if (event.key === " ") events.push("space up"); },
    });
    const send = (name: string, key: string, extras: Record<string, unknown> = {}) => {
      let prevented = false;
      listeners.get(name)!({ key, target: {}, metaKey: false, ctrlKey: false, altKey: false, shiftKey: false,
        repeat: false, preventDefault: () => { prevented = true; }, ...extras } as KeyboardEvent);
      return prevented;
    };
    assert.equal(send("keydown", " "), true);
    assert.equal(send("keydown", " ", { repeat: true }), true);
    send("keyup", " ");
    assert.equal(send("keydown", "ArrowLeft", { shiftKey: true }), true);
    assert.equal(send("keydown", "r"), true);
    assert.equal(send("keydown", "Backspace"), false);
    send("keydown", "Escape");
    hasDocuments = false;
    assert.equal(send("keydown", "r"), false);
    assert.deepEqual(events, ["space down", "space up", "ArrowLeft 4", "tool:Resistor", "escape"]);
    dispose();
    assert.equal(listeners.size, 0);
  } finally {
    globalThis.document = previousDocument;
    globalThis.Element = previousElement;
    globalThis.HTMLElement = previousHTMLElement;
  }
});

test("Space tapped twice on the work surface fits the view, but not on a control or with a key held", () => {
  const previous = { document: globalThis.document, Element: globalThis.Element, HTMLElement: globalThis.HTMLElement, now: performance.now };
  const listeners = new Map<string, (event: KeyboardEvent) => void>();
  globalThis.document = { addEventListener: (name: string, listener: (event: KeyboardEvent) => void) => { listeners.set(name, listener); }, removeEventListener: () => {} } as unknown as Document;
  class FakeElement { constructor(readonly control: boolean) {} closest() { return this.control ? this : null; } }
  globalThis.Element = FakeElement as unknown as typeof Element;
  globalThis.HTMLElement = class {} as typeof HTMLElement;
  let clock = 1000;
  performance.now = () => clock;
  try {
    const events: string[] = [];
    installWorkspaceKeys({ desktop: true, hasDocuments: () => true, typingInField: () => false, shortcuts: () => [],
      run: (id) => { events.push(id); }, escape: () => {}, domainKeyDown: (event) => { if (event.key === " ") events.push("space"); return event.key === " "; } });
    const tap = (after: number, extras: Record<string, unknown> = {}) => {
      clock += after;
      listeners.get("keydown")!({ key: " ", target: new FakeElement(false), metaKey: false, ctrlKey: false, altKey: false, shiftKey: false, repeat: false, preventDefault: () => {}, ...extras } as unknown as KeyboardEvent);
    };
    tap(0); tap(200);
    assert.deepEqual(events, ["space", "space", "view.fit"], "two taps 200 ms apart fit, and the app still sees each tap");
    events.length = 0;
    tap(1000); tap(200); tap(200);
    assert.deepEqual(events.filter((e) => e === "view.fit"), ["view.fit"], "three taps are one fit, not two");
    events.length = 0;
    tap(1000); tap(DOUBLE_SPACE_MS + 50);
    tap(1000); tap(100, { repeat: true });
    tap(1000); tap(100, { shiftKey: true });
    tap(1000, { target: new FakeElement(true) }); tap(100, { target: new FakeElement(true) });
    assert.ok(!events.includes("view.fit"), "slow taps, a held key, Shift and a focused control do not fit");
  } finally {
    globalThis.document = previous.document; globalThis.Element = previous.Element; globalThis.HTMLElement = previous.HTMLElement; performance.now = previous.now;
  }
});
