// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The rules of exporting, decided before anything touches the disk, the same in the page and in the desktop process:
// the project file is always `.<letter>fg` and only Save writes it; an export may be any of the application's formats,
// is written only where the person chose, never replaces a file by surprise, and never writes a protected file (an
// original the document reads, such as an image or a data file).

/** A format an application exports: `{ id: "png", name: "PNG image", extensions: ["png"], mime: "image/png" }`. */
export interface ExportFormat { id: string; name: string; extensions: readonly string[]; mime: string }

/** What happens when an exported name is taken: ask (Replace, Keep both or Cancel), write a free name, or replace after a confirmation. */
export type OverwriteChoice = "ask" | "new-name" | "overwrite";
export const OVERWRITE_CHOICES: readonly OverwriteChoice[] = ["ask", "new-name", "overwrite"];
export const OVERWRITE_LABELS: Record<OverwriteChoice, string> = { ask: "Ask", "new-name": "New name", overwrite: "Replace" };

/** A project file's extension: one letter and `fg` (`nfg`, `lfg`, `pfg`). */
export const PROJECT_EXTENSION = /^[a-z]fg$/;

/** The lowercase extension of a file name or path, or "". */
export const extensionOf = (path: string): string => /\.([a-z0-9]+)$/i.exec(path)?.[1].toLowerCase() ?? "";
/** The last part of a path, with either slash. */
export const fileNameOf = (path: string): string => path.replace(/[\\/]+$/, "").split(/[\\/]/).pop() ?? path;

/** The format a file name has, by its extension. */
export function formatOf(path: string, formats: readonly ExportFormat[]): ExportFormat | undefined {
  const extension = extensionOf(path);
  return formats.find((format) => format.extensions.includes(extension));
}

/** A file name to export `name` as: characters folders refuse become hyphens, and the format's first extension. */
export function exportFileName(name: string, format: ExportFormat): string {
  const stem = name.replace(/\.[a-z0-9]+$/i, "");
  const clean = stem.replace(/[\\/:*?"<>|]/g, "-").replace(/^\.+/, "").trim() || "export";
  return `${clean}.${format.extensions[0]}`;
}

/**
 * "Keep both": the name itself while it is free, otherwise `name-1.png`, `name-2.png` and so on, the first that is
 * neither in the folder nor already chosen. Names are compared without regard to case, as macOS and Windows do.
 */
export function freeName(wanted: string, taken: Iterable<string>): string {
  const used = new Set([...taken].map((name) => name.toLowerCase()));
  if (!used.has(wanted.toLowerCase())) return wanted;
  const dot = wanted.lastIndexOf(".");
  const stem = dot > 0 ? wanted.slice(0, dot) : wanted, extension = dot > 0 ? wanted.slice(dot) : "";
  for (let n = 1; ; n++) if (!used.has(`${stem}-${n}${extension}`.toLowerCase())) return `${stem}-${n}${extension}`;
}

/** A planned write: the file name, and whether it replaces a file that is there. */
export interface PlannedWrite { name: string; replaces: boolean }

/**
 * The writes of an export of `wanted` names into a folder holding `existing`:
 * - new-name: each taken name becomes a free one, nothing is replaced;
 * - overwrite: taken names are replaced, after a confirmation (`confirm`);
 * - ask: when a name is taken, the person chooses (`ask`), with `resolveAsk`.
 * `conflicts` are the taken names.
 */
export function planExport(wanted: readonly string[], existing: Iterable<string>, choice: OverwriteChoice): { writes: PlannedWrite[]; confirm: boolean; ask: boolean; conflicts: string[] } {
  const taken = new Set([...existing].map((name) => name.toLowerCase()));
  const conflicts = wanted.filter((name) => taken.has(name.toLowerCase()));
  const freshNames = () => {
    const used = [...existing];
    return wanted.map((name) => { const free = freeName(name, used); used.push(free); return { name: free, replaces: false }; });
  };
  if (choice === "new-name" || !conflicts.length) return { writes: freshNames(), confirm: false, ask: false, conflicts };
  const replacing = wanted.map((name) => ({ name, replaces: taken.has(name.toLowerCase()) }));
  return { writes: replacing, confirm: choice === "overwrite", ask: choice === "ask", conflicts };
}

/** The writes once the person answered Replace or Keep both. */
export function resolveAsk(wanted: readonly string[], existing: Iterable<string>, answer: "replace" | "keep-both"): PlannedWrite[] {
  return planExport(wanted, existing, answer === "replace" ? "overwrite" : "new-name").writes;
}

/** Paths compared the way the file system does: one kind of slash, no trailing slash, case folded where it is ignored. */
export const comparablePath = (path: string, ignoreCase: boolean): string => {
  const plain = path.replace(/\\/g, "/").replace(/\/+$/, "");
  return ignoreCase ? plain.toLowerCase() : plain;
};

/**
 * Why an export may not be written to `path`, or null when it may: it must have one of the formats, it is never a
 * project file (only Save writes those), and never one of the protected files. `ignoreCase` is true on macOS and Windows.
 */
export function exportProblem(path: string, rules: { formats: readonly ExportFormat[]; protectedPaths: readonly string[]; ignoreCase: boolean }): string | null {
  const name = fileNameOf(path);
  if (PROJECT_EXTENSION.test(extensionOf(path))) return `${name} is a project file; projects are written by Save, not by an export.`;
  if (!formatOf(path, rules.formats)) return `Exports are written as ${listFormats(rules.formats)} files only.`;
  const target = comparablePath(path, rules.ignoreCase);
  if (rules.protectedPaths.some((original) => comparablePath(original, rules.ignoreCase) === target)) return `${name} is an original of the document; originals are never written.`;
  return null;
}

/** "PNG, JPEG or CSV": the formats' first words, joined as a sentence lists them. */
export function listFormats(formats: readonly ExportFormat[]): string {
  const names = [...new Set(formats.map((format) => format.name.split(" ")[0]))];
  return names.length <= 1 ? names.join("") : `${names.slice(0, -1).join(", ")} or ${names.at(-1)}`;
}

/** The sentence of the Replace, Keep both or Cancel question: `photo.png already exists.` or `3 files already exist.` */
export function conflictTitle(conflicts: readonly string[]): string {
  return conflicts.length === 1 ? `${conflicts[0]} already exists.` : `${conflicts.length} files already exist.`;
}

/** The names of a conflict, five at most: `a.png, b.png and 4 more`. */
export function conflictList(conflicts: readonly string[]): string {
  const shown = conflicts.slice(0, 5).join(", ");
  return conflicts.length > 5 ? `${shown} and ${conflicts.length - 5} more` : shown;
}
