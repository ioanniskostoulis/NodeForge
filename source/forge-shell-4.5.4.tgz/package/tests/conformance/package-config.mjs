import assert from "node:assert/strict";
import test from "node:test";
import { electronBuilderConfig } from "../../scripts/package-config.mjs";

test("desktop packaging supports a project with internal file tabs and its own document icon", () => {
  const result = electronBuilderConfig({
    identity: { id: "testforge", name: "TestForge" },
    document: { noun: "report project", plural: "report projects", extension: "tfg", containsMultipleFiles: true,
      tabs: { noun: "file", newTitle: "New file", closeTitle: "Close file" } },
    desktop: { appId: "com.testforge.app", copyright: "TestForge GPL", macCategory: "public.app-category.education",
      extraResources: [{ from: "build/tool.cjs", to: "bin/tool.cjs" }],
      document: { name: "TestForge Document", description: "TestForge document", iconStem: "tfg", iconSource: "assets/icon.png", iconInk: "#e06048", iconLabel: "TFG",
        typeIdentifier: "com.testforge.document", conformsTo: ["public.zip-archive"], mimeType: "application/x-testforge" } },
  });
  assert.equal(result.productName, "TestForge");
  assert.equal(result.win.artifactName, "TestForge-v${version}.${ext}");
  assert.equal(result.mac.artifactName, "TestForge-v${version}.${ext}");
  assert.deepEqual(result.fileAssociations, [{ ext: "tfg", name: "TestForge Document", description: "TestForge document", icon: "tfg", role: "Editor" }]);
  assert.deepEqual(result.mac.extendInfo.UTExportedTypeDeclarations[0].UTTypeTagSpecification["public.filename-extension"], ["tfg"]);
  assert.deepEqual(result.extraResources[0], { from: "build/tool.cjs", to: "bin/tool.cjs" });
  assert.equal(electronBuilderConfig({ identity: { id: "plain", name: "Plain" }, document: null,
    desktop: { appId: "com.plain.app", copyright: "Plain GPL" } }).fileAssociations, undefined);
  assert.throws(() => electronBuilderConfig({ identity: { id: "broken", name: "Broken" }, document: { extension: "bad" },
    desktop: { appId: "com.broken.app", copyright: "Broken GPL" } }), /native file association/);
});

import { artifactName, artifactPattern } from "../../scripts/artifact-name.mjs";

test("release files are named <Name>-v<version>.<ext>", () => {
  assert.equal(artifactName("Example", "1.2.3", "dmg"), "Example-v1.2.3.dmg");
  assert.equal(artifactName("Example", "1.2.3", "exe"), "Example-v1.2.3.exe");
  assert.equal(artifactPattern("Example"), "Example-v${version}.${ext}");
});

import { DMG_BACKGROUND, DMG_HIDDEN, DMG_HIDDEN_ROW, DMG_ICON_SIZE, DMG_VISIBLE, DMG_VOLUME_ICON, DMG_WINDOW, dmgBackgroundSvg, dmgContents } from "../../scripts/dmg-background.mjs";

test("the disk image window centres the app and Applications and moves its hidden files out of view", () => {
  const dmg = electronBuilderConfig({ identity: { id: "plain", name: "Plain" }, document: null, desktop: { appId: "com.plain.app", copyright: "Plain GPL" } }).dmg;
  assert.equal(dmg.background, DMG_BACKGROUND);
  assert.equal(dmg.icon, DMG_VOLUME_ICON);
  assert.equal(dmg.iconSize, DMG_ICON_SIZE);
  const [app, link, ...hidden] = dmg.contents;
  assert.deepEqual(app, { x: 150, y: 184, type: "file", name: "Plain.app" });
  assert.deepEqual(link, { x: 450, y: 184, type: "link", path: "/Applications" });
  // symmetric about the centre of the 600 pt window
  assert.equal((app.x + link.x) / 2, DMG_WINDOW.width / 2);
  // Finder lists these when hidden files are shown; the same files are listed under their names, 200 pt below the bottom edge.
  assert.deepEqual(hidden.map((item) => [item.name, item.path]), [[".background.tiff", DMG_BACKGROUND], [".VolumeIcon.icns", DMG_VOLUME_ICON]]);
  assert.deepEqual(Object.keys(DMG_HIDDEN), [".background.tiff", ".VolumeIcon.icns"]);
  for (const item of hidden) {
    assert.equal(item.type, "file");
    assert.ok(item.y === DMG_HIDDEN_ROW && item.y > DMG_WINDOW.height + DMG_ICON_SIZE, `${item.path} is out of view`);
  }
  assert.deepEqual(dmgContents("Plain"), dmg.contents);
});

test("the disk image background carries the wordmark and arrow in the light accent and the install note", () => {
  const svg = dmgBackgroundSvg({ name: "A&B", accent: "#3c56aa", wordmark: " _\n|_|  \n" });
  assert.ok(svg.startsWith(`<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400"`));
  assert.match(svg, /<g font-family='[^']*monospace' font-size="10.00" fill="#3c56aa">/, "a short wordmark stays at 10 pt");
  assert.ok(svg.includes('xml:space="preserve"> _</text>') && svg.includes('xml:space="preserve">|_|</text>'), "trailing spaces are trimmed, leading ones kept");
  assert.ok(svg.includes('<g fill="none" stroke="#3c56aa"'));
  // The arrow runs from 26 pt right of the app icon to 26 pt left of Applications: 150 + 48 + 26 = 224, 450 - 48 - 26 = 376.
  assert.ok(svg.includes('<line x1="224" y1="184" x2="376" y2="184"/>'));
  assert.ok(svg.includes("Drag A&amp;B to Applications to install it."));
  // Nothing is drawn below what a Finder window with its path and status bars shows: 400 - 32 - 52 = 316 pt.
  const lowest = Math.max(...[...svg.matchAll(/ y2?="([\d.]+)"/g)].map((match) => Number(match[1])));
  assert.ok(lowest <= DMG_VISIBLE, `lowest drawing at ${lowest} pt`);
  // Finder draws the label about 30 pt below a 96 pt icon: 184 + 48 + 30 = 262 pt, above the 12 pt text at 290 pt.
  assert.ok(184 + DMG_ICON_SIZE / 2 + 30 < 290 - 12, "the install text clears the icon labels");
  // A wide wordmark shrinks to 500 pt: 100 columns × 0.6 em = 500 pt at 8.33 pt.
  assert.match(dmgBackgroundSvg({ name: "Wide", accent: "#000000", wordmark: "x".repeat(100) }), /font-size="8.33"/);
});
