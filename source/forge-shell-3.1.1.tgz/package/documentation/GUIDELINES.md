# Forge application guidelines

## Scope

Sections 1 to 12 form the interface contract that every Forge application follows. Sections 13 and 14 specify behaviour that the first applications had but the contract did not cover, and define the shared `forge-shell` package, which implements the contract once for all applications. Section 15 lists what is removed from code copied from an existing application, section 16 describes how the package is created, section 17 records the notes on this guide, and section 18 gives the checklist for migrating one application.

The contract defines the shell, the visual tokens, motion, writing, commands, lists and feedback. It assigns no application a domain, file format, domain-menu catalogue, tool palette or domain-command catalogue; these belong in a short application profile and in the user and format guides of the application. The measured interface reference of an application is a source-backed example, and [PROJECT-STRUCTURE.md](PROJECT-STRUCTURE.md) covers the repository layout.

**Rule strength.** Every shell, appearance, motion, typography, menu, Terminal, listing and message rule applies to every Forge application. A conditional rule applies only to a domain feature that is genuinely absent, such as a file format or a graph. It does not permit omitting the shared inspector, Terminal, Messages, panel controls, Help destinations. A profile supplies product identity and domain behaviour only and cannot waive a shared rule. An exact replica of an existing application additionally requires the source and visual assets of that application.

## 1. Required application profile

Each Forge application keeps an `INTERFACE.md` in its `documentation/` folder. The fields below are recorded explicitly; `none` is a valid value for an inapplicable feature.

| Field | Required content |
|---|---|
| Identity | Product name and capitalisation, lowercase package and command identifier, one-line purpose, version source, author and credits, application-icon source and packaging paths, ASCII wordmark path and exact text, artwork provenance and asset checksum |
| Documents | Primary noun, file extension and MIME type, document-icon files and file-association metadata, new, open, save, import and export behaviour, existence of document tabs, dirty-state rule, close prompt, and whether a project contains several files |
| Theme | The Dark and Light accent substitutions of the application, semantic domain-data colours, and the ink colours of the application and document icons; all other chrome colours are inherited from section 2 |
| Workspace | Centre views, inspector sections and default folds, bottom tabs and their order, default panel sizes and justified deviations from section 4 |
| Navigation | Pointer, wheel, pinch, pan, zoom, keyboard and drag behaviour of each centre view; `none` for an action without a meaningful equivalent |
| Actions | Ordered menus; the identifier, label, shortcut, enabled and checked condition of every action; toolbar groups, tooltips and command aliases |
| Terminal | The command registry with syntax, examples, completions, application-level and document-level scope, cancellation and output type |
| Messages | Application-specific success, warning and error examples, object links, standing-condition keys and persistence |
| Persistence | The values held in application preferences, in the document, or only in the current session |
| Verification | The screens and views to inspect, keyboard paths, document round trips, and platform build and launch checks |
| Build and runtime profiles | `forge.config.json` (identity, document or `null`, theme, HTML slots, desktop metadata) and the runtime menu, command, inspector and pane catalogues |

The profile is the exact application-specific contract. Scopes, document archives, circuit palettes, graph views and other domain features belong in the profile of the application and not in this family-wide document.

## 2. Colours and logo

### Shared neutral tokens

This section is the source of the Forge palette. The CSS variable names and values below are used unchanged in every application. Dark and Light are the shared appearances. Light is selected by `data-theme="light"`, and Dark is the default. The Dark and Light accent hues follow the identity of the application. Warning, error, text, window, panel, button and separator colours are identical in every application. A domain visualisation may define semantic data colours, which do not replace the shared chrome tokens.

| Token | Dark | Light | Use |
|---|---|---|---|
| `--window` | `#1e1e1e` | `#e2e2e2` | Outer window and tab-row background. |
| `--panel` | `#282828` | `#e8e8e8` | Inspector and dialogs. |
| `--raised` | `#303030` | `#dedede` | Tool strip, tab bar and status bar. |
| `--control` | `#3a3a3a` | `#d2d2d2` | Ordinary buttons and hovered menu title. |
| `--control-hover` | `#464646` | `#c6c6c6` | Hovered ordinary control. |
| `--well` | `#1b1b1b` | `#f8f8f7` | Input, Terminal and Messages surface. |
| `--separator` | `#111111` | `#c2c2c2` | One-pixel structural borders. |
| `--hairline` | `rgba(255,255,255,0.06)` | `rgba(0,0,0,0.1)` | Quiet separators. |
| `--empty-sheet` | `#131313` | `#f8f8f7` | Welcome surface, and any canvas that draws the same sheet. |
| `--empty-grid-dot` | `rgba(255,255,255,0.08)` | `rgba(0,0,0,0.10)` | Dots of the welcome grid, 16 px apart. |
| `--empty-grid-line` | `rgba(255,255,255,0.04)` | `rgba(0,0,0,0.05)` | Lines of the welcome grid, 128 px apart. |
| `--text` | `#dadada` | `#222222` | Main text and values. |
| `--text-strong` | `#ffffff` | `#000000` | Emphasis and section-heading hover. |
| `--text2` | `#9c9c9c` | `#555555` | Labels and explanations. |
| `--text3` | `#666666` | `#6a6a6a` | Disabled or quiet text. |
| `--warning` | `#e0a040` | `#9a6000` | Warning word and unseen-problem count. |
| `--pick` | `#2fd3e6` | `#007a99` | Content selection: selected and hovered parts, points and handles on a canvas, selection boxes. Never the interface's own selection, which is the accent. |
| `--error` | `#e5534b` | `#ae3540` | Error word, invalid-input border and field errors; accompanied by an explicit `Error` label. |

### Type, shape and motion tokens

These tokens are identical in every theme and every application. Components use them in place of literals, and the derived sizes follow `--size`.

| Token | Value | Use |
|---|---|---|
| `--size` | `12px` | Base chrome text. |
| `--size-sm` | `calc(var(--size) - 1px)` | Status text, hints and small readouts. |
| `--size-xs` | `calc(var(--size) - 2px)` | Tab and section titles. |
| `--size-lg` | `calc(var(--size) + 1px)` | Popup and dialog titles. |
| `--size-xl` | `calc(var(--size) + 3px)` | Empty-state title. |
| `--weight-strong` | `600` | Names, titles and section headings. |
| `--weight-bold` | `700` | Terminal banner, bold mono text. |
| `--radius-xs` | `2px` | Slider tracks and thumbs. |
| `--radius-sm` | `3px` | Small markers and inline editors. |
| `--radius` | `4px` | Buttons, inputs and rows. |
| `--control-height` | `26px` | Standard control; the small control is this value minus 2 px. |
| `--gap` | `6px` | Space between related controls. |
| `--pad` | `8px` | Standard inner padding. |
| `--duration` | `0.15s` | Standard transition time. |
| `--ease` | `cubic-bezier(0.2, 0, 0, 1)` | Standard transition curve. |

### Accent substitution only

The blue palette below is the mother palette. Each application substitutes its own hue for the five accent tokens only, and keeps their meanings and the contrast relationship between Dark and Light. `--accent-foreground` is white in every application. No application defines a second neutral palette, and a brand hue does not recolour `--window`, `--panel`, `--raised`, `--control`, `--control-hover`, `--well`, `--separator`, `--hairline`, `--text*`, `--warning` or the error red.

| Accent token | Example Dark baseline | Example Light baseline | Shared role |
|---|---|---|---|
| `--accent` | `#7b90df` | `#3c56aa` | Terminal prompt, list numbers and active state. |
| `--accent-light` | `#7b90df` | `#3c56aa` | Active lines, focus, links and transient status. |
| `--accent-about` | `#899de6` | `#3c56aa` | About wordmark and links. |
| `--accent-fill` | `#3c56aa` | `#3c56aa` | Primary buttons and selected tools. |
| `--accent-hover` | `#344c98` | `#344c98` | Hovered primary buttons and selected tools. |
| `--accent-foreground` | `#ffffff` | `#ffffff` | Text and icons on an accent fill; fixed family colour. |

**Calmer Light accents.** Light is the quiet appearance, so its accents default to the deeper fill colour instead of the bright Dark accent. An application specifies only its Dark `accent`, `accentFill` and `accentHover` in `forge.config.json`, and `forge-shell` supplies the remaining values.

| Omitted value | Default |
|---|---|
| Dark `accentLight`, `accentAbout` | The Dark `accent` |
| Light `accent`, `accentLight`, `accentAbout`, `accentFill` | The Dark `accentFill` |
| Light `accentHover` | The Dark `accentHover` |

Any Light value may still be specified to override its default, and the others remain derived. The contrast checks of 4.5:1 apply to the final values, so a fill that is too light for Light is rejected with the value named.

The application records its Dark accents and any Light overrides in `documentation/INTERFACE.md` and tests their legibility against the shared white foreground and the neutral backgrounds. The initial of the application and the initial and extension of the document icon use the approved brand ink recorded there. Warning amber and error red keep their shared values and meanings in every application. Any further appearance requires its own profile contract.

### Application and document icons

The Forge icon family has a single design, with the initial, extension and accent of each application. Approved source artwork that already follows the design is preserved exactly and is not redrawn.

| Asset | Family construction | Per-application substitution |
|---|---|---|
| Application icon | `assets/icon.png`, 1024 × 1024 RGBA, transparent outside one large serif capital taken from the GFS Artemisia letterform of the application. It has no tile, circle, paper background, shadow, word or border. The visible capital is 700 px high (y = 162 to y = 862), centred optically on x = 512, with a width that follows the approved glyph and the proportions and optical alignment of the original letter. | The first capital of the product name, in the approved icon colour. Example: `N` in `#7188e9`. The glyph outline comes from the approved master asset and not from a CSS approximation. |
| Native document icon | A separate 1024 × 1024 transparent artwork: a white portrait page with a folded upper-right corner, a thin cool-grey outline and a soft shadow. The capital of the application is placed prominently on the page, with the uppercase extension without the dot below it, both in the document-icon colour. The bare application icon is not reused for a document association. | Initial, extension text and document-icon colour. Example: `N`, `NFG`, `#7288e8`. An extension longer than three letters requires a fit rule in the profile that keeps the label within the page. |

The canonical geometry of the document icon, at 1024 px, is given below.

| Element | Value |
|---|---|
| Page vertices | `(170,70)`, `(644,70)`, `(854,280)`, `(854,954)`, `(170,954)` |
| Fold | 210 px; fill `#e4e8f4` |
| Page and outline | White `#ffffff` page; 4 px `#cdd2de` outline |
| Shadow | Black at y + 14, alpha 90/255, Gaussian blur radius 18 px |
| Initial | Cropped to its non-transparent bounds, resized to 380 px high with unchanged aspect ratio, centred on x = 512 at y = 330, tinted with the document-icon colour |
| Extension label | Centred at y = 760, bold Arial (Helvetica as fallback), 118 px for three characters |
| Canvas | Transparent outside the page and shadow |

The generator of an application may reside in its `scripts/` folder, and a future application may implement the same geometry in another build tool while retaining the output contract.

The source artwork and the generated `.png`, `.icns` and `.ico` document versions are kept in `assets/icon/`, named for the lowercase extension (`nfg.png`, `nfg.icns`, `nfg.ico`). The application icon master remains at `assets/icon.png` and serves as the application and installer icon and as the browser favicon. The document-icon stem is registered in Electron `fileAssociations` with the extension, a human-readable name and description, and the editor or viewer role; the MIME type is recorded where applicable. The packaged application icon and the icon of a saved file are verified at 16, 32 and 256 px in Finder and Explorer, since a generated source PNG does not prove registration. An application without a native document format records `none` and has no document icon.

The profile records the path and checksum of the approved capital asset, the accent and document-icon ink colours, the extension label, the generated paths and the build command. The provenance of fonts and artwork and the licence wording are kept in `NOTICE.md`. GFS Artemisia is not bundled merely to render an exported PNG. The folded-page document icon remains the family standard even when an application icon is supplied.

### ASCII wordmark

Each application provides a plain-text wordmark at `assets/logo.txt`, written by `forge-shell wordmark <Name> --out assets/logo.txt` (`renderWordmark`). The wordmark spells the product name in its exact brand case in the family's lettering, so that the wordmarks of all applications match:

| Part | Rule |
|---|---|
| Lettering | The Roman FIGlet font by Nick Miners (`scripts/fonts/roman.flf`), as patorjk.com's Text to ASCII Art Generator sets it with the Roman font |
| The family's g | The font's g without the row `` `8oooooo. `` between the bowl and the tail, so its tail sits one line higher |
| Spacing | Neighbouring letters sit exactly one blank column apart where they come closest (`LETTER_GAP`); no line ends in blanks, and there are no blank rows above or below |

The tests `a wordmark is the name in the Roman lettering, with no trailing blanks and no blank rows above or below`, `the family's g is the font's g one line shorter: no row between the bowl and the tail` and `neighbouring letters sit exactly one blank column apart where they come closest` enforce the rules. The glyphs, line count and width therefore depend only on the name. The asset stores literal printable characters and spaces with line breaks and is not a runtime-generated font. Leading spaces and interior alignment are preserved, and only trailing whitespace at the end of the complete asset is trimmed on rendering. The case is not transformed, spaces are not collapsed, lines are not wrapped and no theme substitutes another font. When the asset cannot be loaded, the product name is shown as plain text. The profile records the asset path, the source font or generator, the edits, the author and licence, and a checksum, so that a later rebuild reproduces the same art.

The same wordmark appears in the Terminal banner and in all four information-dialog headers.

| Property | Terminal banner | Information dialog |
|---|---|---|
| Element | Preformatted `<pre>` with zero margin and letter spacing | The same |
| Weight and size | 700, at the saved Terminal size (default 12 px, range 10 to 24 px), line height 1.15 | Fixed 700 12 px/1.15, mono |
| Colour | `--accent` | `--accent-about` |
| Overflow | Horizontally scrollable, never wrapped | The same |

Immediately below the wordmark, the one-line purpose is followed by exactly three spaces and `v<VERSION>` in bold mono; the purpose uses `--text` and the version `--text2`. The information dialog adds a lowercase subtitle such as `about` or `licenses` in bold 12 px/1.4 mono `--text2`. The decorative ASCII art is `aria-hidden="true"`, with a separate accessible product name. The large wordmark does not appear in ordinary editing views. The provenance and licence wording of the asset are kept in `NOTICE.md`.

## 3. Typeface, case and text colour

The interface uses the system UI stack `-apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif` and the mono stack `ui-monospace, "SF Mono", SFMono-Regular, Menlo, "Cascadia Mono", Consolas, monospace`. The base chrome is set in the 12 px UI font. Terminal, Messages and technical readouts use the mono stack; labels, prose and menu text use the UI stack.

| Text role | Case rule | Size and weight | Colour |
|---|---|---|---|
| Product name | Brand case from the profile: `ExampleForge` | Context dependent | `--text` in prose; accent for the wordmark |
| Package, storage and command identifier | Lowercase: `exampleforge` | Mono when shown | `--text` |
| Menu heading and Terminal help category | Initial capital, then lowercase where appropriate: `File`, `Edit`, `Project`, `Document`, `Analysis`; never `FILE` or `PROJECT` | Menu base 12 px UI; help category bold 12 px mono | `--text` |
| Menu action, dialog title, inspector property | Sentence case: `Save as…`, `Build PDF`, `Maximum time step`; proper names and technical abbreviations preserved | Popup 13 px UI; field label 12 px UI | `--text` for an action, `--text2` for a property label |
| Bottom-panel tab and inspector section | Displayed in uppercase by CSS (`TERMINAL`, `MESSAGES`, `BUILD`, `PROPERTIES`); labels are stored in normal case | 10 px, weight 600, `0.6px` letter spacing | Active tab `--text`, inactive `--text3`; section title `--text2` |
| Terminal command verb and state | Lowercase: `save`, `help`, `[on]`, `[off]`; literal file names and identifiers keep their case | 12 px mono; the active word is bold | Help verb, prompt, numbered marker and `[on]` use `--accent`; `[off]` uses `--text2` |
| Terminal entered command | As typed by the user; the documented spelling is lowercase | Bold 12 px mono | `--text`; the prompt remains in the accent |
| Terminal explanation, ordinary list detail, table heading | Sentence case; units and identifiers preserved | Normal 12 px mono | `--text2` |
| Numbered item name | The name of the document or object | Bold 12 px mono | `--text`; the number marker in the accent |
| Document-tab title | The case of the file or project name | Normal 12 px UI | Active `--text`, inactive `--text2`, dirty dot in the accent |
| Status state and message | Initial capital for a state (`Running`, `Paused`, `Ready`); sentence case for a result | 11 px mono | Ordinary `--text2`; transient result `--accent-light` |
| Message kind | `Info`, `Warning`, `Error` | 12 px mono | Info `--text2`, Warning `--warning`, Error semantic red |
| Message body | Sentence case with a final period; filenames, commands and technical symbols preserved | 12 px mono | Info and Warning `--text2`, Error `--text`; object link in the accent |
| About heading, prose and link | Sentence-case headings; prose with proper names | Heading bold 12 px UI; prose 12 px/1.45 UI | Heading `--text`, prose `--text2`, link `--accent-about` |

**Text role classes.** `shell.css` implements the table as classes that carry family, size, weight, colour and alignment. Applications use these classes and write no sizes or colours of their own. Canvas and script code imports `FONT_UI`, `FONT_MONO` and `roleFont(family, size, weight)` from the shell and does not copy the stacks.

| Class | Role and alignment |
|---|---|
| `t-label` | Label (left) |
| `t-value` | Value (right, tabular numerals) |
| `t-mono`, `t-quiet`, `t-link`, `t-heading` | Mono text, quiet text, link, heading |
| `t-tab` | Tab (centred, uppercase) |
| `t-section` | Section title (left, uppercase) |
| `t-kind`, `t-kind-info`, `t-kind-warning`, `t-kind-error` | Message kind |
| `t-marker` | List marker (right, tabular numerals) |

**Builders.** `createButton`, `createField`, `createRow`, `createListLine` and `listMarker` build the standard button, labelled field, property row and list line from these classes, so that the markup is not written by hand in applications.

| Control | Text |
|---|---|
| Property text input and textarea | 11.5 px mono |
| Select | 12 px UI |
| Empty Terminal and Messages notes | 12 px/1.4 mono, `--text2` |
| About wordmark | Bold 12 px/1.15 mono, `--accent-about` |
| About numbered list | 12 px/1.45 mono |

Ordinary document text remains selectable where editing or copying is useful, and the selection of chrome text does not interfere with drag actions.

Only the CSS of the pane tabs and of the inspector sections uses `text-transform: uppercase`; Terminal help categories are written as `File`, `Project` and so on, without an uppercase transform, and commands are lowercase. One name designates each concept across menu, toolbar, inspector, Terminal, tooltip and documentation. Units are placed in a separate property unit column and displayed as `4.7 kΩ`, `27 °C`, `300.15 K`, `20%` and `45°`: a space separates number and unit except for the percent sign and the plane angle, and an SI prefix stays attached to the unit. Interface messages use no decorative middle dots, arrows or dashes as separators.

### Text selection

Selected text is highlighted with `--selection`, the accent at 30% opacity, which follows the active appearance; the text colour does not change.

| Case | Rendering |
|---|---|
| Shell-drawn selection | One rounded shape: lines are joined without gaps, every corner (including the inner corners between lines of different length) is rounded with the `--radius` size (4 px), separate blocks form separate shapes, and the shape lies behind the text. `attachSelectionShape(element)` produces it for any selectable text region, and the shell attaches it to Terminal and Messages, so every application receives it by default. |
| Editors | The editor of an application draws its selection identically (same colour, shape and radius), using the shell geometry (`bandsFromRects`, `joinBands`, `roundedPath`) in its own selection layer. |
| Other text (inputs, textareas) | The native highlight in the `--selection` colour, since a form control cannot draw a custom shape. |
| Select all in Terminal | Cmd or Ctrl+A, and Edit › Select all through `TerminalPanel.selectAll()`, select the text after the `>` while the prompt has the focus (nothing when it is empty), and otherwise the whole transcript, also while a command runs; the transcript is drawn as the shell-drawn selection. The `>` before a command is never selected or highlighted. |

## 4. Shared shell and geometry

The desktop shell is ordered as tool strip, document-tab row (for document-based applications), central work surface, inspector, bottom panel, status bar and overlay root. The inspector and the bottom panel, with their visibility controls, belong to every Forge application, even when a document has no editable properties. The desktop menu is native; a browser edition renders the same menu definition in a menu bar of 26 px above the strip. An application without documents has no document tabs and defines its centre context in the profile. Terminal and Messages are the required bottom utilities, and an application-specific domain pane such as Scopes or Figures lies between them.

| Element | Geometry or conditional rule |
|---|---|
| Tool strip | 36 px high; on macOS desktop 42 px with 96 px of left padding for the window buttons and a drag region; in macOS full screen 12 px of left padding |
| Toolbar button | 32 × 26 px, 4 px radius; action icon 16 × 16 px with a 1.25 px stroke; domain icons are sized by the profile |
| Toolbar separator | 1 × 20 px hairline, 6 px side margins (8 px on macOS desktop) |
| Document-tab row (when used) | 30 px high, 6 px left padding, horizontal scroll with a hidden scrollbar |
| Document tab (when used) | Width 90 to 220 px, 12 px left and 6 px right padding, 6 px gap; close control 18 × 18 px; active top accent line 2 px high, flush with the tab face between its borders; dirty dot 6 px |
| Bottom tab row | 26 px high, 12 px horizontal padding per tab, active bottom accent line 2 px |
| Bottom panel | Default and minimum 246 px high, maximum 640 px; a short window shrinks a taller panel to leave 140 px of central workspace, but never below 246 px |
| Inspector | Default and minimum 246 px wide, maximum 420 px, on the right |
| Splitter | 1 px visible, pointer hit area extended by 4 px on each side; a double click restores the recorded default |
| Closing by dragging | The inspector and the bottom panel never become smaller than their default size: a drag below it holds them at that size, and they close when the drag takes them more than 96 px beyond it (`dragOutcome`, `CLOSE_PAST`). The panel hides with the normal 150 ms transition as soon as the pointer passes that point and reappears if the pointer returns before release. Release while closed saves the panel as hidden (the View menu item is unchecked), and the panel reopens at its last size from View, its shortcut or Terminal. A drag back inside the range never changes the saved size beyond its limits. |
| Inspector section | 12 px padding, 10 px gap, 1 px bottom border; the heading is a button with a chevron and keyboard focus |
| Property field | Label and a 108 px value column, 8 px gap, input or closed select 22 px high |
| Panel button | 24 px high, 4 px radius; the foreground and background states are given in section 6 |
| Status bar | 24 px high, 12 px horizontal padding, 14 px gap, 11 px mono text |
| Narrow window | The centre column clips its contents to its own bounds instead of drawing them under the inspector (`#center { overflow: hidden }`). The shared code editor takes its pane's width, never its longest line's, so long lines scroll inside it. Its find bar keeps the search field at least 120 px wide; in an editor narrower than 480 px it spans the editor less 8 px each side, and below 360 px it has two rows, the field and Close above, the options, count and arrows below. A Terminal wordmark wider than the pane scrolls on its own, and the transcript stays in place. The welcome actions wrap and are centred, with 16 px of side padding. The bottom tabs scroll sideways without a visible scrollbar, as the document tabs do, and keep their size (`flex: none`). The mode label of the tool strip is hidden below a window width of 1200 px. |

### Inspector rows, buttons and options

The inspector geometry of the shell applies in every Forge application. At the default inspector width of 246 px a section has 12 px of padding on each side and therefore 222 px of content width. Its contents form a vertical flex column with a gap of 10 px, and sections have a 1 px `--separator` bottom border. The dimensions are unchanged by content, selection, theme or window size, and a field or button is not sized by its label: long labels wrap in the label column while the control keeps its fixed width and height.

| Item | Layout and size | Text, colour and interaction |
|---|---|---|
| Section heading | Full section width including the 12 px side padding; heading button with 12 px padding and a 5 px icon–text gap; chevron 10 × 10 px, 1.4 px stroke, left margin −2 px | 10 px, weight 600, 0.6 px tracking, uppercase by CSS, `--text2`. Hover and focus brighten the title to `--text-strong` and the chevron to `--accent-light` without filling the heading. An expanded chevron points down and a collapsed one points right. |
| Read-only label and value row | Flex row, `justify-content: space-between`, minimum gap 8 px, full content width (`createRow`) | Label 12 px UI `--text2`; value 12 px UI `--text`, right-aligned by layout and truncated with an ellipsis on one line. Used for Name, Time, counts and measured values; the detail of a value (its window, its method) is the row's tooltip and not a second line. Values are never set in a card or tile inside the inspector. |
| Item under the pointer | A section of its own whose lines describe the item under the pointer or selected (`createInfoLines`): the name first in weight-600 11 px UI `--text`, then one value per line in 11 px mono `--text2`, 3 px apart and selectable; with no item, one quiet sentence such as `Hover or click a part.` The section title may name the state (`Part under pointer`, `Selected part`). | The lines follow hover and selection; nothing in them is editable. |
| Editable text and select row | Grid `minmax(0,1fr) 108px`, column gap 8 px, vertically centred; at 246 px the label column is 106 px and the control 108 px | Label 12 px UI `--text2`, wrapping; text input 11.5 px mono; select 12 px UI. The case and units of options are preserved. A select is not widened for a long choice and the control of another row is not shortened. |
| Text input and closed select | Exactly 108 × 22 px in the standard row, `box-sizing: border-box`, 4 px radius, 1 px `--separator` border, 6 px horizontal padding | `--well` fill, `--text` value. Focus uses an `--accent` border and a 1 px ring. The select arrow stays at the right and the selected label stays within the same width. The option menu of the operating system may extend beyond 108 px, but the closed control never grows. |
| Checkbox row | Grid `auto minmax(0,1fr)`, checkbox and label in one row with an 8 px gap. In Dark the checked square is 13 × 13 px, 3 px radius, 1 px `--accent-fill` border and background, with a centred white check of 11 × 11 px | Label 12 px UI `--text2`. An unchecked box uses the platform square; Light uses the native checkbox with the shared accent. Focus remains visible; a disabled box uses `--text3` and does not toggle. |
| Button group | Flex row across the full content width, 6 px gap; every button has `flex: 1` and a height of exactly 24 px, radius 4 px. Two or three buttons share the width equally; a single button fills it. | 12 px UI, weight 500, centred label and icon, 5 px icon–text gap. Ordinary fill `--control` with `--text`; primary fill `--accent-fill` with `--accent-foreground`. Hover, focus and disabled states follow section 6. Built with `createButtonGroup` and `createButton`. The first section of an inspector holds the main actions of the document in one such group. |
| Slider row | Vertical stack with a 5 px gap between readout and track. The readout is a flex row with the label on the left and an 11 px mono value on the right. The slider area is 16 px high; track and fill start 6 px from the top and are 4 px high; the normal thumb is 8 × 14 px, 1 px from the top. | Track `--well`, fill `--accent`, thumb `--text`; when disabled, fill and thumb are `--text3`. The Light thumb is 10 px wide, white, with a 1 px `#929292` border. |

Adjacent field rows share the same right edge and the same 108 px control width. All inspector buttons are 24 px high, including a full-width action such as `Recommend settings…` or `New seed`; ordinary fields and buttons receive no width or height overrides per application, and a multiline textarea occupies its own full-width row. The unit of a row belongs to its displayed or editable value (`25 °C`, `5 µs`, `0.1%`) and not to a second, misaligned label. A choice list uses the domain terms of the application, while its closed control, typography, selection and spacing follow this rule. On the empty screen the inspector geometry is unchanged: its children receive `opacity: 0.35` and `pointer-events: none`, and no row is collapsed, removed or resized.

### Persistence and the empty screen

Appearance, pane visibility, pane sizes and the inspector side are saved as application preferences. Document data and any view settings that must reopen with it are saved in the document. Message logs, command history, pointer location and the state of running animations are transient and are not stored in the document. Section 10 (Remembered settings) lists each remembered value and how it is stored. A visible document tab shows a dirty mark until the save succeeds. Closing unsaved work offers save, discard and cancel, and a failed or cancelled save keeps the window open.

When no document or project is open, the centre shows the New and Open actions of the application.

| Element | Specification |
|---|---|
| Heading | 15 px semibold, `--text2` |
| Supporting text | 11 px, `--text3` |
| Spacing | 8 px between action buttons, 14 px vertical gap between welcome elements |
| Surface | `--empty-sheet` with a dotted grid of 16 px in `--empty-grid-dot` and a major grid of 128 px in `--empty-grid-line` (section 2). The tokens are set on `body` in each appearance, so that a canvas drawing the same sheet reads them there; the test `the welcome surface takes its sheet and grid from the theme tokens, not from colours of its own` enforces it. |
| Inspector, tool-strip contents, bottom tabs other than Terminal | Visible, with `opacity: 0.35` and `pointer-events: none`; the Terminal tab and the application-level Terminal commands remain available |
| Status bar | Contents hidden with `visibility: hidden`; the height is retained |
| Menus | Document-only actions are present and disabled |

A domain that requires a different empty surface records it in the profile. Normal opacity, pointer behaviour and status contents are restored when a document opens. An application without documents defines its equivalent inactive context in the profile. When an application keeps several files within one project, the profile states whether the top tabs represent projects or internal files; one tab row never serves both without a distinct label and close and save rule.


### Code editor

An application that edits code or text uses the shared editor (`createCodeEditor`, or `codeEditorSetup` in its own CodeMirror view) and its find bar (`createFindBar`, `FindController`). CodeMirror is an optional peer dependency of the shell: an application that does not use the editor never loads it.

| Part | Rule |
|---|---|
| Base | Line numbers, the active line (`--text` at 5 %, 4 px radius), history, bracket matching (`--text` at 14 % with an outline; an unmatched bracket outlined in `--error`), indentation on input, Tab to indent, 13 px mono (`--editor-size`) at a line height of 1.5, on `--well` |
| Caret | 1.5 px in `--accent-light`. It blinks at CodeMirror's 1.2 s rate with an eased fade instead of on and off, stays solid while typing, and glides 80 ms to its next position. Under reduced motion it blinks on and off and jumps. |
| Selection | One rounded shape in `--selection` (`roundedSelection`), with the shell's selection geometry; a selected empty line shows a 6 px stub. |
| Find bar | At the top right of the editor: the query, the match-case, whole-word and pattern toggles, `n of m` (or `No results`, `Invalid pattern`), previous, next and close, and a replace row opened by its chevron with Replace (Return) and Replace all (Cmd or Ctrl+Return). Matches are the accent at 22 %, the current one at 45 %. Esc closes it. |
| Syntax | The tokens of "Syntax colours"; brackets may be coloured by depth (`cm-bracket-1` to `3`) or dimmed by depth (`cm-bracket-dim-1` to `6`). |

The tests `every syntax kind has highlighting tags, no tag has two colours, and each tag gets its kind's class` and `the find bar counts the matches of its query and which one is selected` check the editor.

### Syntax colours

The shared code editor (`code-editor.ts`) colours code with these tokens, through the classes `syntax-<kind>` that `shellHighlightStyle` gives the Lezer highlighting tags (`SYNTAX_TAGS`). Each colour has at least 4.5:1 contrast on `--well`, the editor background, in its appearance.

| Token | Dark | Light | Use |
|---|---|---|---|
| `--syntax-keyword` | `#f97583` | `#c62a3c` | Keywords and literal words (`if`, `true`, `null`) |
| `--syntax-name` | `#79b8ff` | `#005cc5` | Function, class, macro and command names |
| `--syntax-string` | `#9ecbff` | `#032f62` | Strings, characters, regular expressions and escapes |
| `--syntax-number` | `#ffab70` | `#b35000` | Numbers, units and constants |
| `--syntax-comment` | `#8b949e` | `#6a737d` | Comments and meta lines |
| `--syntax-type` | `#b392f0` | `#6f42c1` | Types, namespaces, attributes and annotations |
| `--syntax-operator` | `#c9c9c9` | `#444d56` | Operators, punctuation and separators |
| `--syntax-heading` | `#e1e4e8` | `#24292e` | Headings and strong text (bold) |
| `--syntax-link` | `#79b8ff` | `#005cc5` | Links and URLs (underlined) |
| `--syntax-invalid` | `#ff7b72` | `#b31d28` | Invalid code |
| `--syntax-bracket-1` | `#e5c07b` | `#8a5a00` | Brackets at depth 1, 4, 7 … |
| `--syntax-bracket-2` | `#c678dd` | `#a626a4` | Brackets at depth 2, 5, 8 … |
| `--syntax-bracket-3` | `#56b6c2` | `#0b7380` | Brackets at depth 3, 6, 9 … |
| `--syntax-bracket-dim` | `#f3e9a8` | `#7a6a10` | Dimmed brackets, fading with depth (opacity 1 to 0.42) |

### Selecting and rearranging content

Content (parts on a canvas, points of a plot, scopes, rows, tabs) is selected and rearranged the same way in every application (`content-selection.ts`, `reorder.ts`, `viewport.ts`).

| Part | Rule |
|---|---|
| Colour | Selected and hovered content, its handles and the selection box use `--pick` (cyan), never the accent, which marks the interface's own selection (menus, tabs, tree rows). |
| Click and drag | A pointer that moves 5 px or more from where it went down starts a drag (`DRAG_THRESHOLD`, `dragStarted`); less is a click. |
| Selection box | A drag on empty space draws a box: `--pick` at 12 % fill with a 1 px outline dashed 4 and 3 px at any zoom (`SELECTION_BOX`, `drawSelectionBox`). It takes the items wholly inside it (`boxHits`; `touch` takes those it touches, for an application that needs it). |
| Modifiers | Shift adds to the selection, Cmd on macOS or Ctrl on Windows toggles, and a plain click or box replaces it (`selectionMode`, `nextSelection`). Esc clears the selection. |
| Rearranging | A dragged item stays in place; a 2 px line in `--accent-light` shows where it lands (`attachReorder`), the list scrolls within 24 px of its ends, a drop that would not move it shows no line, and Esc cancels. In a row or column the item lands before the item whose middle the pointer has not passed (`dropIndex`); on a grid of panels it lands on the side of the target within 20 % of its width (at most 40 px), otherwise above or below its middle (`dropEdge`). Document tabs rearrange this way when the application gives `onReorder`. |
| Pan and zoom | A canvas maps content to the view with `Viewport`: zoom keeps the point under the pointer still, between 0.05× and 12×, and Fit centres the content without magnifying beyond 2.5×. |

The tests `a selection box takes the items wholly inside it, or those it touches, whichever way it was dragged`, `Shift adds to the selection, Cmd or Ctrl toggles, and a plain click or box replaces it`, `a drag starts after 5 px, and a drop lands on the side within 20 % (at most 40 px) or above and below the middle`, `a dragged item lands before the item whose middle it has not passed, and moving keeps the others in order` and `the viewport zooms about the pointer within its limits and fits a rectangle without over-magnifying` enforce the rules.

### Panes, dialogs and form blocks

The pieces an application builds around its work come from the shell, so that they look and behave the same in every application.

| Piece | Rule |
|---|---|
| Splitter | Two panes side by side or one above the other (`createSplitter`): a 1 px `--separator` line with a 9 px pointer target, each pane at least 160 px (`splitShare`), a double click restores the default share, and the focused divider moves 2 % per arrow key. |
| View header | The header of a view beside the main work (`createViewHeader`): 28 px on `--raised`, the unsaved dot of the document tabs, the title, the view's icon actions and the close control at the right. It carries no editable or read-only icon: a file's status is shown in the file tree only. |
| Review and apply | Proposed changes before they are applied (`askToApply`): what was found, a table of each change (current and proposed, the proposed value in `--accent-light`, unchanged rows in `--text3`), Apply (Return) and Cancel (Esc) in the platform's order. |
| Table picker | A searchable table to pick from (`askToPick`): the search field filters as it is typed, keeping the rows that contain every word (`filterRows`); Up and Down move, a click or Return picks one row, or ticks rows with `multiple`, and the action and Cancel follow the platform's order. |
| Form blocks | A checkbox row (`createCheckRow`), chips for one of a few choices, drawn as a button group (24 px, radius 4 px, sharing the width; the chosen chip in `--accent-fill` with `--accent-foreground`, the others `--control` with `--text`), with the arrow keys moving between them (`createChips`), a tile for a content region beside the work (`createTile`, see Tiles; not for values in the inspector), a group heading (`createGroupHeading`) and a problem line under a field in `--error` (`setProblem`). |
| Outline | A document's structure (`renderOutline`): numbered by level (`outlineNumbers`: `1`, `1.1`, `1.2`, `2`), indented 12 px per level, the current entry in `--accent-fill`. |
| Text styles | `.link-button`, a link that runs an action, in `--accent-light` and underlined; `.hint-text`, quiet supporting text in `--text3` at 11 px. |

The tests `a divider keeps each pane at least 160 px, and an area too small for both splits in half`, `an outline is numbered by level, and a deeper level restarts when a shallower one advances` and `a table picker keeps the rows that contain every word typed, ignoring case` enforce the rules.

### Saving

Saving works the same in every application (`saving.ts`).

| Part | Rule |
|---|---|
| Writing | `saveDocument` asks for the path first and makes the text after it (`serialize(document, path)`, `path` null for a browser download), once per place written, so that a document that stores paths relative to itself is written once and correctly. A cancelled dialog writes nothing and reports nothing; a format the document cannot be saved in is reported after the path is chosen, and nothing is written. |
| Autosave | A preference with four choices (`AUTOSAVE_CHOICES`): **Off**, the default; **After 1 minute** and **After 5 minutes**, which save a document that long after its last edit, the pause restarting at each edit; and **When the window loses focus**. File › Autosave lists them with the current one checked (`autosaveMenu`), and the shared Terminal verb `autosave [off\|1m\|5m\|focus]` reads or sets it (`shellPreferenceCommand`, when the settings have `autosave`; it answers `Autosave is off.`, `Autosave set to after 1 minute.` or `Autosave takes off, 1m, 5m or focus.`). An untitled document is never autosaved: it has no file yet, and recovery keeps it instead (`createAutosave`). |
| Recovery | While a document has unsaved edits its text is kept as a draft in the application's storage, and cleared when it is saved or its changes are discarded (`createRecovery`). After a crash the next launch offers the drafts, all ticked: **Restore** reopens the ticked ones and **Cancel** keeps them for the next launch (`askToRecover`). Drafts older than seven days are dropped. |
| Open recent | File › Open recent lists the last ten files opened or saved, newest first and without duplicates (`addRecent`, `createRecentFiles`); where two files share a name, the folder follows it (`notes.txt — lab`, `recentLabels`); a separator and **Clear menu** end the list, and an empty list shows `No recent files` (`recentMenu`). On the desktop each file is also added to the system's recent documents (`addRecentDocument`). |

The tests `the text is made once, after the dialog, for the path it is written to`, `cancelled dialog and unsupported format keep a document unsaved, and nothing is written`, `autosave is off by default, or saves 1 or 5 minutes after the last edit, or when the window loses focus`, `autosave restarts its pause at each edit, never saves an untitled document, and saves on blur only when asked`, `recovery keeps one draft per document, clears it on save, drops drafts older than 7 days and lists the newest first` and `Open recent keeps ten files, newest first, without duplicates, named with their folder where names repeat` enforce the rules.

### Order and placement

Things every application shows are ordered and placed the same way (`layout-order.ts`).

| Element | Rule |
|---|---|
| Tool strip groups | Left to right: history (Undo, Redo), clipboard, view (zoom, fit), the application's tools, search at the right (`TOOL_GROUP_ORDER`). `strip.group(items, className, kind)` places a group by its kind, whatever order the application adds it in, and a separator follows each group. |
| Dialog buttons | In the platform's order (`dialogButtonOrder`, `dialogActions`). macOS: the destructive choice (Don't save) at the left, a gap, then Cancel and the primary action at the right. Windows: right-aligned, the primary action first, then the destructive choice and Cancel last. Return chooses the primary action and Esc chooses Cancel on both. |
| Close controls | A close control (×) is always at the top right of what it closes: a document tab's at its right end, shown on hover and on the active tab; a panel's, a popover's, a side view's and a banner's at the top right. It is never at the left on either platform. |

The tests `tool strip groups take the shared order whatever order an application adds them in` and `dialog buttons follow the platform: macOS ends with Cancel and the primary action, Windows starts with it` enforce the order.

## 5. Motion

Motion is limited to state changes in chrome. The initial layout appears without an entrance animation. Under `prefers-reduced-motion: reduce` the final state is applied immediately and the focus and visibility behaviour is preserved. A repeated action cancels or replaces the running animation.

| Transition | Duration | Easing | Property |
|---|---:|---|---|
| Document tab added or removed (when used) | 150 ms | `cubic-bezier(0.2, 0, 0, 1)` | Width, side padding, border width and opacity |
| Active document accent line | 150 ms | `cubic-bezier(0.2, 0, 0, 1)` | Transform and width; fractional tab bounds are measured and only the tab borders are excluded throughout the motion |
| Dirty dot | 150 ms | `ease-out` | Background colour |
| Active bottom-tab line | 150 ms | `ease` | Transform and width |
| Inspector section chevron | 150 ms | `ease` | Rotation from 0° (closed) to 90° (open) |
| Inspector section height | 150 ms | `cubic-bezier(0.2, 0, 0, 1)` | Height after a heading click |
| Inspector and bottom panel show and hide | 150 ms | CSS `ease` | Width or height and opacity; a closed pane becomes hidden and inert |

Decorative looping animation of the chrome is not used. Data animation, such as a simulation trace or a progress indicator, belongs to the profile and has a pause or off rule where the user can control it.

## 6. Tabs, menus and toolbar

### Document tabs

Document tabs represent the unit defined in the profile.

| Behaviour | Specification |
|---|---|
| Active top line | Follows the tab face exactly: `left = tabRect.left - rowRect.left + row.scrollLeft + borderLeftWidth` and `width = max(0, tabRect.width - borderLeftWidth - borderRightWidth)`, with the rectangles from `getBoundingClientRect()` and the border widths from the computed style. Fractional pixels are preserved, the line never paints across a border or into a neighbouring tab, and its position is recomputed during tab growth, shrinkage and resize. |
| Colours | The active tab uses the `--raised` background and `--text`; inactive labels use `--text2`. |
| Controls | A close control appears on hover and on the active tab; its hover state is a `--control-hover` background with a `--text` icon. A `+` control appears when New creates a tab; it is 30 px wide, transparent with a `--text2` icon, and becomes `--panel` with `--text` on hover. Middle click closes a tab. |
| Switching | Changes the active document and its inspector, Messages and Terminal context. The profile specifies whether switching stops audio or background work. |
| Overflow | Tabs shrink to their 90 px minimum width before the row scrolls, as browser tabs do; then they scroll horizontally with the scrollbar hidden, and the `+` control stays pinned at the right end of the row. A closing tab stops accepting pointer actions before its exit animation completes. |

### New documents, Untitled names and closing tabs

In every Forge application with document or editor-file tabs, **New file/document** (`CmdOrCtrl+N`, File › New and the `+` control) creates and activates a separate unsaved in-memory view. No file is written merely because the tab appeared. A separate **New project** workflow may request a location or metadata, but it does not replace New file/document where the application has editable file tabs. The profile defines the domain content, native format and initial settings of the new view; the tab and naming behaviour of this section does not vary by application. A launch without an open document shows the welcome state with no listed tab, and the first New creates `Untitled 1`.

| Rule | Specification |
|---|---|
| Name | An unsaved new tab is named `Untitled n`: capital `U`, one ordinary space and a positive base-10 integer without leading zeroes. |
| Choice of n | Before every New, the exact names of the tabs open in this window are collected, and the smallest `n >= 1` for which `Untitled n` is absent is chosen. Full names are compared case-sensitively; no lifetime counter, highest used number, history of closed tabs or search of file names on disk is used. |
| Examples | An empty window yields `Untitled 1`. With `Untitled 1` and `Untitled 3` open, New yields `Untitled 2`; after `Untitled 2` is closed, the next New yields `Untitled 2` again. |
| Stability | Existing tabs keep their names and are never renumbered when another tab closes or is saved. A successful first save renames the tab to the base name of the saved file, with its extension, and frees the Untitled number. A cancelled or failed save keeps the name and number reserved. A tab named exactly `Untitled 1` reserves 1, whereas `Untitled 1.<extension>` does not. |
| Position | The new tab is inserted immediately after the active tab and activated; with no tabs open it is inserted first. The `+` control remains after all document tabs. A file opened from disk replaces the sole untouched, unsaved blank tab, and otherwise opens immediately after the active tab. An edited blank tab is never silently discarded. |
| Label | The label is the current name of the document, centred within the flexible area between the left dirty-mark slot and the right close control, for `Untitled n` as for every other name and in every active, inactive, clean and dirty state. It occupies one line and ends with an ellipsis beyond the 220 px maximum width. The tooltip may show the full path. A dirty dot appears only after an unsaved edit; a new untouched tab has none. |

Closing a tab removes its view from the open-tab list and does not delete the saved file, project or internal file.

| Case | Behaviour |
|---|---|
| Pristine unsaved blank tab | Closes without a prompt |
| Unsaved tab with content or a path | Offers Save, Discard and Cancel; Cancel or a failed or cancelled Save keeps it open |
| Inactive tab closed | The active tab remains selected |
| Active tab closed | The tab that shifts into its position is selected, or the last preceding tab when none follows |
| Last tab closed | The documentless welcome state, with Terminal available |
| Cleanup | The temporary view state and the per-document Messages and history are removed according to their session lifetime |
| Motion | The 150 ms exit motion of section 5 applies, and pointer input stops before it ends |

The **`tabs`** command lists the open tabs in visual order and numbers the rows from 1. These numbers are positions and not `Untitled n` identities: they shift when tabs are inserted or closed, and a supported `tab <number>` or `close <number>` form addresses the current position. With no tab open, `tabs` answers `No <document noun> tabs open.` with the noun of the profile. The profile records the content of a new file, the label of the welcome button, the saved extension and, for multi-file projects, whether closing a tab removes only a file view; it cannot change the numbering and reuse rule of unsaved tabs.

### Bottom tabs, inspector headings and the action registry

| Subject | Specification |
|---|---|
| Bottom tabs | Utilities of the active document, not documents. Terminal is selected on launch and whenever a new document or project becomes active. Terminal is first and Messages last, with domain panes between them under profile-defined labels and order. The active tab uses `--text` and inactive labels `--text3`. Opening Messages marks its unseen problems as seen. A right-aligned Clear action appears only when Messages is active and non-empty. |
| Inspector headings | Buttons. Hover brightens the title to `--text-strong` and the chevron to `--accent-light`, without filling the heading. A collapsed chevron points right (0°) and an open one down (90°). A click toggles one section and an Option click applies that state to all sections. The profile records the initial folds and which folds persist. |
| Action registry | Actions are defined once, each with a stable identifier, exact label, shortcut, enabled and checked condition, handler, tooltip and command mapping. Native menus are rendered on macOS desktop; the page draws them in the browser and on Windows desktop. |

Menu headings use initial capitals and appear in the order File, Edit, View, profile-defined domain menus, Help. File contains New, Open, Save, Export and Close where they exist; Edit contains Undo and Redo, clipboard and object edits; View contains zoom, panels and appearance; Help provides the four information destinations specified below, and macOS places About in the product-name menu. Related actions are grouped by separators. The rendering and content of menus are specified under "Menu rendering and content".

### Renaming

A document or project is renamed in one place, the `Name` row of the inspector. Document tabs show the name but are read-only: a double click on a tab does not edit it, and its context menu keeps its own actions (such as Close) without a second editor. Files and folders in the file tree of an application have no `Name` row and are renamed in place on their own row.

| Part | Specification |
|---|---|
| Start | A double click on the name; `F2` or Return while the name has keyboard focus; or **Rename…** (`F2`) in its context menu. A right click opens the menu without starting the edit. |
| Field | The name is replaced by the shared field, with the same fill, border, radius, height and focus ring as the other text fields of the inspector (`.name-edit`, styled like `.field input`). It takes the place and size of the row, keeps focus, and carries the accessible name given by the application (`Document name`). |
| Selection | The whole name is selected; for a file only the base name before the last dot, so that the extension remains. |
| Confirmation | Return applies. Leaving the field applies a name that is valid and changed; an unchanged name has no effect. |
| Cancellation | Escape restores the old name, and so does leaving the field with an invalid name. |
| Rejection | Return with an invalid name gives the field the `--error` border and `aria-invalid="true"`, keeps it open and sends the reason to Messages and the status bar. The reasons are sentences with a final period: `Enter a name.`, `A name cannot contain / or \.`, `The name <name> is already used.` Names are compared without regard to case within the same place. |
| Unsaved document | The name becomes the one offered by the first Save; nothing is written to disk. |
| Saved document or file | The saved file is renamed on disk through the approved paths of the desktop bridge. The profile states whether a saved document can be renamed. |

An element with a rename is focusable and its tooltip is `Double-click or press F2 to rename.` The shell provides `startRename`, `attachRename` and `validateName`; an application supplies the current name, additional rules and the effect of applying a name.

### File tree

An application with project files lists them in the inspector with `renderFileTree`. The tree, its rows and its behaviour are common to all applications; the application supplies the files, the effect of opening one, and its own rules (locked paths, paths that must stay, the destination of a dropped file).

| Part | Specification |
|---|---|
| Row | 26 px high, 12 px UI text, 12 px indent per level, a 14 px line icon (`--text3`), then the name truncated with an ellipsis. Folders have a chevron (right when closed, down when open, rotated in 150 ms, without motion under reduced motion) and `--text2` names. Hidden files are `--text3` and sort after visible ones. A locked file shows a small lock icon at the right, with the reason as its tooltip. |
| Order | Folders before files; each level sorted by name, ignoring case and treating digits as numbers. |
| Selection | A selected row is `--control-hover` while the tree has no focus and `--accent-fill` with `--accent-foreground` while it has. A click selects, Shift extends a range, Cmd or Ctrl toggles, and a click elsewhere clears. Only the focused row is in the Tab order. |
| Keyboard | Up, Down, Home and End move; Right opens a folder or moves into it, Left closes it or moves to its parent. The commands take the keys of Finder and File Explorer (`treeKeyCommand`), listed below. |
| Open | A double click runs the open action of the application on a file and toggles a folder; Open does the same from the keyboard. |
| Context menu | In Finder and File Explorer order, groups divided by separators: **Open** and the file entries of the application; **New file**, **New folder** and **Add files…** on a folder or the empty area; the entries of the application for that target (`contextMenu`); **Show in Finder** or **Show in File Explorer**; **Cut**, **Copy**, **Paste**, **Duplicate** and **Copy path** (**Copy paths** for several rows); **Rename…** and **Delete** (with the count for several rows). A command the application does not provide is left out; a refused one stays, disabled, with the reason as its tooltip. |
| Commands | The names are those of both platforms and say what happens: **Delete**, never `Move to Trash` (the application decides whether the file goes to the Trash or the Recycle Bin). Copies are named as the platform names them (`copyTarget`): `notes copy.txt`, `notes copy 2.txt` on macOS, `notes - Copy.txt`, `notes - Copy (2).txt` on Windows. A new file or folder takes the first free name (`newEntryName`) and is renamed in place at once. Cut rows are drawn at 55 % opacity until they are pasted. |
| Extension | An application adds context-menu entries for any target (`contextMenu`, `menu` for a file), icon buttons at the end of a row such as hide, lock or select (`rowActions`, with `TREE_ACTION_ICONS`), icons for its own kinds of file (`icons`), and keys of its own (`keyDown`, before the tree's). A row action is `--text3`, 18 × 18 px with a 12 px icon, visible while the row is hovered or selected, and always visible in `--accent-light` while it is on. |
| Icons and badges | A row shows the icon of its kind: folder, text, code, data, PDF, image, spreadsheet, archive, audio, video or other (`FILE_ICONS`); `fileKind(path)` gives the kind from the extension for an application without kinds of its own. A file's status sits at the right of its row, 12 px in `--text3`, with its tooltip: an application that marks files gives `status` and every file row then shows one, `editable` (`Editable file.`) or `readOnly` (`Read-only file.`) from `TREE_STATUS`, or a status of its own; folders have none (`treeBadges`). The status is shown in the tree only, never in a document tab or a view header. Further badges of the application (`badges`) follow it. |
| Notices | Copy path confirms in the status bar (`notice`): `Copied the path of <path>.` or `Copied <n> paths.` |

| Command | macOS | Windows |
|---|---|---|
| Open | Cmd+O, Cmd+Down | Enter |
| Rename… | Return, `F2` | `F2` |
| Delete | Cmd+Delete | Delete |
| New folder | Shift+Cmd+N | Ctrl+Shift+N |
| Duplicate | Cmd+D | none |
| Cut, Copy, Paste | Cmd+X, Cmd+C, Cmd+V | Ctrl+X, Ctrl+C, Ctrl+V |
| Copy path | Option+Cmd+C | Ctrl+Shift+C |
| Select all | Cmd+A | Ctrl+A |

The tests `the tree's commands carry the names and keys of Finder and File Explorer`, `keys map to the platform's commands` and `copies take the platform's copy names, and new entries the first free name` enforce the table.
| Rename | In place with the shared name field (see Renaming): only the base name of a file is selected, a bare name stays in its folder and a name with a slash moves it; a name already used, `.`, `..` or a backslash is rejected with a sentence. |
| Drag and drop | Rows dragged onto a folder or the tree are moved (a folder cannot move into itself, and locked rows cannot be dragged). Files dropped from the system are added to that folder, and on the tree root the application may choose a folder by file type. The target folder shows the accent fill while the pointer is over it. |
| Empty | `No files.` in `--text3` |

### Files that change outside the application

When a file open in the editor changes on disk, the application compares the text on disk with what it last read or wrote and with the editor.

| Situation | Outcome |
|---|---|
| Nothing changed | No action |
| Only the disk changed | Silent import |
| The editor also holds unsaved edits | `askExternalChange()` opens a dialog titled `<file> changed outside <Product>, and the editor has edits that are not saved.` with **Keep mine** (Escape) and the primary **Reload** (Return) |

`externalAction()` decides, and unsaved edits are never discarded without a question.

### Dropping files

A window or view that opens files dropped from the system uses `attachFileDrop(target, options)` (`file-drop.ts`). The application gives the accepted extensions, the sentence of the drop target and what opening a file does; the shell gives the target, the sorting and the refusal.

| Part | Rule |
|---|---|
| Accepted files | By extension with its dot (`accept: [".png", ".jpg", ".tif"]`), ignoring case (`acceptsFile`); a name without an extension, or with a leading dot only, is refused. `.tiff` and `.tif` are different extensions, so an application that takes both lists both. |
| Drop target | Shown only while a drag carries files from the system (`dragHasFiles`), never for text or rows dragged inside the page. It covers the target: the accent at 10 % with a 2 px dashed `--accent-light` outline 6 px inside the edge, and the sentence of the application (`label`, such as `Drop images to open them.`) centred on `--panel` in 12 px UI `--text`. It stays shown while the pointer crosses the target's children and hides when the pointer leaves the target or drops. |
| Refusal | One sentence for the refused files of a drop (`dropMessage`): `Cannot open notes.docx. Drop a .png, .jpg or .tif file.` At most three names are listed and the rest counted (`Cannot open a, b, c and 2 more.`). The accepted files of the same drop still open. The application sends the sentence to Messages as an error and to the status bar (`onRefused`). |
| One file | With `multiple: false`, a drop of more than one accepted file opens none and answers `Drop one file at a time.` |
| Paths | Each opened file is given as `{ name, path, file }`: the contents are read from `file`; `path` is the path on disk from the desktop bridge (`pathFor: bridge.pathForFile`, Electron's `webUtils.getPathForFile`, which the preload passes to `createDesktopBridge`), and `null` in the browser. |
| Inner targets | A drop that an inner element has already handled (`preventDefault`), such as a folder of the file tree, is left to it. |

The tests `a dropped file is accepted by its extension, ignoring case, and a name without one is refused`, `refused files are named in one sentence, three at most, with the accepted kinds`, `a drop keeps the accepted files and reports the others, and a single-file target refuses two`, `the drop target shows only while files are over it, across child elements, and hands over paths` and `in the browser a dropped file has no path, and the bridge gives the desktop path through webUtils` enforce the rules.

### Keyboard shortcut tiers

Shortcuts come in tiers (`shortcutTier`), so that an application's own commands never take a key the shell, the system or typing needs.

| Tier | macOS | Windows | Owner |
|---|---|---|---|
| Universal | Cmd and a key | Ctrl and a key | The shell: the standard commands of `UNIVERSAL_SHORTCUTS` (New, Open, Save, Save as, Close, Print, Quit, Preferences, Undo, Redo, Cut, Copy, Paste, Select all, Find, Find next and previous, Go to line, Toggle comment, Zoom in and out, Fit on Cmd+0, Actual size on Cmd+1, Show inspector, Show bottom panel, New window, Duplicate, the four Arrange commands, and the next and previous tab) and Replace (`replaceShortcut`: Option+Cmd+F on macOS, Ctrl+H on Windows) |
| App | Shift+Cmd and a letter | Ctrl+Shift and a letter | The application's commands (`appShortcut(letter, "app")`) |
| Secondary | Option+Cmd and a letter | No default | Rarer application commands (`appShortcut(letter, "secondary")`); Ctrl+Alt is AltGr on Windows and types characters on Greek and most European keyboards |
| Tool | A bare key | A bare key | Canvas tools, only while no text field has the focus |

**Conventional shortcuts.** A shortcut that other applications have made conventional for one meaning is kept, outside the tiers: the registry entry names its convention (`convention`, one of `CONVENTIONAL_SHORTCUTS`), and the key must be the convention's. Group and Ungroup are Cmd+G and Shift+Cmd+G; Bold, Italic and Underline are Cmd+B, I and U; Run is Cmd+Return or Cmd+R; Reload or restart is Cmd+R; Build is Cmd+B. A convention takes a universal key only where it names it (`replaces`: Group takes Find next's Cmd+G, Italic takes Show inspector's Cmd+I). Every other command follows the tiers, with no exceptions: a key with a different meaning elsewhere, such as Cmd+E for Rotate or Cmd+Right for Step, which moves to the end of a line in every text field, takes an App or Secondary key.

`checkShortcuts(entries, mac)` reports, as sentences, two commands on one key; a key the system keeps (such as Cmd+H, Cmd+M, Ctrl+Cmd+F, Shift+Cmd+3 to 5 on macOS and Alt+F4, Alt+Tab, Ctrl+Esc on Windows); an application command on a universal key or on Cmd or Ctrl with a single other key; and keys that type characters: Shift alone, Option alone on macOS, and Alt, Ctrl+Alt and Alt+Shift on Windows. An application runs it over its registry in its own tests. The tests `shortcuts fall into tiers: the shell's universal keys, two-modifier app keys, and bare tool keys`, `the shortcut check reports clashes, system keys, universal keys taken by an app and keys that type characters` and `a conventional shortcut may stay outside the tiers when it names its convention; anything else follows the tiers` enforce the table.

### Upper menu bar, application menu and Help

The upper menu bar uses initial-capital labels in the shared order File, Edit, View, application-specific domain menus, Help. On macOS desktop the native menu of the product name precedes File and the native Window menu immediately precedes Help; the browser menu bar and the Windows desktop menu omit these macOS menus unless the profile gives a concrete reason for an equivalent. The profile lists every top-level label in display order, every submenu and separator, the identifier and exact label of each action, and its enabled and checked condition in the open-document and welcome states. An empty domain menu is not displayed merely to match another Forge application. The application menu is the product-name menu of the operating system; the application icon is not an in-window About button.

| Top-level menu | Shared responsibility | Specified by the profile |
|---|---|---|
| `<ProductName>` (macOS desktop only) | About `<ProductName>` first, then the native Services, Hide `<ProductName>`, Hide Others, Show All and Quit `<ProductName>` roles, separated as native groups | Product name, About action identifier, genuine application-specific native items; About dispatches the same action as Help › About on platforms that show it there |
| File | New and Open, examples or recent files when supported, Save and Save as, Import and Export, Close, in workflow order | Exact file and document labels, platform dialogs, formats, recent and example submenus, disabled conditions |
| Edit | Undo and Redo, clipboard actions, selection and domain editing | The actions that require an editable field, a selection or an open document; native text editing keeps working in focused text fields |
| View | Zoom or fit, checked inspector and bottom-panel visibility, display settings and appearance | Exact view labels, panel names, appearance choices, checked states and shortcuts |
| Domain menus | The operations of the application, after View and before Help | Each name, order, submenu, enabled and checked state, and domain shortcut |
| Window (macOS desktop only) | Native window-management roles | Any extra Window item; otherwise the native menu |
| Help | What's new…, Keyboard shortcuts…, Licenses…; on the browser and on non-macOS desktop, About `<ProductName>` first, followed by a separator | Exact product name and content sources of each dialog; the menu does not replace the Terminal `help` command |

All Forge applications provide four information destinations.

| Destination | Content |
|---|---|
| About | An in-application modal with the shared ASCII wordmark, the purpose, the version, credits and attribution, application-specific additions, and a licence summary or link |
| What's new… | The section `## <VERSION>` of `CHANGELOG.md` as numbered release-note rows; the newest section when it is absent, and an unavailable message when there are no sections |
| Keyboard shortcuts… | The current menu shortcuts and application-specific keys, grouped under initial-capital headings and generated from the action registry. Each shortcut is written out as `<modifier> + <key>` with a space either side of each plus, in the platform's names and order (`shortcutText`): `Shift + Cmd + Z`, `Option + Cmd + F`, `Esc` and `Return` on macOS; `Ctrl + Shift + Z`, `Esc` and `Enter` on Windows. Menus keep the compact glyphs of native menus (`displayKey`). |
| Licenses… | The own licence of the application and the included third-party work, followed by the full applicable licence text or an explicit unavailable message |

The shell provides all four (`about.ts`): `helpMenu(productName, appMenuHasAbout)` builds the Help menu with About only where the application menu lacks it; `showAbout()` adds the shared licence summary below the application's own paragraphs; `showWhatsNew()` reads the shipped `CHANGELOG.md` (`releaseNoteBlocks()`); `showShortcuts()` takes groups, which `menuShortcutGroups()` builds from the menu definition, one per top-level menu; and `showLicenses()` lists `SHARED_WORKS` (the shell, Electron and the wordmark lettering) and the application's own included works above the full GPL text, followed by any further licence texts the application ships (`LicenseText`). The profile records the exact credits, licence sources and any domain-specific shortcut groups. Each dialog uses the same wordmark header and closes with its Close button, Esc or a click on the backdrop. Terminal `help` lists command verbs and `help <command>` gives the syntax of a command; selecting an item of the Help menu never inserts a command into the Terminal transcript.

### The component page

`npm run gallery` builds every part of the shell into one page in the frame of an application and serves it on `http://127.0.0.1:4199/`: menus, tool strip, document tabs with long names, a view header, the code editor with its find bar, an outline, inspector sections with a button group at the top and every button state (enabled, disabled and busy, ordinary and primary), fields, a field problem, chips, a slider, measured values with their tooltips, the file tree with a status on every file and the lines of the file under the pointer, a tool flyout, Terminal, Messages with each kind of message, and the status bar. `?show=about`, `shortcuts`, `licenses`, `whatsNew`, `save`, `saveAll`, `apply`, `pick`, `context`, `menu` or `flyout` opens a dialog or menu; `?theme=light` changes the appearance, `?docs=0` shows the welcome screen, `?pane=messages` selects Messages, `?find=0` closes the find bar and `?drop=1` shows the drop target of a file drag. `galleryChecks()` in the page's console lists what it can measure: parts that spill sideways or reach past the window, parts cut off by the pane that holds them, text fields under 100 px wide, and welcome-screen parts, dialogs, the drop target's sentence and button icons more than 2 px off centre (1 px for icons). A visual change to the shell is checked there at 1440 × 900, 1024 × 700, 800 × 600 and 600 × 500, in Dark and Light, before it is released.

### Checking for updates

An application whose profile names its GitHub repository (`identity.repository`, as `owner/name`) checks for a newer release and installs it with one click; one without it has no update check. The check reads the latest published release of that repository (`checkForUpdate()`) and compares its tag (`v3.1.0` or `3.1.0`) with the running version (`compareVersions()`).

| Part | Rule |
|---|---|
| Help menu | **Check for updates…** ends Help, after a separator (`helpMenu(name, appMenuHasAbout, true)`, action `about.updates`). It opens an information dialog that says `<Name> <version> is available. You have <version>.`, or `<Name> is up to date.`, or why the check could not run (`showUpdateCheck()`). |
| Update and restart | On the desktop, when the release has the installer of this platform (`<Name>-v<version>.dmg` or `.exe`, `updateAsset()`), the dialog shows **Update and restart**, which calls the bridge's `installUpdate`. The main process (`registerUpdater()`) downloads only files of the named repository's releases and keeps a download only when its size and GitHub's SHA-256 digest match (`downloadAsset()`). In the browser, and when installing fails, the dialog offers the release page instead. |
| macOS | The disk image is opened out of sight and the new app copied beside the running one; the app quits, and a detached script swaps the two, keeping the old copy until the new one is in place, and opens the new app (`macSwapScript()`). An app opened from its disk image, from a translocated download or from a folder it cannot write cannot replace itself (`cannotReplace()`): the disk image is opened instead, and the person drags the app into Applications. No Apple signing is needed. |
| Windows | The app quits, and a detached script waits, runs the Forge setup with `/S` (it asks for administrator rights once) and opens the installed app again (`windowsUpdateScript()`). A refused or failed setup leaves the installed version, which opens again. |
| At launch | At most once a day (`updateCheckDue()`), a newer release is added to Messages as information: `<Name> <version> is available. Help › Check for updates… installs it.` No dialog opens by itself, and nothing is said when the app is up to date or the check fails. |
| Repository | GitHub answers without sign-in only for a public repository with a published release; a private repository answers `No public release was found.` A token is never shipped in an application. To keep the source private, releases can be published from a separate public repository named in the profile. |

### Menu rendering and content

| Part | Specification |
|---|---|
| Where | macOS desktop uses the native menu bar. The page draws the menus in the browser and on Windows desktop (`drawsMenubar`), where native menus cannot be styled; there the window hides its title bar, keeps the native minimise, maximise and close buttons (`windowChrome`, `usesNativeMenu`), and the drawn menu bar is the title bar. |
| Menu bar | First row of the window, 26 px high (32 px as the Windows title bar, which drags the window and leaves room for its controls), `--raised`, 1 px `--separator` bottom border; titles are 22 px high and 13 px UI, with 8 px side padding and a 5 px radius, and are `--text` at 14 % over the bar when hovered or open |
| Popup | After the macOS menus: `--panel` at 90 % over a 24 px backdrop blur, 1 px border of `--text` at 14 %, 10 px radius, 5 px padding, minimum width 190 px (maximum 380 px, constrained to the viewport minus 8 px), 13 px UI text, maximum height `calc(100vh - 40px)` with vertical scrolling; shadow `0 10px 30px rgba(0,0,0,0.5)` in Dark and `0 8px 24px rgba(35,40,50,0.16)` in Light; never beyond the window |
| Item | Three columns: a 14 px check column reserved in every menu, so that menus with and without checks line up, the label, and the right-aligned shortcut or submenu arrow; at least 22 px high, 2 px vertical padding, 6 px left and 10 px right; 5 px radius; label `--text`, shortcut and arrow `--text2` |
| Hover and keyboard focus | `--accent-fill` background and `--accent-foreground` text, including the shortcut |
| Disabled | `--text3`, without hover fill or action |
| Separator | 1 px `--hairline` line, 5 px above and below, 10 px inset; never at the start or end of a menu and never twice in succession |
| Keyboard | Outside macOS, Alt pressed and released alone, or `F10`, opens the first menu. Left and Right move between menus, Up and Down between items, Right and Return open a submenu, Return runs an item and Esc closes one level. |
| Roles | A drawn menu performs the standard edit roles (`EDIT_ROLES`: Undo, Redo, Cut, Copy, Paste, Delete, Select all) itself; another role is shown only when the application gives it an action. |
| Heading | An unclickable row in `--text2`, weight 600, used only in submenus that need a label |
| Closing | A popup closes on Esc, on an outside click and on selection |

| Content rule | Specification |
|---|---|
| Labels | Sentence case without a final period; an action is a verb phrase (`Save as…`). The ellipsis `…` marks an action that opens a dialog or requests input. A checked item is a noun phrase whose label does not change (`Show inspector`, not `Hide inspector`). |
| Structure | The items of a submenu do not repeat its name; submenus are at most two levels deep. |
| Shortcuts | In menus, the compact platform display (`⌘`, `⇧`, `⌥` on macOS, `Ctrl+Shift+` on Windows, `displayKey`); in help, tooltips and other text, written out (`Shift + Cmd + Z`, `Ctrl + Shift + Z`, `shortcutText`). Taken from the action registry and never part of the label. |
| State | Checks mark toggles, and one checked choice marks a mutually exclusive setting; an action is disabled when its precondition is absent. |
| Separators | Groups are divided by purpose. A group of one item is permitted, and a menu is never one long unseparated list. |

The order of the shared menus is given below; items an application does not have are omitted and the others keep this order.

| Menu | Order |
|---|---|
| File | New, Open, examples or recent (submenu); separator; Save, Save as, Import and Export; separator; Close |
| Edit | Undo, Redo; separator; Cut, Copy, Paste, Duplicate, Delete; separator; Select all; separator; application edit actions; separator; Find items and Go to; separator; Properties |
| View | Zoom in, Zoom out, Fit, Actual size; separator; Show inspector, Show bottom panel (checked); separator; display toggles and submenus of the application; separator; **Appearance** (submenu with Dark and Light, one checked); on desktop a separator followed by the platform items (Toggle full screen, Developer tools) |
| Help | About `<ProductName>` (only where the platform application menu lacks it); separator; What's new…, Keyboard shortcuts…, Licenses… |

The native application menu and Window menu of macOS are unchanged by these rules, and one definition builds the browser menu bar, the desktop native menu and the context menus.

### Information-dialog presentation

The application icon serves the operating system, the installer and the browser favicon; its bitmap does not appear in the Terminal banner or in the information dialogs, which use the `assets/logo.txt` wordmark. The About item of the macOS product-name menu and Help › About, where present, open the same dialog. The four information destinations share one frame, and only the product text, the accent tokens and the application-specific body content of the profile are substituted.

| Part | Geometry and typography | Foreground and background |
|---|---|---|
| Backdrop | Fixed to all viewport edges, dialog centred, stacking level 200 | `rgba(0,0,0,0.45)` over the application |
| Dialog | Width `min(720px, 100vw - 32px)`, maximum height `100vh - 32px`, 10 px radius, flex column, hidden outer overflow; shadow `0 20px 60px rgba(0,0,0,0.6)` | `--panel` background; default text `--text2` |
| Brand header | 22 px padding, 1 px bottom hairline; the full preformatted wordmark, then the purpose, three spaces and `v<VERSION>`, then a lowercase subtitle | `--raised` background; wordmark `--accent-about`; purpose `--text`; version and subtitle `--text2`; border `--hairline` |
| Body | 18 px top and 22 px side and bottom padding, vertical scroll, 14 px between blocks, 4 px between the rows of a block | `--panel` background |
| Block heading | Sentence case, 700 12 px/1.45 UI font | `--text` |
| Prose | Normal 12 px/1.45 UI font, zero paragraph margin; bold emphasis stays in the UI font | `--text2`; bold `--text` |
| Link | Font inherited from its context (UI prose or mono listing), underlined with a 2 px offset | `--accent-about`; hover `--text`; keyboard focus a 1 px `--accent-about` outline with 2 px offset |
| Inline code | 11.5 px mono | `--text` |
| Numbered release-note row | Grid `9ch minmax(0,1fr)`; 12 px/1.45 mono for marker and grid, the note itself in 12 px/1.45 UI font | Six-character padded `[n]` and exactly three spaces in bold `--accent-about`; note `--text2` |
| Numbered credit and licence row | Grid `9ch 24ch minmax(0,1fr)`; marker, name and description in 12 px/1.45 mono. At a viewport width of at most 560 px the grid is `9ch minmax(0,1fr)` and the description moves to the next row, in column 2. | Marker bold `--accent-about`; name bold `--text2` (the link colour when it is a link); description `--text2` |
| Keyboard-shortcut row | Grid `18ch minmax(0,1fr)` with a 1ch gap; key and explanation in 12 px/1.45 mono. Groups use one column below 760 px and two columns with a 3ch gap from 760 px. | Key bold `--accent-about`; explanation `--text2` |
| Full licence prose | 12 px/1.45 UI font, paragraphs 12 px apart | `--text2` |
| Close | Ordinary panel button, 90 px wide and 24 px high, at the right end of the body | Ordinary control colours of the button table below |

The marker uses the format `("[" + n + "]").padStart(6) + "   "` of Terminal and occupies the first grid column of 9ch. A numbered description is not set in mono merely because its marker is: release-note text is UI, whereas the descriptions of credits and licences and the explanations of shortcuts are mono in the layout of the shell. This distinction holds across Forge applications. The neutral and accent tokens of section 2 apply in both appearances, and a click inside the dialog does not close it.

### Button foreground and background

“Inside” denotes the foreground of the label or icon and “outside” the fill of the button. The same state pairs apply in Dark and Light through the semantic tokens of section 2. A disabled button keeps its ordinary or primary background and dims only its foreground: `--text3` on the ordinary fill, and on the accent fill the foreground mixed 55 % into the fill (2.6 to 3.4:1 on the family fills, against 4.9 to 7.5:1 enabled), since `--text3` there measures about 1.1:1 and vanishes. It neither responds to hover nor accepts clicks.

| Control and state | Background | Foreground | Border and focus |
|---|---|---|---|
| Ordinary panel or dialog button | `--control` | `--text` | No border; visible keyboard focus in `--accent-light` |
| Ordinary button, hovered | `--control-hover` | `--text` | No border |
| Primary panel or dialog button | `--accent-fill` | `--accent-foreground` | No border; visible keyboard focus in `--accent-light` |
| Primary button, hovered | `--accent-hover` | `--accent-foreground` | No border |
| Disabled panel or dialog button | Ordinary or primary fill retained | `--text3` on the ordinary fill; `--accent-foreground` mixed 55 % into `--accent-fill` on the primary | No hover change, no action; default pointer |
| Running (busy) panel or dialog button | Ordinary or primary fill retained | Ordinary foreground, or `--accent-foreground` on primary | No hover change; clicks ignored; `aria-busy="true"`; cursor `progress` |
| Toolbar icon button | Transparent over the `--raised` strip | `--text` | No border |
| Toolbar icon button, hovered | `--control-hover` | `--text` | No border |
| Toolbar icon button, selected | `--accent-fill` | `--accent-foreground` | No border |
| Selected toolbar icon, hovered | `--accent-hover` | `--accent-foreground` | No border |
| Disabled toolbar icon | Transparent over the `--raised` strip | `--text3` | No hover change, no action |
| Menu item or tool-flyout item | Transparent over the menu surface | `--text` | No border |
| Enabled menu or flyout item, hovered or focused | `--accent-fill` | `--accent-foreground`, including the shortcut and submenu text | No border |
| Disabled menu or flyout item | Transparent over the menu surface | `--text3` | No hover fill, no action |

Text inputs and selects use the `--well` fill, the `--text` foreground, a 1 px `--separator` border, a 4 px radius, 6 px of horizontal padding and a height of 22 px. Focus changes the border to `--accent` and adds a 1 px `--accent` ring. Textareas use the same colours and border with 4 px of vertical and 6 px of horizontal padding. An invalid field has a semantic red border and a nearby error message, and checkbox marks use the accent of the application. A property that is disabled independently of an empty document has 45% opacity and no edit action. Every button and chip shows whether it can be clicked by its label: an enabled one has its full label colour and a hover fill, and a disabled one keeps its fill, green or grey, with a dimmed label, a default pointer and no hover; a busy one keeps its fill and its full label colour. Keyboard focus is a 1 px `--accent-light` ring 1 px outside the button. The tests `buttons share a group's width at 24 px, and each kind shows whether it can be clicked`, `a disabled primary label is the foreground 55 % into the accent fill: legible, and clearly dimmer than enabled`, `chips are a button group: 24 px, radius 4, sharing the width, the chosen one in the accent fill`, `a button group holds its buttons in order, each primary or ordinary and enabled or disabled as given`, `every file in the tree shows its status, editable or read-only or the app's own, and folders show none`, `a file's status is shown in the tree only: a view header carries no editable or read-only icon`, `no stylesheet rule draws a status icon in the view header` `info lines show the item's name, then its values, and the empty sentence when there is no item` and `info lines set the name in the UI font and the values in mono` enforce these rules. A filled button never colours only its text with the accent, and a toolbar button has no permanent fill unless it is selected. A button kind specific to an application defines all its states in the profile before it is used.

### Running buttons

A running state is shown by the label and the icon and never by a new colour: a running button keeps the fill of its kind (ordinary `--control`, primary `--accent-fill`) and its normal label colour. Green, red, `--warning` and a spinner colour are not used.

| Case | Behaviour |
|---|---|
| Toggle (`Run` and `Pause`, `Build` and `Cancel`) | The button stays enabled and primary in both states. Its label and icon name the action that a click performs next: `Pause` with a pause or stop icon while running, `Run` with a play icon when paused. |
| Busy action that cannot be cancelled (`Build PDF`) | The button stays in place with the in-progress label (`Building PDF…`, ending in an ellipsis), `aria-busy="true"` and `aria-disabled="true"`. It is not `disabled`, so its label keeps full contrast on the fill. Clicks are ignored, hover has no effect and the pointer shows `progress`. The label returns when the work ends, including after an error. |

The status bar shows the same state as a word (`Running`, `Paused`, `Building`, `Ready`) in `--text2`, and in `--accent-light` while work is in progress. `--warning` and `--error` are reserved for problems and are never used for a normal running state. `setButtonBusy()` applies the busy attributes and the label.

### Toolbar

| Subject | Specification |
|---|---|
| Window chrome on macOS | In a window the toolbar leaves 96 px on the left for the window buttons and shows a hairline after them. In full screen there are no window buttons, so the tools sit 12 px from the left edge and the hairline is hidden. The shell provides this: the main process calls `forwardFullScreen(window)` and the page calls `applyDesktopClasses(window.<bridge>)`, which sets `desktop-mac` and keeps `full-screen` current. An application contains no full-screen handling of its own. |
| Grouping | Undo and Redo; clipboard and object edits; view and zoom; then the tools of the application. General actions use line icons, and domain objects an icon family defined by the application. |
| States | Selected: `--accent-fill` with a white icon. Disabled: `--text3`. Hover: `--control-hover`. |
| Accessible name and tooltip | Every icon button has a concise accessible name and a tooltip with the action and its shortcut; placement guidance is added only for a placement mode. |
| Modes | A tool that changes the next pointer action displays its mode as `<verb> <object>. Press Esc to finish`, and Esc returns to the neutral selection mode. |

**Tooltip wording.** Every tooltip has one of two forms and is set with `setTip()`, never with `.title =`. `checkTipWording()` tests a tip against these rules, and `forge-shell check-app` warns about direct `.title` assignments. An editable readout (`editableValue`) takes a sentence from the application that says what to type, and its tooltip is that sentence with a final period (`editableTip`), never a pointer instruction such as `Click to type`.

| Form | Use | Wording |
|---|---|---|
| Action tip | Toolbar buttons and menu-like controls | The action name with its shortcut in parentheses and without a final period (`Undo (Cmd + Z)`, `Undo (Ctrl + Z)`); the shortcut comes from the action registry and is written out by `shortcutText`; placement guidance follows `: ` |
| Sentence tip | Properties, fields and status | One sentence that starts with a capital, ends with a period and has at most 120 characters (`Set the random seed for reproducible variation.`); it states what the control does and not how to use the mouse |

**Mandatory tool-button rules.** Every tool button is built with `createToolButton` (or `strip.tool`) from the label and accelerator of the action registry; the tooltip is `Action (shortcut)` with platform glyphs, the accessible name is the action label, and no shortcut is typed by hand. Standard actions use the shared `TOOL_ICONS` (undo, redo, cut, copy, paste, fit, zoomIn, zoomOut), 16 × 16 px with a 1.25 px line in `currentColor`. Domain icons use `toolIcon()`, so that they share the box and the stroke and take their colour from the button state. The selected, hover, disabled and keyboard-focus states come only from the `.tool` classes (focus is a 1 px `--accent-light` ring) and are not overridden by an application. `forge-shell check-app` warns about icon-only buttons without an accessible name and about icon strokes other than 1.25.

**Shared icons.** Beyond `TOOL_ICONS` and `STATUS_ICONS`, the shell provides `UI_ICONS` in the same 16 px box and 1.25 px line: close, the four chevrons and more for navigation; add, remove, delete, duplicate, rotate, edit, read-only, pointer and check for editing; search, reveal, export, import, link, show, hide, lock, unlock, pin and check-circle for files; refresh and settings. `BUTTON_GLYPHS` are filled 9 px glyphs for the small run controls of a panel button (play, pause, stop, reset, step). An application draws none of these itself: the style lint of `forge-shell check-app` reports a path that repeats a shared icon, with its name. Domain icons (parts, sections, formulas) stay in the application, built with `toolIcon()`.

**Optional modules.** An application may use the modules below; a module that is used follows its specification exactly, and an application that does not use one receives no markup for it.

| Module | Specification |
|---|---|
| Flyout group (`createFlyoutGroup`) | Palette families in a `.flyout-group` after the direct tools. Each flyout button names its family, exposes `aria-haspopup="menu"` and `aria-expanded`, and opens a menu of the available tools of the family. The menu rows have the three columns of every menu row (`flyoutItemMarkup`): the check column, kept empty for alignment, the icon and name, and the shortcut. A tool is an action and never a checkable item: its row is a plain `menuitem` without a check, and the button shows the current tool by its icon. The button's tooltip is `Family: Tool (shortcut)` (`flyoutTip`). A choice closes the menu, selects the tool and updates the icon shown for the family. Escape and an outside press close the menu and return keyboard focus to the button. |
| Toolbar search (`createToolSearch`) | `#toolstrip-search` after the tool groups. The input is a combobox named for the objects searched, with `aria-controls` and `aria-expanded`, and the matches appear in the overlay root. Up and Down change the active result, Enter selects it, and Escape clears and closes. The profile defines the indexed objects and search terms. |
| Tool modes (`createToolModes`) | Exactly one tool is active; the mode label reads `verb object. Press Esc to finish`; Escape always returns to the neutral mode. |

The tests `a flyout row has the three columns of every menu row, and a tool is a plain item, never checked` and `an editable readout's tip is the application's sentence with a final period, and passes the wording check` enforce the flyout rows and the readout tip.

### Status bar

The status bar is the last row of the window, below the bottom panel. It is a single line of 11 px mono text, 24 px high and full width, on `--raised` with a 1 px `--separator` top border, 12 px of side padding and 14 px between items. Nothing wraps, and the middle area is truncated with an ellipsis.

| Part | Position | Content and colour |
|---|---|---|
| State | Left | A round dot of 6 px, the state word (`Ready`, `Running`, `Paused`, `Building`) in `--text`, and an optional short summary such as a time (`0 s`). The colour of the dot encodes the state: `--text3` for idle states (`Ready`, `Paused`), `--accent-light` while work is in progress, and `--warning` or `--error` only for a real problem. |
| Detail | After the state, taking the free space | A persistent explanation in `--text2`. |
| Hint | Replaces the detail while present | A transient result or hint in `--accent-light`; the detail returns when the application clears it. |
| Problems | Right of the detail | A 14 px line icon (`STATUS_ICONS`: a rounded triangle with an exclamation mark for warnings, a circle with one for errors; 1.25 px line, `currentColor`) and the unseen count in tabular numerals, 5 px apart, shown only while unseen problems exist. The colour is `--warning`, or `--error` when the worst unseen problem is an error; a text glyph or an emoji is never used. A click shows Messages and marks the problems as seen. Tooltip and accessible name: `<n> new problem(s). Click to show Messages.` |
| Readouts | Far right | Values of the application such as `Grid 16` and `44%`, in a fixed order, in `--text3`, with a space before units. |

The detail is announced politely to assistive technology. With no document open the bar remains in place and its contents are hidden. Normal running states never use `--warning` or `--error`.

### Tiles

A tile is a titled content region inside a pane (for example a code tile beside a preview tile). Tiles share the width of the pane and do not nest.

| Part | Specification |
|---|---|
| Surface | `--well` for the whole tile; the head has no separate fill |
| Head | 32 px high, 10 px left and 8 px right padding, 6 px gap: a title on the left (weight 600, 11 px UI, `--text`), a flexible space, and an optional readout on the right (10 px mono, `--text2`, no wrapping) |
| Divider | A 1 px `--separator` splitter between tiles that can be dragged |
| Size | Each tile is at least 220 px wide, and a narrower pane scrolls sideways; shares are saved as an application preference and restored |
| Loading | A loading tile keeps its previous content. The head readout names the work (`Building…`, `Updating…`) in `--accent-light` and returns to `--text2` when it ends. No spinner, skeleton block or tile-specific colour is used. |
| Stale | A notice strip lies over the top of the tile without hiding the content: `--raised` fill, 1 px `--separator` border, 4 px radius, 12 px UI text in `--text` |
| Empty | One centred sentence in `--text3` |
| Failure | The reason goes to Messages and the status bar; the readout may read `Failed`, with `--error` for that word only |

## 7. Terminal and commands

The exact rules of each command's registry entry, forms and help, and the shared commands, are in [TERMINAL.md](TERMINAL.md); this section gives the Terminal itself and the layout of help.

Terminal is the command console of an application and not an operating-system shell. It starts with the decorative text wordmark of the application, a one-line purpose followed by `v<VERSION>`, the line `Type help to list commands.` and a `> ` prompt. The wordmark and the prompt use the accent, an echoed command uses bold `--text`, and explanations use `--text2`. The text is selectable, and the input has autocapitalisation and spellcheck switched off. The default font is 12 px/1.4 mono, and the font-size setting is clamped to 10 to 24 px. The region, the output log, the status and the input have accessible names, and new output is announced politely.

The command verbs are lowercase. The bare `help` overview begins `help <command> for details. <value> required; [value] optional.` and then shows categories with initial capitals: `File`, `Edit` and `View` first when present, then the domain categories in menu order, then categories outside the menus such as `Analysis`, and `Console` last for `help`, `history` and `clear`. Within a category the rows are sorted by bare verb.

| Subject | Specification |
|---|---|
| Overview row | Only the lowercase command verb and one short sentence describing its purpose; no syntax, arguments, placeholders, subcommands, choices, pipes or bracketed options appear in the command column. `theme` is shown instead of `theme [dark|light]`, `insert` instead of `insert section|figure|table`, and `edit` instead of `edit <path>`. The full syntax is stored in the registry and rendered only by `help <command>`. |
| Detail view | The accepted forms, choices, notes and an example. A subcommand may have its own topic (`help plot scale`). `<value>` is required and `[value]` optional. |
| Overview layout | One column below a Terminal container width of 900 px and two columns from 900 px, with a 3ch column gap. A category heading has 0.7em of top spacing and is bold 12 px mono `--text`. A row has a command label column of at least 12ch (or the longest verb plus 1ch, whichever is wider) followed by a muted description. A bare verb is bold 12 px mono `--accent` and a description 12 px mono `--text2`. A row stays within one column, and the description wraps. |
| Detail layout | One column with muted syntax and choice rows and `Example` last |
| Registry | The command registry drives validation, help and Tab completion; compatibility aliases are accepted but absent from the main help list |
| Errors | Invalid syntax shows the valid forms (see Help text); a document-only command without a document answers `Open a <document noun> first.` with the noun of the profile |
| State | A query form reports state without changing it, and a mutation reports the resulting state; binary states are `on` and `off` |

### Standard items

Every standard action has one menu label, one key and one Terminal command, the same in every application (`STANDARD_ITEMS`). An application builds its menu items with `standardItem(action)` and never writes their labels or keys itself; it chooses only which standard items it has. `checkShortcuts` reports a standard action on any other key.

| Action | Menu item | Key (macOS; Ctrl for Cmd on Windows) | Terminal |
|---|---|---|---|
| `file.new`, `file.newWindow` | New `<noun>`, New window | Cmd+N, Shift+Cmd+N | `new` |
| `file.open` | Open… | Cmd+O | `open` |
| `file.save`, `file.saveAs` | Save, Save as… | Cmd+S, Shift+Cmd+S | `save`, `save as` |
| `file.print` | Print… | Cmd+P | `print` |
| `file.close` | Close | Cmd+W | `close` |
| `app.settings` | Settings… | Cmd+, | |
| `edit.undo`, `edit.redo` | Undo, Redo | Cmd+Z, Shift+Cmd+Z | `undo`, `redo` |
| `edit.cut`, `edit.copy`, `edit.paste` | Cut, Copy, Paste (roles) | Cmd+X, Cmd+C, Cmd+V | |
| `edit.duplicate`, `edit.delete` | Duplicate, Delete | Cmd+D; Delete shown as ⌫ on macOS and Delete on Windows, handled by the application | |
| `edit.selectAll` | Select all (role) | Cmd+A | |
| `edit.find`, `edit.findNext`, `edit.findPrevious` | Find…, Find next, Find previous | Cmd+F, Cmd+G, Shift+Cmd+G | |
| `edit.replace` | Replace… | Option+Cmd+F on macOS, Ctrl+H on Windows | |
| `edit.goToLine`, `edit.toggleComment` | Go to line…, Toggle comment | Cmd+L, Cmd+/ | |
| `arrange.bringForward`, `arrange.sendBackward` | Bring forward, Send backward | Cmd+], Cmd+[ | |
| `arrange.bringToFront`, `arrange.sendToBack` | Bring to front, Send to back | Shift+Cmd+], Shift+Cmd+[ | |
| `view.zoomIn`, `view.zoomOut` | Zoom in, Zoom out | Cmd+=, Cmd+- | `zoom in`, `zoom out` |
| `view.fit` | Fit | Cmd+0 | `fit` |
| `view.actualSize` | Actual size | Cmd+1 | `zoom actual` |
| `view.inspector`, `view.bottomPanel` | Show inspector, Show bottom panel (checked) | Cmd+I, Cmd+J | `inspector`, `panel` |
| `view.fullScreen` | Toggle full screen (role) | the platform's own: Ctrl+Cmd+F on macOS, F11 on Windows | |
| `tab.next`, `tab.prev` | Next tab, Previous tab | Ctrl+Tab, Ctrl+Shift+Tab on both | |
| `about`, `about.whatsNew`, `about.shortcuts`, `about.licenses`, `about.updates` | About `<product>`, What's new…, Keyboard shortcuts…, Licenses…, Check for updates… | none | `about`, `changes`, `shortcuts`, `licenses`, `updates` |

An item with a role is performed by the native menu (and by `EDIT_ROLES` in a drawn one); an application that handles the action itself, such as Copy on a canvas, passes `{ role: undefined }`. `arrangeItems(enabled)` gives the Arrange group in its order.

Fit is Cmd+0 and Actual size Cmd+1 in every application, as in Photoshop and Illustrator, so that one key fits the view everywhere. `zoomItems(enabled)` gives the View menu's zoom group in its order: Zoom in, Zoom out, Fit, Actual size. On Windows each key is Ctrl in place of Cmd.

### Shared commands

Every application has the shared Terminal commands of the actions it has (`SHARED_COMMANDS`, `sharedCommands(actions)`). Each runs a menu action by its standard identifier (`STANDARD_ACTIONS`), so a command does exactly what its menu item does, and an application lists only the actions it has; the others' commands do not appear. `runSharedCommand()` runs them, and `sharedHelpGroups()` gives their help groups.

| Group | Commands |
|---|---|
| File | `new`, `open`, `recent [number]` (lists the recent files, or opens one by its number), `save [as]`, `close`, and `autosave` where the settings have it |
| Edit | `undo`, `redo` |
| View | `fit`, `zoom in\|out\|fit\|actual`, `panel`, `inspector`, `theme`, `font [size]` (the Terminal text size, 10 to 24 px, or `bigger` and `smaller`) |
| Help | `about`, `version`, `changes` (What's new), `shortcuts`, `licenses`, and `updates` where the profile names a repository |
| Console | `help`, `history`, `clear` |

`save`, `close`, `undo`, `redo`, `fit` and `zoom` need an open document: on the welcome screen they are not listed, and run they answer `Open a <document noun> first.` An application adds its own commands after these, in its own groups.

**The prompt's caret.** The Terminal prompt draws the shared editor's caret instead of the native one: 1.5 px in the accent, gliding 80 ms between positions and fading in and out over the 1.2 s blink, solid again after each move and while typing. It is shown only while the prompt has the focus, nothing is selected and no command runs. Under reduced motion it jumps and blinks without fading.

### Help text

This subsection is the single rule for how help is written, laid out and coloured. It covers the Terminal `help` command, and its last part covers the command-line help of build and check scripts. Terminal help follows the conventions of command-line help (description, usage, options, defaults, a pointer to more), adapted to an application console in which commands are words and not flags.

**The three views.** Help has three outputs, all set in 12 px mono (`--console-size`) inside the Terminal.

| View | Command | Content |
|---|---|---|
| Overview | `help` | One legend line, then categories of bare verbs with one-line descriptions |
| Detail | `help <command>`, `help <command> <subcommand>` | Syntax forms, choices, notes and one example |
| Usage error | Any command typed with bad arguments | The valid forms, then a pointer to the detail view |

**Aliases.** `<command> -h`, `<command> --help` and `<command> ?` mean `help <command>`, and `-h` and `--help` alone mean `help`. Applications map them with `helpAlias()` of the shell. Aliases are accepted and never listed.

**Syntax notation.** A syntax string consists of the verb followed by its parts, separated by single spaces.

| Notation | Meaning | Example |
|---|---|---|
| `verb` | A literal lowercase word | `plot`, `list` |
| `<name>` | A required value | `open <file>` |
| `[<name>]` or `[name]` | An optional value | `history [number]` |
| `<name>...` | A required value that may repeat (rare) | `open <file>...` |
| `[<name>...]` | Any number of values, including none | `close [<tab>...]` |
| `a \| b` | A choice between literal words; listing them as choices is preferred | `on \| off` |

A placeholder name is a short, descriptive, lowercase word or hyphenated words (`<number>`, `<part>`, `<file-name>`); it names the kind of value and never an example of one. Literal words inside a form, such as `vs` or `in`, are not bracketed, which is why placeholders keep their angle brackets. `[options]` is not used: commands take subcommands and values and not flags. `checkCommandSyntax()` tests a syntax string against these rules, and every registry entry is expected to pass it.

**Overview layout.**

| Element | Specification |
|---|---|
| Legend line | Exactly `help <command> for details. <value> required; [value] optional.`, in `--text2` |
| Categories | In the order of section 7: `File`, `Edit`, `View`, application categories in menu order, other categories, `Console` last; empty categories are omitted |
| Category heading | The category name with an initial capital, bold `--text`, 0.7 em of space above; nothing follows it on its line |
| Row | One row per command, sorted by bare verb: the verb in bold `--accent`, padded to a shared column of at least 12 characters (or the longest verb plus 1 character, whichever is wider), then ` - ` and a description in `--text2` |
| Content of a row | No syntax, arguments, choices or brackets; the description wraps within its own column and the verb never wraps |
| Columns | One column below a Terminal width of 900 px and two columns from 900 px, with a gap of 3 characters; a row never splits across columns |

**Detail layout.** One column, without blank lines, in the following order.

| Order | Element | Specification |
|---|---|---|
| 1 | Syntax forms | One per line from column 0, in `--text2` at normal weight; a form with a description carries it after ` - `, also in `--text2`; several forms are padded to a common label width so that the dashes align |
| 2 | Choices | One per line, indented 3 characters: label, ` - `, description, padded to the widest choice label. The default choice ends its description with `(default)`, and without a description the row reads `label - (default)`. |
| 3 | Notes | Each a complete sentence on its own line from column 0, ending with a period |
| 4 | Example | Last, at most one: the label `Example`, ` - ` and a realistic command |

A subcommand with its own topic (`help plot scale`) shows only its own forms.

**Usage errors.** Bad arguments print `Invalid arguments. Usage:`, then every valid form indented 3 characters in the detail style (label, ` - `, description, aligned), then `Type help <command> for details.` The argument typed by the user is not repeated, and no stack trace or internal name is shown. A document-only command without a document answers `Open a <document noun> first.` instead.

**Wording.**

| Element | Rule |
|---|---|
| Descriptions | Short fragments of one line (about 70 characters or fewer): initial capital, no final period, beginning with a verb in the imperative (`Stack all scopes in one column`); they state what the command does and not how |
| Notes, errors, results | Sentences with a final period |
| Verbs, choices, placeholders | Lowercase; identifiers and file names keep their case; units are preceded by a space (`5 µs`) |
| Terms | One name for each concept across menu, toolbar, inspector, Terminal and help |
| Booleans and queries | `on` and `off`; a query form reports state without changing it |

**Colour, weight and indentation.** Help uses no other colours than those below, and never `--warning`, `--error`, underlining or uppercase. The only indent is 3 characters per level (`indent: 1` in a list item): choices and the forms of a usage error use level 1, and everything else starts at column 0.

| Element | Weight | Colour |
|---|---|---|
| Legend line, descriptions, syntax forms, choices, notes, `Example` | Normal | `--text2` |
| Category heading | Bold | `--text` |
| Command verb in the overview | Bold | `--accent` |
| Echoed command above the output | Bold | `--text` |
| First line and pointer line of a usage error | Normal | `--text2` |

**Welcome screen.** With no document open, help lists and details only the commands that run without one, in the same layout; a document-only topic answers `Open a <document noun> first.`

**Command-line help of scripts.** Build, check and release scripts (such as `forge-shell`) are programs and follow the usual command-line form: `-h` and `--help` print the help to standard output and exit with 0, and missing or wrong arguments print the help to standard error and exit with 2.

| Order | Section of the help |
|---|---|
| 1 | A one-sentence description of the program |
| 2 | `Usage: <name> command [options]` |
| 3 | `Commands:`, each with a short description |
| 4 | `Options:`, with the `-s, --long` forms on one line (short form first), the value name after the option and `(default: ...)` where one exists |
| 5 | `Environment:`, listing the environment variables that change behaviour |
| 6 | One line pointing to the detailed documentation |

Descriptions are aligned in one column and written as sentences with a final period, placeholders are lowercase `<value>`, and the whole text is narrower than 80 columns. `forge-shell --help` (`scripts/cli-help.mjs`) is the reference.

### Terminal with no document or project open

Terminal is selected and initialised on the welcome screen. It is not blank: it shows the same ASCII wordmark, purpose and version line, `Type help to list commands.`, selectable transcript area and `> ` input as with an open document. `clear` removes only transcript entries, and the banner, the prompt and the command history remain. The Terminal tab stays enabled while the document-only bottom tabs and inspector controls are dimmed.

| Subject | Specification |
|---|---|
| Overview in this state | Lists only the commands and forms that can run without a document. The shared minimum is `help`, `clear` and `history`, with `new` and `open` for applications that create and open documents; application-level appearance, settings, status and import commands are added only when they work in this state. The normal initial-capital headings and bare lowercase verbs are kept, and empty categories are omitted. File edits, builds, analyses and document-view commands are not shown until their document exists. |
| Document-only command | `help <command>` and execution answer `Open a <document noun> first.` with the noun of the profile |
| Completion | The empty prompt offers only the verbs and forms available on the welcome screen and no document-only choices. A command with application-level and document-level forms lists and completes only its application-level forms here. |
| Profile | Enumerates the exact welcome command set, the allowed forms, the response text and the completion behaviour; availability is not inferred from the existence of a menu item |

| Input behaviour | Specification |
|---|---|
| Keys | Enter submits; Up and Down traverse the command history; Tab inserts a sole completion or prints the alternatives; Esc leaves the input; Ctrl+C cancels a busy, cancellable command. |
| Busy state | During work the output is marked busy and the input is read-only. |
| History | At most 100 unique commands; a repeated command moves to the end. History belongs to the current document or session, is not saved, and is cleared when a different document opens. `clear` clears the transcript and preserves banner and history; `history`, `history <number>` and `history clear` manage the history. |
| Results | Console answers stay in Terminal and are not duplicated as status notifications. |

`help`, `clear` and `history` are shared verbs. Document-based applications use `new`, `open`, `save`, `export`, `tabs`, `tab`, `close`, `undo` and `redo` where the operations exist. Every other verb and its grammar belongs to the profile of the application, and circuit or LaTeX commands are not copied between applications merely to fill a catalogue. Names containing spaces are quoted, and command and file identifiers and technical abbreviations are preserved in results.

### Application-wide controls and commands

An application-wide command changes a window or a saved preference without modifying the open document. The inspector, the bottom-panel visibility, the selected utility tab, the appearance and the Terminal history are distinct states. The menu item, the shortcut and the Terminal command invoke the same state-changing operation. The shared forms below are implemented in every Forge application, since the inspector and the bottom panel are required controls of the shell. The profile lists every additional application-wide command with its exact forms, availability without a document, completion choices, output text and persistence. Domain commands such as a solver command or a build control are not shared merely because they can run without a document.

| Control | Terminal forms | Menu and keyboard | Shared behaviour |
|---|---|---|---|
| Inspector | `inspector`, `inspector on`, `inspector off`, `inspector left`, `inspector right` | View › Show inspector, checked while visible; `CmdOrCtrl+I` toggles | The bare verb toggles visibility; `on` and `off` set it explicitly and are idempotent; `left` and `right` set the side and show the inspector. Side and visibility are application preferences. Without a document the inspector may be shown, but its document controls are dimmed and inert. |
| Bottom panel | `panel on`, `panel off`, `panel <pane>` | View › Show bottom panel (an application may name its utilities in the label), checked while visible; `CmdOrCtrl+J` toggles | `on` shows the panel with its previously selected utility; `off` hides the entire panel without clearing the Terminal output or changing the selected utility; `panel terminal` shows the panel and selects Terminal; `panel <pane>` shows the panel and selects that pane of the profile when usable. A click on a bottom tab selects it, and an unavailable tab is disabled. Visibility is an application preference and the selected utility a session state. A bare `panel` is invalid. |
| Appearance | `theme <appearance>` | View › Appearance, one checked choice | Every application accepts `dark` and `light`. Applying an appearance updates the preference and all open views, and `theme` without a value reports the current appearance. |
| Terminal history | `history`, `history <number>`, `history clear`, `clear` | Terminal input; a Clear control for the transcript is optional | `history` lists the previous commands, a non-negative count limits the listing, `history clear` empties the history and `clear` empties only the transcript. Neither operation closes or hides Terminal, removes its banner or changes documents. |
| Help | `help`, `help <command>` | Terminal input; the Help menu may link to documentation | `help` lists only the bare verbs currently available, in initial-capital categories; the detailed form shows valid syntax and choices. Availability is checked against the state of the active document before completion is offered. |

The platform display of shortcuts is `⌘I` and `⌘J` on macOS and `Ctrl+I` and `Ctrl+J` on Windows. These are View actions and not text typed into Terminal. The checked menu state mirrors visibility and not the existence of a document. Showing and hiding a panel uses the 150 ms width or height and opacity transition of section 5, and a closed pane and its splitter become hidden and inert; selecting a utility starts no further transition when the panel is already visible. Terminal commands report their results in Terminal only.

| Result | Text |
|---|---|
| Inspector visibility | `Inspector enabled.`, `Inspector disabled.`, `Inspector is already on.`, `Inspector is already off.` |
| Bottom-panel visibility | `Bottom panel enabled.`, `Bottom panel disabled.`, `Bottom panel is already on.`, `Bottom panel is already off.` |
| Panel selection | `Showing terminal panel.`; with differently named panes, `Showing <lowercase pane name> panel.` |
| Inspector side | `Inspector moved to the left.`, `Inspector moved to the right.` |

The detailed topics `help inspector` and `help panel` enumerate these forms, whereas the bare `help` shows only `inspector` and `panel`.

## 8. Listings and reports

Lists and tables are produced with structured result types and are numbered from 1. A marker occupies six monospaced characters and is followed by exactly three spaces and the label. The number formula is `("[" + n + "]").padStart(6) + "   "`, and the state formula is `" ".repeat(Math.max(1, 6 - marker.length)) + marker + "   "`.

```text
   [9]   Item nine
  [10]   Item ten
 [100]   Item one hundred
  [on]   Enabled setting
 [off]   Disabled setting
```

| Element | Rendering |
|---|---|
| Numbers and enabled `[on]` | Bold `--accent` |
| `[off]` | Normal `--text2` |
| Enabled and numbered labels | Bold `--text` |
| Disabled labels and explanations | `--text2` |
| Numbered table | Marker in the accent, primary name bold `--text`, later fields `--text2` |
| Columns | Numeric columns are right-aligned and text columns left-aligned; wide tables scroll horizontally |
| Help and About | Command names in the accent with muted descriptions; the numbered rows of About and What's new use the same marker column and accent colour |
| Empty result | A statement of what is empty, such as `No messages.` or `No commands yet.` |

## 9. Status, Messages, errors and tips

The status bar displays the state of the application, a flexible readout and result field, the count of unseen problems and secondary readouts defined by the application. The result of an action appears in `--accent-light` for 4000 ms and is also added to the Messages log of the active document. The ordinary readout uses `--text2`, and a warning or error count uses `--warning`; a click on it opens Messages. The profile defines the state words and any domain-specific dot colours or measurements.

Messages belong to the active document, are limited to the session and retain the latest 500 entries, the newest last. Each row has the local time `HH:MM:SS`, the kind (`Info`, `Warning`, `Error`) and the text, in a grid with columns `9ch 8ch minmax(0,1fr)`. Info does not increment the count of unseen problems, whereas Warning and Error do, and opening Messages resets it. A referenced object name is an accent link that selects or opens the object. A standing condition is logged once when it appears, under a stable condition key, with a quiet period of 30,000 ms before a flickering condition is repeated. Clear empties the log and the count.

| Event | Destination |
|---|---|
| Result of a user action | Status for 4000 ms and Messages as Info |
| Failed action or document or run problem | Messages as Error; the status counts it |
| Degraded but usable state | Messages as Warning; the status counts it |
| Invalid inspector input | Status and Messages as Error; the inspector size remains fixed |
| Invalid dialog input | Beside the field |
| Terminal command result or invalid command | Terminal only |
| Short usage guidance | Tooltip of the relevant control |

A message states the result or problem first and then a recovery action when one is known. Each sentence has one purpose and a final period, and the same technical term is used everywhere. Saved, Built or Verified is not reported before it has happened. Tooltips are one short sentence, with a second only for an essential condition, and standing explanatory prose is kept out of compact inspector sections when a tooltip gives the guidance needed.

## 10. Dialogs, accessibility and persistence

A focused dialog serves a decision or a longer input. Wrong input is shown beside its field, the primary and cancel actions are distinct, and focus is restored on closing. An About window uses the neutral `--panel` and `--raised` surfaces, an accent wordmark, sentence-case headings, the credits and licensing of the application and the shared numbered-list format. What's new reads the section of the current version in the changelog and falls back to the newest section only when the current one is absent; an unavailable message is shown when neither exists. The third-party assets and licences actually used are documented in the `NOTICE.md` of the application.

| Subject | Specification |
|---|---|
| Controls | Real buttons and inputs, accessible names for icon-only controls, visible focus rings, `aria-expanded` for folds and flyouts, `aria-live` for Terminal and status output, and text or icon state alongside colour |
| Keyboard | Editing shortcuts leave text fields usable. Menus show `⌘`, `⌥`, `⇧`, `⌃` and `⌫` on macOS and the Ctrl equivalents on Windows; text that names a key writes it out (`Esc`, `Return`, `Cmd + Delete`), never as `⎋`. The profile records exact shortcuts and platform exceptions. |
| Files | Desktop file operations use native dialogs. A browser edition documents its file-access limits and does not claim a save when only a download started. |
| Tests | `tests/conformance/accessibility.mjs` checks the shared focus styles, live output hooks and reduced-motion paths. Interface tests of an application exercise its icon names, tab navigation, flyouts, focus return and announcement text with the renderer running. |

### Remembered settings

A value is stored in exactly one of three places and never in two.

| Place | Holds | Lifetime |
|---|---|---|
| Application preferences | How the application looks and is set up: appearance, panel visibility and sizes, font sizes, the view options and units of the application | Every launch and every window, with or without a document |
| The document | Data, and any view setting that must reopen with it (for example a saved zoom or trigger) | The file |
| The session | Everything transient | Until the window closes |

**Shell preferences.** Every Forge application keeps the following values as preferences.

| Value | Default | Rule |
|---|---|---|
| `appearance` | `dark` | `dark` or `light`; applied before the first paint, so that the wrong theme never flashes |
| `showInspector`, `inspectorSide` | visible, right | Written by `inspector on\|off\|left\|right` and View › Show inspector |
| `inspectorWidth` | 246 px | Clamped to 246 to 420 px when loaded and dragged (`panelSize`) |
| `showBottomPanel` | visible | Written by `panel on\|off` and View › Show bottom panel |
| `bottomPanelHeight` | 246 px | Clamped to 246 to 640 px when loaded and dragged (`panelSize`); a short window shrinks a taller panel, never below 246 px |
| `terminalFontSize` | 12 px | Clamped to 10 to 24 px |

A splitter stores its size when the pointer is released, and a double click restores the default and stores it.

| Category | Content |
|---|---|
| Application preferences | The `Persistence` row of the profile lists every other preference by name, with default and valid values. The inspector sections are listed there too, each marked persistent or not: a persistent section keeps its folded state as a preference, and a non-persistent one returns to its default at every launch. |
| Session only | Never stored: the selected bottom pane (Terminal at launch and whenever a document becomes active), the active document tab, selection, hover, undo history, Terminal command history and the Messages log. Terminal history belongs to the open document and is not written to disk. |
| Not remembered | Window size and position are not a shell preference, and no Forge application restores them by default; an application that does records this in its profile. |

**Storage.**

| Step | Behaviour |
|---|---|
| 1. One object, one key | Preferences form a single JSON object under `<id>.settings` (`settingsStorageKey`), written through `createSettingsStore`. The whole object is written after each change and listeners are notified. |
| 2. Loading | The defaults are overlaid with the stored object through the `restore` function of the application. A missing or invalid value falls back to its default, and a key the application no longer defines is dropped, so that removed settings do not accumulate. |
| 3. Unavailable storage | Private mode, blocked site data or a command-line run: the application runs on its defaults for that session and shows no error. |
| 4. Renaming or changing a preference | `restore` maps the old name or value to the new one; the choice of a user is never silently reset by an update. |
| 5. Applying | Preferences apply with no document open, and the shell restores the appearance before the pre-paint script of the application (`prePaintScript`) runs. |

The profile of an application fills in the `Persistence` row with its own values, and this section is the only place that defines the shared ones.

## 11. Localhost preview

When a Forge application is created, migrated or changed, its author runs the browser preview of the application on the local machine and opens the printed `http://127.0.0.1:<port>/` URL to inspect the actual interface. This is a rule of development and verification and not a requirement to run production data or a model on a local server. A source HTML file, a screenshot, a successful TypeScript check or an Electron build alone does not count as a running preview.

| Subject | Specification |
|---|---|
| Entry point | Every Forge repository supplies `npm run web`. It builds the renderer into `build/app`, starts an HTTP server bound to `127.0.0.1` only (never `0.0.0.0`, and never published as a remote site) and prints the complete local URL once the server is listening. |
| Port | The default port is recorded in `documentation/DEVELOPMENT.md` of the application; `PORT=<port>` overrides it locally so that several applications can run simultaneously. An existing preview script may remain as an alias of `npm run web`. |
| Served content | The built `build/app/index.html`, with its CSS, JavaScript and static assets, over HTTP. The server process stays alive while the interface is inspected or changed. After an edit the build is rebuilt and the browser reloaded (automatically or explicitly), and the response is checked to be the new build and not a stale page. |
| Port conflicts | An occupied default port leads to inspecting the existing process or choosing another `PORT`; the server of another application is not silently replaced. A server that was started for the work is stopped afterwards unless the user is using it. |
| Shared code | The preview uses the same renderer, shared shell, styles, fonts, icons, tab, inspector, menu and Terminal components and appearance tokens as Electron. Browser-only file-system and operating-system behaviour sits behind a typed local adapter, and fixture data and unavailable desktop operations are labelled honestly. File pickers and downloads may replace native dialogs, but `Saved`, `Built` or `Verified` is not reported for a simulated desktop operation. |
| Electron | Native menus, file associations, operating-system dialogs, packaging and platform behaviour are checked in the actual Electron application; a localhost screenshot cannot establish them. |

For a visual change, the local URL is opened and the affected state is checked at the default desktop window size and in a narrower view: the welcome state and Terminal help without a document, an open document, Dark and Light, the relevant tabs, menus and inspector, and the result of the changed action. The rendered page is captured or inspected after the build, and CSS is not judged from source alone. The work report records the URL, the build and check result, the views actually inspected and any difference between browser and Electron. When the preview cannot be run or opened, this is stated plainly and no visual verification is claimed.

### Identical npm entry points and build locations

Every Forge application exposes the same script names with the same meanings, and the engine of an application supplies its own tests and bundled code behind them. The `web` and `dev` scripts run until stopped. `build` produces the renderer, the Electron main and preload bundles and the engine entry; `start` runs a built desktop application; `dist` packages it; and `checks` runs the complete automated gate, including `check`, `test` and `test:app` and any accuracy or compatibility checks of the engine. No application renames a command to `web:preview`, `typecheck`, `package` or another private spelling as its only entry point.

```json
{
  "scripts": {
    "build": "node scripts/build.mjs",
    "check": "tsc --noEmit -p .",
    "test": "<application engine tests>",
    "test:app": "<application interface tests>",
    "checks": "<complete application gate>",
    "web": "node scripts/web.mjs",
    "dev": "node scripts/web.mjs --desktop",
    "start": "npm run build && electron .",
    "dist": "npm run build && electron-builder --publish never --config.electronDist=./node_modules/electron/dist"
  }
}
```

The script names and shared command bodies are copyable, and the three angle-bracket values are the only engine and test adapters in the block, replaced in each application. The output paths are identical in all applications.

```text
build/
├── app/
│   ├── index.html
│   ├── app.js
│   ├── app.css
│   └── ...                 # assets and optional workers or preview adapter
├── desktop/
│   ├── main.cjs
│   └── preload.cjs
└── engine/
    └── index.cjs
```

The browser preview and the packaged Electron application load the same `build/app/index.html` with its `app.js` and `app.css`. The generated `build/` content is ignored by Git. An application-specific command-line tool may add another output under `build/` but does not rename the shared files. The profile records extra workers and assets and the test commands of the engine, and every application emits these shared paths, while the engine bundles differ in their computation.

## 12. Implementation and review gate

| Subject | Requirement |
|---|---|
| One operation | Menus, toolbar, keyboard and Terminal invoke one underlying action for the same behaviour, and the registry and the interface labels stay in step. |
| Separation | File-system and operating-system calls are behind a typed Electron preload API, and domain computation is separate from the renderer and the main process where practical. |
| Controls of an application | For every application-specific control the profile gives its identifier, location, label and case, dimensions, colours in all themes, enabled, selected and focus states, tooltip, keyboard action, motion, result and error text, and persistence. |
| Commands of an application | For every application-specific command the profile gives its syntax, examples, validation, completion, output layout, cancellation and behaviour without a document. |
| Verification | Dark and Light, the initial and reduced-motion states, all tab, inspector and panel transitions, list spacing, colour and case, the Terminal banner, help and completion of the welcome state, message routing, keyboard focus, the unsaved-close flow and the packaged Windows launch are verified. The built Electron application or the served `build/app` bundle is run for interface checks, since opening `source/app/index.html` directly does not load its generated `main.js`. Actual checks are recorded and results are not inferred. |

The shared guide is complete only together with an application profile and the source-backed domain documentation of that application. The interface reference of an application demonstrates how one implementation is pinned to exact source files. Before the guide is used for a migration, the profile of the target application is written and verified against its current behaviour and the desired changes.

## 13. Context menus, tooltips and unit fields

The behaviours of this section were added after the first applications shipped, and every Forge application uses them as written.

### Context menu

One implementation (`showContextMenu` in `source/app/context-menu.ts`, with `showFieldPopover` for panels of typed values) uses the popup surface and item styling of the browser menu bar (section 6) and is mounted in the overlay root.

| Part | Specification |
|---|---|
| Entries | A label; an optional check column (12 px, present only when some entry of the popup has a `checked` value); an optional shortcut at the right; an optional submenu marker `›`; a non-interactive header row; a separator |
| Separator | 1 px `--hairline`, margin 4 px 6 px |
| Disabled | An entry without action and submenu: `--text3`, no hover fill, no action |
| Hover | `--accent-fill` with `--accent-foreground`, including the shortcut and the submenu marker |
| Submenu | Opens to the right of its row on hover or click, offset 2 px left and 4 px up; moving to a sibling row closes it |
| Dismissal | Esc, a press outside every open popup, or the choice of an entry; opening another context menu dismisses the open one |
| Contents | The caller passes a list or a function; a function is evaluated when the menu opens, so that the state is current |
| Explanation | The tooltip of an entry is its native `title` |

The implementation was reviewed on 2026-10-15, with the following results.

| Behaviour | Result |
|---|---|
| Clamping | A popup and its submenus remain inside the viewport at the right and bottom edges (4 px margin). |
| Keyboard | The arrow keys, Home and End move focus through the enabled entries; Right opens a submenu and Left returns to its parent; Enter and Space choose an entry. Escape returns focus to the opener, and an outside click leaves focus with the control clicked. |
| Field popover | An invalid value is shown beside the field and the field is focused; the red border and the tooltip remain as additional cues. |

### Tooltips

Tooltips are the native `title` attribute. No custom tooltip component exists, so delay and placement follow the operating system. The wording rules of section 9 apply: one short sentence, and a second only for an essential condition. The tooltip of an icon button names the action and its shortcut. A custom tooltip, if introduced, replaces this rule for every application in one change.

### Unit fields

`createUnitField` supplies the shared field layout and commit behaviour, and the application supplies its formatter and parser, such as `si(value, unit)` and `parseSI(text, unit)` in an editor application. The unit stands inside the value of the field (`5 µs`, `4.7 kΩ`) and never in a second label. A bare number typed in the field takes the unit of the field. A value that does not parse is an error under the inspector rule of section 9: it is reported in the status bar and in Messages, the field returns to its last valid value, and the inspector does not change size.

## 14. Shell architecture

Every rule above is implemented once, in the shared package `forge-shell`, and applications consume it at a pinned version. This section is the standing contract.

| Belongs to the shell | Belongs to the application |
|---|---|
| Tokens and the three themes; the frame (tool strip, tabs, panels, splitters, status bar, welcome state) | Product identity, icon capital, wordmark, brand accents |
| Menu renderer, shortcut display and matching, context menu, native menu construction | Domain menus and their actions |
| Terminal, Messages, help rendering, shell verbs, completion | Domain command registry |
| Dialog base, save prompts, About, What's new, Shortcuts and Licenses frames | Credits, licence text, introductory prose |
| Inspector sections and widget kit | Inspector contents |
| Preferences mechanism and shell keys | Preference keys of the application |
| Document lifecycle (new, open, save, `Untitled n`, dirty state, close) | Document model, format, export formats |
| Electron main helpers, packaging configuration, reusable workflow, icon generator, version tooling | IPC handlers and domain scripts of the application |
| Conformance tests | Domain tests |

An application describes itself to the shell in two places.

| Place | Content |
|---|---|
| `forge.config.json` (read at build time by the scripts of the shell) | `identity` (name, id, purpose, wordmark path, version source, port); `document` (nouns, extension, welcome labels, tab nouns, `containsMultipleFiles`; `null` for none); `theme` (the Dark accents and any Light overrides); `html` (the markup files of the centre and the domain panes); `prePaintScript` (optional script run before the first paint); `desktop` (application identifier, copyright, icons, file association, extra resources, installer artwork and family name); `dataColors` (colours that carry data, exempt from the colour lint) |
| A runtime profile object (`ForgeRuntimeProfile` in `source/app/profile.ts`) | The menu builder and menu commands, the console command catalogue, the inspector sections and the order of the bottom panes, handed to the shared renderers |

For an application without saved documents, `document` is `null`, `desktop.document` is omitted, and its permanent centre view is placed in `html.center`. A minimal monitor profile is given below; the accent values are examples that pass the shared contrast gate.

```json
{
  "identity": { "name": "MonitorForge", "id": "monitorforge", "purpose": "system monitor", "wordmarkPath": "logo.txt", "versionSource": "VERSION", "port": 5175 },
  "document": null,
  "theme": {
    "dark": { "accent": "#7b90df", "accentFill": "#3c56aa", "accentHover": "#344c98" }
  },
  "html": { "center": "public/center.html", "panes": "public/panes.html" },
  "desktop": { "appId": "com.monitorforge.app", "copyright": "Copyright 2026 MonitorForge" }
}
```

Its runtime profile can provide `panes: ["terminal", "metrics", "messages"]` and no document actions. The page keeps the shared tab slot empty and renders the centre view immediately.

| Rule of the boundary | Content |
|---|---|
| Imports | The shell never imports application code. An application imports only `forge-shell/app`, `forge-shell/desktop/*`, `forge-shell/styles/*` and the listed `forge-shell/scripts/*` exports. |
| New needs | A need that the profile cannot express becomes a new shell option for every application, and not an override of shell internals in an application. |
| Versions | A shell change that alters behaviour is a minor or major version and appears in the changelog of the shell. |
| Tests | The shell carries its own tests (`tests/conformance`): the `.ts` tests are portable and read no files, so that an application can bundle and run them; a test that reads the shell's own files (its stylesheet, its scripts) is an `.mjs` test and runs in the shell only (`the portable conformance tests read no files, so that an application can run them bundled`). An application demonstrates correct use with `forge-shell check-app` (script `test:shell`) and by bundling the tests of the shell from `node_modules/forge-shell/tests/conformance` in its own `test:app`. |
| Style lint | `forge-shell check-app` lints `public/app.css` and `source/` of the application for raw colours, font sizes outside 10, 11, 12, 13 and 15 px, font weights outside 400, 600 and 700, `text-transform: uppercase`, inline font or colour styles, `!important`, unnamed icon-only buttons, icon strokes other than 1.25 px and direct `.title` assignments. Colours that carry data (scope traces, editor syntax) are listed under `dataColors`. Problems are warnings; `FORGE_STYLE_LINT=error` makes them errors. |

### Generic boundaries

These were application-specific assumptions inside shell code, and each now takes its content from the application.

| Where | Before | Now |
|---|---|---|
| `status-bar.ts` | `Running` and `Paused`, `time`, `grid`, `cursor`, `zoomPercent` and fixed colours | The shell renders the bar and the problem count; the application supplies `stateLabel`, `stateColor`, `summary`, `detail`, `hint` and a list of `readouts` |
| `workspace-keys.ts` | `partKey`, `spaceDown`, `spaceUp`, `nudge`, a fixed `edit.delete` | The shell handles text fields, Esc and menu shortcuts; the application handles its own keys through `domainKeyDown` and `domainKeyUp` |
| `templates/app/index.html` | `whiteBackground` and the `paper` class in the pre-paint script | The shell restores the appearance, and the script of the application (`prePaintScript` in `forge.config.json`, `public/prepaint.js`) applies its settings |

### Remaining integration requirement

| Where | Requirement | Direction |
|---|---|---|
| Generated workflows | The `test:shell`, `check-release.mjs --mac` and `--win` scripts of the application must exist | Documented as required application scripts in UPDATING.md |

## 15. Boundary checklist

The following must not appear in shell code. The first extraction removed all of them from the shell modules, and each new module is checked against the list before it is added.

| Category | Must not appear in shell code | Belongs to |
|---|---|---|
| Identifiers | A product name or id (`exampleforge`), storage keys, environment-variable prefixes, temporary prefixes, `appId`, ports | `forge.config.json`; storage keys come from `settingsStorageKey` and `terminalHistoryStorageKey` |
| Strings | Domain nouns (`circuit`), taglines, About credits, window titles | `forge.config.json` and the About data of the application |
| Document behaviour | A file extension, native format, export list, save filter | `document` and `desktop.document` of `forge.config.json` |
| IPC | Domain channels (`models:*`, `console:*`) | The `main.ts` of the application, registered beside `registerShellMainIpc` |
| Imports | Anything from the engine, library, palette, settings or domain modules of an application | Data and callbacks are passed instead |
| Theme | Brand hex values of an application in shell CSS; schematic or data palettes | `theme` of `forge.config.json`; the renderer of the application |
| CSS and HTML | Element identifiers and classes of an application (`schematic`, `scopes`, `paper`) | `public/center.html`, `public/panes.html` and `public/app.css` of the application |
| Scripts | A hard-coded name, port or list of entry points | Read from `forge.config.json`; the application lists its own build targets |
| Headers | A source file without the licence header | The GPL v2 or later header of the shell is added |

`forge-shell check-app` verifies the built page, the brand CSS and the shared stylesheets, and it scans the source of the shell for product identifiers and formats. Broader domain nouns and behaviour are reviewed by hand.

## 16. Package

| Subject | Specification |
|---|---|
| Repository | `forge-shell`, GPL-2.0-or-later, with tags `vX.Y.Z`. The package is source-only: applications bundle its TypeScript with esbuild and `moduleResolution: Bundler`, and there is no `dist` and no `prepare` step. |
| Installation | `github:<owner>/forge-shell#vX.Y.Z` when the CI of the application can read the repository. For a private repository without cross-repository credentials, `npm pack` is run on a clean checkout of the tag, `forge-shell-X.Y.Z.tgz` is kept in the application, and the dependency is `file:source/forge-shell-X.Y.Z.tgz`; the integrity field of the lockfile pins the archive. |
| Exports | `./app` and `./app/*`; `./desktop/main`, `./desktop/preload` and `./desktop/*`; `./styles/tokens.css` and `./styles/shell.css`; `./templates/*`; and `./scripts/*` for `build`, `build-installer`, `cache-key`, `check-app`, `check-release`, `theme`, `package-config`, `dmg-background`, `file-icon`, `version-hook`, `release-notes`, `web` and `serve` |
| Command | `forge-shell check-app`, `package-config` (writes `build/electron-builder.json`), `dmg-background` (draws the macOS disk image window into `build/dmg`), `brand-css` (writes `build/app/forge-brand.css`), `installer`, `licenses` and `release-notes` |
| Version | `VERSION`, `package.json` and the lockfile agree, and `CHANGELOG.md` has a section per version, with migration notes for breaking releases. A published tag is never moved. |
| Workflows | `forge-shell workflows` writes the four build workflows of an application (Build desktop apps, Build for mac, Build for windows, Clear all), which run the checks, the macOS and Windows builds, the Windows launch and installer checks and the gated release. The application supplies the scripts `check`, `test`, `test:app` and `test:shell`, `scripts/check-release.mjs --mac\|--win` and its two Windows PowerShell scripts. |
| Local work | While the shell and an application are edited together, the application points to a local `file:` copy, which is replaced by the pinned tag or archive before committing. |

```text
forge-shell/
├── source/
│   ├── app/                    # frame, tabs, menus, terminal, messages, dialogs, inspector, settings, profile
│   ├── desktop/                # bridge, native menu, window state, file helpers, main IPC
│   └── styles/                 # tokens.css, shell.css
├── scripts/                    # build, serve, web, theme, package-config, check-app, check-release, cache-key, release-notes, version-hook, file-icon, forge-shell (command)
├── templates/
│   ├── app/                    # index.html page template
│   └── new-app/                # the files of a new application (forge-shell new-app)
├── tests/conformance/
├── .github/workflows/          # check-shell, build-package, publish-release, clear-all
├── documentation/              # GUIDELINES, PROJECT-STRUCTURE, UPDATING, DEVELOPMENT, COMPATIBILITY, INSTALLER
└── VERSION  CHANGELOG.md  NOTICE.md  LICENSE  README.md  package.json  tsconfig.json
```

### Disk image window

The macOS disk image opens a 600 × 400 pt window drawn by `forge-shell dmg-background` before packaging (`scripts/dmg-background.mjs`). Everything drawn stays within the top 316 pt of the background, since the window height includes the 32 pt title bar and Finder may add its path and status bars. It shows the wordmark of the application in its Light accent, a 2 pt accent line along the top edge, a hairline under the wordmark, the application and the Applications link at 96 pt on one row at 184 pt, 150 pt either side of the centre, an accent arrow between them, and two lines of install text in `--text2` and `--text3`. The background is the Light `--panel` colour, so that the labels Finder draws in black remain readable. `.background.tiff` and `.VolumeIcon.icns` are listed again under their own names and placed 200 pt below the window, so that they stay out of view when Finder shows hidden files; Finder then shows a scroll bar. The tests `the disk image window centres the app and Applications and moves its hidden files out of view` and `the disk image background carries the wordmark and arrow in the light accent and the install note` enforce the layout.

### Setup rights

The Windows setup executable is marked `asInvoker` and starts an elevated copy of itself when it lacks administrator rights; it is never marked `requireAdministrator`, which stops the sandboxed helper processes of Chromium. The generated Windows job opens the interactive setup window and fails on a missing or blank screenshot. The details are in [INSTALLER.md](INSTALLER.md#installation). The tests `the setup build pins the installed Electron version and stages the payload manifest`, `the elevation script waits for the elevated copy, passes its exit code and reports a declined prompt as Cancelled` and `the Windows job opens the interactive setup window and checks its screenshot before the silent installation` enforce the rule.

### Silent setup log

A silent run of the Windows setup (`/S`, `/uninstall`) writes its stages to `<id>-setup.log` and keeps the local crash dumps of Electron in the same folder, so that a run ending without one of its own exit codes shows the last stage it reached. The folder, the entries and the CI handling are described in [INSTALLER.md](INSTALLER.md#setup-log-and-crash-dumps). The tests `a silent setup records its stages and keeps crash dumps locally, beside the log` and `a failed Windows installer check shows the setup log and keeps it with the crash dumps` enforce the rule.

### Starting a new application

`forge-shell new-app Name --ext ext --accent #rrggbb --purpose text --author name` writes a new application into a new or empty folder (`--out`, by default `./Name`). The name is one word with a capital first letter; the extension defaults to the first letter of the name followed by `fg`, as in `.nfg` and `.lfg`. From the one accent colour, `deriveAccents()` makes the five Dark accents: the accent and its light variant lightened until they have 4.6:1 on the input surface (`#1b1b1b`), the About accent 6 % lighter, the fill darkened until white labels on it and it on the Light input surface (`#f8f8f7`) have 4.6:1, and the hover 6 % darker than the fill. Light takes the fill and hover, as `resolveTheme()` defines, and both appearances are written into `forge.config.json`.

The new application has the frame of the shell and no domain: the menus (File with New, Open and Autosave; Edit; View with the inspector, the bottom panel and the appearance; Help), the tool strip with Undo and Redo, the inspector, Terminal with the shared verbs, Messages, the status bar and the welcome screen. It has the desktop main process and preload with the shared bridge, file dialogs for its extension, recent documents, the single-instance rule and the launch capture; its wordmark in `assets/logo.txt`; a placeholder icon, a square in the accent, to be replaced before a release, and its document icons, made by `file-icon.py` when Python 3 with Pillow is installed; the build, preview, check, packaging and release scripts; and the four workflows. As generated, it type-checks, builds, passes its tests, the shared conformance tests (`npm run test:app`) and `forge-shell check-app` with no style warning, runs in the browser preview and on the desktop, and packages with `npm run dist`, after which `scripts/check-release.mjs --mac` passes. The next steps are listed in its `documentation/DEVELOPMENT.md`.

## 17. Release decisions

The shared code and its consumer are reviewed and committed separately. The reusable workflow of the shell requires the application scripts listed in section 14. The archive pin of each application stays at a published tag, and uncommitted shell changes are not packaged as that tag.

## 18. Migration checklist for an application

| Step | Content |
|---|---|
| 1 | `documentation/INTERFACE.md` records the profile of the application, including the Dark accents and any Light overrides; `brandCss` rejects an accent below a contrast ratio of 4.5:1. |
| 2 | `forge.config.json`, `public/center.html` and `public/panes.html` are added, and the shell is pinned (tag or `file:` archive). |
| 3 | The copies of the application of tokens, build, serve, web, version and release scripts are replaced by the exports of the shell. |
| 4 | The frame, menus, Terminal, Messages, dialogs and inspector widgets are replaced by those of the shell, one module at a time, with the checks of the application run after each. |
| 5 | Domain menus, commands, inspector sections and About content move into the runtime profile. |
| 6 | `test:shell` (`forge-shell check-app` after a build) is added, and `node_modules/forge-shell/tests/conformance` is bundled into `test:app`. |
| 7 | The browser preview is checked at the default window size and a narrow one, then the packaged macOS application, then the automated Windows build and launch check. |
| 8 | The leftover shell code of the application is deleted in the same change. |
| 9 | Later shell updates follow `UPDATING.md`: the pin is raised, the checks of the application run and the changelog of the shell is read. |
