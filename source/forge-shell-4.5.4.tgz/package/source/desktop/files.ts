// Licensed under the GNU General Public License v2 or later. See LICENSE.
import type { OpenedFile } from "./bridge";

/** Read requested files in order, reporting each unreadable file and opening the rest. */
export function readOpenedFiles(paths: string[], read: (path: string) => string, onError: (path: string, error: Error) => void): OpenedFile[] {
  const opened: OpenedFile[] = [];
  for (const path of paths) {
    try { opened.push({ path, text: read(path) }); }
    catch (error) { onError(path, error as Error); }
  }
  return opened;
}

/** Resolve existing document arguments, ignoring switches and unsupported files. */
export function documentArguments(
  argv: string[], cwd: string, matches: (path: string) => boolean,
  resolvePath: (cwd: string, path: string) => string, exists: (path: string) => boolean,
): string[] {
  return argv.filter((arg) => !arg.startsWith("-") && matches(arg)).map((arg) => resolvePath(cwd, arg)).filter(exists);
}
