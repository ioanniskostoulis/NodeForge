# Changelog

## 4.0.0

- Changed the inspector's grouping to the one of the earlier layouts: sections are grouped by subject (Builder, Files, Simulation, Circuit, Tolerance, Part under pointer), each holds its own actions first and its settings and toggles in place, and there is no General section. The rules are in section 4 (Inspector philosophy).
- Removed `fillGeneralSection`, `generalActionProblem` and `FIRST_SECTION_TITLE` (`inspector-general.ts`). Migration: move the actions of the first section into the section of their subject, as a button group, and drop the helper's import.

## 3.4.0

- Changed the shared icons to the size of the previous set: the Lucide grid is widened to 26.67 units, so each glyph fills 75 % of its 16 px box, and the visible line stays 1.25 px. Run controls at 12 px follow the same rule. The pointer is Lucide `mouse-pointer-2`, an outline arrow. The icon lint of `check-app` accepts the new strokes (2.0833 at 16 px, 2.7778 at 12 px) and still accepts 1.875 and 2.5 for an application's own icons on a 24-unit grid.
- Fixed `fillGeneralSection`, which cleared the whole section and so removed its heading and fold. It now fills a `general-body` box inside the section. Migration: an application that filled an inner box for this helper can pass the section itself.
- Added the welcome grid's geometry as tokens shared by every appearance (`--empty-grid-origin` 40 px, `--empty-grid-dot-step` 16 px, `--empty-grid-line-step` 128 px, `--empty-grid-dot-radius` 1.1 px, `--empty-grid-line-width` 1 px). `#empty-state` now takes every length from them and draws exactly as before. Added `sheetGrid()` and `drawSheetGrid(ctx, width, height, grid, view)` (`sheet-grid.ts`), which draw the same sheet on a canvas from the same tokens, following a `Viewport` when one is given. Migration: a canvas that copied the 16, 128, 32 or 40 px values draws the sheet with `drawSheetGrid` instead.
- Changed the first section of the inspector: the application names it for what its document is, and `General` (`FIRST_SECTION_TITLE`) is the default until a better name exists. `fillGeneralSection` keeps the section's heading, and its rule messages now say `The first section of the inspector`. Migration: an application records the section's name under Workspace in its profile.
- Fixed the file tree, which added its keyboard, context-menu, focus and drop listeners again at every redraw of the same element, so that after n redraws one arrow key moved n rows and one Delete deleted n times.
- Fixed a folder that the application does not list on its own in the file tree: its context menu was the empty tree's, New file went beside it instead of into it, and Duplicate could take its name.
- Changed the file tree's New folder to have no key: Shift+Cmd+N and Ctrl+Shift+N are the shell's New window. Migration: none; New folder stays in the context menu.
- Fixed the find bar, which skipped the match already selected as the query grew (typing `a` then `ab` jumped past the `ab` under the cursor). It now selects the first match from the start of the selection (`matchFrom`).
- Fixed Cmd or Ctrl with a mouse wheel, which zoomed 2.7× per notch; it now zooms 1.15× per notch, as the plain wheel does. A pinch is unchanged.
- Fixed the splitter, which kept following the pointer after a cancelled drag; a drag now also ends when the pointer is cancelled or loses its capture.
- Fixed autosave, which still saved when a pause that started before autosave was turned off ended.
- Fixed Save, which added the extension to a name chosen without it and could replace a file of that name without asking. The dialog is shown once more with the corrected name, and a second answer without the extension saves nothing.
- Fixed the first section's buttons, which read a label with `&` or `<` as markup.
- Fixed the package index, which did not export `fillGeneralSection` and `generalActionProblem`.

## 3.3.0

- Added `fillGeneralSection(section, actions, rows)` (`inspector-general.ts`) for the first section of the inspector. It takes two or three text buttons, exactly one primary, and the document's rows (editable name, File, Images, Grid), and throws when the buttons break that rule. `generalActionProblem(actions)` gives the sentence for a broken rule. Migration: an application builds its General section with this helper instead of its own markup.

## 3.2.0

- Changed the shared icons to Lucide (ISC), drawn from the shell's list (`LUCIDE_ICONS`, `lucideIcon(name, size)`). The visible line stays 1.25 px at 16 px (stroke 1.875 on Lucide's 24 px grid), and BUTTON_GLYPHS are Lucide icons at 12 px. Migration: an application that draws a shared icon by hand should take it from `UI_ICONS`, `TOOL_ICONS` or `STATUS_ICONS` by name. Run and Step no longer share a glyph.
- Changed menus to reserve the 14 px check column only in a popup with a checkable item (`has-checks`), and to size a popup to its content (minimum 120 px). A tool in a flyout is not checkable, so its row has no check column.
- Changed the inspector button rule: a button shows text only, with an icon only where its action has a standard symbol.
- Migration: `flyoutItemMarkup` no longer includes a check column; a context menu or popup that relied on the 14 px column without a checkable item now sizes to its text.

## 3.1.1

- Fixed the conformance tests that applications run: `inspector-parts` read the shell's stylesheet through `import.meta.url`, which is empty when an application bundles the tests as CommonJS, and failed with `Invalid URL`. Its stylesheet checks moved to a shell-only test, and a new check keeps every portable test free of file reads.

## 3.1.0

- Added file drop: `attachFileDrop(target, { accept, label, onFiles, onRefused, pathFor })` opens files dropped from the system on a window or view. It accepts them by extension, ignoring case, shows a drop target only while files are dragged over it, and gives one sentence for refused files (`Cannot open notes.docx. Drop a .png or .tif file.`) to send to Messages and the status bar. With `multiple: false` it takes one file at a time.
- Added `pathForFile(file)` to the desktop bridge, which gives a dropped file's path on disk. Migration: pass Electron's `webUtils` as the fourth argument of `createDesktopBridge` in the preload, as the new-app template does, and give `pathFor: bridge.pathForFile` to `attachFileDrop`. Without it a dropped file has no path.
- Changed Save to make the document's text after the Save dialog has chosen the path: `serialize(document, path)` now receives the destination, so a document that stores paths relative to itself is written once and correctly. A format the document cannot be saved in is now reported after the dialog instead of before it. Migration: an application that wrote the file twice to get relative paths right can use `path` and write once.
- Added the welcome-surface colours as theme tokens (`--empty-sheet`, `--empty-grid-dot`, `--empty-grid-line`) on `body`, so that a canvas can draw the same sheet and grid by reading them. An override on `#empty-state` still applies.
- Fixed the tool flyout menu, which squeezed each tool's icon into the check column and hid its name. Its rows now have the columns of every menu, and a tool is a plain item, never checked.
- Changed chips (`createChips`) to look like a button group: 24 px high with a 4 px radius, sharing the width, the chosen chip in the accent fill, instead of small rounded pills.
- Added a status for every file in the tree: give `status(file)` to `renderFileTree` and each file row shows `editable` or `readOnly` (`TREE_STATUS`) or a status of your own, at the right of the row; folders show none. Migration: an application that added its own editability icons after `renderFileTree` can return them from `status` instead.
- Removed the editable or read-only icon from the view header (`createViewHeader`): a file's status is shown in the file tree only. Migration: the `mode` option is ignored and will be removed; drop it, and give the file's status to the tree through `status`.
- Added `createInfoLines()`, the lines that describe the item under the pointer or selected (its name, then one value per line), and `createButtonGroup()`, the full-width row of buttons that opens an inspector. Measured values belong in read-only rows (`createRow`) with their detail in the tooltip, not in a card.
- Fixed the label of a disabled primary button, which was `--text3` on the accent fill and measured about 1.1:1. The button keeps its accent fill, and its label is now the white foreground mixed 55 % into the fill: legible, and clearly dimmer than when enabled. A disabled chosen chip follows the same rule.
- Fixed the panel buttons, which had no keyboard focus ring; they now show the 1 px `--accent-light` ring.
- Fixed the tooltip of an editable readout (`editableValue`), which read `<title>. Click to type` without a final period. It is now the application's sentence with a final period, and the flyout button's tooltip is set through `setTip`.

## 3.0.0

- Released the shared interface package of the Forge desktop applications: the frame, document tabs, menus, Terminal, Messages, dialogs, inspector, tool strip, status bar, panels and file tree, with the colour, type, shape and motion tokens. An application differs only in its accent colour and supplies its domain content through a profile (`forge.config.json`).
- Added `forge-shell new-app <Name>`, which writes a complete empty application from a name, a file extension (by default its first letter and `fg`) and one accent colour: the frame, the desktop main process and preload, its wordmark, its icons, the scripts and the four build workflows. It type-checks, builds, passes its checks and packages as generated.
- Added checking for updates and one-click updating: an application whose profile names its public GitHub repository (`identity.repository`) gets Help › Check for updates…, and on the desktop **Update and restart** downloads the release's installer, checks its size and SHA-256, installs it and restarts. On macOS the app replaces itself without Apple signing, or opens the disk image where it cannot; on Windows the Forge setup runs silently. At most once a day at launch, a newer release is noted in Messages.
- Added the shared Terminal commands (`new`, `open`, `recent`, `save [as]`, `close`, `undo`, `redo`, `fit`, `zoom`, `panel`, `inspector`, `theme`, `font`, `autosave`, `about`, `version`, `changes`, `shortcuts`, `licenses`, `updates`, `help`, `history`, `clear`). Each runs its menu action by a standard identifier (`STANDARD_ACTIONS`), and an application gets the commands of the actions it has (`sharedCommands()`, `runSharedCommand()`).
- Added the standard items (`STANDARD_ITEMS`, `standardItem()`, `zoomItems()`, `arrangeItems()`): every command applications share has one menu label, one key and, where it has one, one Terminal command, in every application. They cover New window, Print, Settings, the clipboard, Duplicate, Delete, Find and Replace, Go to line, Toggle comment, the four Arrange commands, the zooms with Fit on Cmd+0 and Actual size on Cmd+1, the panels, full screen and the next and previous tab. `checkShortcuts` reports a standard action on any other key.
- Added `documentation/TERMINAL.md`, the exact rules of every command's registry entry, forms and help, and the help of the shared commands (`sharedHelpDetails()`): every choice with its description, notes and an example, the same in every application.
- Added the Help menu and its four dialogs (`helpMenu()`, `showAbout()`, `showWhatsNew()`, `showShortcuts()` with `menuShortcutGroups()`, `showLicenses()`), so that applications need no copies of their own.
- Added saving: autosave as a preference (Off, after 1 or 5 minutes, or when the window loses focus), recovery of unsaved edits after a crash with a restore dialog, and File › Open recent with ten files, also added to the system's recent documents.
- Added the shared code editor on CodeMirror (`createCodeEditor()`), with its find bar, the `--syntax-*` colours, a rounded selection and a caret that glides between positions and fades as it blinks. The Terminal prompt draws the same caret.
- Added keyboard shortcut tiers (`shortcuts.ts`): the universal keys the shell owns, application commands on Shift+Cmd or Ctrl+Shift and a letter, rarer ones on Option+Cmd, bare keys for tools, and conventional shortcuts kept by name (`CONVENTIONAL_SHORTCUTS`). `checkShortcuts()` reports clashes, system keys and keys that type characters.
- Added selection and rearranging of content: the cyan `--pick` colour, box selection, click-or-drag rules, drag to rearrange with a drop line (`attachReorder()`), which document tabs use, and the pan-and-zoom `Viewport` for canvases.
- Added the shared icon set (`UI_ICONS`, `BUTTON_GLYPHS`), the platform order of dialog buttons and tool strip groups (`dialogButtonOrder()`, `TOOL_GROUP_ORDER`), a splitter, a view header, review-and-apply and table-picker dialogs, form blocks and an outline list.
- Added `forge-shell wordmark <Name>`, which sets any name in the family lettering: the Roman FIGlet font with a g one line shorter than the font's, letters one blank column apart where they come closest, and no trailing blanks.
- Added the file tree with the commands and keys of Finder and File Explorer, icons for each kind of file, status badges and application extensions (`renderFileTree()`).
- Added the Windows setup, which runs inside the application it installs, installs for all users, keeps user data on repair and uninstall and refuses a downgrade, and the macOS disk image window. The build ships only the files git tracks as the application's corresponding source.
- Added the build, preview, check and release scripts (`buildForgeApp`, `forge-shell check-app`, `check-release`, `release-notes`, `workflows`), the style lint, and the component page (`npm run gallery`) with measured checks of spilling, clipping and centring at several window sizes.
