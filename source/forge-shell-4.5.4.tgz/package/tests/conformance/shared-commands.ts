import assert from "node:assert/strict";
import test from "node:test";
import { checkCommandSyntax } from "../../source/app/command-help";
import { SHARED_COMMANDS, STANDARD_ACTIONS, runSharedCommand, sharedCommands, sharedHelpGroups, type SharedCommandHost, type StandardAction } from "../../source/app/shared-commands";

const host = (actions: StandardAction[], over: Partial<SharedCommandHost> = {}) => {
  const ran: string[] = [];
  let size = 12;
  const value: SharedCommandHost = { run: (action) => { ran.push(action); }, actions, hasDocument: true, noun: "circuit", productName: "Example", version: "1.2.3",
    fontSize: () => size, setFontSize: (next) => { size = next; }, ...over };
  return { value, ran, size: () => size };
};

test("every shared command is written to the help rules and runs a standard action or none", () => {
  for (const entry of SHARED_COMMANDS) {
    assert.deepEqual(checkCommandSyntax(entry.spec.syntax), [], entry.spec.syntax);
    assert.match(entry.spec.description, /^[A-Z][^.]*[^.]$/, entry.spec.name);
    // An application's own check holds descriptions to 70 characters, so the shared ones must pass it too.
    assert.ok(entry.spec.description.length <= 70, `${entry.spec.name}: ${entry.spec.description.length} characters`);
    for (const action of entry.actions) assert.ok((STANDARD_ACTIONS as readonly string[]).includes(action), action);
  }
});

test("an application gets the shared commands of the actions it has, grouped File, Edit, View, Help, Console", () => {
  const names = sharedCommands(["file.new", "file.open", "view.fit", "about"]).map((entry) => entry.spec.name);
  assert.ok(names.includes("zoom") && names.includes("recent") && names.includes("theme") && names.includes("version"));
  assert.ok(!names.includes("fit") && !names.includes("font") && !names.includes("save") && !names.includes("undo") && !names.includes("autosave") && !names.includes("updates"));
  assert.ok(sharedCommands([], { autosave: true }).some((entry) => entry.spec.name === "autosave"));
  assert.deepEqual(sharedHelpGroups(sharedCommands(["file.new", "edit.undo", "view.fit", "about"])).map(([group]) => group), ["File", "Edit", "View", "Help", "Console"]);
});

test("a shared command runs its menu action, and a document command needs a document", () => {
  const all = host(["file.save", "file.saveAs", "view.fit", "view.zoomIn", "view.actualSize", "about.shortcuts"]);
  for (const [name, arg, action] of [["zoom", "in", "view.zoomIn"], ["zoom", "actual", "view.actualSize"], ["zoom", "fit", "view.fit"], ["save", "", "file.save"], ["save", "as", "file.saveAs"], ["shortcuts", "", "about.shortcuts"]] as const) {
    assert.deepEqual(runSharedCommand(name, arg, all.value), { lines: [] });
    assert.equal(all.ran.at(-1), action);
  }
  assert.deepEqual(runSharedCommand("zoom", "out", all.value), { lines: ["Example has no zoom out command."] });
  assert.deepEqual(runSharedCommand("zoom", "fit", host(["view.fit"], { hasDocument: false }).value), { lines: ["Open a circuit first."] });
  assert.equal(runSharedCommand("fit", "", all.value), null, "fit is zoom fit");
  assert.equal(runSharedCommand("undo", "", all.value), null);
  assert.equal(runSharedCommand("theme", "dark", all.value), null);
  assert.deepEqual(runSharedCommand("version", "", all.value), { lines: ["Example 1.2.3"] });
});

test("recent lists and opens recent files by number; font is no longer a shared command", () => {
  const opened: string[] = [];
  const recent = host(["file.open"], { recent: () => ["/a/one.txt", "/b/two.txt"], openPath: (path) => { opened.push(path); } });
  assert.equal(runSharedCommand("recent", "", recent.value)?.lines?.length, 2);
  assert.deepEqual(runSharedCommand("recent", "2", recent.value), { lines: [] });
  assert.deepEqual(opened, ["/b/two.txt"]);
  assert.deepEqual(runSharedCommand("recent", "9", recent.value), { lines: ["No recent file numbered 9. Type recent to list them."] });
  assert.deepEqual(runSharedCommand("recent", "", host(["file.open"]).value), { lines: ["No recent files."] });
  assert.equal(runSharedCommand("font", "14", host([]).value), null, "the text size is terminal font");
});
