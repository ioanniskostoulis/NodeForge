#!/usr/bin/env node
// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { checkForgeApp } from "./check-app.mjs";
import { electronBuilderConfig } from "./package-config.mjs";
import { renderDmgBackground } from "./dmg-background.mjs";
import { renderWordmark, writeWordmark } from "./wordmark.mjs";
import { brandCss } from "./theme.mjs";
import { buildInstaller } from "./build-installer.mjs";
import { helpText } from "./cli-help.mjs";
import { collectLicenses, licensesMarkdown } from "./licenses.mjs";
import { releaseNotes } from "./release-notes.mjs";
import { writeWorkflows } from "./workflows.mjs";
import { createNewApp, missingIcons } from "./new-app.mjs";

const command = process.argv[2];
const config = () => JSON.parse(readFileSync("forge.config.json", "utf8"));

switch (command) {
  case "-h":
  case "--help":
  case "help":
    console.log(helpText);
    break;
  case "check-app": {
    const result = checkForgeApp();
    console.log(`${result.product} built shell matches its profile and installed package.`);
    break;
  }
  case "licenses": {
    // Print the licence text of every production dependency; fails when one declares no licence.
    const { entries, missing } = collectLicenses();
    if (missing.length) { console.error(`These packages declare no licence: ${missing.join(", ")}.`); process.exitCode = 1; break; }
    console.log(licensesMarkdown(entries));
    break;
  }
  case "workflows": {
    // Write the four workflows of the application (build desktop apps, mac, windows, clear all) into .github/workflows.
    const dir = process.argv.includes("--out") ? process.argv[process.argv.indexOf("--out") + 1] : ".github/workflows";
    console.log(`Wrote ${writeWorkflows(dir).join(", ")} to ${dir}.`);
    break;
  }
  case "release-notes": {
    // The notes of the version in VERSION, from CHANGELOG.md. A release needs its own section, so a missing one fails.
    const version = readFileSync("VERSION", "utf8").trim();
    const notes = releaseNotes(readFileSync("CHANGELOG.md", "utf8"), version, { strict: true });
    if (notes === null) { console.error(`CHANGELOG.md has no "## ${version}" section. Add it before publishing.`); process.exitCode = 1; break; }
    console.log(notes);
    break;
  }
  case "package-config": {
    mkdirSync("build", { recursive: true });
    writeFileSync("build/electron-builder.json", `${JSON.stringify(electronBuilderConfig(config()), null, 2)}\n`);
    break;
  }
  case "dmg-background": {
    // The disk image window is drawn by Electron; only a macOS package needs it.
    if (process.platform !== "darwin" && !process.argv.includes("--force")) { console.log("Disk image background skipped: it is used only on macOS."); break; }
    console.log(`Wrote ${renderDmgBackground().join(" and ")}.`);
    break;
  }
  case "wordmark": {
    // The app's text wordmark in the family's Roman lettering: printed, or written with --out (assets/logo.txt).
    const name = process.argv[3] && !process.argv[3].startsWith("--") ? process.argv[3] : config().identity.name;
    const out = process.argv.includes("--out") ? process.argv[process.argv.indexOf("--out") + 1] : null;
    if (out) { writeWordmark(name, out); console.log(`Wrote the ${name} wordmark to ${out}.`); }
    else console.log(renderWordmark(name));
    break;
  }
  case "new-app": {
    // A complete empty app from a name, a file extension and one accent colour, in a new folder.
    const flag = (name) => { const i = process.argv.indexOf(name); return i > 0 ? process.argv[i + 1] : undefined; };
    const name = process.argv[3] && !process.argv[3].startsWith("--") ? process.argv[3] : undefined;
    const out = flag("--out") ?? name ?? "";
    try {
      const files = createNewApp(out, { name, extension: flag("--ext"), accent: flag("--accent"), purpose: flag("--purpose"), author: flag("--author"), port: flag("--port"), shellDependency: flag("--shell"), repository: flag("--repo") });
      console.log(`Created ${name} in ${out} (${files.length} files). Next: copy the shell archive into ${out}/source, run npm install and npm run web.`);
      if (missingIcons(out)) console.log("The document icons were not made: install Python 3 with Pillow and run python3 node_modules/forge-shell/scripts/file-icon.py before npm run dist.");
    } catch (error) { console.error(error.message); process.exitCode = 1; }
    break;
  }
  case "brand-css": {
    mkdirSync("build/app", { recursive: true });
    writeFileSync("build/app/forge-brand.css", brandCss(config().theme));
    break;
  }
  case "installer": {
    const flag = (name) => { const i = process.argv.indexOf(name); return i > 0 ? process.argv[i + 1] : undefined; };
    const result = await buildInstaller({ payloadDir: flag("--payload") ?? "build/release/win-unpacked", outDir: flag("--out") ?? "build/release", stageOnly: process.argv.includes("--stage-only") });
    console.log(`${config().identity.name} setup staged at ${result.app} (${result.manifest.files.length} files, ${result.manifest.bytes} bytes).`);
    break;
  }
  default:
    console.error(`${command ? `Unknown command: ${command}.` : "Missing command."}\n\n${helpText}`);
    process.exitCode = 2;
}
