// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Machine-wide Windows registration through reg.exe. The setup runs as administrator, so it can write HKLM.
import { DEFAULT_FAMILY } from "./layout.mjs";
// `run(command, args)` is injected so tests can read the commands instead of running them.

const UNINSTALL = String.raw`HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall`;
const CLASSES = String.raw`HKLM\Software\Classes`;

const add = (run, key, name, value, type = "REG_SZ") =>
  run("reg", ["add", key, ...(name ? ["/v", name] : ["/ve"]), "/t", type, "/d", String(value), "/f"]);

/** Settings, Apps entry and the document association, for all users. */
export function registerApp({ run, id, name, version, installDir, exe, publisher, uninstall, extension, description, documentIcon, family = DEFAULT_FAMILY }) {
  const key = `${UNINSTALL}\\${family}.${id}`;
  add(run, key, "DisplayName", name);
  add(run, key, "DisplayVersion", version);
  add(run, key, "Publisher", publisher);
  add(run, key, "InstallLocation", installDir);
  add(run, key, "DisplayIcon", exe);
  add(run, key, "UninstallString", uninstall);
  add(run, key, "NoModify", 1, "REG_DWORD");
  add(run, key, "NoRepair", 1, "REG_DWORD");
  if (extension) {
    const type = `${family}.${id}.${extension}`;
    add(run, `${CLASSES}\\.${extension}`, "", type);
    add(run, `${CLASSES}\\${type}`, "", description ?? name);
    add(run, `${CLASSES}\\${type}\\DefaultIcon`, "", documentIcon ?? `${exe},0`);
    add(run, `${CLASSES}\\${type}\\shell\\open\\command`, "", `"${exe}" "%1"`);
  }
}

export function unregisterApp({ run, id, extension, family = DEFAULT_FAMILY }) {
  run("reg", ["delete", `${UNINSTALL}\\${family}.${id}`, "/f"]);
  if (extension) {
    run("reg", ["delete", `${CLASSES}\\.${extension}`, "/f"]);
    run("reg", ["delete", `${CLASSES}\\${family}.${id}.${extension}`, "/f"]);
  }
}

/**
 * Is the executable at `exePath` running? PowerShell lists the processes of that name with their paths; another copy
 * of the same executable elsewhere, such as the setup, which is the app's own executable, does not count.
 */
export function isRunning(run, exePath) {
  const name = exePath.replace(/^.*[\\/]/, "").replace(/\.exe$/i, "");
  const literal = (text) => `'${text.replaceAll("'", "''")}'`;
  try {
    const output = run("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command",
      `Get-Process -Name ${literal(name)} -ErrorAction SilentlyContinue | ForEach-Object { $_.Path }`]);
    return String(output).split(/\r?\n/).some((line) => line.trim().toLowerCase() === exePath.toLowerCase());
  } catch {
    return false;
  }
}
