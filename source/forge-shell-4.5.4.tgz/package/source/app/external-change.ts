// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { dialogActions } from "./layout-order";

/** What to do when a file on disk may differ from what the editor holds. */
export type ExternalAction = "none" | "import" | "ask";

/**
 * `onDisk` is the file now, `known` what the app last read or wrote, `text` what the editor holds.
 * A change nobody made outside the app (`onDisk` equals `known` or `text`) needs nothing; an outside change is imported
 * when the editor still holds what the app last synced, and asked about when the editor has edits that the import would replace.
 */
export function externalAction(onDisk: string, known: string, text: string): ExternalAction {
  if (onDisk === known || onDisk === text) return "none";
  return text === known ? "import" : "ask";
}

export type ExternalChoice = "reload" | "keep";

/**
 * Ask which version of a file to use: Reload takes the outside one (Return), Keep mine overwrites it on the next save
 * (Escape). `file` is the file's name and `appName` the product name, both shown in the question.
 */
export function askExternalChange(file: string, appName: string): Promise<ExternalChoice> {
  return new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="save-prompt" role="alertdialog" aria-labelledby="external-prompt-title">
        <div class="title" id="external-prompt-title"></div>
        <div class="detail">Reload to use the other version, or keep yours and replace the other one at the next save.</div>
      </div>`;
    backdrop.querySelector(".save-prompt")!.append(dialogActions([{ label: "Reload", role: "primary", className: "reload" }, { label: "Keep mine", role: "cancel", className: "keep" }]));
    backdrop.querySelector(".title")!.textContent = `${file} changed outside ${appName}, and the editor has edits that are not saved.`;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const done = (choice: ExternalChoice): void => {
      document.removeEventListener("keydown", keys, true);
      backdrop.remove();
      previousFocus?.focus();
      resolve(choice);
    };
    const keys = (event: KeyboardEvent): void => {
      event.stopPropagation();
      if (event.key === "Escape") done("keep");
      else if (event.key === "Enter" && !(event.target instanceof HTMLButtonElement)) done("reload");
    };
    backdrop.querySelector(".reload")!.addEventListener("click", () => done("reload"));
    backdrop.querySelector(".keep")!.addEventListener("click", () => done("keep"));
    document.addEventListener("keydown", keys, true);
    (document.getElementById("overlay-root") ?? document.body).append(backdrop);
    (backdrop.querySelector(".reload") as HTMLButtonElement).focus();
  });
}
