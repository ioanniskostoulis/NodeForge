// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The component page (`npm run gallery`): every part of the shell on one page, in the frame of an application, served on
// http://127.0.0.1:4199/ for checking rendering, centring and narrow windows. `?show=` opens a dialog or menu,
// `?theme=light` or `pride` changes the appearance, `?docs=0` shows the welcome screen, `?canvas=1` the canvas editing page (`&tool=crop` or another canvas tool), and `galleryChecks()` in the
// page's console lists the problems it can measure.
import { build } from "esbuild";
import { cpSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join, normalize } from "node:path";
import { brandCss, deriveAccents, resolveTheme } from "./theme.mjs";
import { renderWordmark } from "./wordmark.mjs";

const out = "build/gallery";
rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
await build({ entryPoints: ["tests/gallery/gallery.ts"], bundle: true, format: "esm", platform: "browser", outfile: `${out}/app.js`, logLevel: "warning",
  define: { __APP_LOGO__: JSON.stringify(renderWordmark("Gallery")), __FORGE_VERSION__: JSON.stringify(readFileSync("VERSION", "utf8").trim()) } });
cpSync("source/styles/tokens.css", `${out}/forge-tokens.css`);
cpSync("source/styles/shell.css", `${out}/forge-shell.css`);
writeFileSync(`${out}/forge-brand.css`, brandCss(resolveTheme(deriveAccents("#3fae6a"))));
cpSync("tests/gallery/gallery.css", `${out}/app.css`);
cpSync("LICENSE", `${out}/LICENSE`);
cpSync("CHANGELOG.md", `${out}/CHANGELOG.md`);
writeFileSync(`${out}/index.html`, readFileSync("templates/app/index.html", "utf8")
  .replace("__FORGE_PRODUCT_NAME__", "Gallery").replace('"__FORGE_SETTINGS_KEY__"', '"gallery.settings"').replace("__FORGE_APP_PREPAINT__", "")
  .replace("__FORGE_CENTER_HTML__", readFileSync("tests/gallery/center.html", "utf8").trim()).replace("__FORGE_DOMAIN_PANES_HTML__", ""));
if (process.argv.includes("--build-only")) process.exit(0);
const types = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".md": "text/plain; charset=utf-8", "": "text/plain; charset=utf-8" };
const port = Number(process.env.PORT ?? 4199);
createServer(async (request, response) => {
  const path = normalize(decodeURIComponent(new URL(request.url, "http://x").pathname)).replace(/^(\.\.[/\\])+/, "");
  try {
    const file = join(out, path === "/" || path === "\\" ? "index.html" : path);
    const body = await readFile(file);
    response.writeHead(200, { "content-type": types[extname(file)] ?? "application/octet-stream" }).end(body);
  } catch { response.writeHead(404).end("not found"); }
}).listen(port, "127.0.0.1", () => console.log(`Component page on http://127.0.0.1:${port}/`));
