import assert from "node:assert/strict";
import { test } from "node:test";
import { DROP_NAMES_LISTED, acceptsFile, attachFileDrop, dragHasFiles, dropMessage, fileExtension, sortDrop, type DroppedFile } from "../../source/app/file-drop";
import { createDesktopBridge, type IpcRendererPort } from "../../source/desktop/bridge";

const images = [".png", ".jpg", ".tif"];

test("a dropped file is accepted by its extension, ignoring case, and a name without one is refused", () => {
  assert.equal(fileExtension("/a/b/cells.TIF"), ".tif");
  assert.equal(fileExtension("C:\\scans\\gel.png"), ".png");
  assert.equal(fileExtension(".hidden"), "", "a leading dot is a hidden name, not an extension");
  assert.equal(fileExtension("README"), "");
  assert.equal(acceptsFile("cells.TIF", images), true);
  assert.equal(acceptsFile("cells.tiff", images), false, ".tiff is a different extension from .tif");
  assert.equal(acceptsFile("README", images), false);
});

test("refused files are named in one sentence, three at most, with the accepted kinds", () => {
  assert.equal(DROP_NAMES_LISTED, 3);
  assert.equal(dropMessage(["notes.docx"], images), "Cannot open notes.docx. Drop a .png, .jpg or .tif file.");
  assert.equal(dropMessage(["a.zip", "b.txt"], [".csv"]), "Cannot open a.zip and b.txt. Drop a .csv file.");
  assert.equal(dropMessage(["1.a", "2.a", "3.a"], images), "Cannot open 1.a, 2.a and 3.a. Drop a .png, .jpg or .tif file.", "three are all named");
  assert.equal(dropMessage(["1.a", "2.a", "3.a", "4.a"], images), "Cannot open 1.a, 2.a, 3.a and 1 more. Drop a .png, .jpg or .tif file.", "the fourth is counted");
});

test("a drop keeps the accepted files and reports the others, and a single-file target refuses two", () => {
  assert.deepEqual(sortDrop(["a.png", "b.tif"], images), { accepted: ["a.png", "b.tif"], refused: [], message: null });
  assert.deepEqual(sortDrop(["a.png", "b.docx"], images), { accepted: ["a.png"], refused: ["b.docx"], message: "Cannot open b.docx. Drop a .png, .jpg or .tif file." });
  assert.deepEqual(sortDrop(["a.png"], images, false).accepted, ["a.png"], "one file on a single-file target");
  assert.deepEqual(sortDrop(["a.png", "b.png"], images, false), { accepted: [], refused: ["a.png", "b.png"], message: "Drop one file at a time." });
});

// A target with just enough of the DOM for the drag events.
class FakeElement {
  className = ""; textContent = ""; hidden = false; children: FakeElement[] = []; removed = false;
  listeners = new Map<string, (event: unknown) => void>();
  classes = new Set<string>();
  classList = { add: (...names: string[]) => names.forEach((n) => this.classes.add(n)), remove: (...names: string[]) => names.forEach((n) => this.classes.delete(n)),
    toggle: (name: string, on: boolean) => { if (on) this.classes.add(name); else this.classes.delete(name); } };
  append(...items: FakeElement[]) { this.children.push(...items); }
  remove() { this.removed = true; }
  addEventListener(name: string, fn: (event: unknown) => void) { this.listeners.set(name, fn); }
  removeEventListener(name: string) { this.listeners.delete(name); }
  fire(name: string, event: object) { this.listeners.get(name)?.(event); }
}
const doc = { createElement: () => new FakeElement() } as unknown as Pick<Document, "createElement">;
const file = (name: string) => ({ name }) as File;
const drag = (types: string[], files: File[] = [], defaultPrevented = false) => {
  const event = { defaultPrevented, prevented: false, dataTransfer: { types, files, dropEffect: "none" }, preventDefault() { event.prevented = true; } };
  return event;
};

test("the drop target shows only while files are over it, across child elements, and hands over paths", () => {
  const target = new FakeElement();
  const opened: DroppedFile[][] = [], refusals: string[] = [];
  const detach = attachFileDrop(target as unknown as HTMLElement, { accept: images, label: "Drop images to open them.", onFiles: (files) => opened.push(files), onRefused: (m) => refusals.push(m),
    pathFor: (f) => `/Users/me/${f.name}` }, doc);
  const overlay = target.children[0];
  assert.equal(overlay.className, "file-drop");
  assert.equal(overlay.children[0].textContent, "Drop images to open them.");
  assert.equal(overlay.hidden, true);
  assert.ok(target.classes.has("file-drop-host"));
  // text dragged inside the page is not a file drop
  const text = drag(["text/plain"]);
  target.fire("dragenter", text);
  target.fire("dragover", text);
  assert.equal(overlay.hidden, true);
  assert.equal(text.prevented, false, "the page keeps its own text drags");
  // entering the target and one of its children counts twice; leaving the child keeps it shown
  target.fire("dragenter", drag(["Files"]));
  target.fire("dragenter", drag(["Files"]));
  const over = drag(["Files"]);
  target.fire("dragover", over);
  assert.equal(over.prevented, true, "dragover is taken, so the browser does not open the file in place of the page");
  assert.equal(over.dataTransfer.dropEffect, "copy");
  target.fire("dragleave", drag(["Files"]));
  assert.equal(overlay.hidden, false, "still over the target after leaving a child");
  target.fire("dragleave", drag(["Files"]));
  assert.equal(overlay.hidden, true, "hidden once the pointer leaves the target");
  // a drop opens the accepted files with their paths and reports the refused one
  target.fire("dragenter", drag(["Files"]));
  target.fire("drop", drag(["Files"], [file("cells.tif"), file("notes.docx")]));
  assert.equal(overlay.hidden, true);
  assert.deepEqual(opened.map((files) => files.map((f) => [f.name, f.path])), [[["cells.tif", "/Users/me/cells.tif"]]]);
  assert.deepEqual(refusals, ["Cannot open notes.docx. Drop a .png, .jpg or .tif file."]);
  // a drop an inner element has handled (the file tree) is left to it
  target.fire("drop", drag(["Files"], [file("b.png")], true));
  assert.equal(opened.length, 1);
  detach();
  assert.equal(overlay.removed, true);
  assert.equal(target.listeners.size, 0);
  assert.ok(!target.classes.has("file-drop-host"));
});

test("in the browser a dropped file has no path, and the bridge gives the desktop path through webUtils", () => {
  const target = new FakeElement();
  const opened: DroppedFile[] = [];
  attachFileDrop(target as unknown as HTMLElement, { accept: images, label: "Drop images to open them.", onFiles: (files) => opened.push(...files), onRefused() {} }, doc);
  target.fire("drop", drag(["Files"], [file("a.png")]));
  assert.equal(opened[0].path, null);
  assert.equal(dragHasFiles(null), false);
  const ipc: IpcRendererPort = { send() {}, invoke: async () => undefined, on() {} };
  const desktop = createDesktopBridge(ipc, "darwin", "1.0.0", { getPathForFile: (f) => `/disk/${f.name}` });
  assert.equal(desktop.pathForFile(file("a.png")), "/disk/a.png");
  assert.equal(createDesktopBridge(ipc, "darwin", "1.0.0").pathForFile(file("a.png")), "", "a preload without webUtils gives no path");
  const failing = createDesktopBridge(ipc, "darwin", "1.0.0", { getPathForFile: () => { throw new Error("not a disk file"); } });
  assert.equal(failing.pathForFile(file("made.png")), "");
});
