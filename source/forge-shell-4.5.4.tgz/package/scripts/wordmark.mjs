// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The text wordmark of an app (assets/logo.txt): its name in the Roman FIGlet font by Nick Miners (scripts/fonts/roman.flf),
// set with universal smushing, as patorjk.com/software/taag sets it with Roman and "Universal Smushing", and with the
// family's own g, one line shorter than the font's.
import { readFileSync, writeFileSync } from "node:fs";

const FONT = new URL("./fonts/roman.flf", import.meta.url);

/** A FIGlet font: its height, hard blank and one glyph (an array of `height` rows) per character. */
export function parseFont(text) {
  const lines = text.split(/\r?\n/);
  const [signature, height, , , , commentLines] = lines[0].split(" ");
  const hardblank = signature.at(-1);
  const rows = Number(height);
  const glyphs = new Map();
  let at = 1 + Number(commentLines);
  // The required characters are ASCII 32 to 126, in order; each row ends with one end mark, the last row with two.
  for (let code = 32; code <= 126; code++, at += rows) {
    const block = lines.slice(at, at + rows);
    const mark = block[0].at(-1);
    glyphs.set(String.fromCharCode(code), block.map((row) => row.replace(new RegExp(`\\${mark}+$`), "")));
  }
  return { height: rows, hardblank, glyphs };
}

/**
 * The family's g: the font's g without the row `\`8oooooo.` between the bowl and the tail, so the tail sits one line
 * higher. A blank row at the bottom keeps the glyph's height.
 */
export function familyG(glyph) {
  const index = glyph.findIndex((row) => row.replace(/[$ ]/g, "") === "`8oooooo.");
  if (index < 0) return glyph;
  return [...glyph.slice(0, index), ...glyph.slice(index + 1), " ".repeat(glyph[index].length)];
}

/**
 * Universal smushing of two characters that share a column, as figlet.js does: the later character wins, except a
 * blank, or a hard blank over a visible character, which leaves the earlier one.
 */
export function smushed(left, right, hardblank) {
  if (right === " " || right === "") return left;
  if (right === hardblank && left !== " ") return left;
  return right;
}

// Letters sit one blank column apart where they come closest; a hard blank counts as blank.
export const LETTER_GAP = 1;

/**
 * How many columns the next glyph slides back into the rows set so far: as far as it can while, in every row where both
 * have ink, at least `LETTER_GAP` blank columns separate the last character so far from the glyph's first.
 */
export function smushAmount(rows, glyph, font) {
  const blank = (char) => char === " " || char === font.hardblank || char === undefined;
  const width = rows[0].length, next = Math.max(...glyph.map((row) => row.length));
  let amount = next;
  for (let index = 0; index < rows.length; index++) {
    const line = rows[index], row = glyph[index];
    let trailing = 0;
    while (trailing < width && blank(line[width - 1 - trailing])) trailing++;
    let leading = 0;
    while (leading < row.length && blank(row[leading])) leading++;
    // A row with no ink on either side puts no limit on the slide.
    if (trailing === width || leading === row.length) continue;
    amount = Math.min(amount, trailing + leading - LETTER_GAP);
  }
  return Math.max(0, Math.min(amount, width));
}

/** The rows of `text` in `font`, smushed, with hard blanks as spaces, trailing blanks and blank top and bottom rows removed. */
export function renderWordmark(text, font = romanFont()) {
  const { height, hardblank, glyphs } = font;
  let rows = Array.from({ length: height }, () => "");
  for (const char of text) {
    const glyph = glyphs.get(char);
    if (!glyph) throw new Error(`The wordmark font has no character "${char}".`);
    const shift = rows[0].length ? smushAmount(rows, glyph, font) : 0;
    rows = rows.map((line, index) => {
      const chars = [...line];
      for (let column = 0; column < shift; column++) {
        const at = Math.max(0, line.length - shift + column);
        chars[at] = smushed(chars[at] ?? " ", glyph[index][column] ?? " ", hardblank);
      }
      return chars.join("") + glyph[index].slice(shift);
    });
  }
  const trimmed = rows.map((row) => row.replaceAll(hardblank, " ").replace(/ +$/, ""));
  while (trimmed.length && !trimmed[0]) trimmed.shift();
  while (trimmed.length && !trimmed.at(-1)) trimmed.pop();
  return trimmed.join("\n");
}

/** The Roman font with the family's g. */
export function romanFont() {
  const font = parseFont(readFileSync(FONT, "latin1"));
  font.glyphs.set("g", familyG(font.glyphs.get("g")));
  return font;
}

/** Write the wordmark of `name` to `path` (assets/logo.txt), ending with a newline. */
export function writeWordmark(name, path = "assets/logo.txt") {
  const text = renderWordmark(name);
  writeFileSync(path, `${text}\n`);
  return text;
}
