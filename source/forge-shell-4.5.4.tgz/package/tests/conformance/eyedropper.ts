import assert from "node:assert/strict";
import { test } from "node:test";
import { EYEDROPPER_SIZES, averagePixels, createEyedropper, eyedropperSizeLabel, sampleSquare } from "../../source/app/eyedropper";
import { createToolModes } from "../../source/app/tool-modes";

test("the averaging square is centred on the pixel and cut to the image", () => {
  assert.deepEqual(EYEDROPPER_SIZES, [1, 3, 5]);
  assert.deepEqual(sampleSquare(10.7, 10.2, 1, 100, 100), { left: 10, top: 10, right: 11, bottom: 11 }, "1 px is the pixel itself");
  assert.deepEqual(sampleSquare(10, 10, 3, 100, 100), { left: 9, top: 9, right: 12, bottom: 12 });
  assert.deepEqual(sampleSquare(10, 10, 5, 100, 100), { left: 8, top: 8, right: 13, bottom: 13 });
  assert.deepEqual(sampleSquare(0, 99, 5, 100, 100), { left: 0, top: 97, right: 3, bottom: 100 }, "cut at the corner");
  assert.equal(sampleSquare(-1, 5, 1, 100, 100), null, "off the image");
  assert.deepEqual(sampleSquare(-1, 5, 3, 100, 100), { left: 0, top: 4, right: 1, bottom: 7 }, "a 3 px square one pixel off still reaches it");
  assert.equal(eyedropperSizeLabel(3), "3 × 3 px");
});

test("the mean is over the pixels of the square inside the image", () => {
  // 2 × 2 image: red, green / blue, white
  const data = new Uint8ClampedArray([255, 0, 0, 255, 0, 255, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255]);
  const image = { data, width: 2, height: 2 };
  assert.deepEqual(averagePixels(image, 1, 0, 1), { r: 0, g: 255, b: 0 });
  assert.deepEqual(averagePixels(image, 0, 0, 3), { r: 127.5, g: 127.5, b: 127.5 }, "all four pixels, the rest of the square is off the image");
  assert.deepEqual(averagePixels(image, 0, 0, 1), { r: 255, g: 0, b: 0 });
  assert.equal(averagePixels(image, 5, 5, 3), null);
});

// Just enough of the DOM for the mode: listeners by type, classes and children.
class Fake {
  className = ""; hidden = false; value = ""; textContent = ""; style: Record<string, string> = {}; children: Fake[] = []; removed = false;
  listeners = new Map<string, Set<(event: unknown) => void>>();
  classes = new Set<string>();
  classList = { add: (n: string) => this.classes.add(n), remove: (n: string) => this.classes.delete(n) };
  append(...items: Fake[]) { this.children.push(...items); }
  remove() { this.removed = true; }
  addEventListener(type: string, fn: (event: unknown) => void) { if (!this.listeners.has(type)) this.listeners.set(type, new Set()); this.listeners.get(type)!.add(fn); }
  removeEventListener(type: string, fn: (event: unknown) => void) { this.listeners.get(type)?.delete(fn); }
  fire(type: string, event: object) { for (const fn of [...(this.listeners.get(type) ?? [])]) fn(event); }
  count(type: string) { return this.listeners.get(type)?.size ?? 0; }
  getBoundingClientRect() { return { left: 100, top: 50, width: 400, height: 300 }; }
}
const setup = (extra: { repeat?: boolean; scale?: number } = {}) => {
  const doc = Object.assign(new Fake(), { createElement: () => new Fake() });
  const surface = new Fake();
  let label = "";
  const modes = createToolModes({ setSelected() {}, setMode: (text) => { label = text; } }, () => {}, doc as never);
  const picks: number[][] = [];
  let cancels = 0;
  const sizes: number[] = [];
  const dropper = createEyedropper(modes, { surface: surface as never, document: doc as never, scale: () => extra.scale ?? 1, repeat: extra.repeat,
    onPick: (x, y, size) => picks.push([x, y, size]), onCancel: () => cancels++, onSize: (size) => sizes.push(size) });
  const press = (clientX: number, clientY: number, button = 0) => surface.fire("pointerdown", { clientX, clientY, button, preventDefault() {}, stopPropagation() {} });
  return { doc, surface, modes, dropper, picks, sizes, press, label: () => label, cancels: () => cancels };
};

test("the eyedropper is a tool mode: its label, the crosshair, and a pick that returns to the neutral mode", () => {
  const t = setup({ scale: 2 });
  t.dropper.activate();
  assert.equal(t.label(), "Pick a colour. Press Esc to finish");
  assert.equal(t.modes.active, "eyedropper");
  assert.ok(t.surface.classes.has("eyedropper-active"));
  // client (161, 71) is 61, 21 px into the surface; at 2 px per pixel that is pixel (30, 10)
  t.press(161, 71);
  assert.deepEqual(t.picks, [[30, 10, 3]], "the pixel and the default 3 px square");
  assert.equal(t.modes.active, null);
  assert.equal(t.label(), "");
  assert.ok(!t.surface.classes.has("eyedropper-active"));
  assert.equal(t.surface.count("pointerdown"), 0, "its listeners are removed");
  assert.equal(t.cancels(), 0, "a pick is not a cancel");
});

test("Esc or another tool leaves the eyedropper as a cancel, and the size keys change the square", () => {
  const t = setup();
  t.dropper.activate();
  t.doc.fire("keydown", { key: "5" });
  assert.equal(t.dropper.size, 5);
  t.doc.fire("keydown", { key: "4" });
  assert.equal(t.dropper.size, 5, "4 is not a size");
  assert.deepEqual(t.sizes, [5]);
  t.doc.fire("keydown", { key: "Escape" });
  assert.equal(t.cancels(), 1);
  assert.equal(t.dropper.active, false);
  t.doc.fire("keydown", { key: "1" });
  assert.equal(t.dropper.size, 5, "the size keys work only in the mode");
  t.dropper.activate();
  t.modes.activate("measure", "Measure", "a distance");
  assert.equal(t.cancels(), 2, "choosing another tool cancels");
  t.press(150, 60, 2);
  assert.deepEqual(t.picks, [], "out of the mode nothing is picked");
});

test("with repeat the mode stays after a pick, and a right press picks nothing", () => {
  const t = setup({ repeat: true });
  t.dropper.activate();
  t.press(110, 60, 2);
  assert.deepEqual(t.picks, []);
  t.press(110, 60);
  t.press(120, 70);
  assert.deepEqual(t.picks, [[10, 10, 3], [20, 20, 3]]);
  assert.equal(t.modes.active, "eyedropper");
  t.dropper.cancel();
  assert.equal(t.cancels(), 1);
  assert.throws(() => createEyedropper(t.modes, { surface: t.surface as never, document: t.doc as never, size: 4, onPick() {} }), /The eyedropper size 4 is not one of 1, 3, 5\./);
});
