// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { build, context } from "esbuild";
import { createHash } from "node:crypto";
import { cpSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";
import { APP_MAIN, buildSetupBundle, setupEntry } from "./build-installer.mjs";
import { collectLicenses, licensesMarkdown } from "./licenses.mjs";
import { brandCss } from "./theme.mjs";
import { isTracked, trackedFiles } from "./tracked-files.mjs";

const shellStyles = (name) => fileURLToPath(new URL(`../source/styles/${name}`, import.meta.url));

/** Build a Forge app while the app owns its domain entry points and release inputs. */
export async function buildForgeApp({ configPath = "forge.config.json", targets, staticFiles = [], releaseDirs = [], releaseFiles = [], releaseCopies = [], releaseIgnore = [], watch = false }) {
  const config = JSON.parse(readFileSync(configPath, "utf8"));
  if (!/^[a-z][a-z0-9-]*$/.test(config.identity.id)) throw new Error(`${configPath} identity.id must be a lowercase identifier`);
  const version = readFileSync(config.identity.versionSource, "utf8").trim();
  const pkgVersion = JSON.parse(readFileSync("package.json", "utf8")).version;
  const lockfile = JSON.parse(readFileSync("package-lock.json", "utf8"));
  if (version !== pkgVersion || version !== lockfile.version || version !== lockfile.packages?.[""]?.version) {
    throw new Error("VERSION, package.json and package-lock.json must have the same version");
  }
  const options = { bundle: true, sourcemap: true, logLevel: "warning", target: "es2022", keepNames: true };

  // Browser and Electron both load the same renderer assets.
  rmSync("build/app", { recursive: true, force: true });
  mkdirSync("build/app", { recursive: true });
  cpSync("public", "build/app", { recursive: true });
  cpSync(shellStyles("tokens.css"), "build/app/forge-tokens.css");
  writeFileSync("build/app/forge-brand.css", brandCss(config.theme));
  cpSync(shellStyles("shell.css"), "build/app/forge-shell.css");
  // The page names icon.png as its icon, so the application icon is copied even when the app does not list it.
  const files = existsSync("assets/icon.png") && !staticFiles.some(([, target]) => target === "icon.png") ? [...staticFiles, ["assets/icon.png", "icon.png"]] : staticFiles;
  for (const [source, target] of files) cpSync(source, `build/app/${target}`);
  // The licence text of every bundled third-party package ships with the app.
  const licenses = collectLicenses();
  if (licenses.missing.length) throw new Error(`These packages declare no licence: ${licenses.missing.join(", ")}. Check their terms before shipping them.`);
  writeFileSync("build/app/THIRD-PARTY-LICENSES.md", licensesMarkdown(licenses.entries));
  if (!config.html?.center || !config.html?.panes) throw new Error(`${configPath} html.center and html.panes are required`);
  let index = readFileSync(fileURLToPath(new URL("../templates/app/index.html", import.meta.url)), "utf8")
    .replace("__FORGE_CENTER_HTML__", () => readFileSync(config.html.center, "utf8").trim())
    .replace("__FORGE_DOMAIN_PANES_HTML__", () => readFileSync(config.html.panes, "utf8").trim());
  if (files.some(([source, target]) => source === "assets/icon.png" && target === "icon.png")) {
    const iconVersion = createHash("sha256").update(readFileSync("assets/icon.png")).digest("hex").slice(0, 12);
    index = index.replace('href="icon.png"', `href="icon.png?v=${iconVersion}"`);
  }
  const productName = config.identity.name.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
  const appPrePaint = config.html.prePaintScript ? readFileSync(config.html.prePaintScript, "utf8").trim() : "";
  writeFileSync("build/app/index.html", index
    .replace("__FORGE_PRODUCT_NAME__", () => productName)
    .replace('"__FORGE_SETTINGS_KEY__"', () => JSON.stringify(`${config.identity.id}.settings`))
    .replace("__FORGE_APP_PREPAINT__", () => appPrePaint));
  const sourceRoot = "build/app/release-source";
  mkdirSync(sourceRoot, { recursive: true });
  // Only tracked files ship as the corresponding source: a file kept only on the developer's disk stays there.
  const tracked = trackedFiles();
  for (const dir of releaseDirs) cpSync(dir, `${sourceRoot}/${dir}`, { recursive: true, filter: (entry) => {
    if (!isTracked(tracked, entry)) return false;
    const path = entry.replaceAll("\\", "/");
    return !path.endsWith("/.DS_Store") && !releaseIgnore.includes(path);
  } });
  for (const file of releaseFiles) cpSync(file, `${sourceRoot}/${file}`);
  for (const { from, to } of releaseCopies) cpSync(from, `${sourceRoot}/${to}`, { recursive: true, dereference: true,
    filter: (entry) => {
      const path = entry.replaceAll("\\", "/");
      return !path.endsWith("/.DS_Store") && !path.endsWith("/node_modules") && !path.endsWith("/build") && !releaseIgnore.includes(path);
    },
  });
  // The generated licence texts also ship with the corresponding source.
  cpSync("build/app/THIRD-PARTY-LICENSES.md", `${sourceRoot}/THIRD-PARTY-LICENSES.md`);

  // The Electron main process (package.json "main") is built as app-main.cjs beside a generated entry, which runs
  // the bundled Forge setup instead when the app is started from its setup executable (see build-installer.mjs).
  const electronMain = JSON.parse(readFileSync("package.json", "utf8")).main;
  const isMain = (target) => !!electronMain && !!target.outfile && normalize(target.outfile) === normalize(electronMain);
  const builds = targets.map((target) => ({ ...options, ...target, ...(isMain(target) ? { outfile: join(dirname(target.outfile), APP_MAIN) } : {}),
    define: { ...(target.define ?? {}), __FORGE_VERSION__: JSON.stringify(version) } }));
  if (targets.some(isMain)) {
    mkdirSync(dirname(electronMain), { recursive: true });
    writeFileSync(electronMain, setupEntry());
    await buildSetupBundle({ config, version, desktopDir: dirname(electronMain) });
  }
  if (watch) {
    for (const target of builds) await (await context(target)).watch();
    console.log("watching…");
  } else await Promise.all(builds.map((target) => build(target)));
}
