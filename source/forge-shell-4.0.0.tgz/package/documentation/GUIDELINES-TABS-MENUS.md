# Forge application guidelines: tabs and menus

Part of [GUIDELINES.md](GUIDELINES.md), section 6.

## 6. Tabs, menus and toolbar

### Document tabs

Document tabs represent the unit defined in the profile.

| Behaviour | Specification |
|---|---|
| Active top line | Follows the tab face exactly: `left = tabRect.left - rowRect.left + row.scrollLeft + borderLeftWidth` and `width = max(0, tabRect.width - borderLeftWidth - borderRightWidth)`, with the rectangles from `getBoundingClientRect()` and the border widths from the computed style. Fractional pixels are preserved, the line never paints across a border or into a neighbouring tab, and its position is recomputed during tab growth, shrinkage and resize. |
| Colours | The active tab uses the `--raised` background and `--text`; inactive labels use `--text2`. |
| Controls | A close control appears on hover and on the active tab; its hover state is a `--control-hover` background with a `--text` icon. A `+` control appears when New creates a tab; it is 30 px wide, transparent with a `--text2` icon, and becomes `--panel` with `--text` on hover. Middle click closes a tab. |
| Switching | Changes the active document and its inspector, Messages and Terminal context. The profile specifies whether switching stops audio or background work. |
| Overflow | Tabs shrink to their 90 px minimum width before the row scrolls, as browser tabs do; then they scroll horizontally with the scrollbar hidden, and the `+` control stays pinned at the right end of the row. A closing tab stops accepting pointer actions before its exit animation completes. |

### New documents, Untitled names and closing tabs

In every Forge application with document or editor-file tabs, **New file/document** (`CmdOrCtrl+N`, File › New and the `+` control) creates and activates a separate unsaved in-memory view. No file is written merely because the tab appeared. A separate **New project** workflow may request a location or metadata, but it does not replace New file/document where the application has editable file tabs. The profile defines the domain content, native format and initial settings of the new view; the tab and naming behaviour of this section does not vary by application. A launch without an open document shows the welcome state with no listed tab, and the first New creates `Untitled 1`.

| Rule | Specification |
|---|---|
| Name | An unsaved new tab is named `Untitled n`: capital `U`, one ordinary space and a positive base-10 integer without leading zeroes. |
| Choice of n | Before every New, the exact names of the tabs open in this window are collected, and the smallest `n >= 1` for which `Untitled n` is absent is chosen. Full names are compared case-sensitively; no lifetime counter, highest used number, history of closed tabs or search of file names on disk is used. |
| Examples | An empty window yields `Untitled 1`. With `Untitled 1` and `Untitled 3` open, New yields `Untitled 2`; after `Untitled 2` is closed, the next New yields `Untitled 2` again. |
| Stability | Existing tabs keep their names and are never renumbered when another tab closes or is saved. A successful first save renames the tab to the base name of the saved file, with its extension, and frees the Untitled number. A cancelled or failed save keeps the name and number reserved. A tab named exactly `Untitled 1` reserves 1, whereas `Untitled 1.<extension>` does not. |
| Position | The new tab is inserted immediately after the active tab and activated; with no tabs open it is inserted first. The `+` control remains after all document tabs. A file opened from disk replaces the sole untouched, unsaved blank tab, and otherwise opens immediately after the active tab. An edited blank tab is never silently discarded. |
| Label | The label is the current name of the document, centred within the flexible area between the left dirty-mark slot and the right close control, for `Untitled n` as for every other name and in every active, inactive, clean and dirty state. It occupies one line and ends with an ellipsis beyond the 220 px maximum width. The tooltip may show the full path. A dirty dot appears only after an unsaved edit; a new untouched tab has none. |

Closing a tab removes its view from the open-tab list and does not delete the saved file, project or internal file.

| Case | Behaviour |
|---|---|
| Pristine unsaved blank tab | Closes without a prompt |
| Unsaved tab with content or a path | Offers Save, Discard and Cancel; Cancel or a failed or cancelled Save keeps it open |
| Inactive tab closed | The active tab remains selected |
| Active tab closed | The tab that shifts into its position is selected, or the last preceding tab when none follows |
| Last tab closed | The documentless welcome state, with Terminal available |
| Cleanup | The temporary view state and the per-document Messages and history are removed according to their session lifetime |
| Motion | The 150 ms exit motion of section 5 applies, and pointer input stops before it ends |

The **`tabs`** command lists the open tabs in visual order and numbers the rows from 1. These numbers are positions and not `Untitled n` identities: they shift when tabs are inserted or closed, and a supported `tab <number>` or `close <number>` form addresses the current position. With no tab open, `tabs` answers `No <document noun> tabs open.` with the noun of the profile. The profile records the content of a new file, the label of the welcome button, the saved extension and, for multi-file projects, whether closing a tab removes only a file view; it cannot change the numbering and reuse rule of unsaved tabs.

### Bottom tabs, inspector headings and the action registry

| Subject | Specification |
|---|---|
| Bottom tabs | Utilities of the active document, not documents. Terminal is selected on launch and whenever a new document or project becomes active. Terminal is first and Messages last, with domain panes between them under profile-defined labels and order. The active tab uses `--text` and inactive labels `--text3`. Opening Messages marks its unseen problems as seen. A right-aligned Clear action appears only when Messages is active and non-empty. |
| Inspector headings | Buttons. Hover brightens the title to `--text-strong` and the chevron to `--accent-light`, without filling the heading. A collapsed chevron points right (0°) and an open one down (90°). A click toggles one section and an Option click applies that state to all sections. The profile records the initial folds and which folds persist. |
| Action registry | Actions are defined once, each with a stable identifier, exact label, shortcut, enabled and checked condition, handler, tooltip and command mapping. Native menus are rendered on macOS desktop; the page draws them in the browser and on Windows desktop. |

Menu headings use initial capitals and appear in the order File, Edit, View, profile-defined domain menus, Help. File contains New, Open, Save, Export and Close where they exist; Edit contains Undo and Redo, clipboard and object edits; View contains zoom, panels and appearance; Help provides the four information destinations specified below, and macOS places About in the product-name menu. Related actions are grouped by separators. The rendering and content of menus are specified under "Menu rendering and content".

### Renaming

A document or project is renamed in one place, the `Name` row of the inspector. Document tabs show the name but are read-only: a double click on a tab does not edit it, and its context menu keeps its own actions (such as Close) without a second editor. Files and folders in the file tree of an application have no `Name` row and are renamed in place on their own row.

| Part | Specification |
|---|---|
| Start | A double click on the name; `F2` or Return while the name has keyboard focus; or **Rename…** (`F2`) in its context menu. A right click opens the menu without starting the edit. |
| Field | The name is replaced by the shared field, with the same fill, border, radius, height and focus ring as the other text fields of the inspector (`.name-edit`, styled like `.field input`). It takes the place and size of the row, keeps focus, and carries the accessible name given by the application (`Document name`). |
| Selection | The whole name is selected; for a file only the base name before the last dot, so that the extension remains. |
| Confirmation | Return applies. Leaving the field applies a name that is valid and changed; an unchanged name has no effect. |
| Cancellation | Escape restores the old name, and so does leaving the field with an invalid name. |
| Rejection | Return with an invalid name gives the field the `--error` border and `aria-invalid="true"`, keeps it open and sends the reason to Messages and the status bar. The reasons are sentences with a final period: `Enter a name.`, `A name cannot contain / or \.`, `The name <name> is already used.` Names are compared without regard to case within the same place. |
| Unsaved document | The name becomes the one offered by the first Save; nothing is written to disk. |
| Saved document or file | The saved file is renamed on disk through the approved paths of the desktop bridge. The profile states whether a saved document can be renamed. |

An element with a rename is focusable and its tooltip is `Double-click or press F2 to rename.` The shell provides `startRename`, `attachRename` and `validateName`; an application supplies the current name, additional rules and the effect of applying a name.

### File tree

An application with project files lists them in the inspector with `renderFileTree`. The tree, its rows and its behaviour are common to all applications; the application supplies the files, the effect of opening one, and its own rules (locked paths, paths that must stay, the destination of a dropped file).

| Part | Specification |
|---|---|
| Row | 26 px high, 12 px UI text, 12 px indent per level, a 14 px line icon (`--text3`), then the name truncated with an ellipsis. Folders have a chevron (right when closed, down when open, rotated in 150 ms, without motion under reduced motion) and `--text2` names. Hidden files are `--text3` and sort after visible ones. A locked file shows a small lock icon at the right, with the reason as its tooltip. |
| Order | Folders before files; each level sorted by name, ignoring case and treating digits as numbers. A folder the application does not list on its own, because it only holds listed files, is drawn and acts as a folder for every command (`entryOf`, `isFolder`). |
| Selection | A selected row is `--control-hover` while the tree has no focus and `--accent-fill` with `--accent-foreground` while it has. A click selects, Shift extends a range, Cmd or Ctrl toggles, and a click elsewhere clears. Only the focused row is in the Tab order. |
| Keyboard | Up, Down, Home and End move; Right opens a folder or moves into it, Left closes it or moves to its parent. The commands take the keys of Finder and File Explorer (`treeKeyCommand`), listed below. |
| Open | A double click runs the open action of the application on a file and toggles a folder; Open does the same from the keyboard. |
| Context menu | In Finder and File Explorer order, groups divided by separators: **Open** and the file entries of the application; **New file**, **New folder** and **Add files…** on a folder or the empty area; the entries of the application for that target (`contextMenu`); **Show in Finder** or **Show in File Explorer**; **Cut**, **Copy**, **Paste**, **Duplicate** and **Copy path** (**Copy paths** for several rows); **Rename…** and **Delete** (with the count for several rows). A command the application does not provide is left out; a refused one stays, disabled, with the reason as its tooltip. |
| Commands | The names are those of both platforms and say what happens: **Delete**, never `Move to Trash` (the application decides whether the file goes to the Trash or the Recycle Bin). Copies are named as the platform names them (`copyTarget`): `notes copy.txt`, `notes copy 2.txt` on macOS, `notes - Copy.txt`, `notes - Copy (2).txt` on Windows. A new file or folder takes the first free name (`newEntryName`) and is renamed in place at once. Cut rows are drawn at 55 % opacity until they are pasted. |
| Extension | An application adds context-menu entries for any target (`contextMenu`, `menu` for a file), icon buttons at the end of a row such as hide, lock or select (`rowActions`, with `TREE_ACTION_ICONS`), icons for its own kinds of file (`icons`), and keys of its own (`keyDown`, before the tree's). A row action is `--text3`, 18 × 18 px with a 12 px icon, visible while the row is hovered or selected, and always visible in `--accent-light` while it is on. |
| Icons and badges | A row shows the icon of its kind: folder, text, code, data, PDF, image, spreadsheet, archive, audio, video or other (`FILE_ICONS`); `fileKind(path)` gives the kind from the extension for an application without kinds of its own. A file's status sits at the right of its row, 12 px in `--text3`, with its tooltip: an application that marks files gives `status` and every file row then shows one, `editable` (`Editable file.`) or `readOnly` (`Read-only file.`) from `TREE_STATUS`, or a status of its own; folders have none (`treeBadges`). The status is shown in the tree only, never in a document tab or a view header. Further badges of the application (`badges`) follow it. |
| Notices | Copy path confirms in the status bar (`notice`): `Copied the path of <path>.` or `Copied <n> paths.` |

| Command | macOS | Windows |
|---|---|---|
| Open | Cmd+O, Cmd+Down | Enter |
| Rename… | Return, `F2` | `F2` |
| Delete | Cmd+Delete | Delete |
| New folder | none (Shift+Cmd+N is New window) | none (Ctrl+Shift+N is New window) |
| Duplicate | Cmd+D | none |
| Cut, Copy, Paste | Cmd+X, Cmd+C, Cmd+V | Ctrl+X, Ctrl+C, Ctrl+V |
| Copy path | Option+Cmd+C | Ctrl+Shift+C |
| Select all | Cmd+A | Ctrl+A |

The tests `the tree's commands carry the names and keys of Finder and File Explorer`, `keys map to the platform's commands` and `copies take the platform's copy names, and new entries the first free name` and `a folder that only holds listed files is a folder for every command` enforce the table.
| Rename | In place with the shared name field (see Renaming): only the base name of a file is selected, a bare name stays in its folder and a name with a slash moves it; a name already used, `.`, `..` or a backslash is rejected with a sentence. |
| Drag and drop | Rows dragged onto a folder or the tree are moved (a folder cannot move into itself, and locked rows cannot be dragged). Files dropped from the system are added to that folder, and on the tree root the application may choose a folder by file type. The target folder shows the accent fill while the pointer is over it. |
| Empty | `No files.` in `--text3` |
| Redrawing | `renderFileTree` is called again on the same element to redraw; the listeners of the previous drawing are removed, so a key, a drop or a context menu acts once however often the tree was drawn. |

### Files that change outside the application

When a file open in the editor changes on disk, the application compares the text on disk with what it last read or wrote and with the editor.

| Situation | Outcome |
|---|---|
| Nothing changed | No action |
| Only the disk changed | Silent import |
| The editor also holds unsaved edits | `askExternalChange()` opens a dialog titled `<file> changed outside <Product>, and the editor has edits that are not saved.` with **Keep mine** (Escape) and the primary **Reload** (Return) |

`externalAction()` decides, and unsaved edits are never discarded without a question.

### Dropping files

A window or view that opens files dropped from the system uses `attachFileDrop(target, options)` (`file-drop.ts`). The application gives the accepted extensions, the sentence of the drop target and what opening a file does; the shell gives the target, the sorting and the refusal.

| Part | Rule |
|---|---|
| Accepted files | By extension with its dot (`accept: [".png", ".jpg", ".tif"]`), ignoring case (`acceptsFile`); a name without an extension, or with a leading dot only, is refused. `.tiff` and `.tif` are different extensions, so an application that takes both lists both. |
| Drop target | Shown only while a drag carries files from the system (`dragHasFiles`), never for text or rows dragged inside the page. It covers the target: the accent at 10 % with a 2 px dashed `--accent-light` outline 6 px inside the edge, and the sentence of the application (`label`, such as `Drop images to open them.`) centred on `--panel` in 12 px UI `--text`. It stays shown while the pointer crosses the target's children and hides when the pointer leaves the target or drops. |
| Refusal | One sentence for the refused files of a drop (`dropMessage`): `Cannot open notes.docx. Drop a .png, .jpg or .tif file.` At most three names are listed and the rest counted (`Cannot open a, b, c and 2 more.`). The accepted files of the same drop still open. The application sends the sentence to Messages as an error and to the status bar (`onRefused`). |
| One file | With `multiple: false`, a drop of more than one accepted file opens none and answers `Drop one file at a time.` |
| Paths | Each opened file is given as `{ name, path, file }`: the contents are read from `file`; `path` is the path on disk from the desktop bridge (`pathFor: bridge.pathForFile`, Electron's `webUtils.getPathForFile`, which the preload passes to `createDesktopBridge`), and `null` in the browser. |
| Inner targets | A drop that an inner element has already handled (`preventDefault`), such as a folder of the file tree, is left to it. |

The tests `a dropped file is accepted by its extension, ignoring case, and a name without one is refused`, `refused files are named in one sentence, three at most, with the accepted kinds`, `a drop keeps the accepted files and reports the others, and a single-file target refuses two`, `the drop target shows only while files are over it, across child elements, and hands over paths` and `in the browser a dropped file has no path, and the bridge gives the desktop path through webUtils` enforce the rules.

### Keyboard shortcut tiers

Shortcuts come in tiers (`shortcutTier`), so that an application's own commands never take a key the shell, the system or typing needs.

| Tier | macOS | Windows | Owner |
|---|---|---|---|
| Universal | Cmd and a key | Ctrl and a key | The shell: the standard commands of `UNIVERSAL_SHORTCUTS` (New, Open, Save, Save as, Close, Print, Quit, Preferences, Undo, Redo, Cut, Copy, Paste, Select all, Find, Find next and previous, Go to line, Toggle comment, Zoom in and out, Fit on Cmd+0, Actual size on Cmd+1, Show inspector, Show bottom panel, New window, Duplicate, the four Arrange commands, and the next and previous tab) and Replace (`replaceShortcut`: Option+Cmd+F on macOS, Ctrl+H on Windows) |
| App | Shift+Cmd and a letter | Ctrl+Shift and a letter | The application's commands (`appShortcut(letter, "app")`) |
| Secondary | Option+Cmd and a letter | No default | Rarer application commands (`appShortcut(letter, "secondary")`); Ctrl+Alt is AltGr on Windows and types characters on Greek and most European keyboards |
| Tool | A bare key | A bare key | Canvas tools, only while no text field has the focus |

**Conventional shortcuts.** A shortcut that other applications have made conventional for one meaning is kept, outside the tiers: the registry entry names its convention (`convention`, one of `CONVENTIONAL_SHORTCUTS`), and the key must be the convention's. Group and Ungroup are Cmd+G and Shift+Cmd+G; Bold, Italic and Underline are Cmd+B, I and U; Run is Cmd+Return or Cmd+R; Reload or restart is Cmd+R; Build is Cmd+B. A convention takes a universal key only where it names it (`replaces`: Group takes Find next's Cmd+G, Italic takes Show inspector's Cmd+I). Every other command follows the tiers, with no exceptions: a key with a different meaning elsewhere, such as Cmd+E for Rotate or Cmd+Right for Step, which moves to the end of a line in every text field, takes an App or Secondary key.

`checkShortcuts(entries, mac)` reports, as sentences, two commands on one key; a key the system keeps (such as Cmd+H, Cmd+M, Ctrl+Cmd+F, Shift+Cmd+3 to 5 on macOS and Alt+F4, Alt+Tab, Ctrl+Esc on Windows); an application command on a universal key or on Cmd or Ctrl with a single other key; and keys that type characters: Shift alone, Option alone on macOS, and Alt, Ctrl+Alt and Alt+Shift on Windows. An application runs it over its registry in its own tests. The tests `shortcuts fall into tiers: the shell's universal keys, two-modifier app keys, and bare tool keys`, `the shortcut check reports clashes, system keys, universal keys taken by an app and keys that type characters` and `a conventional shortcut may stay outside the tiers when it names its convention; anything else follows the tiers` enforce the table.

### Upper menu bar, application menu and Help

The upper menu bar uses initial-capital labels in the shared order File, Edit, View, application-specific domain menus, Help. On macOS desktop the native menu of the product name precedes File and the native Window menu immediately precedes Help; the browser menu bar and the Windows desktop menu omit these macOS menus unless the profile gives a concrete reason for an equivalent. The profile lists every top-level label in display order, every submenu and separator, the identifier and exact label of each action, and its enabled and checked condition in the open-document and welcome states. An empty domain menu is not displayed merely to match another Forge application. The application menu is the product-name menu of the operating system; the application icon is not an in-window About button.

| Top-level menu | Shared responsibility | Specified by the profile |
|---|---|---|
| `<ProductName>` (macOS desktop only) | About `<ProductName>` first, then the native Services, Hide `<ProductName>`, Hide Others, Show All and Quit `<ProductName>` roles, separated as native groups | Product name, About action identifier, genuine application-specific native items; About dispatches the same action as Help › About on platforms that show it there |
| File | New and Open, examples or recent files when supported, Save and Save as, Import and Export, Close, in workflow order | Exact file and document labels, platform dialogs, formats, recent and example submenus, disabled conditions |
| Edit | Undo and Redo, clipboard actions, selection and domain editing | The actions that require an editable field, a selection or an open document; native text editing keeps working in focused text fields |
| View | Zoom or fit, checked inspector and bottom-panel visibility, display settings and appearance | Exact view labels, panel names, appearance choices, checked states and shortcuts |
| Domain menus | The operations of the application, after View and before Help | Each name, order, submenu, enabled and checked state, and domain shortcut |
| Window (macOS desktop only) | Native window-management roles | Any extra Window item; otherwise the native menu |
| Help | What's new…, Keyboard shortcuts…, Licenses…; on the browser and on non-macOS desktop, About `<ProductName>` first, followed by a separator | Exact product name and content sources of each dialog; the menu does not replace the Terminal `help` command |

All Forge applications provide four information destinations.

| Destination | Content |
|---|---|
| About | An in-application modal with the shared ASCII wordmark, the purpose, the version, credits and attribution, application-specific additions, and a licence summary or link |
| What's new… | The section `## <VERSION>` of `CHANGELOG.md` as numbered release-note rows; the newest section when it is absent, and an unavailable message when there are no sections |
| Keyboard shortcuts… | The current menu shortcuts and application-specific keys, grouped under initial-capital headings and generated from the action registry. Each shortcut is written out as `<modifier> + <key>` with a space either side of each plus, in the platform's names and order (`shortcutText`): `Shift + Cmd + Z`, `Option + Cmd + F`, `Esc` and `Return` on macOS; `Ctrl + Shift + Z`, `Esc` and `Enter` on Windows. Menus keep the compact glyphs of native menus (`displayKey`). |
| Licenses… | The own licence of the application and the included third-party work, followed by the full applicable licence text or an explicit unavailable message |

The shell provides all four (`about.ts`): `helpMenu(productName, appMenuHasAbout)` builds the Help menu with About only where the application menu lacks it; `showAbout()` adds the shared licence summary below the application's own paragraphs; `showWhatsNew()` reads the shipped `CHANGELOG.md` (`releaseNoteBlocks()`); `showShortcuts()` takes groups, which `menuShortcutGroups()` builds from the menu definition, one per top-level menu; and `showLicenses()` lists `SHARED_WORKS` (the shell, Electron and the wordmark lettering) and the application's own included works above the full GPL text, followed by any further licence texts the application ships (`LicenseText`). The profile records the exact credits, licence sources and any domain-specific shortcut groups. Each dialog uses the same wordmark header and closes with its Close button, Esc or a click on the backdrop. Terminal `help` lists command verbs and `help <command>` gives the syntax of a command; selecting an item of the Help menu never inserts a command into the Terminal transcript.

### The component page

`npm run gallery` builds every part of the shell into one page in the frame of an application and serves it on `http://127.0.0.1:4199/`: menus, tool strip, document tabs with long names, a view header, the code editor with its find bar, an outline, inspector sections with a button group at the top and every button state (enabled, disabled and busy, ordinary and primary), fields, a field problem, chips, a slider, measured values with their tooltips, the file tree with a status on every file and the lines of the file under the pointer, a tool flyout, Terminal, Messages with each kind of message, and the status bar. `?show=about`, `shortcuts`, `licenses`, `whatsNew`, `save`, `saveAll`, `apply`, `pick`, `context`, `menu` or `flyout` opens a dialog or menu; `?theme=light` changes the appearance, `?docs=0` shows the welcome screen, `?pane=messages` selects Messages, `?find=0` closes the find bar and `?drop=1` shows the drop target of a file drag. `galleryChecks()` in the page's console lists what it can measure: parts that spill sideways or reach past the window, parts cut off by the pane that holds them, text fields under 100 px wide, and welcome-screen parts, dialogs, the drop target's sentence and button icons more than 2 px off centre (1 px for icons). A visual change to the shell is checked there at 1440 × 900, 1024 × 700, 800 × 600 and 600 × 500, in Dark and Light, before it is released.

### Checking for updates

An application whose profile names its GitHub repository (`identity.repository`, as `owner/name`) checks for a newer release and installs it with one click; one without it has no update check. The check reads the latest published release of that repository (`checkForUpdate()`) and compares its tag (`v3.1.0` or `3.1.0`) with the running version (`compareVersions()`).

| Part | Rule |
|---|---|
| Help menu | **Check for updates…** ends Help, after a separator (`helpMenu(name, appMenuHasAbout, true)`, action `about.updates`). It opens an information dialog that says `<Name> <version> is available. You have <version>.`, or `<Name> is up to date.`, or why the check could not run (`showUpdateCheck()`). |
| Update and restart | On the desktop, when the release has the installer of this platform (`<Name>-v<version>.dmg` or `.exe`, `updateAsset()`), the dialog shows **Update and restart**, which calls the bridge's `installUpdate`. The main process (`registerUpdater()`) downloads only files of the named repository's releases and keeps a download only when its size and GitHub's SHA-256 digest match (`downloadAsset()`). In the browser, and when installing fails, the dialog offers the release page instead. |
| macOS | The disk image is opened out of sight and the new app copied beside the running one; the app quits, and a detached script swaps the two, keeping the old copy until the new one is in place, and opens the new app (`macSwapScript()`). An app opened from its disk image, from a translocated download or from a folder it cannot write cannot replace itself (`cannotReplace()`): the disk image is opened instead, and the person drags the app into Applications. No Apple signing is needed. |
| Windows | The app quits, and a detached script waits, runs the Forge setup with `/S` (it asks for administrator rights once) and opens the installed app again (`windowsUpdateScript()`). A refused or failed setup leaves the installed version, which opens again. |
| At launch | At most once a day (`updateCheckDue()`), a newer release is added to Messages as information: `<Name> <version> is available. Help › Check for updates… installs it.` No dialog opens by itself, and nothing is said when the app is up to date or the check fails. |
| Repository | GitHub answers without sign-in only for a public repository with a published release; a private repository answers `No public release was found.` A token is never shipped in an application. To keep the source private, releases can be published from a separate public repository named in the profile. |

### Menu rendering and content

| Part | Specification |
|---|---|
| Where | macOS desktop uses the native menu bar. The page draws the menus in the browser and on Windows desktop (`drawsMenubar`), where native menus cannot be styled; there the window hides its title bar, keeps the native minimise, maximise and close buttons (`windowChrome`, `usesNativeMenu`), and the drawn menu bar is the title bar. |
| Menu bar | First row of the window, 26 px high (32 px as the Windows title bar, which drags the window and leaves room for its controls), `--raised`, 1 px `--separator` bottom border; titles are 22 px high and 13 px UI, with 8 px side padding and a 5 px radius, and are `--text` at 14 % over the bar when hovered or open |
| Popup | After the macOS menus: `--panel` at 90 % over a 24 px backdrop blur, 1 px border of `--text` at 14 %, 10 px radius, 5 px padding, minimum width 120 px (maximum 380 px, constrained to the viewport minus 8 px), 13 px UI text, maximum height `calc(100vh - 40px)` with vertical scrolling; shadow `0 10px 30px rgba(0,0,0,0.5)` in Dark and `0 8px 24px rgba(35,40,50,0.16)` in Light; never beyond the window |
| Item | Two or three columns: a 14 px check column only in a popup that has a checkable item (`has-checks`), so a menu of plain actions has no gap; the label, and the right-aligned shortcut or submenu arrow; at least 22 px high, 2 px vertical padding, 6 px left and 10 px right; 5 px radius; label `--text`, shortcut and arrow `--text2` |
| Hover and keyboard focus | `--accent-fill` background and `--accent-foreground` text, including the shortcut |
| Disabled | `--text3`, without hover fill or action |
| Separator | 1 px `--hairline` line, 5 px above and below, 10 px inset; never at the start or end of a menu and never twice in succession |
| Keyboard | Outside macOS, Alt pressed and released alone, or `F10`, opens the first menu. Left and Right move between menus, Up and Down between items, Right and Return open a submenu, Return runs an item and Esc closes one level. |
| Roles | A drawn menu performs the standard edit roles (`EDIT_ROLES`: Undo, Redo, Cut, Copy, Paste, Delete, Select all) itself; another role is shown only when the application gives it an action. |
| Heading | An unclickable row in `--text2`, weight 600, used only in submenus that need a label |
| Closing | A popup closes on Esc, on an outside click and on selection |

| Content rule | Specification |
|---|---|
| Labels | Sentence case without a final period; an action is a verb phrase (`Save as…`). The ellipsis `…` marks an action that opens a dialog or requests input. A checked item is a noun phrase whose label does not change (`Show inspector`, not `Hide inspector`). |
| Structure | The items of a submenu do not repeat its name; submenus are at most two levels deep. |
| Shortcuts | In menus, the compact platform display (`⌘`, `⇧`, `⌥` on macOS, `Ctrl+Shift+` on Windows, `displayKey`); in help, tooltips and other text, written out (`Shift + Cmd + Z`, `Ctrl + Shift + Z`, `shortcutText`). Taken from the action registry and never part of the label. |
| State | Checks mark toggles, and one checked choice marks a mutually exclusive setting; an action is disabled when its precondition is absent. |
| Separators | Groups are divided by purpose. A group of one item is permitted, and a menu is never one long unseparated list. |

The order of the shared menus is given below; items an application does not have are omitted and the others keep this order.

| Menu | Order |
|---|---|
| File | New, Open, examples or recent (submenu); separator; Save, Save as, Import and Export; separator; Close |
| Edit | Undo, Redo; separator; Cut, Copy, Paste, Duplicate, Delete; separator; Select all; separator; application edit actions; separator; Find items and Go to; separator; Properties |
| View | Zoom in, Zoom out, Fit, Actual size; separator; Show inspector, Show bottom panel (checked); separator; display toggles and submenus of the application; separator; **Appearance** (submenu with Dark and Light, one checked); on desktop a separator followed by the platform items (Toggle full screen, Developer tools) |
| Help | About `<ProductName>` (only where the platform application menu lacks it); separator; What's new…, Keyboard shortcuts…, Licenses… |

The native application menu and Window menu of macOS are unchanged by these rules, and one definition builds the browser menu bar, the desktop native menu and the context menus.

### Information-dialog presentation

The application icon serves the operating system, the installer and the browser favicon; its bitmap does not appear in the Terminal banner or in the information dialogs, which use the `assets/logo.txt` wordmark. The About item of the macOS product-name menu and Help › About, where present, open the same dialog. The four information destinations share one frame, and only the product text, the accent tokens and the application-specific body content of the profile are substituted.

| Part | Geometry and typography | Foreground and background |
|---|---|---|
| Backdrop | Fixed to all viewport edges, dialog centred, stacking level 200 | `rgba(0,0,0,0.45)` over the application |
| Dialog | Width `min(720px, 100vw - 32px)`, maximum height `100vh - 32px`, 10 px radius, flex column, hidden outer overflow; shadow `0 20px 60px rgba(0,0,0,0.6)` | `--panel` background; default text `--text2` |
| Brand header | 22 px padding, 1 px bottom hairline; the full preformatted wordmark, then the purpose, three spaces and `v<VERSION>`, then a lowercase subtitle | `--raised` background; wordmark `--accent-about`; purpose `--text`; version and subtitle `--text2`; border `--hairline` |
| Body | 18 px top and 22 px side and bottom padding, vertical scroll, 14 px between blocks, 4 px between the rows of a block | `--panel` background |
| Block heading | Sentence case, 700 12 px/1.45 UI font | `--text` |
| Prose | Normal 12 px/1.45 UI font, zero paragraph margin; bold emphasis stays in the UI font | `--text2`; bold `--text` |
| Link | Font inherited from its context (UI prose or mono listing), underlined with a 2 px offset | `--accent-about`; hover `--text`; keyboard focus a 1 px `--accent-about` outline with 2 px offset |
| Inline code | 11.5 px mono | `--text` |
| Numbered release-note row | Grid `9ch minmax(0,1fr)`; 12 px/1.45 mono for marker and grid, the note itself in 12 px/1.45 UI font | Six-character padded `[n]` and exactly three spaces in bold `--accent-about`; note `--text2` |
| Numbered credit and licence row | Grid `9ch 24ch minmax(0,1fr)`; marker, name and description in 12 px/1.45 mono. At a viewport width of at most 560 px the grid is `9ch minmax(0,1fr)` and the description moves to the next row, in column 2. | Marker bold `--accent-about`; name bold `--text2` (the link colour when it is a link); description `--text2` |
| Keyboard-shortcut row | Grid `18ch minmax(0,1fr)` with a 1ch gap; key and explanation in 12 px/1.45 mono. Groups use one column below 760 px and two columns with a 3ch gap from 760 px. | Key bold `--accent-about`; explanation `--text2` |
| Full licence prose | 12 px/1.45 UI font, paragraphs 12 px apart | `--text2` |
| Close | Ordinary panel button, 90 px wide and 24 px high, at the right end of the body | Ordinary control colours of the button table below |

The marker uses the format `("[" + n + "]").padStart(6) + "   "` of Terminal and occupies the first grid column of 9ch. A numbered description is not set in mono merely because its marker is: release-note text is UI, whereas the descriptions of credits and licences and the explanations of shortcuts are mono in the layout of the shell. This distinction holds across Forge applications. The neutral and accent tokens of section 2 apply in both appearances, and a click inside the dialog does not close it.

### Button foreground and background

“Inside” denotes the foreground of the label or icon and “outside” the fill of the button. The same state pairs apply in Dark and Light through the semantic tokens of section 2. A disabled button keeps its ordinary or primary background and dims only its foreground: `--text3` on the ordinary fill, and on the accent fill the foreground mixed 55 % into the fill (2.6 to 3.4:1 on the family fills, against 4.9 to 7.5:1 enabled), since `--text3` there measures about 1.1:1 and vanishes. It neither responds to hover nor accepts clicks.

| Control and state | Background | Foreground | Border and focus |
|---|---|---|---|
| Ordinary panel or dialog button | `--control` | `--text` | No border; visible keyboard focus in `--accent-light` |
| Ordinary button, hovered | `--control-hover` | `--text` | No border |
| Primary panel or dialog button | `--accent-fill` | `--accent-foreground` | No border; visible keyboard focus in `--accent-light` |
| Primary button, hovered | `--accent-hover` | `--accent-foreground` | No border |
| Disabled panel or dialog button | Ordinary or primary fill retained | `--text3` on the ordinary fill; `--accent-foreground` mixed 55 % into `--accent-fill` on the primary | No hover change, no action; default pointer |
| Running (busy) panel or dialog button | Ordinary or primary fill retained | Ordinary foreground, or `--accent-foreground` on primary | No hover change; clicks ignored; `aria-busy="true"`; cursor `progress` |
| Toolbar icon button | Transparent over the `--raised` strip | `--text` | No border |
| Toolbar icon button, hovered | `--control-hover` | `--text` | No border |
| Toolbar icon button, selected | `--accent-fill` | `--accent-foreground` | No border |
| Selected toolbar icon, hovered | `--accent-hover` | `--accent-foreground` | No border |
| Disabled toolbar icon | Transparent over the `--raised` strip | `--text3` | No hover change, no action |
| Menu item or tool-flyout item | Transparent over the menu surface | `--text` | No border |
| Enabled menu or flyout item, hovered or focused | `--accent-fill` | `--accent-foreground`, including the shortcut and submenu text | No border |
| Disabled menu or flyout item | Transparent over the menu surface | `--text3` | No hover fill, no action |

Text inputs and selects use the `--well` fill, the `--text` foreground, a 1 px `--separator` border, a 4 px radius, 6 px of horizontal padding and a height of 22 px. Focus changes the border to `--accent` and adds a 1 px `--accent` ring. Textareas use the same colours and border with 4 px of vertical and 6 px of horizontal padding. An invalid field has a semantic red border and a nearby error message, and checkbox marks use the accent of the application. A property that is disabled independently of an empty document has 45% opacity and no edit action. Every button and chip shows whether it can be clicked by its label: an enabled one has its full label colour and a hover fill, and a disabled one keeps its fill, green or grey, with a dimmed label, a default pointer and no hover; a busy one keeps its fill and its full label colour. Keyboard focus is a 1 px `--accent-light` ring 1 px outside the button. The tests `buttons share a group's width at 24 px, and each kind shows whether it can be clicked`, `a disabled primary label is the foreground 55 % into the accent fill: legible, and clearly dimmer than enabled`, `chips are a button group: 24 px, radius 4, sharing the width, the chosen one in the accent fill`, `a button group holds its buttons in order, each primary or ordinary and enabled or disabled as given`, `every file in the tree shows its status, editable or read-only or the app's own, and folders show none`, `a file's status is shown in the tree only: a view header carries no editable or read-only icon`, `no stylesheet rule draws a status icon in the view header` `info lines show the item's name, then its values, and the empty sentence when there is no item` and `info lines set the name in the UI font and the values in mono` enforce these rules. A filled button never colours only its text with the accent, and a toolbar button has no permanent fill unless it is selected. A button kind specific to an application defines all its states in the profile before it is used.

### Running buttons

A running state is shown by the label and the icon and never by a new colour: a running button keeps the fill of its kind (ordinary `--control`, primary `--accent-fill`) and its normal label colour. Green, red, `--warning` and a spinner colour are not used.

| Case | Behaviour |
|---|---|
| Toggle (`Run` and `Pause`, `Build` and `Cancel`) | The button stays enabled and primary in both states. Its label and icon name the action that a click performs next: `Pause` with a pause or stop icon while running, `Run` with a play icon when paused. |
| Busy action that cannot be cancelled (`Build PDF`) | The button stays in place with the in-progress label (`Building PDF…`, ending in an ellipsis), `aria-busy="true"` and `aria-disabled="true"`. It is not `disabled`, so its label keeps full contrast on the fill. Clicks are ignored, hover has no effect and the pointer shows `progress`. The label returns when the work ends, including after an error. |

The status bar shows the same state as a word (`Running`, `Paused`, `Building`, `Ready`) in `--text2`, and in `--accent-light` while work is in progress. `--warning` and `--error` are reserved for problems and are never used for a normal running state. `setButtonBusy()` applies the busy attributes and the label.

### Toolbar

| Subject | Specification |
|---|---|
| Window chrome on macOS | In a window the toolbar leaves 96 px on the left for the window buttons and shows a hairline after them. In full screen there are no window buttons, so the tools sit 12 px from the left edge and the hairline is hidden. The shell provides this: the main process calls `forwardFullScreen(window)` and the page calls `applyDesktopClasses(window.<bridge>)`, which sets `desktop-mac` and keeps `full-screen` current. An application contains no full-screen handling of its own. |
| Grouping | Undo and Redo; clipboard and object edits; view and zoom; then the tools of the application. General actions use line icons, and domain objects an icon family defined by the application. |
| States | Selected: `--accent-fill` with a white icon. Disabled: `--text3`. Hover: `--control-hover`. |
| Accessible name and tooltip | Every icon button has a concise accessible name and a tooltip with the action and its shortcut; placement guidance is added only for a placement mode. |
| Modes | A tool that changes the next pointer action displays its mode as `<verb> <object>. Press Esc to finish`, and Esc returns to the neutral selection mode. |

**Tooltip wording.** Every tooltip has one of two forms and is set with `setTip()`, never with `.title =`. `checkTipWording()` tests a tip against these rules, and `forge-shell check-app` warns about direct `.title` assignments. An editable readout (`editableValue`) takes a sentence from the application that says what to type, and its tooltip is that sentence with a final period (`editableTip`), never a pointer instruction such as `Click to type`.

| Form | Use | Wording |
|---|---|---|
| Action tip | Toolbar buttons and menu-like controls | The action name with its shortcut in parentheses and without a final period (`Undo (Cmd + Z)`, `Undo (Ctrl + Z)`); the shortcut comes from the action registry and is written out by `shortcutText`; placement guidance follows `: ` |
| Sentence tip | Properties, fields and status | One sentence that starts with a capital, ends with a period and has at most 120 characters (`Set the random seed for reproducible variation.`); it states what the control does and not how to use the mouse |

**Mandatory tool-button rules.** Every tool button is built with `createToolButton` (or `strip.tool`) from the label and accelerator of the action registry; the tooltip is `Action (shortcut)` with platform glyphs, the accessible name is the action label, and no shortcut is typed by hand. Standard actions use the shared `TOOL_ICONS` (undo, redo, cut, copy, paste, fit, zoomIn, zoomOut), 16 × 16 px with a 1.25 px visible line in `currentColor`. Domain icons use `toolIcon()`, so that they share the box and the stroke and take their colour from the button state. The selected, hover, disabled and keyboard-focus states come only from the `.tool` classes (focus is a 1 px `--accent-light` ring) and are not overridden by an application. `forge-shell check-app` warns about icon-only buttons without an accessible name and about icon strokes other than 1.25.

**Shared icons.** Every shared icon is a Lucide icon (ISC) from the shell's list (`LUCIDE_ICONS`, `lucideIcon(name, size)`), drawn at 16 px with a 1.25 px visible line. The Lucide grid is widened to 26.67 units so the glyph fills 75 % of the box, as the old shapes did; the stroke is then 2.08 on that grid. One name means one glyph across all apps. Beyond `TOOL_ICONS` and `STATUS_ICONS`, the shell provides `UI_ICONS`: close, the four chevrons and more for navigation; add, remove, delete, duplicate, rotate, edit, read-only, pointer and check for editing; search, reveal, export, import, link, show, hide, lock, unlock, pin and check-circle for files; refresh and settings. `BUTTON_GLYPHS` are filled 9 px glyphs for the small run controls of a panel button (play, pause, stop, reset, step). An application draws none of these itself: the style lint of `forge-shell check-app` reports a path that repeats a shared icon, with its name. Domain icons (parts, sections, formulas) stay in the application, built with `toolIcon()`.

**Optional modules.** An application may use the modules below; a module that is used follows its specification exactly, and an application that does not use one receives no markup for it.

| Module | Specification |
|---|---|
| Flyout group (`createFlyoutGroup`) | Palette families in a `.flyout-group` after the direct tools. Each flyout button names its family, exposes `aria-haspopup="menu"` and `aria-expanded`, and opens a menu of the available tools of the family. The rows have the icon and name, and the shortcut when the tool has one (`flyoutItemMarkup`). A tool is not checkable, so a flyout has no check column. A tool is an action and never a checkable item: its row is a plain `menuitem` without a check, and the button shows the current tool by its icon. The button's tooltip is `Family: Tool (shortcut)` (`flyoutTip`). A choice closes the menu, selects the tool and updates the icon shown for the family. Escape and an outside press close the menu and return keyboard focus to the button. |
| Toolbar search (`createToolSearch`) | `#toolstrip-search` after the tool groups. The input is a combobox named for the objects searched, with `aria-controls` and `aria-expanded`, and the matches appear in the overlay root. Up and Down change the active result, Enter selects it, and Escape clears and closes. The profile defines the indexed objects and search terms. |
| Tool modes (`createToolModes`) | Exactly one tool is active; the mode label reads `verb object. Press Esc to finish`; Escape always returns to the neutral mode. |

The tests `a flyout row has the three columns of every menu row, and a tool is a plain item, never checked` and `an editable readout's tip is the application's sentence with a final period, and passes the wording check` enforce the flyout rows and the readout tip.

### Status bar

The status bar is the last row of the window, below the bottom panel. It is a single line of 11 px mono text, 24 px high and full width, on `--raised` with a 1 px `--separator` top border, 12 px of side padding and 14 px between items. Nothing wraps, and the middle area is truncated with an ellipsis.

| Part | Position | Content and colour |
|---|---|---|
| State | Left | A round dot of 6 px, the state word (`Ready`, `Running`, `Paused`, `Building`) in `--text`, and an optional short summary such as a time (`0 s`). The colour of the dot encodes the state: `--text3` for idle states (`Ready`, `Paused`), `--accent-light` while work is in progress, and `--warning` or `--error` only for a real problem. |
| Detail | After the state, taking the free space | A persistent explanation in `--text2`. |
| Hint | Replaces the detail while present | A transient result or hint in `--accent-light`; the detail returns when the application clears it. |
| Problems | Right of the detail | A 14 px line icon (`STATUS_ICONS`: a rounded triangle with an exclamation mark for warnings, a circle with one for errors; 1.25 px line, `currentColor`) and the unseen count in tabular numerals, 5 px apart, shown only while unseen problems exist. The colour is `--warning`, or `--error` when the worst unseen problem is an error; a text glyph or an emoji is never used. A click shows Messages and marks the problems as seen. Tooltip and accessible name: `<n> new problem(s). Click to show Messages.` |
| Readouts | Far right | Values of the application such as `Grid 16` and `44%`, in a fixed order, in `--text3`, with a space before units. |

The detail is announced politely to assistive technology. With no document open the bar remains in place and its contents are hidden. Normal running states never use `--warning` or `--error`.

### Tiles

A tile is a titled content region inside a pane (for example a code tile beside a preview tile). Tiles share the width of the pane and do not nest.

| Part | Specification |
|---|---|
| Surface | `--well` for the whole tile; the head has no separate fill |
| Head | 32 px high, 10 px left and 8 px right padding, 6 px gap: a title on the left (weight 600, 11 px UI, `--text`), a flexible space, and an optional readout on the right (10 px mono, `--text2`, no wrapping) |
| Divider | A 1 px `--separator` splitter between tiles that can be dragged |
| Size | Each tile is at least 220 px wide, and a narrower pane scrolls sideways; shares are saved as an application preference and restored |
| Loading | A loading tile keeps its previous content. The head readout names the work (`Building…`, `Updating…`) in `--accent-light` and returns to `--text2` when it ends. No spinner, skeleton block or tile-specific colour is used. |
| Stale | A notice strip lies over the top of the tile without hiding the content: `--raised` fill, 1 px `--separator` border, 4 px radius, 12 px UI text in `--text` |
| Empty | One centred sentence in `--text3` |
| Failure | The reason goes to Messages and the status bar; the readout may read `Failed`, with `--error` for that word only |



**Inspector grouping.** The inspector is a list of sections grouped by subject (section 4, Inspector philosophy). Each section holds its own actions as its first row, and an action appears once in the inspector. There is no General section.
