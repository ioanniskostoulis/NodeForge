// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { followPointer } from "./pointer-drag";
import { setTip } from "./tips";
import { wheelSteps } from "./wheel";

const el = <K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string): HTMLElementTagNameMap[K] => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
};

/** A value a slider snaps to, optionally marked with a tick under the track. */
export interface SliderStop {
  value: number;
  tick?: "minor" | "major";
}

/** Optional extras for a slider. */
export interface SliderExtras {
  /** Scale labels under the track, at slider values. */
  labels?: { value: number; text: string }[];
  /** Double-click: the value to go back to (null: nothing to reset to). */
  reset?: () => number | null;
  /** Group each drag, step or reset as one undoable change. */
  undo?: { begin(): void; end(): void };
}

/**
 * Flat tool-app slider: thin track, accent fill, small thumb. Dragging is continuous, sticking to a
 * tick mark only within 2 px of it; with `stops`, the scroll wheel and arrow keys step
 * from one to the next.
 */
export function makeSlider(value: number, min: number, max: number, onChange: (v: number) => void, enabled = true, stops: SliderStop[] = [], extras: SliderExtras = {}) {
  const ticked = stops.some((s) => s.tick);
  const root = el("div", "slider" + (ticked ? " ticked" : "") + (extras.labels?.length ? " labelled" : ""));
  root.setAttribute("role", "slider");
  root.setAttribute("aria-valuemin", String(min));
  root.setAttribute("aria-valuemax", String(max));
  root.setAttribute("aria-valuenow", String(value));
  const track = el("div", "track"), fill = el("div", "fill"), thumb = el("div", "thumb");
  const marker = el("div", "marker");
  marker.hidden = true;
  const at = (v: number) => `calc(4px + ${(v - min) / (max - min)} * (100% - 8px))`;
  root.append(track);
  for (const s of stops) {
    if (!s.tick) continue;
    const t = el("div", "tick" + (s.tick === "major" ? " major" : ""));
    t.style.left = at(s.value);
    root.append(t);
  }
  for (const l of extras.labels ?? []) {
    const t = el("div", "scale-label", l.text);
    t.style.left = at(l.value);
    // the end labels stay inside the slider
    if (l.value <= min) t.classList.add("start");
    else if (l.value >= max) t.classList.add("end");
    root.append(t);
  }
  root.append(fill, marker, thumb);
  const set = (v: number) => {
    const f = Math.max(0, Math.min(1, (v - min) / (max - min)));
    const x = 4 + f * (root.clientWidth - 8 || 1);
    fill.style.width = `${x}px`;
    thumb.style.left = `${x}px`;
  };
  const change = (v: number) => {
    value = Math.max(min, Math.min(max, v));
    root.setAttribute("aria-valuenow", String(value));
    set(value);
    onChange(value);
  };
  // a step (wheel notch, arrow key, reset) as one undoable change; a drag is one from press to release
  const stepTo = (v: number) => {
    const next = Math.max(min, Math.min(max, v));
    if (next === value) return;
    extras.undo?.begin();
    change(next);
    extras.undo?.end();
  };
  const stepSize = (max - min) / 100;
  const sortedStops = stops.map((s) => s.value).sort((a, b) => a - b);
  const eps = (max - min) * 1e-6;
  /** The value one step from `from` in the direction `dir`: the next stop, or 1/100 of the span without stops. */
  const stepFrom = (from: number, dir: number): number => {
    if (!sortedStops.length) return from + dir * stepSize;
    if (dir > 0) return sortedStops.find((s) => s > from + eps) ?? max;
    return [...sortedStops].reverse().find((s) => s < from - eps) ?? min;
  };
  /** The value `steps` steps from the current one. */
  const stepped = (steps: number): number => {
    let v = value;
    for (let i = 0; i < Math.abs(steps); i++) v = Math.max(min, Math.min(max, stepFrom(v, Math.sign(steps))));
    return v;
  };
  /** The value under the pointer, stuck to a tick mark within 2 px of it, so round values are easy to hit. */
  const valueAt = (clientX: number): number => {
    const r = root.getBoundingClientRect();
    const f = Math.max(0, Math.min(1, (clientX - r.left - 4) / Math.max(1, r.width - 8)));
    let v = min + f * (max - min);
    const magnet = (2 / Math.max(1, r.width - 8)) * (max - min);
    for (const s of stops) if (s.tick && Math.abs(s.value - v) <= magnet) v = s.value;
    return Math.max(min, Math.min(max, v));
  };
  if (enabled) {
    root.addEventListener("pointerdown", (e) => {
      let undoStarted = false;
      const move = (ev: PointerEvent) => {
        const next = valueAt(ev.clientX);
        if (next === value) return;
        if (!undoStarted) {
          extras.undo?.begin();
          undoStarted = true;
        }
        change(next);
      };
      if (!followPointer(root, e, { move, end: () => { if (undoStarted) extras.undo?.end(); } })) return;
      move(e);
    });
    root.tabIndex = 0;
    // a step per notch of a mouse wheel, or per bit of trackpad travel either way; a fast turn is one undo step
    root.addEventListener("wheel", wheelSteps((steps) => stepTo(stepped(steps))), { passive: false });
    root.addEventListener("keydown", (e) => {
      const dir = { ArrowRight: 1, ArrowUp: 1, ArrowLeft: -1, ArrowDown: -1 }[e.key];
      if (dir) stepTo(stepped(dir));
      else if (e.key === "Home") stepTo(min);
      else if (e.key === "End") stepTo(max);
      else return;
      e.preventDefault();
      e.stopPropagation();
    });
    if (extras.reset) {
      root.addEventListener("dblclick", () => {
        const v = extras.reset!();
        if (v !== null) stepTo(v);
      });
    }
  }
  requestAnimationFrame(() => set(value));
  new ResizeObserver(() => set(value)).observe(root);
  return {
    root,
    set: (v: number) => {
      value = v;
      root.setAttribute("aria-valuenow", String(value));
      set(v);
    },
    /** Show a marker at a value (e.g. what's actually reached), or hide it. */
    marker: (v: number | null) => {
      marker.hidden = v === null;
      if (v !== null) marker.style.left = at(Math.max(min, Math.min(max, v)));
    },
  };
}

export function sliderRow(label: string, value: number, min: number, max: number, onChange: (v: number) => void, enabled = true, stops: SliderStop[] = [], extras: SliderExtras = {}) {
  const row = el("div", "slider-row" + (enabled ? "" : " disabled"));
  const head = el("div", "head");
  const valueText = el("span", "value");
  head.append(el("span", "", label), valueText);
  const slider = makeSlider(value, min, max, onChange, enabled, stops, extras);
  slider.root.setAttribute("aria-label", label);
  row.append(head, slider.root);
  return { row, valueText, slider };
}

/** The tooltip of an editable readout: the sentence of the application, ending with a period (`Enter a value from 0 to 255.`). */
export function editableTip(title: string): string {
  const text = title.trim();
  return /[.!?]$/.test(text) ? text : `${text}.`;
}

/**
 * Make a readout editable in place: click it to type a value; Return applies (if `apply`
 * accepts it), Escape or leaving cancels. `title` is a sentence that says what to type.
 */
export function editableValue(span: HTMLElement, current: () => string, apply: (text: string) => boolean, title: string): void {
  span.classList.add("editable");
  setTip(span, editableTip(title));
  span.addEventListener("click", () => {
    const input = el("input", "value-edit");
    input.type = "text";
    input.spellcheck = false;
    input.value = current();
    span.replaceWith(input);
    input.focus();
    input.select();
    // Removing the focused field fires its blur, which would close it a second time from inside the first.
    let closed = false;
    const done = (commit: boolean) => {
      if (closed || !input.isConnected) return;
      if (commit && !apply(input.value)) {
        input.classList.add("invalid");
        return;
      }
      closed = true;
      input.replaceWith(span);
    };
    input.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Enter") done(true);
      else if (e.key === "Escape") done(false);
    });
    input.addEventListener("blur", () => done(false));
  });
}
