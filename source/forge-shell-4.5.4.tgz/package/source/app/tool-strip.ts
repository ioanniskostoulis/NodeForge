// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { toolGroupIndex, type ToolGroupKind } from "./layout-order";
import { createToolButton, type ToolButtonOptions } from "./tool-button";

/** Shared strip frame; applications provide their own actions and palette groups. */
export function createToolStrip(root: HTMLElement, run: (id: string) => void) {
  root.replaceChildren();
  const tools = document.createElement("div");
  tools.id = "toolstrip-tools";
  root.append(tools);
  const buttons = new Map<string, HTMLButtonElement>();
  const mode = document.createElement("span");
  mode.id = "mode-label";

  /**
   * Add a group of tools. A group of `kind` takes its place in the shared order (`TOOL_GROUP_ORDER`: history, clipboard,
   * view, the application's tools, search), whatever order the application adds the groups in; a separator follows it.
   */
  const placed: { kind: ToolGroupKind; element: HTMLElement; separator: HTMLElement }[] = [];
  const group = (items: HTMLElement[], className = "", kind: ToolGroupKind = "app"): void => {
    const element = document.createElement("div");
    element.className = `tool-group ${className}`.trim();
    element.dataset.kind = kind;
    element.append(...items);
    const separator = document.createElement("div");
    separator.className = "tool-sep";
    const index = toolGroupIndex(placed.map((entry) => entry.kind), kind);
    const before = placed[index]?.element ?? null;
    tools.insertBefore(element, before);
    tools.insertBefore(separator, before);
    placed.splice(index, 0, { kind, element, separator });
  };

  /** Deprecated: use `tool`. The accessible name is derived from the title by removing a shortcut or placement note. */
  const button = (icon: string, title: string, id: string, enabled = true): HTMLButtonElement => {
    const element = document.createElement("button");
    element.className = "tool";
    element.innerHTML = icon;
    element.title = title;
    element.setAttribute("aria-label", title.replace(/\s*\(.*$/, "").replace(/:.*$/, ""));
    element.disabled = !enabled;
    element.addEventListener("click", () => run(id));
    buttons.set(id, element);
    return element;
  };

  /** Build a tool button from the registry label and accelerator; the tooltip and accessible name come from them. */
  const tool = (options: ToolButtonOptions): HTMLButtonElement => {
    const element = createToolButton(options);
    element.addEventListener("click", () => run(options.id));
    buttons.set(options.id, element);
    return element;
  };

  return {
    tools,
    tool,
    buttons,
    group,
    button,
    finish(): void { root.append(mode); },
    setEnabled(id: string, enabled: boolean): void {
      const element = buttons.get(id);
      if (element) element.disabled = !enabled;
    },
    setSelected(id: string, selected: boolean): void {
      buttons.get(id)?.classList.toggle("selected", selected);
    },
    setMode(label: string): void { mode.textContent = label; },
  };
}
