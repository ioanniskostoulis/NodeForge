// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The shell's overlay scrollbars: an 8 px thumb drawn over the trailing edge of every scrolling pane, fading in on
// scroll. The thumb keeps its width under the pointer, which the browser's own overlay thumb does not, and it takes no
// layout space, so a pane keeps its full width.
import { followPointer } from "./pointer-drag";

/**
 * The thumb's width at rest and under the pointer, and the gap between the thumb and the pane's edge, in px. The thumb's
 * box is the wider of the two, so it is easy to grab; the drawn bar inside it is thin and widens, toward the pane, as
 * the pointer nears the edge or drags it (the styles animate the change), as the macOS overlay bar does.
 */
export const SCROLLBAR_THICKNESS_PX = 6;
export const SCROLLBAR_HOVER_THICKNESS_PX = 10;
export const SCROLLBAR_INSET_PX = 2;
/** The shortest thumb along its track, in px. */
export const SCROLLBAR_MIN_LENGTH_PX = 24;
/** A bar stays visible this long after the pane stops scrolling, in ms. */
export const SCROLLBAR_IDLE_MS = 900;
/** How close to the trailing edge the pointer reveals a bar, in px. */
export const SCROLLBAR_REVEAL_PX = 12;
/** The attribute that hides a pane's own scrollbar while the shell draws one. */
export const SCROLLBAR_ATTRIBUTE = "data-shell-scrollbar";

/** How long the observer waits for a group of changes to settle before measuring again, in ms. */
const RESCAN_MS = 120;
const LAYER_ID = "shell-scrollbars";
/** The class of the global layer and of the layer inside each overlay. */
const LAYER_CLASS = "shell-scrollbar-layer";
/**
 * Overlays that sit above the global layer (dialogs, menus, select lists). A pane inside one draws its bar in a layer of
 * that overlay, so the bar is neither hidden under the overlay nor drawn over it for a pane behind.
 */
const OVERLAY_HOSTS = ".modal-backdrop, .menu-popup, .select-popup";
/** Elements that scroll inside a control of their own; their bar stays theirs. */
const OWN_SCROLLERS = new Set(["INPUT", "TEXTAREA", "SELECT"]);
const SCROLLS = /^(auto|scroll|overlay)$/;

export interface ThumbGeometry {
  /** The thumb's length along its track, in px. */
  lengthPx: number;
  /** The distance of the thumb's start from the start of its track, in px. */
  offsetPx: number;
}

/**
 * The thumb for a scroll position, or null when the content fits and no bar is drawn. The length is the view's share
 * of the content, but never under 24 px and never past the track; the offset places that length over the travel left in
 * the track, so the thumb meets both ends of the track exactly at the ends of the scroll.
 */
export function thumbGeometry(trackPx: number, viewPx: number, contentPx: number, scrollPx: number): ThumbGeometry | null {
  const travelPx = contentPx - viewPx;
  if (!(travelPx > 0) || !(trackPx > 0)) return null;
  const lengthPx = Math.min(trackPx, Math.max(SCROLLBAR_MIN_LENGTH_PX, (trackPx * viewPx) / contentPx));
  const reached = Math.min(1, Math.max(0, scrollPx / travelPx));
  return { lengthPx, offsetPx: (trackPx - lengthPx) * reached };
}

type Axis = "y" | "x";

interface Bar {
  element: HTMLElement;
  /** The layer the thumb is drawn in: the global one, or the one of the overlay the pane is inside. */
  layer: HTMLElement;
  axis: Axis;
  thumb: HTMLDivElement;
  /** The pane's viewport box at the last measurement, so the pointer check costs no layout read. */
  box: DOMRect;
  lengthPx: number;
  trackPx: number;
  hovering: boolean;
  dragging: boolean;
  timer: number;
}

/**
 * Draw the overlay scrollbars of every scrolling pane under `document.body`, and return the function that removes
 * them. Panes are found as they appear, so the call belongs once at start-up; a pane keeps its own scrollbar until it
 * is found.
 */
export function installScrollbars(): () => void {
  if (typeof document === "undefined" || !document.body) return () => {};

  const newLayer = (): HTMLElement => {
    const element = Object.assign(document.createElement("div"), { className: LAYER_CLASS });
    element.setAttribute("aria-hidden", "true");
    return element;
  };
  const layer = newLayer();
  layer.id = LAYER_ID;
  document.body.append(layer);
  /** The layer of each overlay, made when its first pane needs a bar; it leaves the page with its overlay. */
  const overlayLayers = new WeakMap<Element, HTMLElement>();
  const isLayer = (node: Node): boolean => node instanceof Element && !!node.closest(`.${LAYER_CLASS}`);
  /** The layer for a pane's bars: its overlay's (appended last, so it is drawn above the overlay's content), or the global one. */
  const layerFor = (element: HTMLElement): HTMLElement => {
    const host = element.closest(OVERLAY_HOSTS);
    if (!host) return layer;
    let own = overlayLayers.get(host);
    if (!own) { own = newLayer(); overlayLayers.set(host, own); }
    if (own.parentElement !== host || host.lastElementChild !== own) host.append(own);
    return own;
  };

  const scrollers = new Map<HTMLElement, Map<Axis, Bar>>();
  /** The panes whose own scrollbar was hidden, and so gets it back on dispose. */
  const taken = new Set<HTMLElement>();

  // MARK: a bar's place and visibility

  function measure(bar: Bar): boolean {
    const element = bar.element;
    const vertical = bar.axis === "y";
    const viewPx = vertical ? element.clientHeight : element.clientWidth;
    const contentPx = vertical ? element.scrollHeight : element.scrollWidth;
    const trackPx = viewPx - 2 * SCROLLBAR_INSET_PX;
    const geometry = thumbGeometry(trackPx, viewPx, contentPx, vertical ? element.scrollTop : element.scrollLeft);
    if (!geometry) return false;
    bar.box = element.getBoundingClientRect();
    bar.trackPx = trackPx;
    if (bar.lengthPx !== geometry.lengthPx) {
      bar.lengthPx = geometry.lengthPx;
      if (vertical) bar.thumb.style.height = `${geometry.lengthPx}px`;
      else bar.thumb.style.width = `${geometry.lengthPx}px`;
    }
    // The thumb is a child of a fixed layer, so the box's viewport coordinates, less the layer's own origin (not 0 inside
    // an overlay with a transform or a backdrop filter), are its coordinates; a transform moves it on the compositor,
    // while only its length, which changes with the content, is laid out.
    const origin = bar.layer === layer ? null : bar.layer.getBoundingClientRect();
    const x = (origin ? -origin.left : 0) + (vertical
      ? bar.box.right - SCROLLBAR_INSET_PX - SCROLLBAR_HOVER_THICKNESS_PX
      : bar.box.left + element.clientLeft + SCROLLBAR_INSET_PX + geometry.offsetPx);
    const y = (origin ? -origin.top : 0) + (vertical
      ? bar.box.top + element.clientTop + SCROLLBAR_INSET_PX + geometry.offsetPx
      : bar.box.bottom - SCROLLBAR_INSET_PX - SCROLLBAR_HOVER_THICKNESS_PX);
    bar.thumb.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    return true;
  }

  function reveal(bar: Bar, idleMs = 0): void {
    window.clearTimeout(bar.timer);
    bar.timer = 0;
    bar.thumb.dataset.visible = "true";
    bar.thumb.dataset.hover = String(bar.hovering || bar.dragging);
    if (idleMs > 0) bar.timer = window.setTimeout(() => conceal(bar), idleMs);
  }

  function conceal(bar: Bar): void {
    window.clearTimeout(bar.timer);
    bar.timer = 0;
    bar.thumb.dataset.hover = String(bar.hovering || bar.dragging);
    if (bar.dragging || bar.hovering) return;
    bar.thumb.dataset.visible = "false";
  }

  // MARK: bars, panes and discovery

  function removeBar(bar: Bar): void {
    window.clearTimeout(bar.timer);
    bar.thumb.remove();
    const entry = scrollers.get(bar.element);
    if (!entry) return;
    entry.delete(bar.axis);
    if (!entry.size) scrollers.delete(bar.element);
  }

  function drop(element: HTMLElement): void {
    const entry = scrollers.get(element);
    if (!entry) return;
    for (const bar of [...entry.values()]) removeBar(bar);
  }

  /** Forget a pane that left the page: its bars, its observer and the attribute it was given. */
  function forget(element: HTMLElement): void {
    drop(element);
    resize.unobserve(element);
    element.removeAttribute(SCROLLBAR_ATTRIBUTE);
    taken.delete(element);
  }

  function startDrag(event: PointerEvent, bar: Bar): void {
    if (event.button !== 0 || !measure(bar)) return;
    const element = bar.element;
    const vertical = bar.axis === "y";
    const startPointer = vertical ? event.clientY : event.clientX;
    const startScroll = vertical ? element.scrollTop : element.scrollLeft;
    const travelPx = bar.trackPx - bar.lengthPx;
    const maxScroll = vertical ? element.scrollHeight - element.clientHeight : element.scrollWidth - element.clientWidth;
    const move = (moved: PointerEvent) => {
      const delta = (vertical ? moved.clientY : moved.clientX) - startPointer;
      const next = startScroll + (travelPx > 0 ? (delta / travelPx) * maxScroll : 0);
      if (vertical) element.scrollTop = next;
      else element.scrollLeft = next;
    };
    const end = () => {
      bar.dragging = false;
      delete bar.thumb.dataset.dragging;
      conceal(bar);
    };
    if (!followPointer(bar.thumb, event, { move, end })) return;
    event.preventDefault();
    bar.dragging = true;
    bar.thumb.dataset.dragging = "true";
  }

  function barFor(element: HTMLElement, axis: Axis): Bar {
    let entry = scrollers.get(element);
    if (!entry) { entry = new Map(); scrollers.set(element, entry); }
    const existing = entry.get(axis);
    if (existing) return existing;
    const thumb = Object.assign(document.createElement("div"), { className: "shell-scrollbar" });
    thumb.dataset.visible = "false";
    thumb.dataset.axis = axis;
    const bar: Bar = { element, layer: layerFor(element), axis, thumb, box: new DOMRect(), lengthPx: 0, trackPx: 0, hovering: false, dragging: false, timer: 0 };
    thumb.addEventListener("pointerenter", () => { bar.hovering = true; measure(bar); reveal(bar); });
    thumb.addEventListener("pointerleave", () => { bar.hovering = false; conceal(bar); });
    thumb.addEventListener("pointerdown", (event) => startDrag(event, bar));
    bar.layer.append(thumb);
    entry.set(axis, bar);
    return bar;
  }

  /** Measure one pane, hide its own scrollbar and draw, resize, move or drop each of its bars. */
  function sync(element: HTMLElement): void {
    if (isLayer(element) || OWN_SCROLLERS.has(element.tagName)) return;
    const ours = element.hasAttribute(SCROLLBAR_ATTRIBUTE);
    // Most elements fit their content: they are passed over before their style is read, which keeps a rescan cheap.
    if (!ours && element.scrollHeight <= element.clientHeight + 1 && element.scrollWidth <= element.clientWidth + 1) return;
    const style = getComputedStyle(element);
    const scrollsY = SCROLLS.test(style.overflowY);
    const scrollsX = SCROLLS.test(style.overflowX);
    // A pane that hides its scrollbar on purpose (the tab rows) keeps it hidden.
    if ((!scrollsY && !scrollsX) || (!ours && style.scrollbarWidth === "none")) { drop(element); return; }
    if (!ours) {
      element.setAttribute(SCROLLBAR_ATTRIBUTE, "");
      taken.add(element);
      resize.observe(element);
    }
    // Hiding the pane's own bar gives it its full width back, which can itself end one of the overflows.
    const overflowsY = scrollsY && element.scrollHeight > element.clientHeight + 1;
    const overflowsX = scrollsX && element.scrollWidth > element.clientWidth + 1;
    if (!overflowsY) dropBar(element, "y");
    if (overflowsY && !measure(barFor(element, "y"))) dropBar(element, "y");
    if (!overflowsX) dropBar(element, "x");
    if (overflowsX && !measure(barFor(element, "x"))) dropBar(element, "x");
  }

  function dropBar(element: HTMLElement, axis: Axis): void {
    const bar = scrollers.get(element)?.get(axis);
    if (bar) removeBar(bar);
  }

  function scan(node: Element): void {
    if (node instanceof HTMLElement) sync(node);
    for (const child of node.querySelectorAll("*")) if (child instanceof HTMLElement) sync(child);
  }

  /** The panes around a change: content added to a pane that fitted can make it overflow. */
  function syncAncestors(node: Element): void {
    for (let parent = node.parentElement; parent && parent !== document.body; parent = parent.parentElement) {
      if (!scrollers.has(parent)) sync(parent);
    }
  }

  // MARK: the page's events

  const onScroll = (event: Event) => {
    const element = event.target;
    if (!(element instanceof HTMLElement) || isLayer(element)) return;
    sync(element);
    for (const bar of scrollers.get(element)?.values() ?? []) reveal(bar, SCROLLBAR_IDLE_MS);
    // A shown bar of a pane inside the one that scrolled moves with that pane.
    for (const [inner, bars] of scrollers) {
      if (inner === element || !element.contains(inner)) continue;
      for (const bar of bars.values()) if (bar.thumb.dataset.visible === "true") measure(bar);
    }
  };

  const onPointerMove = (event: PointerEvent) => {
    for (const entry of scrollers.values()) {
      for (const bar of entry.values()) {
        if (bar.dragging || event.target === bar.thumb) continue;
        const inside = event.target instanceof Node && bar.element.contains(event.target);
        const box = bar.box;
        const near = inside && (bar.axis === "y"
          ? event.clientX > box.right - SCROLLBAR_REVEAL_PX && event.clientX <= box.right + 1 && event.clientY >= box.top && event.clientY <= box.bottom
          : event.clientY > box.bottom - SCROLLBAR_REVEAL_PX && event.clientY <= box.bottom + 1 && event.clientX >= box.left && event.clientX <= box.right);
        if (near === bar.hovering) continue;
        bar.hovering = near;
        if (near) { measure(bar); reveal(bar); }
        else conceal(bar);
      }
    }
  };

  // A smaller window can make any pane overflow, so the whole page is looked at again once the resize settles.
  const onWindowResize = () => {
    for (const element of [...scrollers.keys()]) sync(element);
    schedule(document.body);
  };

  const resize = new ResizeObserver((entries) => {
    for (const entry of entries) if (entry.target instanceof HTMLElement) sync(entry.target);
  });

  /** New panes, and content that makes an old pane taller or wider, wait for one rescan per group of changes. */
  const pending = new Set<Element>();
  let rescan = 0;
  const schedule = (node?: Element) => {
    if (node) pending.add(node);
    if (!rescan) rescan = window.setTimeout(flush, RESCAN_MS);
  };
  const flush = () => {
    rescan = 0;
    const nodes = [...pending];
    pending.clear();
    for (const element of [...taken]) if (!element.isConnected) forget(element);
    for (const node of nodes) {
      if (!node.isConnected) continue;
      scan(node);
      syncAncestors(node);
    }
    for (const element of [...scrollers.keys()]) sync(element);
  };
  const observer = new MutationObserver((records) => {
    let changed = false;
    for (const record of records) {
      if (record.type === "characterData") {
        if (record.target.parentElement) pending.add(record.target.parentElement);
        changed = true;
        continue;
      }
      if (record.removedNodes.length) changed = true;
      for (const node of record.addedNodes) {
        if (isLayer(node)) continue;
        if (node instanceof Element) { pending.add(node); changed = true; }
        else if (node.parentElement && !isLayer(node.parentElement)) { pending.add(node.parentElement); changed = true; }
      }
    }
    if (changed) schedule();
  });

  document.addEventListener("scroll", onScroll, { capture: true, passive: true });
  document.addEventListener("pointermove", onPointerMove, { capture: true, passive: true });
  window.addEventListener("resize", onWindowResize);
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  scan(document.body);

  return () => {
    observer.disconnect();
    resize.disconnect();
    document.removeEventListener("scroll", onScroll, true);
    document.removeEventListener("pointermove", onPointerMove, true);
    window.removeEventListener("resize", onWindowResize);
    window.clearTimeout(rescan);
    for (const element of [...scrollers.keys()]) drop(element);
    for (const element of [...taken]) forget(element);
    layer.remove();
  };
}
