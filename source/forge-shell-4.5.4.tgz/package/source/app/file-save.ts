// Licensed under the GNU General Public License v2 or later. See LICENSE.

export interface SavableDocument<Format extends string> {
  name: string;
  path: string | null;
  markSaved(path: string | null, format: Format): void;
}

export interface SaveHost<Format extends string, Document extends SavableDocument<Format>> {
  document: Document;
  as: boolean;
  suggestedName?: string;
  extension: string;
  mimeType: string;
  stripExtension: (name: string) => string;
  beforeSave: () => void;
  prepare: (document: Document) => void;
  /** The saved text, made once the destination is known: `path` is where it is written, or null for a browser download. */
  serialize: (document: Document, path: string | null) => { text: string; format: Format };
  nativeFormat: Format;
  unsupportedMessage: string;
  report: (message: string, kind: "info" | "error", document: Document) => void;
  afterSave: () => void;
  desktop?: {
    saveDialog(defaultName: string): Promise<string | null>;
    writeFile(path: string, text: string): Promise<void>;
  };
}

/**
 * Save one document through a native file dialog or a browser download. The text is made after the dialog has chosen
 * the path, so that a document that stores paths relative to itself is written once, for the place it is written to.
 */
export async function saveDocument<Format extends string, Document extends SavableDocument<Format>>(host: SaveHost<Format, Document>): Promise<boolean> {
  const { document: doc, extension, stripExtension } = host;
  host.beforeSave();
  const baseName = stripExtension(doc.name);
  host.prepare(doc);
  /** The text for `path`, or null after reporting a format the document cannot be saved in. */
  const textFor = (path: string | null): { text: string; format: Format } | null => {
    const made = host.serialize(doc, path);
    if (made.format === host.nativeFormat) return made;
    host.report(host.unsupportedMessage, "error", doc);
    return null;
  };
  const suffix = new RegExp(`\\.${extension}$`, "i");
  const defaultName = `${stripExtension(host.suggestedName ?? `${baseName}.${extension}`)}.${extension}`;
  if (host.desktop) {
    const desktop = host.desktop;
    /**
     * A path from the Save dialog that ends in the extension, or null when cancelled. A path without it is offered once
     * more, already corrected, so that the dialog (not this code) asks before an existing file of that name is replaced.
     */
    const choosePath = async (): Promise<string | null> => {
      let chosen = await desktop.saveDialog(defaultName);
      if (chosen && !suffix.test(chosen)) chosen = await desktop.saveDialog(`${stripExtension(chosen)}.${extension}`);
      if (chosen && !suffix.test(chosen)) { host.report(`Couldn't save: the name must end in .${extension}.`, "error", doc); return null; }
      return chosen;
    };
    let path = doc.path;
    if (host.as || !path || !suffix.test(path)) {
      path = await choosePath();
      if (!path) return false;
    }
    let made = textFor(path);
    if (!made) return false;
    try {
      await desktop.writeFile(path, made.text);
    } catch (error) {
      // A file opened in this session has not necessarily passed through Save As.
      if (!String(error).includes("Save permission required")) {
        host.report(`Couldn't save: ${error instanceof Error ? error.message : String(error)}`, "error", doc);
        return false;
      }
      path = await choosePath();
      if (!path) return false;
      // The new place may change what the text holds, so it is made again for it.
      made = textFor(path);
      if (!made) return false;
      try {
        await desktop.writeFile(path, made.text);
      } catch (retryError) {
        host.report(`Couldn't save: ${retryError instanceof Error ? retryError.message : String(retryError)}`, "error", doc);
        return false;
      }
    }
    doc.markSaved(path, made.format);
    host.report(`Saved ${path.split(/[\\/]/).pop()}.`, "info", doc);
  } else {
    const made = textFor(null);
    if (!made) return false;
    const name = `${baseName}.${extension}`;
    const link = Object.assign(window.document.createElement("a"), {
      href: URL.createObjectURL(new Blob([made.text], { type: host.mimeType })), download: name,
    });
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 5000);
    doc.markSaved(null, made.format);
    doc.name = name;
    host.report(`Downloaded ${name}.`, "info", doc);
  }
  host.afterSave();
  return true;
}
