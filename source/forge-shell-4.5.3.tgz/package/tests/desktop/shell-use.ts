import assert from "node:assert/strict";
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

// Loaded from its own place at run time, not bundled, since it reads the shell's files relative to itself.
const checker = new URL("../../../scripts/check-app.mjs", import.meta.url).href;
const { PROJECT_EXTENSION, settingsProblems, shellUseProblems } = (await import(checker)) as { PROJECT_EXTENSION: RegExp; shellUseProblems(dir: string): string[]; settingsProblems(dir: string, config: object): string[] };

test("the app check names every place an application replaces a shell part, and what to use instead", () => {
  const dir = mkdtempSync(join(tmpdir(), "shell-use-"));
  try {
    mkdirSync(join(dir, "desktop"));
    writeFileSync(join(dir, "desktop", "main.ts"), [
      "const ok = await dialog.showSaveDialog(win, { title: \"Save\" });",
      "const { response } = await dialog.showMessageBox(win, { buttons: [\"Replace\", \"Cancel\"] });",
      "const answer = dialog.showMessageBoxSync(win, {});",
      "await dialog.showSaveDialog(win, { title: \"Export image\" });",
    ].join("\n"));
    writeFileSync(join(dir, "app.ts"), "if (confirm(\"Delete?\")) remove();\nwindow.alert('Done');\nconst confirmed = confirmReplace(names);\nconst kind = el(\"select\");\nconst list = document.createElement('select');\nhost.innerHTML = `<select id=\"k\">`;\nif (tool.kind === \"select\") setTool({ kind: \"select\" });\n");
    const problems: string[] = shellUseProblems(dir);
    assert.deepEqual(problems.map((problem: string) => problem.replace(dir, "").split(": use ")[0]), ["/app.ts:1", "/app.ts:2", "/app.ts:4", "/app.ts:5", "/app.ts:6", "/desktop/main.ts:2", "/desktop/main.ts:3", "/desktop/main.ts:4"]);
    assert.match(problems[2], /use createSelectControl/);
    assert.match(problems[5], /use askToChoose/);
    assert.match(problems[7], /use exportFiles/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test("a project file is always .<letter>fg", () => {
  for (const extension of ["nfg", "lfg", "pfg"]) assert.match(extension, PROJECT_EXTENSION);
  for (const extension of ["png", "nfgx", "fg", "n1g"]) assert.doesNotMatch(extension, PROJECT_EXTENSION);
});

test("every application has the shell's Settings, with General, Terminal and, with a repository, Updates", () => {
  const dir = mkdtempSync(join(tmpdir(), "settings-use-"));
  try {
    const write = (text: string) => writeFileSync(join(dir, "main.ts"), text);
    write("const menu = [standardItem(\"app.settings\")];\nif (id === \"app.settings\") showSettings({ pages: [generalPage(host), terminalPage(host), updatesPage(options)] });\n");
    assert.deepEqual(settingsProblems(dir, { identity: { repository: "owner/name" } }), []);
    write("if (id === \"app.settings\") showSettings({ pages: [generalPage(host), terminalPage(host)] });\n");
    assert.deepEqual(settingsProblems(dir, {}), [], "without a repository, no Updates page is needed");
    assert.match(settingsProblems(dir, { identity: { repository: "owner/name" } }).join(" "), /lacks the Updates page/);
    write("const dialog = Object.assign(document.createElement(\"div\"), { className: \"prefs-dialog\" });\n");
    const problems = settingsProblems(dir, {});
    assert.equal(problems.length, 5, "missing Settings…, showSettings, General, Terminal, and an own dialog");
    assert.match(problems.at(-1)!, /draws a settings dialog of its own/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
