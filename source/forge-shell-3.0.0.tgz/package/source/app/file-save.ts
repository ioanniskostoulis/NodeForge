// Licensed under the GNU General Public License v2 or later. See LICENSE.

export interface SavableDocument<Format extends string> {
  name: string;
  path: string | null;
  markSaved(path: string | null, format: Format): void;
}

export interface SaveHost<Format extends string, Document extends SavableDocument<Format>> {
  document: Document;
  as: boolean;
  suggestedName?: string;
  extension: string;
  mimeType: string;
  stripExtension: (name: string) => string;
  beforeSave: () => void;
  prepare: (document: Document) => void;
  serialize: (document: Document) => { text: string; format: Format };
  nativeFormat: Format;
  unsupportedMessage: string;
  report: (message: string, kind: "info" | "error", document: Document) => void;
  afterSave: () => void;
  desktop?: {
    saveDialog(defaultName: string): Promise<string | null>;
    writeFile(path: string, text: string): Promise<void>;
  };
}

/** Save one document through a native file dialog or a browser download. */
export async function saveDocument<Format extends string, Document extends SavableDocument<Format>>(host: SaveHost<Format, Document>): Promise<boolean> {
  const { document: doc, extension, stripExtension } = host;
  host.beforeSave();
  const baseName = stripExtension(doc.name);
  host.prepare(doc);
  const { text, format } = host.serialize(doc);
  if (format !== host.nativeFormat) {
    host.report(host.unsupportedMessage, "error", doc);
    return false;
  }
  const suffix = new RegExp(`\\.${extension}$`, "i");
  if (host.desktop) {
    let path = doc.path;
    if (host.as || !path || !suffix.test(path)) {
      path = await host.desktop.saveDialog(`${stripExtension(host.suggestedName ?? `${baseName}.${extension}`)}.${extension}`);
      if (!path) return false;
      if (!suffix.test(path)) path = `${stripExtension(path)}.${extension}`;
    }
    try {
      await host.desktop.writeFile(path, text);
    } catch (error) {
      // A file opened in this session has not necessarily passed through Save As.
      if (!String(error).includes("Save permission required")) {
        host.report(`Couldn't save: ${error instanceof Error ? error.message : String(error)}`, "error", doc);
        return false;
      }
      path = await host.desktop.saveDialog(`${stripExtension(doc.name)}.${extension}`);
      if (!path) return false;
      try {
        await host.desktop.writeFile(path, text);
      } catch (retryError) {
        host.report(`Couldn't save: ${retryError instanceof Error ? retryError.message : String(retryError)}`, "error", doc);
        return false;
      }
    }
    doc.markSaved(path, format);
    host.report(`Saved ${path.split(/[\\/]/).pop()}.`, "info", doc);
  } else {
    const name = `${baseName}.${extension}`;
    const link = Object.assign(window.document.createElement("a"), {
      href: URL.createObjectURL(new Blob([text], { type: host.mimeType })), download: name,
    });
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 5000);
    doc.markSaved(null, format);
    doc.name = name;
    host.report(`Downloaded ${name}.`, "info", doc);
  }
  host.afterSave();
  return true;
}
