import assert from "node:assert/strict";
import { test } from "node:test";
import { generalHelp } from "../../source/app/command-help";

test("Help keeps shell categories at the edges and app categories in supplied order", () => {
  const names = ["clear", "edit", "open", "plot", "theme"];
  const commands = names.map((name) => ({ name, syntax: name, description: name }));
  const result = generalHelp(false, {
    commands, helpCommands: commands, availableOnWelcome: new Set(names), details: {},
    welcomeForms: {}, welcomeTopics: {}, noDocumentMessage: "Open a document first.",
    groups: [["Console", ["clear"]], ["Analysis", ["plot"]], ["View", ["theme"]], ["File", ["open"]], ["Edit", ["edit"]]],
  });
  assert.deepEqual(result.groups?.map((group) => group.title), ["File", "Edit", "View", "Analysis", "Console"]);
});

import { checkCommandSyntax, commandHelp, helpAlias, invalidUsage } from "../../source/app/command-help";

test("bad syntax shows every valid form with its description", () => {
  const result = invalidUsage({ name: "scope", syntax: "scope", description: "", args: /x/, subcommands: [{ syntax: "scope stack", description: "Stack all scopes" }, { syntax: "scope move <number> <side> <number>", description: "Place a scope" }] });
  assert.equal(result.lines[0], "Invalid arguments. Usage:");
  assert.equal(result.lines.length, 4);
  assert.deepEqual(result.lines[2], { label: "scope move <number> <side> <number>", comment: "Place a scope", indent: 1, subdued: true, labelWidth: 35 });
  assert.equal(result.lines[3], "Type help scope for details.");
});

test("help aliases map -h, --help and ? to help", () => {
  assert.equal(helpAlias("plot -h"), "help plot");
  assert.equal(helpAlias("plot fft --help"), "help plot fft");
  assert.equal(helpAlias("plot ?"), "help plot");
  assert.equal(helpAlias("--help"), "help");
  assert.equal(helpAlias("plot fft"), null);
  assert.equal(helpAlias("save notes-h"), null);
});

test("a default choice is marked in the detailed help", () => {
  const command = { name: "theme", syntax: "theme [appearance]", description: "Show or change the appearance", args: /.*/, example: "theme dark" };
  const result = commandHelp("theme", false, { commands: [command], helpCommands: [command], availableOnWelcome: new Set(), welcomeForms: {}, welcomeTopics: {}, groups: [], noDocumentMessage: "",
    details: { theme: { choices: [["dark", "Dark appearance"], ["light", ""]], defaultChoice: "dark" } } });
  const rows = result.lines.filter((line) => typeof line !== "string") as { label: string; comment: string }[];
  assert.equal(rows.find((row) => row.label === "dark")?.comment, "Dark appearance (default)");
  assert.equal(rows.find((row) => row.label === "light")?.comment, "");
});

test("syntax strings follow the placeholder conventions", () => {
  for (const good of ["plot <expression> vs <expression>", "scope linked [state]", "open <file>...", "history [number]", "close [<tab>...]"]) assert.deepEqual(checkCommandSyntax(good), [], good);
  for (const bad of ["Plot <x>", "plot <Expression>", "plot <x", "plot ...", "plot [a", "close [tab...]"]) assert.ok(checkCommandSyntax(bad).length > 0, bad);
});
