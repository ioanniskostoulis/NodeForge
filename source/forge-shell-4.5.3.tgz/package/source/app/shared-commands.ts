// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The Terminal commands every application shares. Most run a menu action by its standard identifier, so a command
// does exactly what its menu item does; an application lists the actions it has, and only their commands appear.
import type { HelpDetails } from "./command-help";
import type { CommandSpec } from "./command-spec";
import type { ConsoleResult } from "./terminal";

/** The standard action identifiers the shared commands run. An application's menu items use the same identifiers. */
export const STANDARD_ACTIONS = [
  "file.new", "file.newWindow", "file.open", "file.save", "file.saveAs", "file.print", "file.close", "app.settings",
  "edit.undo", "edit.redo", "edit.cut", "edit.copy", "edit.paste", "edit.duplicate", "edit.delete", "edit.selectAll",
  "edit.find", "edit.findNext", "edit.findPrevious", "edit.replace", "edit.goToLine", "edit.toggleComment",
  "arrange.bringForward", "arrange.sendBackward", "arrange.bringToFront", "arrange.sendToBack",
  "view.zoomIn", "view.zoomOut", "view.fit", "view.actualSize", "view.inspector", "view.bottomPanel", "view.fullScreen",
  "tab.next", "tab.prev",
  "about", "about.whatsNew", "about.shortcuts", "about.licenses", "about.updates",
] as const;
export type StandardAction = (typeof STANDARD_ACTIONS)[number];

/** A shared command: its registry entry, the actions it needs (any one of them), and whether it needs an open document. */
export interface SharedCommand { spec: CommandSpec; actions: readonly StandardAction[]; document: boolean; group: "File" | "Edit" | "View" | "Help" | "Console"; details?: HelpDetails }

const command = (name: string, syntax: string, description: string, args: RegExp, group: SharedCommand["group"], actions: readonly StandardAction[] = [], document = false, choices?: string[], example?: string): SharedCommand =>
  ({ spec: { name, syntax, description, args, ...(choices ? { choices } : {}), ...(example ? { example } : {}) }, actions, document, group });

/** Every shared command, in help order. Preferences, `help`, `history`, `terminal` and `clear` need no action. */
export const SHARED_COMMANDS: readonly SharedCommand[] = [
  command("new", "new", "Create a new document", /^$/, "File", ["file.new"]),
  command("open", "open", "Open a document", /^$/, "File", ["file.open"]),
  command("recent", "recent [number]", "List recent files, or open one by its number", /^(|\d+)$/, "File", ["file.open"], false, undefined, "recent 2"),
  command("save", "save [as]", "Save the document, or save it under a new name", /^(|as)$/, "File", ["file.save", "file.saveAs"], true, ["as"]),
  command("close", "close", "Close the document", /^$/, "File", ["file.close"], true),
  command("print", "print", "Print the document", /^$/, "File", ["file.print"], true),
  command("settings", "settings [page]", "Open Settings, or one of its pages", /^(|[a-z][a-z0-9-]*)$/, "File", ["app.settings"], false, undefined, "settings updates"),
  command("autosave", "autosave [choice]", "Show or set when documents are saved", /^(|off|1m|5m|focus)$/, "File", [], false, ["off", "1m", "5m", "focus"]),
  command("undo", "undo", "Undo the last change", /^$/, "Edit", ["edit.undo"], true),
  command("redo", "redo", "Redo the last undone change", /^$/, "Edit", ["edit.redo"], true),
  command("zoom", "zoom <choice>", "Zoom in or out, fit the view, or show it at actual size", /^(in|out|fit|actual)$/, "View", ["view.zoomIn", "view.zoomOut", "view.fit", "view.actualSize"], true, ["in", "out", "fit", "actual"], "zoom in"),
  command("panel", "panel [choice]", "Show or hide the bottom panel, or show a pane", /^\S*$/, "View", [], false, ["on", "off"]),
  command("inspector", "inspector [choice]", "Show, hide or move the inspector", /^(|on|off|left|right)$/, "View", [], false, ["on", "off", "left", "right"]),
  // A hidden appearance is accepted but never listed: the choices are the documented ones only.
  command("theme", "theme [choice]", "Show or set the appearance", /^(|dark|light|pride)$/, "View", [], false, ["dark", "light"]),
  command("about", "about", "Show the About window", /^$/, "Help", ["about"]),
  command("version", "version", "Show the version", /^$/, "Help"),
  command("changes", "changes", "Show what is new in this version", /^$/, "Help", ["about.whatsNew"]),
  command("shortcuts", "shortcuts", "Show the keyboard shortcuts", /^$/, "Help", ["about.shortcuts"]),
  command("licenses", "licenses", "Show the licenses", /^$/, "Help", ["about.licenses"]),
  command("help", "help [command]", "List commands, or show one command's forms", /^.*$/, "Console"),
  command("terminal", "terminal [setting] [choice]", "Show or set a Terminal preference: font, banner, caret, spacing or wrap", /^(|(?:font|banner|caret|spacing|wrap)(?: \S+)?)$/, "Console", [], false, ["font bigger", "font smaller", "banner on", "banner off", "caret blink", "caret steady", "spacing comfortable", "spacing compact", "wrap on", "wrap off"], "terminal wrap off"),
  command("history", "history [number]", "List previous commands, clear them, or set how many are kept", /^(|\d+|clear|limit(?: \d+)?)$/, "Console", [], false, ["clear", "limit"]),
  command("clear", "clear", "Clear the Terminal screen", /^$/, "Console"),
];

/**
 * The help of each shared command: every choice with its description, in the order of the registry, then notes and one
 * example, so that `help <command>` and `<command> -h` print the same in every application.
 */
const DETAILS: Record<string, HelpDetails> = {
  recent: { notes: ["With no value, the recent files are listed."], example: "recent 2" },
  settings: { notes: ["A page's name, such as general, terminal or updates, opens Settings on that page.", "With no value, Settings opens on the page shown last."], example: "settings updates" },
  save: { choices: [["as", "Save the document under a new name"]], notes: ["With no value, the document is saved."] },
  autosave: { choices: [["off", "Never save automatically"], ["1m", "Save 1 minute after the last edit"], ["5m", "Save 5 minutes after the last edit"], ["focus", "Save when the window loses focus"]], notes: ["With no value, the current choice is shown."], example: "autosave 1m" },
  zoom: { choices: [["in", "Zoom in"], ["out", "Zoom out"], ["fit", "Fit the view to the document"], ["actual", "Show the document at actual size"]], example: "zoom in" },
  panel: { choices: [["on", "Show the bottom panel"], ["off", "Hide the bottom panel"]], notes: ["A pane's name, such as terminal or messages, shows that pane.", "With no value, the panel's state is shown."], example: "panel messages" },
  inspector: { choices: [["on", "Show the inspector"], ["off", "Hide the inspector"], ["left", "Move the inspector to the left"], ["right", "Move the inspector to the right"]], notes: ["With no value, the inspector's state is shown."], example: "inspector left" },
  theme: { choices: [["dark", "Dark appearance"], ["light", "Light appearance"]], notes: ["With no value, the current appearance is shown."], example: "theme light" },
  help: { notes: ["<command> -h, <command> --help and <command> ? also show a command's help."], example: "help zoom" },
  terminal: { choices: [["font bigger", "Text one pixel larger"], ["font smaller", "Text one pixel smaller"], ["banner on", "Show the banner at the top"], ["banner off", "Hide the banner"], ["caret blink", "The caret fades in and out"], ["caret steady", "The caret stays solid"], ["spacing comfortable", "Lines 1.4 times the text size apart"], ["spacing compact", "Lines 1.2 times the text size apart"], ["wrap on", "Wrap a long line"], ["wrap off", "Scroll sideways instead of wrapping"]], notes: ["terminal font <number> sets the text size, from 10 to 24 px.", "With no value, every preference is shown; terminal <setting> shows one.", "The history limit has its own command: history limit."], example: "terminal wrap off" },
  history: { choices: [["clear", "Clear the command history"], ["limit", "Show or set how many commands are kept: 25, 50 or 100"]], notes: ["A number lists that many of the last commands.", "With no value, every command of this session is listed.", "history limit 50 keeps the last 50 commands; the most is 100."], example: "history 5" },
};

/** The help details of the shared commands, for `HelpCatalog.details`, before the application's own. */
export function sharedHelpDetails(commands: readonly SharedCommand[] = SHARED_COMMANDS): Record<string, HelpDetails> {
  return Object.fromEntries(commands.filter((entry) => DETAILS[entry.spec.name]).map((entry) => [entry.spec.name, DETAILS[entry.spec.name]]));
}

/** The shared commands an application has: those whose actions it lists, plus those that need none. */
export function sharedCommands(actions: Iterable<string>, options: { autosave?: boolean } = {}): SharedCommand[] {
  const has = new Set(actions);
  return SHARED_COMMANDS.filter((entry) => (entry.spec.name !== "autosave" || options.autosave) && (!entry.actions.length || entry.actions.some((action) => has.has(action))));
}

/** The help groups of the shared commands, for `HelpCatalog.groups`, before the application's own groups. */
export function sharedHelpGroups(commands: readonly SharedCommand[]): [string, string[]][] {
  const groups = new Map<string, string[]>();
  for (const entry of commands) groups.set(entry.group, [...(groups.get(entry.group) ?? []), entry.spec.name]);
  return [...groups];
}

export interface SharedCommandHost {
  /** Run a standard action, as its menu item does. */
  run(action: StandardAction): void;
  /** The standard actions the application has (as given to `sharedCommands`). */
  actions: Iterable<string>;
  hasDocument: boolean;
  /** The document noun, for `Open a <noun> first.` */
  noun: string;
  productName: string;
  version: string;
  /** The recent files, newest first, and opening one; without them `recent` answers that there are none. */
  recent?(): readonly string[];
  openPath?(path: string): void;
  /** Open Settings on a page (`settings updates`); without it `settings` runs `app.settings`. */
  openSettings?(page?: string): void;
  /** The ids of the Settings pages, so `settings <page>` can name them when the page is unknown. */
  settingsPages?(): readonly string[];
  /** @deprecated The text size is `terminal font`, run by the Terminal itself; these are no longer read. */
  fontSize?(): number;
  /** @deprecated See `fontSize`. */
  setFontSize?(size: number): void;
}

/**
 * Run a shared command that is not a preference, `help`, `history`, `terminal` or `clear` (those stay with `shellPreferenceCommand`,
 * the help catalogue and the Terminal). Returns null for any other command or an action the application lacks.
 */
export function runSharedCommand(name: string, arg: string, host: SharedCommandHost): ConsoleResult | null {
  const has = new Set(host.actions);
  const entry = SHARED_COMMANDS.find((item) => item.spec.name === name);
  if (!entry || ["autosave", "panel", "inspector", "theme", "help", "history", "terminal", "clear"].includes(name)) return null;
  if (entry.actions.length && !entry.actions.some((action) => has.has(action))) return null;
  if (entry.document && !host.hasDocument) return { lines: [`Open a ${host.noun} first.`] };
  const run = (action: StandardAction): ConsoleResult => {
    if (!has.has(action)) return { lines: [`${host.productName} has no ${action.split(".")[1].replace(/([A-Z])/g, " $1").toLowerCase()} command.`] };
    host.run(action);
    return { lines: [] };
  };
  switch (name) {
    case "version": return { lines: [`${host.productName} ${host.version}`] };
    case "settings": {
      const pages = host.settingsPages?.() ?? [];
      if (arg && pages.length && !pages.includes(arg)) return { lines: [`No settings page ${arg}. Pages: ${pages.join(", ")}.`] };
      if (host.openSettings) { host.openSettings(arg || undefined); return { lines: [] }; }
      return run("app.settings");
    }
    case "save": return run(arg === "as" ? "file.saveAs" : "file.save");
    case "zoom": return run(({ in: "view.zoomIn", out: "view.zoomOut", fit: "view.fit", actual: "view.actualSize" } as const)[arg as "in"]);
    case "recent": {
      const files = host.recent?.() ?? [];
      if (!files.length) return { lines: ["No recent files."] };
      if (!arg) return { lines: files.map((path, index) => ({ marker: `[${index + 1}]`, label: path, comment: "" })) };
      const path = files[Number(arg) - 1];
      if (!path) return { lines: [`No recent file numbered ${arg}. Type recent to list them.`] };
      if (!host.openPath) return run("file.open");
      host.openPath(path);
      return { lines: [] };
    }
    default: return run(entry.actions[0]);
  }
}
