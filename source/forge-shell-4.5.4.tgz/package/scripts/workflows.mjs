// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

// Artifacts count against the account's Actions storage (500 MB on the Free plan for private repositories). The
// installers only carry from the build jobs to the publish job, which puts them in the release: kept 1 day.
// Screenshots and setup logs are for checking a run: kept 7 days.
const setup = `      - uses: actions/checkout@v5
      - uses: actions/setup-node@v5
        with:
          node-version: 22
      - run: npm ci`;

const checks = `  checks:
    runs-on: ubuntu-latest
    env:
      ELECTRON_SKIP_BINARY_DOWNLOAD: "1"
    steps:
${setup}
      - run: npm run check
      - run: npm test
      - run: npm run test:app
      - run: npm run test:shell`;

const macos = `  macos:
    runs-on: macos-latest
    steps:
${setup}
      - run: node node_modules/electron/install.js
      - run: npm run dist
        env:
          CSC_IDENTITY_AUTO_DISCOVERY: "false"
      - run: node scripts/check-release.mjs --mac
      - uses: actions/upload-artifact@v4
        with:
          name: forge-macos
          path: build/release/*.dmg
          if-no-files-found: error
          compression-level: 0
          retention-days: 1`;

const windows = `  windows:
    runs-on: windows-latest
    steps:
${setup}
      - run: node node_modules/electron/install.js
      - run: npm run dist
        env:
          CSC_IDENTITY_AUTO_DISCOVERY: "false"
      - run: node scripts/check-release.mjs --win
      - name: Launch packaged app and check screenshot
        shell: pwsh
        run: ./scripts/check-windows-capture.ps1
      - name: Open setup window and check screenshot
        shell: pwsh
        env:
          FORGE_CAPTURE: \${{ github.workspace }}/build/release/setup-window.png
        run: |
          $setup = Get-ChildItem build/release/*-v*.exe | Select-Object -First 1
          $process = Start-Process -FilePath $setup.FullName -PassThru
          $null = $process.Handle
          if (-not $process.WaitForExit(180000)) { Stop-Process -Id $process.Id -Force; throw 'The setup window did not close within 180 s.' }
          if ($process.ExitCode -ne 0) { throw "The setup window exited $($process.ExitCode), expected 0." }
          if (-not (Test-Path $env:FORGE_CAPTURE)) { throw 'The setup window was not captured.' }
          Add-Type -AssemblyName System.Drawing
          $image = [System.Drawing.Bitmap]::FromFile($env:FORGE_CAPTURE)
          $colors = @{}
          for ($x = 0; $x -lt $image.Width; $x += 8) { for ($y = 0; $y -lt $image.Height; $y += 8) { $colors[$image.GetPixel($x, $y).ToArgb()] = 1 } }
          Write-Host "Setup window: $($image.Width) x $($image.Height) screenshot, $($colors.Count) colours."
          $image.Dispose()
          if ($colors.Count -lt 3) { throw 'The setup window screenshot is blank.' }
      - name: Check Windows installer upgrades
        shell: pwsh
        env:
          FORGE_SETUP_LOG_DIR: \${{ github.workspace }}/build/release/setup-log
        run: ./scripts/check-windows-installer.ps1
      - name: Show setup log
        if: failure()
        shell: pwsh
        run: Get-Content build/release/setup-log/*.log -ErrorAction SilentlyContinue
      - name: Save setup log and crash dumps
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: windows-setup-log
          path: build/release/setup-log
          if-no-files-found: ignore
          retention-days: 7
      - name: Save launch screenshot
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: windows-launch-screenshot
          path: |
            build/release/windows-launch.png*
            build/release/setup-window.png
          if-no-files-found: ignore
          retention-days: 7
      - uses: actions/upload-artifact@v4
        with:
          name: forge-windows
          path: build/release/*-v*.exe
          if-no-files-found: error
          compression-level: 0
          retention-days: 1`;

const publish = (needs) => `  publish:
    needs: [${needs.join(", ")}]
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - uses: actions/checkout@v5
      - uses: actions/setup-node@v5
        with:
          node-version: 22
      - run: npm ci --ignore-scripts
      - uses: actions/download-artifact@v4
        with:
          pattern: forge-*
          path: installers
          merge-multiple: true
      - name: Publish the release
        env:
          GH_TOKEN: \${{ github.token }}
        run: |
          if [ "$GITHUB_REF_TYPE" = tag ]; then TAG="$GITHUB_REF_NAME"; else TAG="v$(cat VERSION)"; fi
          APP_NAME="$(node -p 'require("./forge.config.json").identity.name')"
          npx forge-shell release-notes > "$RUNNER_TEMP/notes.md"
          if gh release view "$TAG" >/dev/null 2>&1; then
            gh release edit "$TAG" --notes-file "$RUNNER_TEMP/notes.md"
            gh release upload "$TAG" installers/* --clobber
          else
            gh release create "$TAG" installers/* --target "$GITHUB_SHA" --title "$APP_NAME \${TAG#v}" --notes-file "$RUNNER_TEMP/notes.md"
          fi`;

const clear = `  clear:
    runs-on: ubuntu-latest
    steps:
      - name: Confirm
        run: |
          if [ "\${{ inputs.confirm }}" != "clear all" ]; then
            echo 'Nothing was deleted. Type "clear all" in the confirm box to delete every release, tag and workflow run.'
            exit 1
          fi
      - name: Delete every release, tag and workflow run
        env:
          GH_TOKEN: \${{ github.token }}
          GH_REPO: \${{ github.repository }}
        run: |
          # releases first, with their tags
          for tag in $(gh release list --limit 1000 --json tagName --jq '.[].tagName'); do
            gh release delete "$tag" --yes --cleanup-tag
          done
          # then any tag that never had a release
          for ref in $(gh api "repos/$GITHUB_REPOSITORY/git/matching-refs/tags" --paginate --jq '.[].ref'); do
            gh api -X DELETE "repos/$GITHUB_REPOSITORY/git/$ref" || true
          done
          # then the run history, so that deleted workflows leave the Actions sidebar; this run is kept
          for run in $(gh api "repos/$GITHUB_REPOSITORY/actions/runs" --paginate --jq '.workflow_runs[].id'); do
            [ "$run" = "$GITHUB_RUN_ID" ] || gh api -X DELETE "repos/$GITHUB_REPOSITORY/actions/runs/$run" || true
          done
          echo "Deleted all releases, tags and workflow runs."`;

const header = (name, note, on) => `name: ${name}

# ${note}
# Generated by \`forge-shell workflows\`; edit forge-shell, not this file.
on:
${on}

permissions:
  contents: read

concurrency:
  group: ${name.toLowerCase().replaceAll(" ", "-")}-\${{ github.ref }}
  cancel-in-progress: false

jobs:
`;

const dispatchOnly = "  workflow_dispatch:";

/** The four workflows of an application, as `{ file name: text }`. Each one lists by name in the Actions sidebar. */
export function workflowFiles() {
  return {
    "build-desktop-apps.yml": header("Build desktop apps", "Checks, builds the macOS and Windows apps and publishes both installers to the release v<VERSION>. Runs on pushes to the main branch, on version tags and by hand.",
      `  push:\n    branches: [main]\n    paths-ignore: ["documentation/**", "**/*.md", "LICENSE"]\n    tags: ["v*"]\n${dispatchOnly}`) + [checks, macos, windows, publish(["checks", "macos", "windows"])].join("\n\n") + "\n",
    "build-for-mac.yml": header("Build for mac", "Checks, builds and publishes the macOS app only. Run it by hand.", dispatchOnly) + [checks, macos, publish(["checks", "macos"])].join("\n\n") + "\n",
    "build-for-windows.yml": header("Build for windows", "Checks, builds and publishes the Windows app only. Run it by hand.", dispatchOnly) + [checks, windows, publish(["checks", "windows"])].join("\n\n") + "\n",
    "clear-all.yml": header("Clear all", "Deletes every release, tag and workflow run of the repository; it builds nothing and cannot be undone. Run it by hand and type \"clear all\" to confirm.",
      `${dispatchOnly}\n    inputs:\n      confirm:\n        description: Type "clear all" to delete every release, tag and workflow run.\n        required: true`).replace("permissions:\n  contents: read", "permissions:\n  contents: write\n  actions: write") + clear + "\n",
  };
}

/** Write the four workflow files into `dir` (default `.github/workflows`). */
export function writeWorkflows(dir = ".github/workflows") {
  mkdirSync(dir, { recursive: true });
  const files = workflowFiles();
  for (const [name, text] of Object.entries(files)) writeFileSync(join(dir, name), text);
  return Object.keys(files);
}
