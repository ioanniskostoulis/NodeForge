// Licensed under the GNU General Public License v2 or later. See LICENSE.

/**
 * The notes under `## <version>` in the changelog. With `strict` a missing section returns null; otherwise the newest
 * section stands in, which is for local previews only: a release must have the section of its own version.
 */
export function releaseNotes(changelog, version, { strict = false } = {}) {
  const lines = changelog.split("\n");
  let start = lines.findIndex((line) => line.trim() === `## ${version}`);
  if (start < 0 && !strict) start = lines.findIndex((line) => line.startsWith("## "));
  if (start < 0) return null;
  const end = lines.findIndex((line, index) => index > start && line.startsWith("## "));
  return lines.slice(start + 1, end < 0 ? undefined : end).join("\n").trim();
}
