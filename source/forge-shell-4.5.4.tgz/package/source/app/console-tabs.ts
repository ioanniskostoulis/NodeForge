// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { numberedItem, numberedTable } from "./listing";
import type { ConsoleResult } from "./terminal";

export interface ConsoleTabDocument {
  displayTitle: string;
  dirty: boolean;
}

export interface ConsoleTabHost<Document extends ConsoleTabDocument> {
  documents(): readonly Document[];
  activeDocument(): Document;
  activate(document: Document): void;
  close(document: Document): Promise<void>;
  /** Lowercase document noun, for example "circuit" or "report". */
  documentNoun: string;
}

/** The Terminal's tabs, tab, close, and clear verbs. */
export async function consoleTabCommand<Document extends ConsoleTabDocument>(
  command: string, arg: string, host: ConsoleTabHost<Document>,
): Promise<ConsoleResult | null> {
  if (command === "clear") return { clear: true };
  if (command !== "tabs" && command !== "tab" && command !== "close") return null;
  const documents = host.documents();
  if (command === "tabs") return documents.length
    ? { tables: [numberedTable(["Tab", "State"], documents.map((document) => [
      document.displayTitle,
      [document === host.activeDocument() ? "Active" : "", document.dirty ? "Unsaved" : ""].filter(Boolean).join(", "),
    ]))] }
    : { lines: [`No ${host.documentNoun} tabs open.`] };
  if (command === "tab") {
    const target = numberedItem(documents, arg, "Tab");
    host.activate(target);
    return { lines: [`Tab ${arg}: ${target.displayTitle}.`] };
  }
  if (!documents.length) return { lines: [`No ${host.documentNoun} tabs open.`] };
  const target = arg ? numberedItem(documents, arg, "Tab") : host.activeDocument();
  await host.close(target);
  return { lines: [host.documents().includes(target) ? "Tab kept open." : `Closed ${target.displayTitle}.`] };
}
