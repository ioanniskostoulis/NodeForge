import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const css = readFileSync(new URL("../../source/styles/shell.css", import.meta.url), "utf8");
const rule = (selector) => css.match(new RegExp(`(?:^|\\n)${selector.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")} \\{([^}]*)\\}`))?.[1] ?? "";

test("in a narrow window the centre clips, the welcome actions wrap and the bottom tabs scroll", () => {
  assert.match(rule("#center"), /overflow: hidden/);
  assert.match(rule("#empty-state .actions"), /flex-wrap: wrap/);
  assert.match(rule("#empty-state .actions"), /justify-content: center/);
  assert.match(css, /#bottom-tabs \{[^}]*overflow-x: auto/);
  assert.match(css, /@media \(max-width: 1200px\) \{ #mode-label \{ display: none; \} \}/);
  assert.match(css, /#bottom-tabs \.tab, #bottom-tabs \.tab-action \{ flex: none; \}/);
});

test("tabs shrink before they scroll, New stays in reach, and the editor, its find bar and the Terminal wordmark fit their panes", () => {
  assert.match(css, /\.doc-tab \{[^}]*flex: 0 1 auto/);
  assert.match(css, /\.new-tab \{[^}]*position: sticky; right: 0/);
  assert.match(css, /\.shell-editor\.cm-editor \{[^}]*container: shell-editor \/ inline-size;[^}]*min-width: 0/);
  assert.match(css, /@container shell-editor \(max-width: 480px\) \{\s*\.find-tile \{ right: 8px; width: calc\(100% - 16px\); \}/);
  assert.match(css, /@container find-tile \(max-width: 360px\)/);
  assert.match(css, /\.find-tile input \{ flex: 1 1 140px; min-width: 120px;/);
  assert.match(css, /\.console-banner pre \{ overflow-x: auto; max-width: 100%;/);
  assert.match(css, /\.picker-table tr\.active input\[type="checkbox"\]:checked[^{]*\{ border-color: var\(--accent-foreground\); \}/);
});

test("the Terminal prompt draws the shared caret: it glides 80 ms and fades as it blinks, both off under reduced motion", () => {
  assert.match(css, /\.console-field\.caret-drawn \.console-input \{ caret-color: transparent; \}/);
  assert.match(css, /\.console-caret \{[^}]*width: 1\.5px;[^}]*transition: transform 80ms ease-out;/);
  assert.match(css, /animation: console-caret-blink 1\.2s ease-in-out 0\.5s infinite;/);
  assert.match(css, /\.console-caret \{ transition: none; \}/);
});
