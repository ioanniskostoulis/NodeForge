// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Electron main process of a Forge setup: a terminal window, or `/S` for a silent install.
import { app, BrowserWindow, crashReporter, dialog, ipcMain, shell } from "electron";
import { execFileSync, spawn, spawnSync } from "node:child_process";
import { copyFileSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { homedir, tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { inspectInstall, runInstall, runUninstall } from "./install.mjs";
import { appEnvironment, elevationScript, encodedCommand, envArgument, isElevated, restoreEnv } from "./elevate.mjs";
import { DEFAULT_FAMILY, installLayout } from "./layout.mjs";
import { openSetupLog, setupLogDir } from "./log.mjs";
import { isRunning, registerApp, unregisterApp } from "./windows.mjs";

// An elevated copy receives the setup's variables as an argument (see elevate.mjs); restore them before any is read.
const argv = restoreEnv(process.argv.slice(1), process.env);
const meta = JSON.parse(readFileSync(join(__dirname, "setup.json"), "utf8"));
const resources = app.isPackaged ? process.resourcesPath : (process.env.FORGE_SETUP_RESOURCES ?? __dirname);
// The setup runs inside the app it installs: the files to install are the app's own folder, beside its executable.
const payloadDir = process.env.FORGE_SETUP_PAYLOAD ?? (app.isPackaged ? dirname(process.execPath) : join(resources, "payload"));
const manifest = JSON.parse(readFileSync(join(resources, "payload.json"), "utf8"));
// Electron's fs treats a .asar file as a folder. The payload contains the app's own app.asar, which
// must be copied as one ordinary file, so turn that handling off for this process. This has to come
// after everything read from this package's own asar (setup.json above), which it would hide.
process.noAsar = true;
const windows = process.platform === "win32";
// The setup is the app's executable, so it takes its own name and settings folder: an open copy of the app neither
// holds its single-instance lock nor shares its settings.
app.setName(`${meta.product} Setup`);
app.setPath("userData", join(app.getPath("appData"), `${meta.product} Setup`));
// All users: `C:\Program Files\<family>\<Product>`. The setup asks for administrator rights when it starts (below).
const root = process.env.FORGE_INSTALL_ROOT ?? (windows ? (process.env.ProgramFiles ?? "C:\\Program Files") : join(homedir(), ".local", "share"));
const family = meta.family ?? DEFAULT_FAMILY;
const args = argv.map((a) => a.toLowerCase());
const silent = args.includes("/s") || args.includes("--silent");
const uninstall = args.includes("/uninstall") || args.includes("--uninstall");
const forced = args.includes("/force") || args.includes("--force");
const purge = args.includes("/purge") || args.includes("--purge");
const exeName = `${meta.product}.exe`;
const run = (command, argv) => execFileSync(command, argv, { encoding: "utf8", windowsHide: true, stdio: ["ignore", "pipe", "ignore"] });
const layout = installLayout(root, meta.product, family);
const appExe = join(layout.app, exeName);
const shortcut = () => join(process.env.ProgramData ?? process.env.APPDATA ?? homedir(), "Microsoft", "Windows", "Start Menu", "Programs", `${meta.product}.lnk`);

let window = null;
let controller = null;

// A silent run has no window: it records each stage in a log and keeps Electron's crash dumps beside it, so a
// run that ends without one of its own exit codes shows the last stage it reached.
const record = silent || uninstall ? openSetupLog(setupLogDir({ temp: tmpdir(), family }), meta.id) : null;
if (record) {
  app.setPath("crashDumps", dirname(record.path));
  crashReporter.start({ uploadToServer: false });
  record.write(`Start: ${meta.product} setup ${manifest.version}, arguments "${argv.join(" ")}".`);
  record.write({ setup: process.env.PORTABLE_EXECUTABLE_FILE ?? process.execPath, resources, root, electron: process.versions.electron, pid: process.pid });
  app.on("child-process-gone", (_event, details) => record.write(`Child process gone: ${JSON.stringify(details)}.`));
  process.on("unhandledRejection", (reason) => record.write(reason instanceof Error ? reason : `Unhandled rejection: ${String(reason)}.`));
  process.on("exit", (code) => record.write(`Process exit ${code}.`));
  // Nobody can dismiss Electron's error dialog: fail with an exit code instead.
  process.on("uncaughtException", (error) => { record.write(error); app.exit(1); });
}

// The executable runs as the user who started it. Without administrator rights, the setup starts an elevated copy of
// itself through User Account Control, waits for it and exits with its exit code. FORGE_INSTALL_ROOT (tests) needs no rights.
const elevated = () => { try { return isElevated(run("whoami", ["/groups"])); } catch { return false; } };
if (windows && app.isPackaged && !process.env.FORGE_INSTALL_ROOT && !elevated()) {
  record?.write("Elevate: starting a copy with administrator rights.");
  const script = elevationScript(process.execPath, [...argv, envArgument(process.env)]);
  const result = spawnSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encodedCommand(script)], { windowsHide: true, stdio: "ignore" });
  const code = result.status ?? 1;
  record?.write(`Elevated copy exit ${code}.`);
  process.exit(code);
}

// Only the installed app counts as running: the setup itself is a copy of the same executable, elsewhere.
const running = () => (windows ? isRunning(run, appExe) : false);

function register(version) {
  if (!windows) return null;
  record?.write("Register: setup copy, Settings entry, file association and Start menu shortcut.");
  // The setup copies itself so Settings, Apps can run `/uninstall` after this file is deleted.
  const copy = join(layout.family, ".setup", `${meta.product}-Setup.exe`);
  const documentIcon = meta.documentIcon ? join(layout.family, ".setup", meta.documentIcon) : null;
  const source = process.env.PORTABLE_EXECUTABLE_FILE ?? process.execPath;
  mkdirSync(join(layout.family, ".setup"), { recursive: true });
  copyFileSync(source, copy);
  if (documentIcon) copyFileSync(join(resources, meta.documentIcon), documentIcon);
  registerApp({ run, id: meta.id, name: meta.product, version, installDir: layout.app, exe: appExe, publisher: meta.publisher,
    uninstall: `"${copy}" /uninstall`, extension: meta.extension, description: meta.description, documentIcon, family });
  shell.writeShortcutLink(shortcut(), "create", { target: appExe, icon: appExe, description: meta.purpose });
  return "Start menu entry, Settings entry and file association";
}

async function install({ force }, onEvent) {
  const result = await runInstall({ root, product: meta.product, id: meta.id, version: manifest.version, source: payloadDir, manifest,
    running: running(), force, onEvent, signal: controller?.signal, family });
  const registered = register(manifest.version);
  if (registered) onEvent({ step: "register", status: "done", detail: registered });
  return result;
}

/** The app's own settings and caches for the account running the uninstall. Documents are never touched. */
function removeAppData() {
  for (const base of [process.env.APPDATA, process.env.LOCALAPPDATA]) if (base) rmSync(join(base, meta.product), { recursive: true, force: true });
}

/** The running uninstaller cannot delete itself: a detached command removes it, and the family folder if it is then empty. */
function removeSelfLater() {
  const setup = join(layout.family, ".setup");
  const command = `timeout /t 3 /nobreak >nul & rmdir /s /q "${setup}" & rmdir "${layout.family}"`;
  spawn("cmd.exe", ["/c", command], { detached: true, stdio: "ignore", windowsHide: true }).unref();
}

async function silentRun() {
  if (uninstall) {
    let wipe = purge;
    if (!silent) {
      // Run from Settings or the Control Panel, with no `/S`: ask whether to keep the app's settings.
      const answer = await dialog.showMessageBox({ type: "question", title: `Uninstall ${meta.product}`, message: `Uninstall ${meta.product}?`,
        detail: "Your documents are never deleted. Settings are kept unless you choose to delete them.",
        buttons: ["Uninstall, keep settings", "Uninstall and delete settings", "Cancel"], defaultId: 0, cancelId: 2, noLink: true });
      if (answer.response === 2) return 5;
      wipe = answer.response === 1;
    }
    record.write(`Uninstall: ${layout.app}${wipe ? ", deleting settings" : ""}.`);
    await runUninstall({ root, product: meta.product, id: meta.id, family });
    record.write("Unregister: Settings entry, file association and Start menu shortcut.");
    if (windows) { unregisterApp({ run, id: meta.id, extension: meta.extension, family }); rmSync(shortcut(), { force: true }); }
    if (wipe) removeAppData();
    if (windows && app.isPackaged) removeSelfLater();
    return 0;
  }
  try {
    await install({ force: forced }, (event) => { if (!event.progress) record.write(event); });
    return 0;
  } catch (error) {
    record.write(error);
    return { RUNNING: 3, BUSY: 3, NEWER: 2, CHECKSUM: 4, ABORT: 5 }[error.code] ?? 1;
  }
}

if (silent || uninstall) {
  app.whenReady().then(async () => {
    record.write("Ready.");
    const code = await silentRun();
    // A process exit code other than this one means the setup crashed while closing.
    record.write(`Exit ${code}.`);
    app.exit(code);
  });
} else {
  if (!app.requestSingleInstanceLock()) app.quit();
  ipcMain.handle("setup:state", async () => {
    const state = await inspectInstall({ root, product: meta.product, id: meta.id, incoming: manifest.version, running: running(), family });
    return { product: meta.product, id: meta.id, purpose: meta.purpose, logo: meta.logo, installDir: layout.app, plan: state.plan };
  });
  ipcMain.handle("setup:install", async (event, options) => {
    controller = new AbortController();
    try {
      await install({ force: Boolean(options?.force) }, (data) => event.sender.send("setup:event", data));
      return { ok: true };
    } catch (error) {
      return { ok: false, code: error.code ?? "ERROR", message: error.message };
    }
  });
  ipcMain.on("setup:cancel", () => controller?.abort());
  ipcMain.on("setup:close", () => { controller?.abort(); app.quit(); });
  ipcMain.on("setup:open", () => {
    // Without the setup's variables, which would start the app as its own setup again.
    spawn(appExe, [], { detached: true, stdio: "ignore", env: appEnvironment(process.env) }).unref();
    app.quit();
  });
  app.whenReady().then(() => {
    window = new BrowserWindow({
      width: 720, height: 408, resizable: false, maximizable: false, frame: false, show: false, backgroundColor: "#1b1b1b",
      webPreferences: { preload: join(__dirname, "preload.cjs"), contextIsolation: true, nodeIntegration: false, sandbox: false },
    });
    window.once("ready-to-show", () => window.show());
    void window.loadFile(join(__dirname, "index.html"));
    // FORGE_SETUP_AUTORUN presses the default button; FORGE_CAPTURE saves a screenshot of the window.
    const capture = process.env.FORGE_CAPTURE;
    window.webContents.once("did-finish-load", () => {
      if (process.env.FORGE_SETUP_AUTORUN) setTimeout(() => void window.webContents.executeJavaScript('document.querySelector("[data-c=install]")?.click()'), 1200);
      if (capture) setTimeout(async () => {
        const image = await window.webContents.capturePage();
        writeFileSync(capture, image.toPNG());
        if (!process.env.FORGE_CAPTURE_KEEP) app.quit();
      }, Number(process.env.FORGE_CAPTURE_DELAY ?? 3000));
    });
  });
  app.on("window-all-closed", () => app.quit());
}
