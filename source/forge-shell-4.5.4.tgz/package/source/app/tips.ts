// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { shortcutText } from "./menus";

export interface TipParts {
  /** The action name: `Undo`. */
  label: string;
  /** The registry accelerator (`CmdOrCtrl+Z`), shown with platform glyphs. */
  shortcut?: string;
  /** A short extra sentence, such as placement guidance. */
  note?: string;
}

/** Longest sentence tip, in characters. Longer explanations belong in the documentation. */
export const MAX_TIP_LENGTH = 120;

/** `Label (shortcut)`, then `: note` when there is one. */
export function tipText(parts: TipParts, display: (key: string) => string = shortcutText): string {
  const base = parts.shortcut ? `${parts.label} (${display(parts.shortcut)})` : parts.label;
  return parts.note ? `${base}: ${parts.note}` : base;
}

/** Set an element's tooltip. A string is a sentence tip for a property or status; an object is an action tip. */
export function setTip(element: HTMLElement, tip: string | TipParts): void {
  element.title = typeof tip === "string" ? tip : tipText(tip);
}

/**
 * Check a tooltip against the wording rules. An action tip is a short name with an optional `(shortcut)`. A tip of five
 * words or more is a sentence: it ends with a period. All tips start with a capital and have at most 120 characters.
 */
export function checkTipWording(text: string): string[] {
  const problems: string[] = [];
  if (!/^[A-Z0-9]/.test(text)) problems.push(`${text}: start with a capital letter`);
  if (text.length > MAX_TIP_LENGTH) problems.push(`${text}: longer than ${MAX_TIP_LENGTH} characters`);
  const words = text.replace(/\([^)]*\)/g, "").trim().split(/\s+/).length;
  if (words >= 5 && !text.endsWith(".")) problems.push(`${text}: a sentence tip ends with a period`);
  return problems;
}
