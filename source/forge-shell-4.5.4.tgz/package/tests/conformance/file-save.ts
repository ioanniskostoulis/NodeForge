import assert from "node:assert/strict";
import test from "node:test";
import { saveDocument } from "../../source/app/file-save";

test("native save marks a document saved only after a successful write", async () => {
  const document = { name: "Example.xml", path: null as string | null, saved: false,
    markSaved(path: string | null) { this.path = path; this.saved = true; } };
  const reports: string[] = [];
  let written = "";
  const options = {
    document, as: false, extension: "nfg", mimeType: "application/json",
    stripExtension: (name: string) => name.replace(/\.(nfg|xml)$/i, ""),
    beforeSave: () => {}, prepare: () => {},
    serialize: () => ({ text: "payload", format: "nfg" as const }), nativeFormat: "nfg" as const,
    unsupportedMessage: "Unsupported format.",
    report: (message: string) => { reports.push(message); }, afterSave: () => {},
    desktop: {
      dialogs: [] as string[],
      async saveDialog(name: string) { this.dialogs.push(name); return name === "Example.nfg" ? "/tmp/Example" : name; },
      async writeFile(path: string, text: string) { written = `${path}:${text}`; },
    },
  };
  assert.equal(await saveDocument(options), true);
  assert.equal(written, "/tmp/Example.nfg:payload");
  assert.deepEqual(options.desktop.dialogs, ["Example.nfg", "/tmp/Example.nfg"], "a name without the extension is offered again, corrected, so the dialog asks before replacing a file");
  assert.equal(document.path, "/tmp/Example.nfg");
  assert.equal(document.saved, true);
  assert.deepEqual(reports, ["Saved Example.nfg."]);

  document.saved = false;
  options.desktop.writeFile = async () => { throw new Error("disk full"); };
  assert.equal(await saveDocument({ ...options, as: true }), false);
  assert.equal(document.saved, false);
  assert.deepEqual(reports.at(-1), "Couldn't save: disk full");
});

test("cancelled dialog and unsupported format keep a document unsaved, and nothing is written", async () => {
  const document = { name: "Untitled 1", path: null as string | null, saved: false,
    markSaved() { this.saved = true; } };
  let format: "nfg" | "text" = "nfg";
  let chosen: string | null = null;
  const reports: string[] = [];
  const options = {
    document, as: false, extension: "nfg", mimeType: "application/json",
    stripExtension: (name: string) => name,
    beforeSave: () => {}, prepare: () => {},
    serialize: () => ({ text: "payload", format }), nativeFormat: "nfg" as const,
    unsupportedMessage: "Unsupported format.",
    report: (message: string) => { reports.push(message); }, afterSave: () => {},
    desktop: { async saveDialog() { return chosen; }, async writeFile() { throw new Error("should not write"); } },
  };
  assert.equal(await saveDocument(options), false, "the dialog was cancelled");
  assert.equal(document.saved, false);
  assert.deepEqual(reports, [], "a cancelled dialog reports nothing");
  format = "text";
  chosen = "/tmp/Untitled 1.nfg";
  assert.equal(await saveDocument(options), false);
  assert.equal(document.saved, false);
  assert.deepEqual(reports, ["Unsupported format."]);
});

test("the text is made once, after the dialog, for the path it is written to", async () => {
  const document = { name: "Untitled 1", path: null as string | null, markSaved(path: string | null) { this.path = path; } };
  const order: string[] = [];
  const writes: string[] = [];
  let permission = true;
  const answers = ["/a/Plot.pfg", "/b/Approved.pfg"];
  const options = {
    document, as: false, extension: "pfg", mimeType: "application/json", stripExtension: (name: string) => name.replace(/\.pfg$/i, ""),
    beforeSave() {}, prepare() {}, nativeFormat: "pfg" as const, unsupportedMessage: "Unsupported format.", report() {}, afterSave() {},
    // a project that stores its data files relative to itself
    serialize: (_document: unknown, path: string | null) => { order.push(`serialize ${path}`); return { text: `data relative to ${path}`, format: "pfg" as const }; },
    desktop: {
      async saveDialog() { order.push("dialog"); return answers.shift() ?? null; },
      async writeFile(path: string, text: string) {
        writes.push(`${path}: ${text}`);
        if (!permission && path === "/a/Plot.pfg") throw new Error("Save permission required. Choose a path in the save dialog.");
      },
    },
  };
  assert.equal(await saveDocument(options), true);
  assert.deepEqual(order, ["dialog", "serialize /a/Plot.pfg"], "serialised once, after the path is chosen");
  assert.deepEqual(writes, ["/a/Plot.pfg: data relative to /a/Plot.pfg"]);
  // a write that needs a fresh grant makes the text again for the new place
  order.length = 0; writes.length = 0; permission = false;
  assert.equal(await saveDocument(options), true);
  assert.deepEqual(order, ["serialize /a/Plot.pfg", "dialog", "serialize /b/Approved.pfg"], "a saved path needs no dialog first");
  assert.deepEqual(writes, ["/a/Plot.pfg: data relative to /a/Plot.pfg", "/b/Approved.pfg: data relative to /b/Approved.pfg"]);
  assert.equal(document.path, "/b/Approved.pfg");
});

test("saving an opened file asks for a dialog grant before writing", async () => {
  const document = { name: "Opened.nfg", path: "/tmp/Opened.nfg" as string | null,
    markSaved(path: string | null) { this.path = path; } };
  const writes: string[] = [];
  const saved = await saveDocument({
    document, as: false, extension: "nfg", mimeType: "application/json",
    stripExtension: (name) => name.replace(/\.nfg$/i, ""),
    beforeSave() {}, prepare() {}, serialize: () => ({ text: "payload", format: "nfg" as const }),
    nativeFormat: "nfg" as const, unsupportedMessage: "Unsupported format.", report() {}, afterSave() {},
    desktop: {
      async saveDialog(name) { assert.equal(name, "Opened.nfg"); return "/tmp/Approved.nfg"; },
      async writeFile(path) {
        writes.push(path);
        if (path === "/tmp/Opened.nfg") throw new Error("Save permission required. Choose a path in the save dialog.");
      },
    },
  });
  assert.equal(saved, true);
  assert.deepEqual(writes, ["/tmp/Opened.nfg", "/tmp/Approved.nfg"]);
  assert.equal(document.path, "/tmp/Approved.nfg");
});

test("a Save dialog answered twice without the extension writes nothing", async () => {
  const reports: string[] = [];
  const document = { name: "Notes", path: null as string | null, markSaved() { throw new Error("should not be saved"); } };
  const saved = await saveDocument({
    document, as: false, extension: "nfg", mimeType: "application/json", stripExtension: (name: string) => name.replace(/\.[^./]+$/, ""),
    beforeSave: () => {}, prepare: () => {}, serialize: () => ({ text: "payload", format: "nfg" as const }), nativeFormat: "nfg" as const,
    unsupportedMessage: "Unsupported format.", report: (message: string) => { reports.push(message); }, afterSave: () => {},
    desktop: { async saveDialog() { return "/tmp/Notes.txt"; }, async writeFile() { throw new Error("should not write"); } },
  });
  assert.equal(saved, false);
  assert.deepEqual(reports, ["Couldn't save: the name must end in .nfg."]);
});
