// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The sheet of the welcome screen, drawn on a canvas: the same colours and the same geometry, read from the tokens that
// the welcome CSS uses (`--empty-*` in tokens.css), so that the grid is defined once.

/** The token of each value of the sheet. Lengths are in px. */
export const SHEET_GRID_TOKENS = {
  sheet: "--empty-sheet",
  dot: "--empty-grid-dot",
  line: "--empty-grid-line",
  originPx: "--empty-grid-origin",
  dotStepPx: "--empty-grid-dot-step",
  lineStepPx: "--empty-grid-line-step",
  dotRadiusPx: "--empty-grid-dot-radius",
  lineWidthPx: "--empty-grid-line-width",
} as const;

/** The sheet's colours, and where its dots and lines fall, in view px at a scale of 1. */
export interface SheetGrid {
  sheet: string; dot: string; line: string;
  originPx: number; dotStepPx: number; lineStepPx: number; dotRadiusPx: number; lineWidthPx: number;
}

/** A family of dots or lines closer than this on screen, in px, is not drawn: it would read as a tint, not a grid. */
export const SHEET_GRID_MIN_PITCH_PX = 4;

const LENGTHS = ["originPx", "dotStepPx", "lineStepPx", "dotRadiusPx", "lineWidthPx"] as const;

/** The grid from a token reader (a computed style's `getPropertyValue`). Throws a sentence when a token is missing or not in px. */
export function sheetGridFrom(read: (token: string) => string): SheetGrid {
  const value = (token: string): string => {
    const text = read(token).trim();
    if (!text) throw new Error(`The sheet grid needs ${token}; load the shell's tokens.css.`);
    return text;
  };
  const grid = { sheet: value(SHEET_GRID_TOKENS.sheet), dot: value(SHEET_GRID_TOKENS.dot), line: value(SHEET_GRID_TOKENS.line) } as SheetGrid;
  for (const key of LENGTHS) {
    const text = value(SHEET_GRID_TOKENS[key]);
    const match = /^(-?\d*\.?\d+)px$/.exec(text);
    if (!match) throw new Error(`${SHEET_GRID_TOKENS[key]} is ${text}, not a length in px.`);
    grid[key] = Number(match[1]);
  }
  if (grid.dotStepPx <= 0 || grid.lineStepPx <= 0) throw new Error("The steps of the sheet grid must be greater than 0 px.");
  return grid;
}

/** The grid of the page's current appearance, as the welcome screen draws it. */
export function sheetGrid(element: Element = document.body): SheetGrid {
  const style = getComputedStyle(element);
  return sheetGridFrom((token) => style.getPropertyValue(token));
}

/** The positions `origin + k × step` (any whole k) in [from, to), in order. */
export function gridPositions(originPx: number, stepPx: number, fromPx: number, toPx: number): number[] {
  const positions: number[] = [];
  for (let at = originPx + Math.ceil((fromPx - originPx) / stepPx) * stepPx; at < toPx; at += stepPx) positions.push(at);
  return positions;
}

/** Content-to-view mapping of a canvas that pans and zooms (`Viewport`): view = world × scale + origin. */
export interface SheetView { scale: number; ox: number; oy: number }

/**
 * Draw the sheet over a `widthPx` × `heightPx` canvas in CSS px (a context already scaled for the device pixel ratio).
 * At the default `view` it is the welcome screen pixel for pixel: lines are the `lineWidthPx` from each position
 * rightwards and downwards, dots are centred on each position. With a `view`, the grid is fixed to the content and its
 * steps scale with it, while dots and lines keep their size on screen; a family under `SHEET_GRID_MIN_PITCH_PX` apart is
 * left out.
 */
export function drawSheetGrid(ctx: CanvasRenderingContext2D, widthPx: number, heightPx: number, grid: SheetGrid = sheetGrid(), view: SheetView = { scale: 1, ox: 0, oy: 0 }): void {
  ctx.save();
  ctx.fillStyle = grid.sheet;
  ctx.fillRect(0, 0, widthPx, heightPx);
  const lineStep = grid.lineStepPx * view.scale, dotStep = grid.dotStepPx * view.scale;
  const [x0, y0] = [grid.originPx * view.scale + view.ox, grid.originPx * view.scale + view.oy];
  if (lineStep >= SHEET_GRID_MIN_PITCH_PX) {
    ctx.fillStyle = grid.line;
    for (const x of gridPositions(x0, lineStep, -grid.lineWidthPx, widthPx)) ctx.fillRect(x, 0, grid.lineWidthPx, heightPx);
    for (const y of gridPositions(y0, lineStep, -grid.lineWidthPx, heightPx)) ctx.fillRect(0, y, widthPx, grid.lineWidthPx);
  }
  if (dotStep >= SHEET_GRID_MIN_PITCH_PX) {
    ctx.fillStyle = grid.dot;
    ctx.beginPath();
    const ys = gridPositions(y0, dotStep, -grid.dotRadiusPx, heightPx + grid.dotRadiusPx);
    for (const x of gridPositions(x0, dotStep, -grid.dotRadiusPx, widthPx + grid.dotRadiusPx)) {
      for (const y of ys) { ctx.moveTo(x + grid.dotRadiusPx, y); ctx.arc(x, y, grid.dotRadiusPx, 0, 2 * Math.PI); }
    }
    ctx.fill();
  }
  ctx.restore();
}
