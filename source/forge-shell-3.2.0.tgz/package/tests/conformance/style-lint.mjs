import assert from "node:assert/strict";
import { test } from "node:test";
import { lintCss, lintSource, lintIcons, checkDataColors } from "../../scripts/style-lint.mjs";

test("css lint flags colours, sizes, weights, uppercase and !important", () => {
  const css = ".a { color: #123456; font-size: 14px; font-weight: 500; text-transform: uppercase; margin: 0 !important; }";
  const found = lintCss(css, "app.css");
  for (const part of ["raw colour #123456", "14px", "weight 500", "uppercase", "!important"]) assert.ok(found.some((m) => m.includes(part)), part);
  assert.deepEqual(lintCss(".a { color: var(--text); font: 600 11px var(--ui); font-size: var(--size); } /* #fff */", "app.css"), []);
});

test("data colours are allowed and compared without case", () => {
  assert.deepEqual(lintCss(".trace { color: #79B8FF; }", "app.css", { dataColors: ["#79b8ff"] }), []);
  assert.deepEqual(lintSource('const c = "#79b8ff";', "scopes.ts", { dataColors: ["#79b8ff"] }), []);
  assert.throws(() => checkDataColors(["red"]), /hex/);
});

test("source lint flags inline font and colour styles", () => {
  assert.equal(lintSource('el.style.color = "x";', "a.ts").length, 1);
  assert.equal(lintSource('el.innerHTML = `<b style="font-weight:700">x</b>`;', "a.ts").length, 1);
  assert.equal(lintSource('el.style.width = "10px";', "a.ts").length, 0);
});

test("icon lint flags unnamed icon-only buttons and off-convention strokes", () => {
  assert.equal(lintIcons('<button class="tool"><svg width="16"></svg></button>', "a.ts").length, 1);
  assert.equal(lintIcons('<button class="tool" aria-label="Undo"><svg width="16"></svg></button>', "a.ts").length, 0);
  assert.equal(lintIcons('<button>Save</button>', "a.ts").length, 0);
  assert.equal(lintIcons('<svg stroke-width="2"></svg>', "a.ts").length, 1);
  // a shared icon drawn by hand is reported with its name; an application's own icon is not
  assert.deepEqual(lintIcons(`close.innerHTML = toolIcon('<path d="M18 6 6 18"/>');`, "a.ts"), ["a.ts:1 draws the shared close icon itself; use the shell's icon"]);
  assert.deepEqual(lintIcons(`toolIcon('<path d="M3 4h10M3 8h7M3 12h10"/>')`, "a.ts"), []);
  assert.equal(lintIcons('<svg stroke-width="1.25"></svg>', "a.ts").length, 0);
});

test("source lint flags direct tooltip assignment but not the page title", () => {
  assert.equal(lintSource('button.title = "Undo";', "a.ts").length, 1);
  assert.equal(lintSource('document.title = "x";', "a.ts").length, 0);
  assert.equal(lintSource('button.title = `Add ${folder}`;', "a.ts").length, 1);
  assert.equal(lintSource('this.title = options.title;', "a.ts").length, 0);
});
