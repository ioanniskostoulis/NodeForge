// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { matchesKey } from "./menus";

export interface WorkspaceKeysOptions {
  desktop: boolean;
  hasDocuments: () => boolean;
  typingInField: () => boolean;
  shortcuts: () => readonly { key: string; id: string }[];
  run: (id: string) => void;
  escape: () => void;
  domainKeyDown?: (event: KeyboardEvent) => boolean;
  domainKeyUp?: (event: KeyboardEvent) => void;
}

/** Route shell shortcuts while leaving domain keys to the app. */
export function installWorkspaceKeys(options: WorkspaceKeysOptions): () => void {
  const keydown = (e: KeyboardEvent) => {
    const target = e.target;
    if (target instanceof HTMLElement && target.closest("input, textarea, select")) {
      if (e.key === "Escape") target.blur();
      else if (!options.desktop && !options.typingInField()) {
        const hit = options.shortcuts().find((shortcut) => /^edit\.(undo|redo)$/.test(shortcut.id) && matchesKey(e, shortcut.key));
        if (hit) { e.preventDefault(); options.run(hit.id); }
      }
      return;
    }
    const plain = !e.metaKey && !e.ctrlKey && !e.altKey;
    if (!options.hasDocuments() && plain) return;
    if (e.key === "Escape") { options.escape(); return; }
    if (options.domainKeyDown?.(e)) { e.preventDefault(); return; }
    if (options.desktop) return;
    const hit = options.shortcuts().find((shortcut) => matchesKey(e, shortcut.key));
    if (hit) { e.preventDefault(); options.run(hit.id); }
  };
  const keyup = (e: KeyboardEvent) => { options.domainKeyUp?.(e); };
  document.addEventListener("keydown", keydown);
  document.addEventListener("keyup", keyup);
  return () => { document.removeEventListener("keydown", keydown); document.removeEventListener("keyup", keyup); };
}
