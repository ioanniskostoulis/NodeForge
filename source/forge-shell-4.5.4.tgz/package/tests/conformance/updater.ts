import assert from "node:assert/strict";
import test from "node:test";
import { appBundle, cannotReplace, installUpdate, macSwapScript, UNSAVED_WORK_REASON, windowsUpdateLog, windowsUpdateScript } from "../../source/desktop/updater";
import { updateAsset, type Release } from "../../source/app/updates";

const release: Release = { version: "3.1.0", url: "https://github.com/owner/app/releases/tag/v3.1.0", name: "3.1.0", assets: [
  { name: "Example-v3.1.0.dmg", url: "https://github.com/owner/app/releases/download/v3.1.0/Example-v3.1.0.dmg", size: 10, sha256: null },
  { name: "Example-v3.1.0.exe", url: "https://github.com/owner/app/releases/download/v3.1.0/Example-v3.1.0.exe", size: 20, sha256: null },
  { name: "Example-v3.1.0.dmg.blockmap", url: "https://github.com/owner/app/releases/download/v3.1.0/Example-v3.1.0.dmg.blockmap", size: 1, sha256: null },
] };

test("an update with unsaved work open downloads nothing and never quits", async () => {
  let requested = 0;
  let quit = 0;
  const result = await installUpdate(release.assets[0], {
    repository: "owner/app", executable: "/Applications/Example.app/Contents/MacOS/Example", platform: "darwin",
    quit: () => { quit++; }, openPath: async () => "", hasUnsavedWork: () => true,
    request: (async () => { requested++; return new Response("x"); }) as unknown as typeof fetch,
  });
  assert.deepEqual(result, { status: "failed", reason: UNSAVED_WORK_REASON });
  assert.deepEqual([requested, quit], [0, 0]);
});

test("the update installs the release's disk image on macOS and its setup on Windows", () => {
  assert.equal(updateAsset(release, "Example", "darwin")?.name, "Example-v3.1.0.dmg");
  assert.equal(updateAsset(release, "Example", "win32")?.name, "Example-v3.1.0.exe");
  assert.equal(updateAsset(release, "Example", "linux"), null);
  assert.equal(updateAsset(release, "Other", "darwin"), null);
});

test("a macOS app replaces itself only from a real folder, never from its disk image or a translocated download", () => {
  assert.equal(appBundle("/Applications/Example.app/Contents/MacOS/Example"), "/Applications/Example.app");
  assert.equal(appBundle("/usr/local/bin/node"), null);
  assert.equal(cannotReplace("/Applications/Example.app"), null);
  assert.match(cannotReplace("/private/var/folders/x/AppTranslocation/1/d/Example.app")!, /Move it to Applications/);
  assert.match(cannotReplace("/Volumes/Example 3.1.0/Example.app")!, /Drag it to Applications/);
  assert.match(cannotReplace(null)!, /not in an app bundle/);
});

test("the swap scripts wait for the app, keep the old copy until the new one is in place, and quote paths", () => {
  const mac = macSwapScript({ pid: 42, bundle: "/Applications/It's.app", staged: "/Applications/It's.app.new", work: "/tmp/w" });
  assert.match(mac, /while kill -0 42/);
  assert.ok(mac.includes(`'/Applications/It'\\''s.app'`));
  assert.ok(mac.indexOf("mv '/Applications/It'\\''s.app' '/Applications/It'\\''s.app.old'") < mac.indexOf("mv '/Applications/It'\\''s.app.new'"));
});

test("the Windows update runs away from the app's folder, waits for all of the app, and retries a setup that found it in use", () => {
  const app = "C:\\Program Files\\Forge\\It's\\It's.exe";
  const script = windowsUpdateScript({ pid: 7, setup: "C:\\Temp\\u\\It-v3.1.0.exe", app, work: "C:\\Temp\\u", log: "C:\\Temp\\It update.log" });
  const lines = script.split("\r\n");
  const at = (text: string) => lines.findIndex((line) => line.includes(text));
  assert.ok(at("Set-Location -LiteralPath 'C:\\Temp\\u'") < at("Wait-Process -Id 7"), "the script leaves the app's folder before anything else");
  assert.ok(at("Wait-Process -Id 7") < at("Where-Object { $_.Path -eq 'C:\\Program Files\\Forge\\It''s\\It''s.exe' }"), "then waits for every process of the app's executable");
  assert.match(script, /AddSeconds\(30\)/, "at most 30 s");
  assert.match(lines[at("-ArgumentList '/S'")], /-WorkingDirectory 'C:\\Temp\\u' -Wait -PassThru/, "the setup starts from the temporary folder too");
  assert.match(script, /for \(\$try = 1; \$try -le 3; \$try\+\+\)/);
  assert.match(script, /if \(\$code -ne 3\) \{ break \}/, "only 'in use' is tried again");
  assert.ok(at("-ArgumentList '/S'") < at(`Start-Process -FilePath '${app.replaceAll("'", "''")}' -WorkingDirectory $env:USERPROFILE`), "the app opens again after the setup, not from its own folder");
  assert.match(script, /Add-Content -LiteralPath \$log/);
  assert.equal(windowsUpdateLog("C:\\Program Files\\Forge\\Example\\Example.exe", "C:/Temp"), "C:/Temp/Example update.log");
});

