// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The main-process side of exporting, shared by every Forge desktop application: an export dialog offering the
// application's formats, a folder dialog for several files, and binary writes only where one of them approved. A path
// the Save dialog approved may be replaced (the dialog asked); any other write into an approved folder is exclusive
// ("wx") unless the person confirmed Replace, so a file is never replaced by surprise. A project file and the
// application's protected files (the originals a document reads) are refused whatever was approved.
import { comparablePath, exportProblem, fileNameOf, formatOf, type ExportFormat } from "../app/export-plan";
import type { ShellIpcEvent, ShellIpcRegistry } from "./ipc-main";

export interface ExportMainOptions {
  formats: readonly ExportFormat[];
  /** True on macOS and Windows, whose file systems ignore case. */
  ignoreCase: boolean;
  /** Files the main process knows the window's documents read (originals); the page may name more with each write. */
  protectedPaths?(event: ShellIpcEvent): readonly string[];
  /** Electron's save dialog for the window: `{ title, defaultPath, filters }`; the chosen path, or null when cancelled. */
  saveDialog(event: ShellIpcEvent, options: { title: string; defaultPath: string; filters: { name: string; extensions: string[] }[] }): Promise<string | null>;
  /** Electron's open dialog with `openDirectory` and `createDirectory`; the chosen folder, or null. */
  folderDialog(event: ShellIpcEvent, options: { title: string; buttonLabel: string }): Promise<string | null>;
  readdir(folder: string): Promise<string[]>;
  /** `fs.promises.writeFile(path, bytes, { flag })`: "w" may replace, "wx" fails when the file exists. */
  writeFile(path: string, bytes: Uint8Array, flag: "w" | "wx"): Promise<void>;
  /** Node's `path.resolve` and `path.dirname`. */
  resolve(path: string): string;
  dirname(path: string): string;
}

/** The export IPC: `exportDialog`, `exportFolder`, `exportFolderNames` and `writeExport`. Call `forget(id)` when a window closes. */
export function registerExportIpc(ipc: ShellIpcRegistry, options: ExportMainOptions): { forget(id: number): void } {
  const approved = new Map<number, { paths: Set<string>; folders: Set<string> }>();
  const of = (id: number) => approved.get(id) ?? approved.set(id, { paths: new Set(), folders: new Set() }).get(id)!;
  const key = (path: string) => comparablePath(options.resolve(path), options.ignoreCase);

  ipc.handle("exportDialog", async (event, suggestedName: unknown, formatIds: unknown) => {
    const wanted = Array.isArray(formatIds) ? options.formats.filter((format) => formatIds.includes(format.id)) : [];
    const formats = wanted.length ? wanted : [...options.formats];
    if (!formats.length) throw new Error("This application has no export formats.");
    const name = typeof suggestedName === "string" && suggestedName ? suggestedName : `export.${formats[0].extensions[0]}`;
    // The format of the suggested name comes first, so the dialog opens on it.
    const first = formatOf(name, formats) ?? formats[0];
    const ordered = [first, ...formats.filter((format) => format !== first)];
    const chosen = await options.saveDialog(event, {
      title: "Export", defaultPath: name, filters: ordered.map((format) => ({ name: format.name, extensions: [...format.extensions] })),
    });
    if (!chosen) return null;
    // A name typed without an extension takes the chosen format's.
    const path = formatOf(chosen, formats) ? chosen : `${chosen}.${first.extensions[0]}`;
    const problem = exportProblem(path, { formats, protectedPaths: options.protectedPaths?.(event) ?? [], ignoreCase: options.ignoreCase });
    if (problem) throw new Error(problem);
    of(event.sender.id).paths.add(key(path));
    // Its folder takes new files too, never replacing one, for Keep both.
    of(event.sender.id).folders.add(key(options.dirname(options.resolve(path))));
    return path;
  });

  ipc.handle("exportFolder", async (event, title: unknown) => {
    const folder = await options.folderDialog(event, { title: typeof title === "string" && title ? title : "Export to a folder", buttonLabel: "Export" });
    if (!folder) return null;
    const resolved = options.resolve(folder);
    of(event.sender.id).folders.add(key(resolved));
    return { folder: resolved, names: await options.readdir(resolved) };
  });

  ipc.handle("exportFolderNames", async (event, path: unknown) => {
    const folder = options.dirname(options.resolve(String(path)));
    if (!of(event.sender.id).folders.has(key(folder))) throw new Error("Only a folder an export dialog chose is listed.");
    return options.readdir(folder);
  });

  ipc.handle("writeExport", async (event, path: unknown, bytes: unknown, originals: unknown, replace: unknown) => {
    if (typeof path !== "string" || !path || !(bytes instanceof Uint8Array)) throw new Error("The export is not valid.");
    const target = options.resolve(path);
    const allowed = of(event.sender.id);
    const chosenPath = allowed.paths.has(key(target));
    if (!chosenPath && !allowed.folders.has(key(options.dirname(target)))) throw new Error("Exports are written only where an export dialog chose.");
    const protectedPaths = [...(options.protectedPaths?.(event) ?? []), ...(Array.isArray(originals) ? originals.filter((item): item is string => typeof item === "string") : [])];
    const problem = exportProblem(target, { formats: options.formats, protectedPaths, ignoreCase: options.ignoreCase });
    if (problem) throw new Error(problem);
    try {
      await options.writeFile(target, bytes, chosenPath || replace === true ? "w" : "wx");
    } catch (error) {
      if ((error as { code?: string })?.code === "EEXIST") throw new Error(`${fileNameOf(target)} already exists and was not replaced.`);
      throw error;
    }
  });

  return { forget: (id) => { approved.delete(id); } };
}
