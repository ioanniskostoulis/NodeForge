import assert from "node:assert/strict";
import { test } from "node:test";
import { documentArguments, readOpenedFiles } from "../../source/desktop/files.js";
import { DesktopWindowState } from "../../source/desktop/window-state.js";

test("desktop window state keeps startup files and unsaved-close decisions per window", () => {
  const windows = new DesktopWindowState<string>();
  windows.setStartupFiles(1, ["a"]);
  windows.setStartupFiles(2, ["b"]);
  assert.deepEqual(windows.takeStartupFiles(1), ["a"]);
  assert.deepEqual(windows.takeStartupFiles(1), []);
  assert.deepEqual(windows.takeStartupFiles(2), ["b"]);
  windows.setEdited(1, true);
  assert.equal(windows.needsClosePrompt(1), true);
  assert.equal(windows.needsClosePrompt(2), false);
  windows.confirmClose(1);
  assert.equal(windows.needsClosePrompt(1), false);
  windows.beginQuit();
  assert.equal(windows.closed(1, 1), false);
  assert.equal(windows.closed(2, 0), true);
  windows.cancelQuit();
  assert.equal(windows.closed(3, 0), false);
});

test("desktop file helpers retain valid files and report individual read errors", () => {
  const found = documentArguments(["--test", "one.nfg", "other.txt", "missing.nfg"], "/work",
    (path) => /\.nfg$/.test(path), (cwd, path) => `${cwd}/${path}`, (path) => path !== "/work/missing.nfg");
  assert.deepEqual(found, ["/work/one.nfg"]);
  const errors: string[] = [];
  const opened = readOpenedFiles(["one", "bad", "two"], (path) => {
    if (path === "bad") throw new Error("unreadable");
    return `contents of ${path}`;
  }, (path, error) => { errors.push(`${path}: ${error.message}`); });
  assert.deepEqual(opened, [{ path: "one", text: "contents of one" }, { path: "two", text: "contents of two" }]);
  assert.deepEqual(errors, ["bad: unreadable"]);
});
