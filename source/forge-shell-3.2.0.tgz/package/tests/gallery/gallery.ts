// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The component page: every part of the shell in the frame of an application, with long names, many tabs and every
// kind of message, so that rendering, centring and narrow windows can be checked in one place (scripts/gallery.mjs).
import { helpMenu, menuShortcutGroups, showAbout, showLicenses, showShortcuts, showWhatsNew, type InfoOptions } from "../../source/app/about";
import { createBottomTabs } from "../../source/app/bottom-tabs";
import { createButton, createButtonGroup, setButtonBusy, createCheckRow, createChips, createField, createGroupHeading, createInfoLines, createRow, setProblem } from "../../source/app/builders";
import { createCodeEditor } from "../../source/app/code-editor";
import { showContextMenu } from "../../source/app/context-menu";
import { applyDesktopClasses } from "../../source/app/desktop-classes";
import { askToApply, askToPick, askToSave, askToSaveAll } from "../../source/app/dialogs";
import { createEmptyState } from "../../source/app/empty-state";
import { createFindBar, FindController } from "../../source/app/find-bar";
import { attachFileDrop } from "../../source/app/file-drop";
import { renderFileTree, type FileSelection, type TreeFile } from "../../source/app/file-tree";
import { InspectorSections } from "../../source/app/inspector-sections";
import { sliderRow } from "../../source/app/inspector-widgets";
import { renderMenubar, shortcutText, type MenuNode } from "../../source/app/menus";
import { MessageLog, MessagesPanel } from "../../source/app/messages";
import { renderOutline } from "../../source/app/outline-list";
import { createPanelLayout } from "../../source/app/panel-layout";
import { showUpdateCheck } from "../../source/app/updates";
import { autosaveMenu, recentMenu } from "../../source/app/saving";
import { createSplitter } from "../../source/app/splitter";
import { StatusBar } from "../../source/app/status-bar";
import { DocumentTabs, type TabDocument } from "../../source/app/tabs";
import { TerminalPanel } from "../../source/app/terminal";
import { setTip } from "../../source/app/tips";
import { TOOL_ICONS, UI_ICONS } from "../../source/app/tool-icons";
import { createFlyoutGroup } from "../../source/app/tool-flyout";
import { createToolStrip } from "../../source/app/tool-strip";
import { createUnitField } from "../../source/app/unit-field";
import { createViewHeader } from "../../source/app/view-header";

declare const __APP_LOGO__: string;
declare const __FORGE_VERSION__: string;
const $ = (id: string) => document.getElementById(id)!;
const params = new URLSearchParams(location.search);
const info: InfoOptions = { productName: "Gallery", purpose: "component page", logo: __APP_LOGO__, version: __FORGE_VERSION__ };
document.body.dataset.theme = params.get("theme") ?? "dark";
applyDesktopClasses(undefined);

// MARK: menus and tool strip

const menus: MenuNode[] = [
  { label: "File", submenu: [{ id: "new", label: "New document", key: "CmdOrCtrl+N" }, { id: "open", label: "Open…", key: "CmdOrCtrl+O" }, recentMenu(["/a/notes.txt", "/b/notes.txt", "/c/report with a long name.txt"]), { separator: true },
    { id: "save", label: "Save", key: "CmdOrCtrl+S" }, { id: "saveAs", label: "Save as…", key: "CmdOrCtrl+Shift+S", enabled: false }, autosaveMenu("1m"), { separator: true }, { id: "close", label: "Close", key: "CmdOrCtrl+W" }] },
  { label: "Edit", submenu: [{ role: "undo", label: "Undo", key: "CmdOrCtrl+Z" }, { role: "redo", label: "Redo", key: "CmdOrCtrl+Shift+Z" }, { separator: true }, { role: "selectAll", label: "Select all", key: "CmdOrCtrl+A" }] },
  { label: "View", submenu: [{ id: "inspector", label: "Show inspector", key: "CmdOrCtrl+I", checked: true }, { id: "panel", label: "Show bottom panel", key: "CmdOrCtrl+J", checked: true }, { separator: true },
    { label: "Appearance", submenu: [{ id: "dark", label: "Dark", checked: true }, { id: "light", label: "Light", checked: false }] }] },
  { label: "Simulate", submenu: [{ id: "run", label: "Run", key: "CmdOrCtrl+Return" }, { id: "step", label: "Step", key: "CmdOrCtrl+Shift+T" }] },
  helpMenu("Gallery", false, true),
];
function run(id: string): void {
  if (id === "about") showAbout(info, `<div class="block"><p class="about-intro">The component page of the shell.</p></div>`);
  else if (id === "about.whatsNew") void showWhatsNew(info);
  else if (id === "about.shortcuts") showShortcuts(info, menuShortcutGroups(menus, (key) => shortcutText(key)));
  else if (id === "about.licenses") void showLicenses(info);
}
renderMenubar($("menubar"), menus, run);
const strip = createToolStrip($("toolstrip"), run);
strip.group([strip.tool({ id: "undo", label: "Undo", icon: TOOL_ICONS.undo, shortcut: "CmdOrCtrl+Z" }), strip.tool({ id: "redo", label: "Redo", icon: TOOL_ICONS.redo, shortcut: "CmdOrCtrl+Shift+Z" })], "", "history");
strip.group([strip.tool({ id: "cut", label: "Cut", icon: TOOL_ICONS.cut }), strip.tool({ id: "copy", label: "Copy", icon: TOOL_ICONS.copy }), strip.tool({ id: "paste", label: "Paste", icon: TOOL_ICONS.paste })], "", "clipboard");
strip.group([strip.tool({ id: "zoomIn", label: "Zoom in", icon: TOOL_ICONS.zoomIn }), strip.tool({ id: "zoomOut", label: "Zoom out", icon: TOOL_ICONS.zoomOut }), strip.tool({ id: "fit", label: "Fit", icon: TOOL_ICONS.fit })], "", "view");
strip.group([strip.tool({ id: "pointer", label: "Select", icon: UI_ICONS.pointer, shortcut: "V" }), strip.tool({ id: "rotate", label: "Rotate", icon: UI_ICONS.rotate }), strip.tool({ id: "duplicate", label: "Duplicate", icon: UI_ICONS.duplicate }), strip.tool({ id: "delete", label: "Delete", icon: UI_ICONS.delete })]);
// A palette family with tools of long and short names, so that the flyout menu's columns can be checked.
const shapes = createFlyoutGroup({ id: "shapes", label: "Shapes", onSelect() {}, tools: [
  { id: "rect", label: "Rectangle", icon: UI_ICONS.add, shortcut: "R" }, { id: "ellipse", label: "Ellipse", icon: UI_ICONS.remove },
  { id: "polygon", label: "Polygon with a long name", icon: UI_ICONS.edit, shortcut: "P" }] });
strip.group([shapes.button], "flyout-group");
strip.finish();

// MARK: documents

interface Doc extends TabDocument { name: string; dirty: boolean; path: string | null }
const documents: Doc[] = params.get("docs") === "0" ? [] : [
  { name: "Untitled 1", dirty: false, path: null }, { name: "lorenz-attractor.nfg", dirty: true, path: "/Users/me/Documents/lorenz-attractor.nfg" },
  { name: "a report with a very long name that is cut off.lfg", dirty: false, path: "/Users/me/a report with a very long name that is cut off.lfg" }, { name: "notes.txt", dirty: false, path: "/notes.txt" },
];
let active: Doc | null = documents[1] ?? null;
const tabs = new DocumentTabs<Doc>($("doc-tabs"), {
  newTitle: `New document (${shortcutText("CmdOrCtrl+N")})`, closeTitle: `Close document (${shortcutText("CmdOrCtrl+W")})`,
  onNew: () => { documents.push({ name: `Untitled ${documents.length + 1}`, dirty: false, path: null }); renderDocuments(); },
  onActivate: (document) => { active = document; renderDocuments(); },
  onClose: (document) => { documents.splice(documents.indexOf(document), 1); if (active === document) active = documents[0] ?? null; renderDocuments(); },
  onReorder: (from, to) => { const [moved] = documents.splice(from, 1); documents.splice(to > from ? to - 1 : to, 0, moved); renderDocuments(); },
});
const empty = createEmptyState($("center"), { title: "No document open", newLabel: "New document", openLabel: "Open…", detail: "Create or open a .gfg document",
  newShortcut: shortcutText("CmdOrCtrl+N"), openShortcut: shortcutText("CmdOrCtrl+O"), onNew: () => {}, onOpen: () => {} });
function renderDocuments(): void {
  tabs.render(documents, active);
  empty.hidden = documents.length > 0;
  document.body.classList.toggle("no-docs", documents.length === 0);
}
(window as unknown as { gallery: unknown }).gallery = { documents, tabs, renderDocuments, log: () => log };

// MARK: centre: a view header, an editor with its find bar, and an outline, side by side

const work = $("work");
work.append(createViewHeader({ title: "main.tex", dirty: true, actions: [{ icon: UI_ICONS.export, label: "Export", run() {} }, { icon: UI_ICONS.close, label: "Close", run() {} }] }));
const split = Object.assign(document.createElement("div"), { className: "gallery-split" });
const editorHost = Object.assign(document.createElement("div"), { className: "gallery-editor" });
const outline = document.createElement("div");
split.append(editorHost, outline);
work.append(split);
createSplitter(split, editorHost, outline, { axis: "x", share: 0.7 });
const bar = createFindBar("the document");
let editor: ReturnType<typeof createCodeEditor>;
const find = new FindController(() => editor, bar);
editor = createCodeEditor({ parent: editorHost, extensions: find.extensions(), doc: [
  "% A report", "\\documentclass[preset=default, language=greek]{report}", "\\begin{document}", "\\section{Introduction}",
  "The section explains the setup. A long line that wraps or scrolls sideways, depending on the editor's settings, to test the view.",
  "\\subsection{Method}", "\\section{Results}", "\\end{document}",
].join("\n") });
if (params.get("find") !== "0") { find.openFind(params.get("replace") === "1"); bar.find.value = "section"; bar.find.dispatchEvent(new Event("input")); }
renderOutline(outline, [{ title: "Introduction", level: 1, id: "a" }, { title: "Method", level: 2, id: "b" }, { title: "Results with a long heading that wraps", level: 1, id: "c" }], "b", () => {});
// Files dropped on the centre; `?drop=1` shows the drop target, as while files are dragged over it.
attachFileDrop(work, { accept: [".png", ".jpg", ".tif"], label: "Drop images to open them.", onFiles: (dropped) => log.add("info", `Opened ${dropped.map((f) => f.name).join(", ")}.`),
  onRefused: (message) => log.add("error", message) });
if (params.get("drop") === "1") {
  const transfer = new DataTransfer();
  transfer.items.add(new File([""], "cells.tif"));
  work.dispatchEvent(new DragEvent("dragenter", { dataTransfer: transfer, bubbles: true }));
}

// MARK: inspector

const open = new Set(["run", "buttons", "document", "fields", "measurements", "files", "pointer"]);
const sections = new InspectorSections({ root: $("inspector"), keys: ["run", "buttons", "document", "fields", "measurements", "files", "pointer", "closed"], isOpen: (key) => open.has(key), setOpen: (key, value) => { if (value) open.add(key); else open.delete(key); } });
// The standard top section: the main actions of the document, one button group across the width.
sections.create("Run", "run").append(createButtonGroup([createButton({ label: "Run", primary: true }), createButton({ label: "Step" }), createButton({ label: "Reset" })]));
// Every state of the two kinds of button: enabled, disabled and busy, ordinary and primary.
const busy = createButton({ label: "Building PDF…", primary: true });
setButtonBusy(busy, "Building PDF…");
sections.create("Button states", "buttons").append(
  createButtonGroup([createButton({ label: "Build PDF", primary: true }), createButton({ label: "Open PDF" })]),
  createButtonGroup([createButton({ label: "Build PDF", primary: true, disabled: true }), createButton({ label: "Open PDF", disabled: true })]),
  createButtonGroup([busy, createButton({ label: "Cancel" })]));
const documentSection = sections.create("Document", "document");
documentSection.append(createRow("Name", "lorenz-attractor.nfg"), createRow("Path", "/Users/me/Documents/a very long folder name/lorenz-attractor.nfg"), createGroupHeading("Grid"),
  createCheckRow("Snap to grid", true, () => {}), createChips([{ value: "s", label: "Small" }, { value: "m", label: "Medium" }, { value: "l", label: "Large" }], "m", () => {}));
const fields = sections.create("Fields and sliders", "fields");
const name = Object.assign(document.createElement("input"), { type: "text", value: "R1" });
const broken = Object.assign(document.createElement("input"), { type: "text", value: "12 kΩ x" });
const problem = document.createElement("div");
broken.classList.add("invalid");
setProblem(problem, "Type a number with a unit, such as 12 kΩ.");
fields.append(createField("Name", name), createField("A label that is long enough to wrap", broken), problem);
fields.append(createUnitField({ label: "Resistance", unit: "Ω", value: 1000, format: (value, unit) => `${value} ${unit}`, parse: Number.parseFloat, apply() {}, reportError() {}, invalidMessage: "Type a resistance." }).row);
fields.append(sliderRow("Speed", 40, 0, 100, () => {}).row);
// Values are read-only rows; a row's tooltip gives the detail on hover.
const measurements = sections.create("Measurements", "measurements");
const measured = (label: string, value: string, tip: string) => { const row = createRow(label, value); setTip(row, tip); return row; };
measurements.append(measured("Mean", "1.25 V", "The mean of the trace over the last 10 ms."), measured("Peak", "3.30 V", "The largest value of the trace over the last 10 ms."), measured("Samples", "4096", "Values in the window, at 409.6 kHz."));
const files = sections.create("Files", "files");
const treeList = document.createElement("div");
files.append(treeList);
const treeFiles: TreeFile[] = [{ path: "main.tex", kind: "tex" }, { path: "figures", kind: "folder" }, { path: "figures/plot with a long name.png", kind: "image" }, { path: "data", kind: "folder" }, { path: "data/run.csv", kind: "data" }];
const selection: FileSelection = { path: "main.tex" };
renderFileTree(treeList, treeFiles, { enabled: true, showHidden: false, selection, collapsed: new Set(), label: "Files", dragType: "application/x-gallery",
  open() {}, reveal() {}, trash() {}, add() {}, drop() {}, rename() {}, warn() {}, problem() {}, rerender() {},
  status: (file) => file.path === "main.tex" ? "editable" : "readOnly" });
// The item under the pointer, as the apps show it: the name first, then its values; quiet text when there is none.
const pointer = createInfoLines("Hover or click a file.");
sections.create("File under pointer", "pointer").append(pointer.element);
treeList.addEventListener("pointerover", (event) => {
  const path = (event.target as HTMLElement).closest<HTMLElement>(".tree-row")?.dataset.path;
  const file = treeFiles.find((item) => item.path === path);
  pointer.show(file ? [file.path.split("/").pop()!, `Kind     ${file.kind}`, `Folder   ${file.path.includes("/") ? file.path.slice(0, file.path.lastIndexOf("/")) : "project"}`] : null);
});
treeList.addEventListener("pointerleave", () => pointer.show(null));
sections.create("Closed section", "closed");

// MARK: bottom panel and status bar

const log = new MessageLog();
log.add("info", "Saved lorenz-attractor.nfg.");
log.add("warning", "The simulation step is larger than the smallest time constant; results may be inaccurate.");
log.add("error", "Could not open data/run.csv: the file is not valid CSV on line 12.");
const clear = Object.assign(document.createElement("button"), { className: "tab-action messages-clear", textContent: "Clear" });
setTip(clear, "Clear the messages.");
const messages = new MessagesPanel($("messages-pane"), { subjectName: () => null, selectSubject: () => {} }, clear);
messages.setLog(log);
const selectBottom = createBottomTabs<"terminal" | "messages">($("bottom-tabs"), [
  { name: "terminal", element: $("terminal-pane"), onSelect: () => terminal.show() },
  { name: "messages", element: $("messages-pane"), onSelect: () => messages.refresh(true) },
]);
$("bottom-tabs").append(clear);
const terminal = new TerminalPanel($("terminal-pane"), __APP_LOGO__, __FORGE_VERSION__, {
  execute: async () => ({ lines: ["help <command> for details. <value> required; [value] optional."], groups: [{ title: "File", items: [{ label: "new", comment: "Create a new document" }, { label: "open", comment: "Open a document" }] }] }),
  complete: () => [],
}, { appName: "Gallery", tagline: "component page", historyStorageKey: "gallery.history", fontSize: () => 12, setFontSize() {}, onFontSizeChange() {} });
selectBottom(params.get("pane") === "messages" ? "messages" : "terminal");
if (params.get("pane") !== "messages") void terminal.run("help");
new StatusBar($("statusbar"), () => selectBottom("messages")).render({ stateLabel: "Running", stateColor: "var(--accent-light)", summary: "1.25 s",
  detail: "Simulating lorenz-attractor.nfg with a step of 5 µs and three scopes", hint: null, unseenProblems: 2, problemKind: "error", readouts: ["Grid 16", "44 %"] });
renderDocuments();
const layout = { showInspector: true, inspectorSide: "right" as const, inspectorWidth: 246, showBottomPanel: true, bottomPanelHeight: 246 };
createPanelLayout({ center: $("center"), inspector: $("inspector"), inspectorSplit: $("inspector-split"), bottom: $("bottom"), bottomSplit: $("bottom-split"),
  settings: layout, defaults: { inspectorWidth: 246, bottomPanelHeight: 246 }, save: (change) => Object.assign(layout, change) })();

// MARK: dialogs and menus on request (?show=)

const show = params.get("show");
if (show === "about") run("about");
if (show === "shortcuts") run("about.shortcuts");
if (show === "licenses") run("about.licenses");
if (show === "whatsNew") run("about.whatsNew");
if (show === "updates") {
  // A stand-in release, so that the desktop's Update and restart can be seen in the browser.
  const release = { tag_name: "v9.0.0", html_url: "https://github.com/owner/gallery/releases/tag/v9.0.0", name: "9.0.0",
    assets: [{ name: "Gallery-v9.0.0.dmg", browser_download_url: "https://github.com/owner/gallery/releases/download/v9.0.0/Gallery-v9.0.0.dmg", size: 1 }] };
  void showUpdateCheck(info, "owner/gallery", { platform: "darwin", request: (async () => new Response(JSON.stringify(release))) as unknown as typeof fetch,
    install: async () => ({ status: "failed", reason: "The download failed: GitHub answered 404." }) });
}
if (show === "save") void askToSave("lorenz-attractor.nfg");
if (show === "saveAll") void askToSaveAll(documents.filter((item) => item.dirty).concat(documents.slice(0, 2)), "documents");
if (show === "apply") void askToApply("Apply the recommended settings?", ["The step is too large."], [["Step", "50 µs", "5 µs"], ["Tolerance with a long name", "0.001", "0.0001"]]);
if (show === "pick") void askToPick({ title: "Choose files to restore", columns: ["Document", "Last change", "File"], rows: [{ id: "a", cells: ["notes.txt", "today 14:05", "/a/notes.txt"] }, { id: "b", cells: ["a very long document name.lfg", "yesterday 09:12", "/Users/me/Documents/a very long folder name/a very long document name.lfg"] }], multiple: true, ticked: ["a"], action: "Restore", placeholder: "Search" });
if (show === "context") showContextMenu(300, 200, [{ label: "Open", action() {} }, { label: "Rename…", key: "Return", action() {} }, { separator: true, label: "" }, { label: "Delete", action() {} }]);
if (show === "flyout") shapes.button.click();
if (show === "menu") (document.querySelector("#menubar .menu-title, #menubar [role=menuitem]") as HTMLElement | null)?.click();

// MARK: measured checks (galleryChecks() in the console)

/** The problems the page can measure: content cut off or spilling out, and parts that should be centred but are not. */
function galleryChecks(): string[] {
  const problems: string[] = [];
  const name = (element: Element) => `${element.tagName.toLowerCase()}${element.id ? `#${element.id}` : ""}${element.className && typeof element.className === "string" ? `.${element.className.trim().split(/\s+/).join(".")}` : ""}`;
  // Elements that must never spill sideways: frame rows, buttons, menu items, inspector rows and dialog parts.
  for (const element of document.querySelectorAll<HTMLElement>("#toolstrip, #doc-tabs, #statusbar, #bottom-tabs, #menubar, .panel-button, .menu-item, #inspector .row, #inspector label, .about .body, .find-tile, .find-row, .view-header, #empty-state")) {
    if (!element.offsetParent && getComputedStyle(element).position !== "fixed") continue;
    const style = getComputedStyle(element);
    const scrolls = /auto|scroll/.test(style.overflowX);
    if (!scrolls && element.scrollWidth > element.clientWidth + 1 && style.textOverflow !== "ellipsis") problems.push(`${name(element)} spills ${element.scrollWidth - element.clientWidth} px sideways.`);
    const box = element.getBoundingClientRect();
    if (box.right > innerWidth + 1) problems.push(`${name(element)} reaches ${Math.round(box.right - innerWidth)} px past the window.`);
  }
  // Parts wider than the pane that holds them, which a clipping ancestor would cut off.
  for (const element of document.querySelectorAll<HTMLElement>(".cm-editor, .find-tile, #empty-state, .view-header, .outline-list, .tree-row, .messages-list, .console-output")) {
    if (!element.offsetParent) continue;
    const box = element.getBoundingClientRect();
    for (let parent = element.parentElement; parent && parent !== document.body; parent = parent.parentElement) {
      if (getComputedStyle(parent).overflowX === "visible") continue;
      const frame = parent.getBoundingClientRect();
      if (box.right > frame.right + 1 || box.left < frame.left - 1) problems.push(`${name(element)} is cut off by ${name(parent)} (${Math.round(Math.max(box.right - frame.right, frame.left - box.left))} px).`);
      break;
    }
  }
  // Text inputs too narrow to show a word.
  for (const input of document.querySelectorAll<HTMLInputElement>("input[type=text], input:not([type])")) {
    if (input.offsetParent && input.clientWidth < 100) problems.push(`${name(input)} is ${input.clientWidth} px wide.`);
  }
  // Centred parts: the welcome screen's contents and every open dialog.
  const centred = (element: Element | null, within: DOMRect, label: string) => {
    if (!element || !(element as HTMLElement).offsetParent && getComputedStyle(element).position !== "fixed") return;
    const box = element.getBoundingClientRect();
    const dx = Math.abs(box.left + box.width / 2 - (within.left + within.width / 2));
    if (dx > 2) problems.push(`${label} is ${Math.round(dx)} px off centre.`);
  };
  const emptyState = document.getElementById("empty-state");
  if (emptyState && !emptyState.hidden) for (const part of emptyState.children) centred(part, emptyState.getBoundingClientRect(), `#empty-state .${(part as HTMLElement).className}`);
  for (const dialog of document.querySelectorAll(".modal-backdrop > *")) centred(dialog, new DOMRect(0, 0, innerWidth, innerHeight), name(dialog));
  const drop = document.querySelector<HTMLElement>(".file-drop:not([hidden])");
  if (drop) centred(drop.firstElementChild, drop.getBoundingClientRect(), ".file-drop-label");
  // Icons inside buttons centred in their button.
  for (const icon of document.querySelectorAll<SVGElement>(".tool svg, .find-icon svg, .new-tab svg, .doc-tab .close svg")) {
    const button = icon.closest("button");
    if (!button || !button.offsetParent) continue;
    const a = icon.getBoundingClientRect(), b = button.getBoundingClientRect();
    const dx = Math.abs(a.left + a.width / 2 - (b.left + b.width / 2)), dy = Math.abs(a.top + a.height / 2 - (b.top + b.height / 2));
    if (dx > 1 || dy > 1) problems.push(`${name(button)} icon is ${dx.toFixed(1)}, ${dy.toFixed(1)} px off centre.`);
  }
  return problems;
}
(window as unknown as { galleryChecks: typeof galleryChecks }).galleryChecks = galleryChecks;
