import assert from "node:assert/strict";
import test from "node:test";
import { saveDocument } from "../../source/app/file-save";

test("native save marks a document saved only after a successful write", async () => {
  const document = { name: "Example.xml", path: null as string | null, saved: false,
    markSaved(path: string | null) { this.path = path; this.saved = true; } };
  const reports: string[] = [];
  let written = "";
  const options = {
    document, as: false, extension: "nfg", mimeType: "application/json",
    stripExtension: (name: string) => name.replace(/\.(nfg|xml)$/i, ""),
    beforeSave: () => {}, prepare: () => {},
    serialize: () => ({ text: "payload", format: "nfg" as const }), nativeFormat: "nfg" as const,
    unsupportedMessage: "Unsupported format.",
    report: (message: string) => { reports.push(message); }, afterSave: () => {},
    desktop: {
      async saveDialog(name: string) { assert.equal(name, "Example.nfg"); return "/tmp/Example"; },
      async writeFile(path: string, text: string) { written = `${path}:${text}`; },
    },
  };
  assert.equal(await saveDocument(options), true);
  assert.equal(written, "/tmp/Example.nfg:payload");
  assert.equal(document.path, "/tmp/Example.nfg");
  assert.equal(document.saved, true);
  assert.deepEqual(reports, ["Saved Example.nfg."]);

  document.saved = false;
  options.desktop.writeFile = async () => { throw new Error("disk full"); };
  assert.equal(await saveDocument({ ...options, as: true }), false);
  assert.equal(document.saved, false);
  assert.deepEqual(reports.at(-1), "Couldn't save: disk full");
});

test("cancelled dialog and unsupported format keep a document unsaved", async () => {
  const document = { name: "Untitled 1", path: null as string | null, saved: false,
    markSaved() { this.saved = true; } };
  let format: "nfg" | "text" = "nfg";
  const reports: string[] = [];
  const options = {
    document, as: false, extension: "nfg", mimeType: "application/json",
    stripExtension: (name: string) => name,
    beforeSave: () => {}, prepare: () => {},
    serialize: () => ({ text: "payload", format }), nativeFormat: "nfg" as const,
    unsupportedMessage: "Unsupported format.",
    report: (message: string) => { reports.push(message); }, afterSave: () => {},
    desktop: { async saveDialog() { return null; }, async writeFile() { throw new Error("should not write"); } },
  };
  assert.equal(await saveDocument(options), false);
  assert.equal(document.saved, false);
  format = "text";
  assert.equal(await saveDocument(options), false);
  assert.equal(document.saved, false);
  assert.deepEqual(reports, ["Unsupported format."]);
});

test("saving an opened file asks for a dialog grant before writing", async () => {
  const document = { name: "Opened.nfg", path: "/tmp/Opened.nfg" as string | null,
    markSaved(path: string | null) { this.path = path; } };
  const writes: string[] = [];
  const saved = await saveDocument({
    document, as: false, extension: "nfg", mimeType: "application/json",
    stripExtension: (name) => name.replace(/\.nfg$/i, ""),
    beforeSave() {}, prepare() {}, serialize: () => ({ text: "payload", format: "nfg" as const }),
    nativeFormat: "nfg" as const, unsupportedMessage: "Unsupported format.", report() {}, afterSave() {},
    desktop: {
      async saveDialog(name) { assert.equal(name, "Opened.nfg"); return "/tmp/Approved.nfg"; },
      async writeFile(path) {
        writes.push(path);
        if (path === "/tmp/Opened.nfg") throw new Error("Save permission required. Choose a path in the save dialog.");
      },
    },
  });
  assert.equal(saved, true);
  assert.deepEqual(writes, ["/tmp/Opened.nfg", "/tmp/Approved.nfg"]);
  assert.equal(document.path, "/tmp/Approved.nfg");
});
