import assert from "node:assert/strict";
import { test } from "node:test";
import { wheelIntent } from "../../source/app/wheel";

let clock = 0;
/** A wheel event 1 s after the last, so that each one starts a gesture of its own. */
const wheel = (fields: Partial<{ deltaX: number; deltaY: number; deltaMode: number; wheelDeltaY: number; ctrlKey: boolean; metaKey: boolean; shiftKey: boolean }>) => {
  clock += 1000;
  return { deltaX: 0, deltaY: 0, deltaMode: 0, ctrlKey: false, metaKey: false, shiftKey: false, ...fields } as unknown as WheelEvent;
};
(globalThis as { performance: { now(): number } }).performance = { now: () => clock };
const factor = (event: WheelEvent) => { const intent = wheelIntent(event, false); assert.equal(intent.kind, "zoom"); return (intent as { factor: number }).factor; };

test("Ctrl or Cmd with a mouse wheel zooms one notch at a time, as the plain wheel does", () => {
  const plain = factor(wheel({ deltaY: 100, wheelDeltaY: -120 }));
  assert.ok(Math.abs(plain - 1 / 1.15) < 1e-9, "a plain notch zooms out by 1.15");
  assert.ok(Math.abs(factor(wheel({ deltaY: 100, wheelDeltaY: -120, ctrlKey: true })) - plain) < 1e-9, "Ctrl + notch: 1.15, not exp(−1) = 0.37");
  assert.ok(Math.abs(factor(wheel({ deltaY: -100, wheelDeltaY: 120, metaKey: true })) - 1.15) < 1e-9);
  assert.ok(Math.abs(factor(wheel({ deltaY: 3, deltaMode: 1, ctrlKey: true })) - 1 / 1.15) < 1e-9, "one line-mode notch (3 lines)");
});

test("a pinch zooms by its distance, in small steps", () => {
  // A trackpad pinch: Ctrl + small pixel deltas, the legacy delta exactly −3 × deltaY.
  assert.ok(Math.abs(factor(wheel({ deltaY: 2, wheelDeltaY: -6, ctrlKey: true })) - Math.exp(-0.02)) < 1e-9);
  assert.ok(Math.abs(factor(wheel({ deltaY: -1.5, ctrlKey: true })) - Math.exp(0.015)) < 1e-9);
});
