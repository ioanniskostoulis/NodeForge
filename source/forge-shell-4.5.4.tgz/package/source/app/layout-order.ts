// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The order of things every application shows the same way: tool strip groups and dialog buttons.

/** The tool strip's groups, left to right: history, clipboard, view, the application's tools, then search at the right. */
export const TOOL_GROUP_ORDER = ["history", "clipboard", "view", "app", "search"] as const;
export type ToolGroupKind = (typeof TOOL_GROUP_ORDER)[number];

/** Where a group of `kind` goes among groups already placed (`placed`, left to right): after every group that comes earlier. */
export function toolGroupIndex(placed: readonly ToolGroupKind[], kind: ToolGroupKind): number {
  const rank = TOOL_GROUP_ORDER.indexOf(kind);
  const after = placed.findIndex((other) => TOOL_GROUP_ORDER.indexOf(other) > rank);
  return after < 0 ? placed.length : after;
}

/** A dialog button: the primary action (Return), Cancel (Esc), a destructive choice such as Don't save, or another one. */
export interface DialogButton { label: string; role: "primary" | "cancel" | "destructive" | "other"; className?: string }

/**
 * The buttons of a dialog in the platform's order. macOS: the destructive choice at the left, a gap, then the others,
 * Cancel and the primary action at the right. Windows: right-aligned, the primary action first, then the destructive
 * choice, the others and Cancel last. `null` marks the gap.
 */
export function dialogButtonOrder(buttons: readonly DialogButton[], mac: boolean): (DialogButton | null)[] {
  const of = (role: DialogButton["role"]) => buttons.filter((button) => button.role === role);
  if (mac) {
    const destructive = of("destructive");
    return [...destructive, null, ...of("other"), ...of("cancel"), ...of("primary")];
  }
  return [null, ...of("primary"), ...of("destructive"), ...of("other"), ...of("cancel")];
}

const isMac = typeof navigator !== "undefined" && /Mac/.test(navigator.platform);

/** The action row of a dialog: its buttons in the platform's order (`dialogButtonOrder`), with the gap as a spacer. */
export function dialogActions(buttons: readonly DialogButton[], mac = isMac): HTMLElement {
  const row = document.createElement("div");
  row.className = "actions";
  for (const button of dialogButtonOrder(buttons, mac)) {
    if (!button) { row.append(Object.assign(document.createElement("span"), { className: "spacer" })); continue; }
    const element = document.createElement("button");
    element.className = `panel-button${button.role === "primary" ? " primary" : ""}${button.className ? ` ${button.className}` : ""}`;
    element.textContent = button.label;
    row.append(element);
  }
  return row;
}
