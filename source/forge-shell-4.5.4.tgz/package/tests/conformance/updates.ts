import assert from "node:assert/strict";
import test from "node:test";
import { helpMenu } from "../../source/app/about";
import { UPDATE_CHECK_INTERVAL_MS, checkForUpdate, compareVersions, isRepository, parseVersion, updateCheckDue, updateMessage } from "../../source/app/updates";

const answer = (status: number, body: unknown) => (async () => new Response(JSON.stringify(body), { status })) as unknown as typeof fetch;

test("versions and tags compare by their numbers", () => {
  assert.deepEqual(parseVersion("v3.10.2"), [3, 10, 2]);
  assert.equal(parseVersion("3.1"), null);
  assert.ok(compareVersions("v3.10.0", "3.9.9")! > 0);
  assert.equal(compareVersions("3.0.0", "v3.0.0"), 0);
  assert.ok(compareVersions("2.9.9", "3.0.0")! < 0);
  assert.equal(compareVersions("latest", "3.0.0"), null);
  assert.ok(isRepository("owner/name.app"));
  assert.ok(!isRepository("https://github.com/owner/name"));
});

test("a newer release is reported with its page; the same or an older one is current", async () => {
  const release = { tag_name: "v3.1.0", html_url: "https://github.com/owner/app/releases/tag/v3.1.0", name: "3.1.0" };
  const newer = await checkForUpdate("owner/app", "3.0.0", answer(200, release));
  assert.deepEqual(newer, { status: "available", release: { version: "3.1.0", url: release.html_url, name: "3.1.0", assets: [] } });
  assert.equal(updateMessage(newer, "Example"), "Example 3.1.0 is available.");
  const current = await checkForUpdate("owner/app", "3.1.0", answer(200, release));
  assert.equal(current.status, "current");
  assert.equal(updateMessage(current, "Example"), "Example is up to date.");
  assert.equal((await checkForUpdate("owner/app", "4.0.0", answer(200, release))).status, "current");
});

test("a private repository, a failed request or a strange answer is unavailable, never an error", async () => {
  assert.deepEqual(await checkForUpdate("owner/app", "3.0.0", answer(404, {})), { status: "unavailable", reason: "No public release was found." });
  assert.equal((await checkForUpdate("owner/app", "3.0.0", answer(500, {}))).status, "unavailable");
  const offline = (async () => { throw new TypeError("offline"); }) as unknown as typeof fetch;
  assert.deepEqual(await checkForUpdate("owner/app", "3.0.0", offline), { status: "unavailable", reason: "Updates could not be checked. Check the internet connection." });
  assert.equal((await checkForUpdate("owner/app", "3.0.0", answer(200, { tag_name: "nightly", html_url: "https://github.com/x" }))).status, "unavailable");
  assert.equal((await checkForUpdate("owner/app", "3.0.0", answer(200, { tag_name: "v9.0.0", html_url: "https://example.com/x" }))).status, "unavailable");
  assert.equal((await checkForUpdate("", "3.0.0", answer(200, {}))).status, "unavailable");
});

test("the automatic check runs at most once a day", () => {
  const map = new Map<string, string>();
  const storage = { getItem: (key: string) => map.get(key) ?? null, setItem: (key: string, value: string) => void map.set(key, value) };
  assert.equal(updateCheckDue("app.updates", storage, 1_000), true);
  assert.equal(updateCheckDue("app.updates", storage, 1_000 + UPDATE_CHECK_INTERVAL_MS - 1), false);
  assert.equal(updateCheckDue("app.updates", storage, 1_000 + UPDATE_CHECK_INTERVAL_MS), true);
});

test("updates are offered on the welcome screen, not in Help or the Terminal", async () => {
  for (const updates of [true, false]) assert.deepEqual(helpMenu("Example", true, updates).submenu!.map((item) => item.separator ? "-" : item.id), ["about.whatsNew", "-", "about.shortcuts", "-", "about.licenses"]);
  const { SHARED_COMMANDS } = await import("../../source/app/shared-commands");
  assert.ok(!SHARED_COMMANDS.some((command) => command.name === "updates"), "no updates command");
});

test("only this repository's release files are kept, with GitHub's SHA-256 digest when given", async () => {
  const sha = "a".repeat(64);
  const result = await checkForUpdate("owner/app", "3.0.0", answer(200, { tag_name: "v3.1.0", html_url: "https://github.com/owner/app/releases/tag/v3.1.0", assets: [
    { name: "App-v3.1.0.dmg", browser_download_url: "https://github.com/owner/app/releases/download/v3.1.0/App-v3.1.0.dmg", size: 5, digest: `sha256:${sha}` },
    { name: "App-v3.1.0.exe", browser_download_url: "https://example.com/App-v3.1.0.exe", size: 5 },
    { name: "notes.txt", browser_download_url: "https://github.com/other/app/releases/download/v3.1.0/notes.txt", size: 1 },
  ] }));
  assert.equal(result.status, "available");
  if (result.status === "available") assert.deepEqual(result.release.assets, [{ name: "App-v3.1.0.dmg", url: "https://github.com/owner/app/releases/download/v3.1.0/App-v3.1.0.dmg", size: 5, sha256: sha }]);
});

test("Update and restart asks the app to deal with unsaved work first, and a cancel installs nothing", async () => {
  const { runInstall } = await import("../../source/app/updates");
  let click: (() => Promise<void>) | null = null;
  const button = { disabled: false, addEventListener: (_name: string, listener: () => Promise<void>) => { click = listener; } } as unknown as HTMLButtonElement;
  const status = { textContent: "", classList: { add() {}, remove() {} } } as unknown as HTMLElement;
  let installed = 0;
  runInstall({ prepare: async () => false, install: async () => { installed++; return { status: "restarting" }; } },
    { name: "Example-v3.1.0.dmg", url: "https://github.com/owner/app/releases/download/v3.1.0/Example-v3.1.0.dmg", size: 10, sha256: null }, button, status, "");
  await click!();
  assert.equal(installed, 0);
  assert.equal(button.disabled, false);
  assert.equal(status.textContent, "Update cancelled. Your documents are still open.");
});
