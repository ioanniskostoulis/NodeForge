// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { createHash } from "node:crypto";

/** Cache downloads by dependency records, independent of the app's own patch version. */
export function cacheKeyValues(lockfile) {
  const packages = lockfile.packages;
  const dependencyLock = Object.fromEntries(Object.entries(packages)
    .filter(([path]) => path !== "")
    .map(([path, entry]) => [path, { version: entry.version, integrity: entry.integrity, resolved: entry.resolved }]));
  const dependencies = createHash("sha256").update(JSON.stringify(dependencyLock)).digest("hex").slice(0, 20);
  const electron = packages["node_modules/electron"]?.version;
  const builder = packages["node_modules/electron-builder"]?.version;
  if (!electron || !builder) throw new Error("Electron and electron-builder must be in package-lock.json");
  return { dependencies, electron: `${electron}-builder-${builder}` };
}
