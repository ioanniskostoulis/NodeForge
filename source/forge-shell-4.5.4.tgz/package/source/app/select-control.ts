// Licensed under the GNU General Public License v2 or later. See LICENSE.
// A select with the shell's drawn menu surface, shared by settings and generator fields.

export interface SelectChoice { value: string; label: string; separator?: boolean }

export interface SelectControlOptions {
  choices: readonly SelectChoice[];
  value: string;
  label: string;
  className?: string;
  disabled?: boolean;
  title?: string;
  overlay?: HTMLElement;
  doc?: Document;
  onChange(value: string): void;
}

let nextId = 0;

/** Draw a select field whose options use the shell menu instead of the browser or operating-system popup. */
export function createSelectControl(options: SelectControlOptions): HTMLButtonElement {
  const doc = options.doc ?? document;
  const button = doc.createElement("button");
  button.type = "button";
  button.className = options.className ?? "select-control";
  button.disabled = !!options.disabled;
  button.setAttribute("aria-label", options.label);
  button.setAttribute("aria-haspopup", "listbox");
  button.setAttribute("aria-expanded", "false");
  if (options.title) button.title = options.title;
  const id = `select-popup-${++nextId}`;
  button.setAttribute("aria-controls", id);

  let value = options.value;
  let popup: HTMLElement | null = null;
  let items: HTMLButtonElement[] = [];

  const selectedLabel = () => options.choices.find((choice) => !choice.separator && choice.value === value)?.label ?? value;
  const renderValue = () => {
    button.replaceChildren();
    button.append(Object.assign(doc.createElement("span"), { className: "select-value", textContent: selectedLabel() }));
    button.append(Object.assign(doc.createElement("span"), { className: "select-chevron", "aria-hidden": "true" }));
  };
  const close = (refocus: boolean) => {
    popup?.remove();
    popup = null;
    items = [];
    button.setAttribute("aria-expanded", "false");
    doc.removeEventListener("pointerdown", outside, true);
    if (refocus) button.focus();
  };
  const outside = (event: Event) => { if (!popup?.contains(event.target as Node) && event.target !== button) close(false); };
  const choose = (choice: SelectChoice) => {
    value = choice.value;
    renderValue();
    close(true);
    options.onChange(value);
  };
  const open = (direction: -1 | 0 | 1 = 0) => {
    if (popup || button.disabled) return;
    popup = doc.createElement("div");
    popup.id = id;
    popup.className = "menu-popup context select-popup";
    popup.setAttribute("role", "listbox");
    popup.setAttribute("aria-label", options.label);
    items = [];
    for (const choice of options.choices) {
      if (choice.separator) {
        popup.append(Object.assign(doc.createElement("div"), { className: "menu-sep" }));
        continue;
      }
      const item = doc.createElement("button");
      item.type = "button";
      item.className = "menu-item";
      item.setAttribute("role", "option");
      item.setAttribute("aria-selected", String(choice.value === value));
      item.append(Object.assign(doc.createElement("span"), { className: "label", textContent: choice.label }));
      item.addEventListener("click", () => choose(choice));
      items.push(item);
      popup.append(item);
    }
    popup.addEventListener("keydown", (event) => {
      const at = items.indexOf(doc.activeElement as HTMLButtonElement);
      let next = at;
      if (event.key === "Escape") { event.preventDefault(); close(true); }
      else if (event.key === "ArrowDown") { event.preventDefault(); next = (at + 1 + items.length) % items.length; }
      else if (event.key === "ArrowUp") { event.preventDefault(); next = (at - 1 + items.length) % items.length; }
      else if (event.key === "Home") { event.preventDefault(); next = 0; }
      else if (event.key === "End") { event.preventDefault(); next = items.length - 1; }
      else if (event.key === "Tab") { close(true); return; }
      else return;
      items[next]?.focus();
    });
    const rect = button.getBoundingClientRect();
    (options.overlay ?? doc.getElementById("overlay-root") ?? doc.body).append(popup);
    const size = popup.getBoundingClientRect();
    popup.style.left = `${Math.max(4, Math.min(rect.left, window.innerWidth - size.width - 4))}px`;
    popup.style.top = `${rect.bottom + 2 + size.height > window.innerHeight - 4 ? Math.max(4, rect.top - 2 - size.height) : rect.bottom + 2}px`;
    button.setAttribute("aria-expanded", "true");
    doc.addEventListener("pointerdown", outside, true);
    const selected = Math.max(0, items.findIndex((item) => item.getAttribute("aria-selected") === "true"));
    items[(selected + direction + items.length) % items.length]?.focus();
  };

  renderValue();
  button.addEventListener("click", () => popup ? close(true) : open());
  button.addEventListener("keydown", (event) => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") { event.preventDefault(); open(event.key === "ArrowUp" ? -1 : 1); }
    else if (event.key === "Enter" || event.key === " ") { event.preventDefault(); open(); }
  });
  return button;
}
