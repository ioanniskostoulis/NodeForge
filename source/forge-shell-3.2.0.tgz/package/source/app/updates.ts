// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Checking for a newer release on GitHub: the latest published release of the application's repository is compared
// with the running version. The person is told; on the desktop, Update and restart installs it (desktop/updater.ts).
// The GitHub API answers without sign-in only for a public repository; a private one answers as unavailable.
import { escape, infoWindow, link, type InfoOptions } from "./about";
import type { StorageLike as SavingStorage } from "./saving";

/** A file published with a release: its download address, size in bytes and SHA-256 digest when GitHub gives one. */
export interface ReleaseAsset { name: string; url: string; size: number; sha256: string | null }

/** The newest release of a repository, as the update check reads it. */
export interface Release { version: string; url: string; name: string; assets: ReleaseAsset[] }

/** What installing an update did: the app restarts into it, or the downloaded installer was opened, or it failed. */
export type InstallResult = { status: "restarting" } | { status: "opened" } | { status: "failed"; reason: string };

/** The installer of a release for this platform, named as the family names them (`<Name>-v<version>.dmg` or `.exe`). */
export function updateAsset(release: Release, productName: string, platform: string): ReleaseAsset | null {
  const extension = platform === "darwin" ? "dmg" : platform === "win32" ? "exe" : null;
  return extension ? release.assets.find((asset) => asset.name === `${productName}-v${release.version}.${extension}`) ?? null : null;
}

export type UpdateResult =
  | { status: "available"; release: Release }
  | { status: "current"; release: Release }
  | { status: "unavailable"; reason: string };

/** Automatic checks run at most once in this period, in ms (one day). */
export const UPDATE_CHECK_INTERVAL_MS = 24 * 3600 * 1000;

/** The numeric parts of a version or tag (`v3.1.0` → [3, 1, 0]), or null when it is not one. */
export function parseVersion(text: string): number[] | null {
  const match = /^v?(\d+)\.(\d+)\.(\d+)$/.exec(text.trim());
  return match ? match.slice(1).map(Number) : null;
}

/** Negative when `a` is older than `b`, zero when equal, positive when newer; null when either is not a version. */
export function compareVersions(a: string, b: string): number | null {
  const first = parseVersion(a), second = parseVersion(b);
  if (!first || !second) return null;
  for (let index = 0; index < 3; index++) if (first[index] !== second[index]) return first[index] - second[index];
  return 0;
}

/** Whether a repository is named as `owner/name`. */
export function isRepository(text: unknown): text is string {
  return typeof text === "string" && /^[A-Za-z0-9-]+\/[A-Za-z0-9._-]+$/.test(text);
}

/** Read the latest release of `repository` (`owner/name`) and compare it with `version`. Never throws. */
export async function checkForUpdate(repository: string, version: string, request: typeof fetch = fetch): Promise<UpdateResult> {
  if (!isRepository(repository)) return { status: "unavailable", reason: "No release page is set for this app." };
  let response: Response;
  try {
    response = await request(`https://api.github.com/repos/${repository}/releases/latest`, { headers: { Accept: "application/vnd.github+json" } });
  } catch {
    return { status: "unavailable", reason: "Updates could not be checked. Check the internet connection." };
  }
  // A private repository, or one without published releases, answers 404 to a request without sign-in.
  if (response.status === 404) return { status: "unavailable", reason: "No public release was found." };
  if (!response.ok) return { status: "unavailable", reason: `Updates could not be checked: GitHub answered ${response.status}.` };
  try {
    const body = await response.json() as { tag_name?: unknown; html_url?: unknown; name?: unknown; assets?: unknown };
    const tag = String(body.tag_name ?? "");
    const order = compareVersions(tag, version);
    if (order === null || typeof body.html_url !== "string" || !body.html_url.startsWith("https://github.com/")) {
      return { status: "unavailable", reason: "The latest release has no version number." };
    }
    // Only files served from this repository's releases are kept.
    const prefix = `https://github.com/${repository}/releases/download/`;
    const assets = (Array.isArray(body.assets) ? body.assets : []).flatMap((item): ReleaseAsset[] => {
      const asset = item as { name?: unknown; browser_download_url?: unknown; size?: unknown; digest?: unknown };
      if (typeof asset.name !== "string" || typeof asset.browser_download_url !== "string" || !asset.browser_download_url.startsWith(prefix)) return [];
      const digest = typeof asset.digest === "string" && /^sha256:[0-9a-f]{64}$/.test(asset.digest) ? asset.digest.slice(7) : null;
      return [{ name: asset.name, url: asset.browser_download_url, size: Number(asset.size) || 0, sha256: digest }];
    });
    const release = { version: tag.replace(/^v/, ""), url: body.html_url, name: typeof body.name === "string" ? body.name : tag, assets };
    return order > 0 ? { status: "available", release } : { status: "current", release };
  } catch {
    return { status: "unavailable", reason: "The answer from GitHub could not be read." };
  }
}

/** The one-line result, as Messages and the status bar show it. */
export function updateMessage(result: UpdateResult, productName: string): string {
  if (result.status === "available") return `${productName} ${result.release.version} is available.`;
  if (result.status === "current") return `${productName} is up to date.`;
  return result.reason;
}

type StorageLike = Pick<SavingStorage, "getItem" | "setItem">;

/**
 * Whether the automatic check at launch is due: at most once a day, kept under `storageKey`. Records the check when
 * it is due.
 */
export function updateCheckDue(storageKey: string, storage: StorageLike = localStorage, now = Date.now()): boolean {
  let last: number | null = null;
  try { const stored = storage.getItem(storageKey); last = stored === null ? null : Number(stored); } catch { /* storage unavailable: check */ }
  // Never checked, an unreadable value or a time in the future (the clock was changed) all make the check due.
  if (last !== null && Number.isFinite(last) && last <= now && now - last < UPDATE_CHECK_INTERVAL_MS) return false;
  try { storage.setItem(storageKey, String(now)); } catch { /* storage unavailable */ }
  return true;
}

/**
 * Help › Check for updates…: checks now and shows the result. When a newer release has an installer for this
 * platform and `install` is given (the desktop bridge's `installUpdate`), **Update and restart** installs it;
 * otherwise, and when installing fails, the release page is offered.
 */
export async function showUpdateCheck(info: InfoOptions, repository: string, options: { platform?: string; install?(asset: ReleaseAsset): Promise<InstallResult>; request?: typeof fetch } = {}): Promise<UpdateResult> {
  infoWindow("check for updates", info, `<div class="block update-check"><p class="about-intro">Checking for updates…</p></div>`);
  const result = await checkForUpdate(repository, info.version, options.request ?? fetch);
  const body = document.querySelector<HTMLElement>(".modal-backdrop.info .update-check");
  if (!body) return result;
  if (result.status !== "available") { body.innerHTML = `<p class="about-intro">${escape(updateMessage(result, info.productName))}</p>`; return result; }
  const asset = options.install && options.platform ? updateAsset(result.release, info.productName, options.platform) : null;
  const page = `${link("Open the release page", result.release.url)}`;
  body.innerHTML = `<p class="about-intro">${escape(updateMessage(result, info.productName))} You have ${escape(info.version)}.</p>
    <p class="about-intro update-status">${asset ? `${page} to read what changed.` : `${page} to download it.`}</p>
    ${asset ? `<button class="panel-button primary update-install">Update and restart</button>` : ""}`;
  const button = body.querySelector<HTMLButtonElement>(".update-install");
  const status = body.querySelector<HTMLElement>(".update-status")!;
  button?.addEventListener("click", async () => {
    button.disabled = true;
    status.textContent = "Downloading the update…";
    const outcome = await options.install!(asset!).catch((error: unknown): InstallResult => ({ status: "failed", reason: error instanceof Error ? error.message : String(error) }));
    if (outcome.status === "restarting") status.textContent = "Installing. The app restarts when it is done.";
    else if (outcome.status === "opened") status.textContent = "The installer is open. Drag the app into Applications to finish.";
    else { status.innerHTML = `${escape(outcome.reason)} ${page} to download it.`; button.disabled = false; }
  });
  return result;
}
