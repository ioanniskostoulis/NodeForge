import assert from "node:assert/strict";
import { test } from "node:test";
import { baseNameEnd, validateName } from "../../source/app/rename";

test("names are validated with sentence messages", () => {
  assert.equal(validateName("  "), "Enter a name.");
  assert.equal(validateName("a/b"), "A name cannot contain / or \\.");
  assert.equal(validateName("a\\b"), "A name cannot contain / or \\.");
  assert.equal(validateName("Report", { taken: ["report"] }), "The name Report is already used.");
  assert.equal(validateName(" Report ", { taken: ["Notes"] }), null);
  assert.equal(validateName("a:b", { illegal: /:/ }), "A name cannot contain / or \\.");
});

test("only the base name of a file is selected", () => {
  assert.equal(baseNameEnd("main.tex"), 4);
  assert.equal(baseNameEnd("archive.tar.gz"), 11);
  assert.equal(baseNameEnd(".hidden"), 7);
  assert.equal(baseNameEnd("Untitled 1"), 10);
});

/** A node that is in the page until replaced; replacing it while it has the focus fires its blur, as a browser does. */
class FakeNode {
  isConnected = true;
  dataset: Record<string, string> = {};
  style = { setProperty() {}, removeProperty() {} };
  classList = { names: new Set<string>(), add: (...names: string[]) => names.forEach((n) => this.classList.names.add(n)), remove: (...names: string[]) => names.forEach((n) => this.classList.names.delete(n)), contains: (name: string) => this.classList.names.has(name) };
  parentElement: FakeNode | null = null;
  listeners = new Map<string, ((event: unknown) => void)[]>();
  value = "";
  focused = false;
  attributes: Record<string, string> = {};
  setAttribute(name: string, value: string) { this.attributes[name] = value; }
  addEventListener(name: string, listener: (event: unknown) => void) { this.listeners.set(name, [...(this.listeners.get(name) ?? []), listener]); }
  emit(name: string, event: unknown = {}) { for (const listener of this.listeners.get(name) ?? []) listener(event); }
  focus() { this.focused = true; }
  setSelectionRange() {}
  getBoundingClientRect() { return { height: 14 }; }
  replaceWith(other: FakeNode) {
    if (!this.isConnected) throw new Error("NotFoundError: the node to be replaced is no longer a child of this node.");
    if (this.focused) { this.focused = false; this.emit("blur"); }
    if (!this.isConnected) throw new Error("NotFoundError: the node to be replaced is no longer a child of this node.");
    this.isConnected = false;
    other.isConnected = true;
  }
}

test("finishing a rename removes the field once: its blur does not finish it again from inside", async () => {
  const { startRename } = await import("../../source/app/rename");
  const previous = globalThis.document;
  const made: FakeNode[] = [];
  globalThis.document = { createElement: () => { const node = new FakeNode(); node.isConnected = false; made.push(node); return node; } } as unknown as Document;
  try {
    for (const key of ["Enter", "Escape"]) {
      const row = new FakeNode();
      row.classList.add("row");
      const value = new FakeNode();
      value.parentElement = row;
      let applied = "";
      startRename(value as unknown as HTMLElement, { current: () => "Untitled 1", apply: (name) => { applied = name; } });
      const field = made.at(-1)!;
      assert.ok(field.isConnected && field.focused, "the field replaces the value and has the focus");
      assert.ok(row.classList.contains("renaming") && row.classList.contains("field"), "the row lays out as a field while renaming");
      field.value = "Lens image";
      assert.doesNotThrow(() => field.emit("keydown", { key, preventDefault() {}, stopPropagation() {} }), `${key} finishes without NotFoundError`);
      assert.equal(value.isConnected, true, "the value is back");
      assert.ok(value.focused && value.classList.contains("renamed"), "the name has the focus, without a ring right after the rename");
      value.emit("keydown", { key: "Tab" });
      assert.ok(!value.classList.contains("renamed"), "the ring returns on the next key");
      assert.ok(!row.classList.contains("renaming") && !row.classList.contains("field"), "the row is a row again");
      assert.equal(applied, key === "Enter" ? "Lens image" : "", key === "Enter" ? "Return applies once" : "Escape applies nothing");
    }
  } finally {
    globalThis.document = previous;
  }
});
