// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Build __NAME__ into build/: the interface (build/app), the Electron main process and preload (build/desktop).
import { readFileSync } from "node:fs";
import { buildForgeApp } from "forge-shell/scripts/build";

const logo = readFileSync("assets/logo.txt", "utf8");
await buildForgeApp({
  targets: [
    { entryPoints: ["source/app/main.ts"], outfile: "build/app/app.js", platform: "browser", format: "esm", define: { __APP_LOGO__: JSON.stringify(logo) } },
    { entryPoints: ["source/desktop/main.ts"], outfile: "build/desktop/main.cjs", platform: "node", format: "cjs", external: ["electron"] },
    { entryPoints: ["source/desktop/preload.ts"], outfile: "build/desktop/preload.cjs", platform: "node", format: "cjs", external: ["electron"] },
  ],
  staticFiles: [["assets/logo.txt", "logo.txt"], ["LICENSE", "LICENSE"], ["NOTICE.md", "NOTICE.md"], ["CHANGELOG.md", "CHANGELOG.md"]],
  releaseDirs: ["source", "public", "assets", "scripts", "documentation"],
  releaseCopies: [{ from: "node_modules/forge-shell", to: "vendor/forge-shell" }],
  releaseFiles: ["LICENSE", "NOTICE.md", "README.md", "CHANGELOG.md", "VERSION", "forge.config.json", "package.json", "package-lock.json", "tsconfig.json"],
  watch: process.argv.includes("--watch"),
});
