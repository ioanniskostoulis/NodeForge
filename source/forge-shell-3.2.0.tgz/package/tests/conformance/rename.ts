import assert from "node:assert/strict";
import { test } from "node:test";
import { baseNameEnd, validateName } from "../../source/app/rename";

test("names are validated with sentence messages", () => {
  assert.equal(validateName("  "), "Enter a name.");
  assert.equal(validateName("a/b"), "A name cannot contain / or \\.");
  assert.equal(validateName("a\\b"), "A name cannot contain / or \\.");
  assert.equal(validateName("Report", { taken: ["report"] }), "The name Report is already used.");
  assert.equal(validateName(" Report ", { taken: ["Notes"] }), null);
  assert.equal(validateName("a:b", { illegal: /:/ }), "A name cannot contain / or \\.");
});

test("only the base name of a file is selected", () => {
  assert.equal(baseNameEnd("main.tex"), 4);
  assert.equal(baseNameEnd("archive.tar.gz"), 11);
  assert.equal(baseNameEnd(".hidden"), 7);
  assert.equal(baseNameEnd("Untitled 1"), 10);
});
