# __NAME__

__NAME__: __PURPOSE__, for macOS and Windows, built on the shared Forge shell.

## Commands

| Command | Purpose |
|---|---|
| `npm install` | Installs the dependencies and the version hook |
| `npm run web` | Serves the browser preview on `http://127.0.0.1:__PORT__/` |
| `npm start` | Builds and runs the desktop application |
| `npm run check`, `npm test`, `npm run test:app`, `npm run test:shell` | The checks of every Forge application |
| `npm run dist` | Packages the macOS disk image; on Windows, the setup |

Documents are saved as `.__EXT__` files.
