// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { showContextMenu, type MenuEntry } from "./context-menu";
import { startRename } from "./rename";
import { setTip } from "./tips";
import { UI_ICONS, toolIcon } from "./tool-icons";

/** A file or folder of a project. `kind` picks the icon; the shell knows folder, text, pdf, image, spreadsheet and other. */
export type TreeFile = { path: string; kind: string; size?: number; hidden?: true };
export type TreeNode = { name: string; path: string; kind: string; hidden: boolean; children: TreeNode[] };

const byName = (a: { name: string }, b: { name: string }) => a.name.localeCompare(b.name, undefined, { sensitivity: "base", numeric: true });

/** Every file as a folder tree, folders before files, each level sorted by name. Hidden entries are dropped unless `showHidden`. */
export function buildTree(files: readonly TreeFile[], showHidden: boolean): TreeNode[] {
  const root: TreeNode = { name: "", path: "", kind: "folder", hidden: false, children: [] };
  const folders = new Map<string, TreeNode>([["", root]]);
  const folder = (path: string): TreeNode => {
    const existing = folders.get(path);
    if (existing) return existing;
    const slash = path.lastIndexOf("/");
    const node: TreeNode = { name: path.slice(slash + 1), path, kind: "folder", hidden: false, children: [] };
    folder(slash < 0 ? "" : path.slice(0, slash)).children.push(node);
    folders.set(path, node);
    return node;
  };
  for (const file of files) {
    if (file.hidden && !showHidden) continue;
    if (file.kind === "folder") { folder(file.path).hidden = !!file.hidden; continue; }
    const slash = file.path.lastIndexOf("/");
    folder(slash < 0 ? "" : file.path.slice(0, slash)).children.push({ name: file.path.slice(slash + 1), path: file.path, kind: file.kind, hidden: !!file.hidden, children: [] });
  }
  const sort = (node: TreeNode): void => {
    // Visible entries first, then hidden ones; folders before files, each in name order.
    node.children.sort((a, b) => Number(a.hidden) - Number(b.hidden) || (a.kind === "folder" ? 0 : 1) - (b.kind === "folder" ? 0 : 1) || byName(a, b));
    node.children.forEach(sort);
  };
  sort(root);
  return root.children;
}

/** Keep only the items whose folder is not also in the list, so a folder moved or removed with its contents counts once. */
export function topLevel(paths: readonly string[]): string[] {
  return paths.filter((path) => !paths.some((other) => other !== path && path.startsWith(`${other}/`)));
}

/** The path a rename field produces: a bare name stays in the file's folder, a name with a slash is a path from the project root. `null` when nothing changes. */
export function renameTarget(from: string, typed: string): string | null {
  const name = typed.trim().replace(/^\/+|\/+$/g, "");
  if (!name) return null;
  const slash = from.lastIndexOf("/");
  const target = name.includes("/") || slash < 0 ? name : `${from.slice(0, slash)}/${name}`;
  return target === from ? null : target;
}

/** Why renaming `from` to `target` is refused, or `null`. `reserved` adds an app rule. Names are compared without regard to case. */
export function renameProblem(from: string, target: string | null, files: readonly TreeFile[], reserved?: (target: string) => string | null): string | null {
  if (!target) return null;
  if (target.split("/").some((part) => !part || part === "." || part === "..") || target.includes("\\")) return "A name cannot be . or .., or contain \\.";
  const own = reserved?.(target);
  if (own) return own;
  return files.some((file) => file.path !== from && file.path.toLowerCase() === target.toLowerCase()) ? `The name ${target} is already used.` : null;
}

export interface MoveRules {
  /** Why `from` cannot be moved at all, or `null`. */
  blocked?(from: string): string | null;
  /** An app rule for a move to `folder`; return the reason it is refused, or `null`. */
  refuse?(from: string, folder: string): string | null;
  reserved?(target: string): string | null;
}

/** The path a dragged item takes when dropped on `folder` ("" is the root), or the reason it cannot move there. `null` when it would not move. */
export function moveTarget(from: string, folder: string, files: readonly TreeFile[], rules: MoveRules = {}): { target: string } | { problem: string } | null {
  const name = from.slice(from.lastIndexOf("/") + 1);
  const target = folder ? `${folder}/${name}` : name;
  if (target === from) return null;
  if (folder === from || folder.startsWith(`${from}/`)) return { problem: `${from} cannot move into itself.` };
  const blocked = rules.blocked?.(from) ?? rules.refuse?.(from, folder);
  if (blocked) return { problem: blocked };
  const problem = renameProblem(from, target, files, rules.reserved);
  return problem ? { problem } : { target };
}

export const FILE_ICONS: Record<string, string> = {
  folder: toolIcon('<path d="M2.5 4.5a1 1 0 0 1 1-1h3l1.5 1.5h4.5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1z"/>'),
  text: toolIcon('<path d="M4 2.5h5l3 3v8H4z"/><path d="M9 2.5v3h3M6 8.5h4M6 11h3"/>'),
  code: toolIcon('<path d="M4 2.5h5l3 3v8H4z"/><path d="M9 2.5v3h3M7 8 5.8 9.5 7 11M9 8l1.2 1.5L9 11"/>'),
  data: toolIcon('<path d="M4 2.5h5l3 3v8H4z"/><path d="M9 2.5v3h3M6 8h4M6 10h4M6 12h4M8 8v4"/>'),
  pdf: toolIcon('<path d="M4 2.5h5l3 3v8H4z"/><path d="M9 2.5v3h3M6 9.5h4"/>'),
  image: toolIcon('<rect x="2.5" y="3.5" width="11" height="9" rx="1"/><circle cx="6" cy="6.5" r="1"/><path d="m3 11.5 3.5-3 2.5 2 1.5-1 2.5 2"/>'),
  spreadsheet: toolIcon('<rect x="2.5" y="3" width="11" height="10" rx="1"/><path d="M2.5 6.5h11M2.5 9.5h11M6.5 3v10"/>'),
  archive: toolIcon('<rect x="3" y="2.5" width="10" height="11" rx="1"/><path d="M8 2.5v1.5M8 5v1.5M8 7.5V9M7 10h2v1.8H7z"/>'),
  audio: toolIcon('<path d="M6 11.5V4l6-1.5v7.5"/><circle cx="4.5" cy="11.5" r="1.5"/><circle cx="10.5" cy="10" r="1.5"/>'),
  video: toolIcon('<rect x="2.5" y="4" width="8" height="8" rx="1"/><path d="m10.5 7 3-2v6l-3-2"/>'),
  other: toolIcon('<path d="M4 2.5h5l3 3v8H4z"/><path d="M9 2.5v3h3"/>'),
};

// The kind of a file from its extension, for an application that has no kinds of its own.
const KINDS: Record<string, readonly string[]> = {
  text: ["txt", "md", "markdown", "rst", "log", "tex", "bib", "cls", "sty"],
  code: ["js", "mjs", "cjs", "ts", "tsx", "jsx", "py", "c", "h", "cpp", "hpp", "rs", "go", "java", "m", "jl", "r", "sh", "html", "css", "xml", "yml", "yaml", "toml", "ini", "cir", "sp", "spice", "net"],
  data: ["csv", "tsv", "json", "dat", "mat", "npy", "parquet", "h5", "hdf5"],
  pdf: ["pdf"],
  image: ["png", "jpg", "jpeg", "gif", "webp", "svg", "bmp", "tif", "tiff", "heic", "eps"],
  spreadsheet: ["xlsx", "xls", "xlsm", "ods", "numbers"],
  archive: ["zip", "gz", "tgz", "bz2", "xz", "7z", "rar", "tar"],
  audio: ["wav", "mp3", "flac", "aac", "m4a", "ogg", "aiff"],
  video: ["mp4", "mov", "m4v", "webm", "avi", "mkv"],
};

/** The kind of a file, from its extension (`fileKind("data/run.csv")` is `data`); `other` when unknown. */
export function fileKind(path: string): string {
  const name = path.slice(path.lastIndexOf("/") + 1);
  const dot = name.lastIndexOf(".");
  const extension = dot > 0 ? name.slice(dot + 1).toLowerCase() : "";
  return Object.entries(KINDS).find(([, extensions]) => extensions.includes(extension))?.[0] ?? "other";
}


export interface TreeBadge { icon: string; label: string }
/** A file's status: one of the shared ones, or a badge of the app's own. */
export type TreeStatus = keyof typeof TREE_STATUS | TreeBadge;

/** The shared file statuses, with the icons and tooltips every app uses for them. */
export const TREE_STATUS = {
  editable: { icon: UI_ICONS.edit, label: "Editable file." },
  readOnly: { icon: UI_ICONS.readOnly, label: "Read-only file." },
} as const satisfies Record<string, TreeBadge>;

/** The badges of a file row: its status first, when the app gives statuses, then the app's other badges. */
export function treeBadges(host: Pick<FileTreeHost, "status" | "badges">, file: TreeFile | undefined): TreeBadge[] {
  if (!file || file.kind === "folder") return [];
  const status = host.status?.(file);
  return [...(status ? [typeof status === "string" ? TREE_STATUS[status] : status] : []), ...(host.badges?.(file) ?? [])];
}

/** Icons for the row actions an app adds (`FileTreeHost.rowActions`), from the shared set. */
export const TREE_ACTION_ICONS: Record<string, string> = {
  show: UI_ICONS.show, hide: UI_ICONS.hide, lock: UI_ICONS.lock, unlock: UI_ICONS.unlock, select: UI_ICONS.checkCircle, pin: UI_ICONS.pin,
};
const lockIcon = TREE_ACTION_ICONS.lock;
const chevronIcon = UI_ICONS.chevronRight;

// MARK: standard commands

const isMac = typeof navigator !== "undefined" && /Mac/.test(navigator.platform);

/** The tree's standard commands. Keys are Electron accelerators, shown in the context menu with the platform glyphs. */
export type TreeCommand = "open" | "newFile" | "newFolder" | "rename" | "delete" | "duplicate" | "cut" | "copy" | "paste" | "copyPath" | "reveal" | "selectAll";

/** The label and key of each command on macOS or Windows, as Finder and File Explorer name and bind them. */
export function treeCommands(mac = isMac): Record<TreeCommand, { label: string; key?: string }> {
  return {
    open: { label: "Open", key: mac ? "CmdOrCtrl+O" : "Enter" },
    newFile: { label: "New file" },
    // No key: Shift+Cmd+N and Ctrl+Shift+N are the shell's New window (`UNIVERSAL_SHORTCUTS.newWindow`).
    newFolder: { label: "New folder" },
    rename: { label: "Rename…", key: mac ? "Enter" : "F2" },
    delete: { label: "Delete", key: mac ? "CmdOrCtrl+Backspace" : "Delete" },
    duplicate: { label: "Duplicate", ...(mac ? { key: "CmdOrCtrl+D" } : {}) },
    cut: { label: "Cut", key: "CmdOrCtrl+X" },
    copy: { label: "Copy", key: "CmdOrCtrl+C" },
    paste: { label: "Paste", key: "CmdOrCtrl+V" },
    copyPath: { label: "Copy path", key: mac ? "CmdOrCtrl+Alt+C" : "CmdOrCtrl+Shift+C" },
    reveal: { label: mac ? "Show in Finder" : "Show in File Explorer" },
    selectAll: { label: "Select all", key: "CmdOrCtrl+A" },
  };
}

/** The keys of a key press, as the tree reads them. */
export interface TreeKey { key: string; code?: string; metaKey: boolean; ctrlKey: boolean; altKey: boolean; shiftKey: boolean }

/** The standard command a key press asks for in the tree, or `null`. F2 renames and Cmd+Down opens on macOS too. */
export function treeKeyCommand(event: TreeKey, mac = isMac): TreeCommand | null {
  const cmd = mac ? event.metaKey : event.ctrlKey;
  const plain = !event.metaKey && !event.ctrlKey && !event.altKey && !event.shiftKey;
  const key = event.key.length === 1 ? event.key.toLowerCase() : event.key;
  if (cmd && !event.altKey && !event.shiftKey) {
    const byLetter: Record<string, TreeCommand> = { a: "selectAll", x: "cut", c: "copy", v: "paste", ...(mac ? { o: "open", d: "duplicate", ArrowDown: "open", Backspace: "delete" } : {}) };
    return byLetter[key] ?? null;
  }
  if (cmd && event.shiftKey && !event.altKey) return !mac && key === "c" ? "copyPath" : null;
  // Option changes the character (Option+C types ç), so the physical key is read.
  if (cmd && event.altKey && !event.shiftKey && mac && (key === "c" || event.code === "KeyC")) return "copyPath";
  if (!plain) return null;
  if (key === "F2") return "rename";
  if (key === "Enter") return mac ? "rename" : "open";
  if (key === "Delete") return "delete";
  return null;
}

/**
 * The path a copy of `from` takes in `folder` ("" is the root), as the platform names copies: "notes copy.txt",
 * "notes copy 2.txt" on macOS; "notes - Copy.txt", "notes - Copy (2).txt" on Windows. A folder has no extension.
 */
export function copyTarget(from: string, folder: string, files: readonly TreeFile[], mac = isMac): string {
  const name = from.slice(from.lastIndexOf("/") + 1);
  const dot = isFolder(from, files) ? -1 : name.lastIndexOf(".");
  const [stem, extension] = dot > 0 ? [name.slice(0, dot), name.slice(dot)] : [name, ""];
  const at = (candidate: string) => (folder ? `${folder}/${candidate}` : candidate);
  if (!taken(at(name), files)) return at(name);
  for (let count = 1; ; count++) {
    const suffix = mac ? (count === 1 ? " copy" : ` copy ${count}`) : (count === 1 ? " - Copy" : ` - Copy (${count})`);
    const candidate = at(`${stem}${suffix}${extension}`);
    if (!taken(candidate, files)) return candidate;
  }
}

/** A free name for a new entry in `folder`: `untitled.txt`, then `untitled 2.txt`, and so on. */
export function newEntryName(name: string, folder: string, files: readonly TreeFile[]): string {
  const dot = name.lastIndexOf(".");
  const [stem, extension] = dot > 0 ? [name.slice(0, dot), name.slice(dot)] : [name, ""];
  const at = (candidate: string) => (folder ? `${folder}/${candidate}` : candidate);
  for (let count = 1; ; count++) {
    const candidate = at(count === 1 ? name : `${stem} ${count}${extension}`);
    if (!taken(candidate, files)) return candidate;
  }
}

/** Is a path in use, ignoring case: listed, or a folder that holds a listed file? */
const taken = (path: string, files: readonly TreeFile[]): boolean => {
  const lower = path.toLowerCase();
  return files.some((file) => { const other = file.path.toLowerCase(); return other === lower || other.startsWith(`${lower}/`); });
};

/** Is `path` a folder: listed as one, or holding a listed file (a folder the application does not list on its own)? */
export function isFolder(path: string, files: readonly TreeFile[]): boolean {
  return files.some((file) => (file.path === path && file.kind === "folder") || file.path.startsWith(`${path}/`));
}

/** The entry of `path`: the listed one, or a folder made for a path that only holds listed files; undefined otherwise. */
export function entryOf(path: string, files: readonly TreeFile[]): TreeFile | undefined {
  return files.find((file) => file.path === path) ?? (path && isFolder(path, files) ? { path, kind: "folder" } : undefined);
}

/** The folder an item of the tree belongs to: a folder is its own, a file is in its parent ("" is the root). */
export function folderOf(path: string, files: readonly TreeFile[]): string {
  if (!path || isFolder(path, files)) return path;
  const slash = path.lastIndexOf("/");
  return slash < 0 ? "" : path.slice(0, slash);
}

/** `path` is the row with focus; `paths` is every selected row (just `path` when absent); `anchor` is where a Shift range starts. */
export interface FileSelection { path: string | null; paths?: string[]; anchor?: string | null }

/** An icon button an app adds at the end of a row, such as hide, lock or select. */
export interface TreeRowAction {
  /** The icon markup, such as `TREE_ACTION_ICONS.hide`. */
  icon: string;
  /** The action name for the tooltip and the accessible name, such as `Hide`. */
  label: string;
  /** On (shown in the accent and always visible) or off (shown while the row is hovered or selected). */
  pressed?: boolean;
  action(): void;
}

/** What a context menu was opened on: one file or folder, several rows, or the empty tree (`file` null, `paths` empty). */
export interface TreeMenuTarget { file: TreeFile | null; paths: string[] }

export interface FileTreeHost {
  /** False on the welcome screen: the tree renders but does nothing. */
  enabled: boolean;
  /** Overrides of the platform wording of Show in Finder or Show in File Explorer, and of Delete. */
  revealLabel?: string;
  trashLabel?: string;
  showHidden: boolean;
  /** The selected rows, kept across redraws. */
  selection: FileSelection;
  /** Folder paths the user collapsed; kept for the session. */
  collapsed: Set<string>;
  /** Accessible name of the tree. */
  label: string;
  /** Name of the drag data type, unique to the app. */
  dragType: string;
  open(file: TreeFile): void;
  reveal(path: string): void;
  /** Delete a file or folder (an app may move it to the system Trash or Recycle Bin). */
  trash(path: string): void;
  add(folder: string): void;
  drop(folder: string, files: File[]): void;
  rename(from: string, to: string): void;
  /** A message for the user's action (a warning in Messages). */
  warn(text: string): void;
  /** A rejected input (an error in Messages and the status bar). */
  problem(text: string): void;
  rerender(): void;
  /** Create a file or folder in `folder` and return its path; the tree then starts renaming it. Absent: no New file or New folder. */
  newFile?(folder: string): Promise<string | void> | string | void;
  newFolder?(folder: string): Promise<string | void> | string | void;
  /** Copy `from` to the free path `to` (Copy and Paste, Duplicate). Absent: no Copy, Paste or Duplicate of files. */
  copy?(from: string, to: string): void;
  /** The text Copy path puts on the clipboard for the selected paths; defaults to the project paths, one per line. */
  pathText?(paths: string[]): string;
  /** Why a path cannot be renamed or moved (shown as a lock), or `null`. */
  lockedReason?(path: string): string | null;
  /** Why a path cannot be removed, or `null`. */
  keepReason?(path: string): string | null;
  /** Extra context-menu entries for a file, shown after Open. */
  menu?(file: TreeFile): MenuEntry[];
  /** Extra context-menu entries for any target (file, folder, several rows or the empty tree), shown before Show in Finder. */
  contextMenu?(target: TreeMenuTarget): MenuEntry[];
  /** Icon buttons at the end of a row, such as hide, lock or select. */
  rowActions?(file: TreeFile): TreeRowAction[];
  /**
   * The status of every file: editable, read-only, or a status of the app's own. When given, each file row shows its
   * status, so that no file is left without one; folders have none.
   */
  status?(file: TreeFile): TreeStatus;
  /** Further badges after the status, each with its tooltip. */
  badges?(file: TreeFile): TreeBadge[];
  /** A short confirmation of an action, such as a copied path (information in the status bar). */
  notice?(text: string): void;
  /** Icons for extra kinds of file, added to `FILE_ICONS`. */
  icons?: Record<string, string>;
  /** A key the app handles for the selected paths before the tree does; return true when handled. */
  keyDown?(event: KeyboardEvent, paths: string[]): boolean;
  /** Double-click or Open on a file; defaults to `open`. */
  activate?(file: TreeFile): void;
  /** The folder a file dropped on the tree root goes to; defaults to the root. */
  dropFolder?(name: string): string;
  /** Rules for moving a dragged item, and a hook after it moved. */
  moveRules?: MoveRules;
  moved?(from: string, to: string): void;
  /** An app rule for names, such as a file that must stay at the root. */
  reserved?(target: string): string | null;
}

type PickMode = "one" | "toggle" | "range";
const pickMode = (event: MouseEvent | KeyboardEvent): PickMode => (event.shiftKey ? "range" : event.metaKey || event.ctrlKey ? "toggle" : "one");

/**
 * The listeners of each tree's own element and of the document, removed when that tree is drawn again: the element
 * is kept across redraws, so a listener added at every draw would otherwise run once per draw.
 */
const listeners = new WeakMap<HTMLElement, AbortController>();
/** The rows put on the tree's clipboard by Cut or Copy, kept across redraws. */
let clipboard: { mode: "cut" | "copy"; paths: string[] } | null = null;
/** A path the tree renames as soon as it is drawn (a new file or folder). */
let pendingRename: string | null = null;
const treeRows = (list: ParentNode): HTMLElement[] => [...list.querySelectorAll<HTMLElement>(".tree-row")];

function makeRow(name: string, node: { path: string; kind: string; hidden: boolean }, depth: number, host: FileTreeHost, file: TreeFile | undefined): HTMLElement {
  const row = document.createElement("div");
  row.className = node.hidden ? "tree-row hidden-file" : "tree-row";
  if (clipboard?.mode === "cut" && clipboard.paths.includes(node.path)) row.classList.add("cut");
  row.tabIndex = -1;
  row.style.setProperty("--depth", String(depth));
  row.setAttribute("role", "treeitem");
  row.setAttribute("aria-level", String(depth + 1));
  row.dataset.path = node.path;
  row.dataset.kind = node.kind;
  const icon = document.createElement("span"); icon.className = "tree-icon"; icon.innerHTML = host.icons?.[node.kind] ?? FILE_ICONS[node.kind] ?? FILE_ICONS.other;
  const label = document.createElement("span"); label.className = "tree-name"; label.textContent = name;
  row.append(icon, label);
  for (const action of (file && host.rowActions?.(file)) ?? []) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "tree-action" + (action.pressed ? " pressed" : "");
    button.innerHTML = action.icon;
    button.tabIndex = -1;
    button.setAttribute("aria-label", action.label);
    if (action.pressed !== undefined) button.setAttribute("aria-pressed", String(action.pressed));
    setTip(button, action.label);
    button.addEventListener("click", (event) => { event.stopPropagation(); if (host.enabled) action.action(); });
    button.addEventListener("dblclick", (event) => event.stopPropagation());
    row.append(button);
  }
  for (const badge of treeBadges(host, file)) {
    const element = document.createElement("span");
    element.className = "tree-badge";
    element.innerHTML = badge.icon;
    element.setAttribute("aria-label", badge.label);
    setTip(element, badge.label);
    row.append(element);
  }
  const locked = host.lockedReason?.(node.path);
  if (locked) {
    const badge = document.createElement("span"); badge.className = "tree-lock"; badge.innerHTML = lockIcon;
    setTip(badge, locked);
    row.classList.add("locked"); row.append(badge);
  } else if (!host.keepReason?.(node.path)) {
    row.draggable = true;
    row.addEventListener("dragstart", (event) => {
      if (!event.dataTransfer) return;
      const group = row.closest(".file-list")?.querySelectorAll<HTMLElement>(".tree-row.selected");
      const movable = (path: string) => !host.lockedReason?.(path) && !host.keepReason?.(path);
      const carried = row.classList.contains("selected") && group ? [...group].map((item) => item.dataset.path!).filter(movable) : [node.path];
      event.dataTransfer.setData(host.dragType, JSON.stringify(carried));
      event.dataTransfer.effectAllowed = "move";
    });
  }
  return row;
}

function acceptDrop(element: HTMLElement, folder: string, host: FileTreeHost, files: readonly TreeFile[], signal?: AbortSignal): void {
  const over = (event: DragEvent) => event.dataTransfer?.types.includes("Files") || event.dataTransfer?.types.includes(host.dragType);
  element.addEventListener("dragover", (event) => {
    if (!host.enabled || !over(event)) return;
    event.preventDefault(); event.stopPropagation();
    event.dataTransfer!.dropEffect = event.dataTransfer!.types.includes(host.dragType) ? "move" : "copy";
    if (folder) element.classList.add("drop-target");
  }, { signal });
  element.addEventListener("dragleave", () => element.classList.remove("drop-target"), { signal });
  element.addEventListener("drop", (event) => {
    element.classList.remove("drop-target");
    if (!host.enabled || !event.dataTransfer) return;
    const carried = event.dataTransfer.getData(host.dragType);
    if (carried) {
      event.preventDefault(); event.stopPropagation();
      let dragged: string[] = [];
      try { dragged = topLevel(JSON.parse(carried) as string[]); } catch { /* not ours */ }
      for (const from of dragged) {
        const move = moveTarget(from, folder, files, { ...host.moveRules, reserved: host.reserved });
        if (move && "problem" in move) host.problem(move.problem);
        else if (move) { host.moved?.(from, move.target); host.rename(from, move.target); }
      }
      return;
    }
    if (!event.dataTransfer.files.length) return;
    event.preventDefault(); event.stopPropagation();
    const dropped = [...event.dataTransfer.files];
    if (folder || !host.dropFolder) return host.drop(folder, dropped);
    // On the root, each file goes to the folder its type belongs in.
    for (const target of new Set(dropped.map((file) => host.dropFolder!(file.name)))) host.drop(target, dropped.filter((file) => host.dropFolder!(file.name) === target));
  }, { signal });
}

/** Draw the file tree into `list`. Call again to redraw; the previous document listener is replaced. */
export function renderFileTree(list: HTMLElement, files: readonly TreeFile[], host: FileTreeHost): void {
  list.replaceChildren();
  list.className = "file-list";
  list.setAttribute("role", "tree");
  list.setAttribute("aria-label", host.label);
  list.tabIndex = -1;
  const commands = treeCommands();
  const label = (command: TreeCommand) => (command === "reveal" ? host.revealLabel : command === "delete" ? host.trashLabel : undefined) ?? commands[command].label;

  const chosenPaths = () => new Set(host.selection.paths ?? (host.selection.path ? [host.selection.path] : []));
  /** Mark the selected rows; only the focused row is in the tab order, and arrow keys move between rows. */
  const mark = (): void => {
    const rows = treeRows(list);
    const present = new Set(rows.map((row) => row.dataset.path!));
    const chosen = [...chosenPaths()].filter((path) => present.has(path));
    host.selection.paths = chosen;
    if (host.selection.path && !present.has(host.selection.path)) host.selection.path = chosen[chosen.length - 1] ?? null;
    for (const row of rows) {
      const on = chosen.includes(row.dataset.path!);
      row.classList.toggle("selected", on); row.setAttribute("aria-selected", String(on));
      row.tabIndex = row.dataset.path === host.selection.path || (!host.selection.path && row === rows[0]) ? 0 : -1;
    }
  };
  const select = (path: string, mode: PickMode = "one"): void => {
    const anchor = host.selection.anchor ?? host.selection.path;
    if (mode === "range" && anchor) {
      const order = treeRows(list).map((row) => row.dataset.path!);
      const [from, to] = [order.indexOf(anchor), order.indexOf(path)].sort((a, b) => a - b);
      host.selection.paths = from < 0 ? [path] : order.slice(from, to + 1);
    } else if (mode === "toggle") {
      const next = chosenPaths();
      if (!next.delete(path)) next.add(path);
      host.selection.paths = [...next]; host.selection.anchor = path;
    } else { host.selection.paths = [path]; host.selection.anchor = path; }
    host.selection.path = path;
    mark();
  };
  /** The items an action on `path` applies to: the whole selection when `path` is in it, else just `path`. */
  const group = (path: string): string[] => { const all = [...chosenPaths()]; return all.includes(path) ? all : [path]; };
  const clear = (): void => { if (host.selection.path || host.selection.paths?.length) { host.selection.path = null; host.selection.paths = []; host.selection.anchor = null; mark(); } };
  listeners.get(list)?.abort();
  const drawn = new AbortController();
  listeners.set(list, drawn);
  const { signal } = drawn;
  list.addEventListener("focusout", (event) => { if (!list.contains(event.relatedTarget as Node | null)) clear(); }, { signal });
  document.addEventListener("pointerdown", (event) => { if (!list.contains(event.target as Node)) clear(); }, { signal });

  /** Rename in place with the shared field; a file keeps its extension selected out of the way, a name with a slash moves it. */
  const beginRename = (path: string): void => {
    const row = treeRows(list).find((item) => item.dataset.path === path);
    const name = row?.querySelector<HTMLElement>(".tree-name");
    if (!row || !name) return;
    const blocked = host.lockedReason?.(path);
    if (blocked) { host.warn(blocked); return; }
    startRename(name, {
      current: () => name.textContent ?? "",
      label: `Rename ${path}`,
      selectBase: row.dataset.kind !== "folder",
      validate: (typed) => (typed.trim() ? renameProblem(path, renameTarget(path, typed), files, host.reserved) : "Enter a name."),
      onError: host.problem,
      apply: (typed) => { const target = renameTarget(path, typed); if (target) host.rename(path, target); },
    });
  };

  // MARK: the commands, shared by the context menu and the keys

  const removable = (paths: readonly string[]) => topLevel(paths).filter((path) => !host.keepReason?.(path));
  const create = (make: FileTreeHost["newFile"], folder: string): void => {
    if (!make) return;
    void Promise.resolve(make(folder)).then((path) => { if (path) { pendingRename = path; host.selection.path = path; host.selection.paths = [path]; } });
  };
  const paste = (folder: string): void => {
    if (!clipboard) return;
    const { mode, paths } = clipboard;
    for (const from of topLevel(paths)) {
      if (mode === "cut") {
        const move = moveTarget(from, folder, files, { ...host.moveRules, reserved: host.reserved });
        if (move && "problem" in move) host.problem(move.problem);
        else if (move) { host.moved?.(from, move.target); host.rename(from, move.target); }
      } else if (host.copy) {
        if (folder === from || folder.startsWith(`${from}/`)) { host.problem(`${from} cannot be copied into itself.`); continue; }
        host.copy(from, copyTarget(from, folder, files));
      }
    }
    if (mode === "cut") clipboard = null;
  };
  const copyPaths = (paths: string[]): void => {
    void navigator.clipboard?.writeText(host.pathText?.(paths) ?? paths.join("\n"))
      .then(() => host.notice?.(paths.length === 1 ? `Copied the path of ${paths[0]}.` : `Copied ${paths.length} paths.`))
      .catch((error: unknown) => host.problem(`Could not copy: ${error instanceof Error ? error.message : String(error)}.`));
  };
  /** Run a standard command on `paths` (the empty list is the tree itself). */
  const runCommand = (command: TreeCommand, paths: string[]): void => {
    const path = paths[0] ?? "";
    const file = entryOf(path, files);
    if (command === "open") {
      // Open expands or collapses a folder, as Enter does in File Explorer, and opens each file.
      if (file?.kind === "folder" && paths.length === 1) treeRows(list).find((row) => row.dataset.path === path)?.dispatchEvent(new MouseEvent("dblclick", { bubbles: true }));
      else for (const item of paths.map((p) => files.find((f) => f.path === p)).filter((f): f is TreeFile => !!f && f.kind !== "folder")) (host.activate ?? host.open)(item);
    }
    else if (command === "newFile") create(host.newFile, folderOf(path, files));
    else if (command === "newFolder") create(host.newFolder, folderOf(path, files));
    else if (command === "rename" && file && paths.length === 1) beginRename(path);
    else if (command === "delete") removable(paths).forEach((item) => host.trash(item));
    else if (command === "duplicate" && host.copy) for (const item of topLevel(paths)) host.copy(item, copyTarget(item, item.includes("/") ? item.slice(0, item.lastIndexOf("/")) : "", files));
    else if (command === "cut" && paths.length) { clipboard = { mode: "cut", paths: removable(paths).filter((item) => !host.lockedReason?.(item)) }; host.rerender(); }
    else if (command === "copy" && paths.length && host.copy) clipboard = { mode: "copy", paths: [...paths] };
    else if (command === "paste") paste(folderOf(path, files));
    else if (command === "copyPath" && paths.length) copyPaths(paths);
    else if (command === "reveal") host.reveal(path);
    else if (command === "selectAll") { host.selection.paths = treeRows(list).map((row) => row.dataset.path!); mark(); }
  };
  const entry = (command: TreeCommand, paths: string[], disabledBecause?: string | null): MenuEntry => ({
    label: command === "delete" && paths.length > 1 ? `${label(command)} (${removable(paths).length})` : label(command),
    key: commands[command].key, title: disabledBecause ?? undefined, action: disabledBecause ? undefined : () => runCommand(command, paths),
  });
  const separator: MenuEntry = { label: "", separator: true };
  /** The context menu: the standard groups in Finder and File Explorer order, with the app's entries before Show in Finder. */
  const entriesFor = (target: TreeMenuTarget): MenuEntry[] => {
    const { file, paths } = target;
    const single = paths.length === 1 ? paths[0] : null;
    const folder = file?.kind === "folder" || !file;
    const locked = single ? host.lockedReason?.(single) : null;
    const keep = paths.length ? (removable(paths).length ? null : (single ? host.keepReason?.(single) : null) ?? "These items cannot be deleted.") : null;
    const groups: MenuEntry[][] = [];
    if (file && file.kind !== "folder") groups.push([entry("open", paths), ...(paths.length === 1 ? host.menu?.(file) ?? [] : [])]);
    if (folder && paths.length <= 1) groups.push([...(host.newFile ? [entry("newFile", paths)] : []), ...(host.newFolder ? [entry("newFolder", paths)] : []), { label: "Add files…", action: () => host.add(folderOf(single ?? "", files)) }]);
    const extra = host.contextMenu?.(target) ?? [];
    if (extra.length) groups.push(extra);
    groups.push([entry("reveal", single ? [single] : [""])]);
    const clip: MenuEntry[] = [];
    if (paths.length) clip.push(entry("cut", paths, removable(paths).length ? null : keep), ...(host.copy ? [entry("copy", paths)] : []));
    if (clipboard && paths.length <= 1) clip.push(entry("paste", single ? [single] : []));
    if (paths.length && host.copy) clip.push(entry("duplicate", paths));
    if (paths.length) clip.push({ ...entry("copyPath", paths), label: paths.length > 1 ? "Copy paths" : label("copyPath") });
    if (clip.length) groups.push(clip);
    if (paths.length) groups.push([...(single ? [entry("rename", [single], locked)] : []), entry("delete", paths, keep)]);
    return groups.filter((items) => items.length).flatMap((items, index) => (index ? [separator, ...items] : items));
  };
  const openMenu = (event: MouseEvent, file: TreeFile | null): void => {
    event.preventDefault();
    if (!host.enabled) return;
    if (file) {
      const paths = group(file.path);
      if (paths.length === 1) select(file.path);
      showContextMenu(event.clientX, event.clientY, entriesFor({ file: paths.length === 1 ? file : null, paths }));
    } else showContextMenu(event.clientX, event.clientY, entriesFor({ file: null, paths: [] }));
  };
  const ignore = (event: Event): boolean => !host.enabled || !!(event.target as HTMLElement).closest("input");

  const draw = (nodes: readonly TreeNode[], depth: number): void => {
    for (const node of nodes) {
      // A folder that only holds listed files has no entry of its own; it is the same folder for every command.
      const entryFile = entryOf(node.path, files)!;
      const row = makeRow(node.name, node, depth, host, entryFile);
      setTip(row, node.path);
      row.addEventListener("contextmenu", (event) => { event.stopPropagation(); openMenu(event, entryFile); });
      if (node.kind === "folder") {
        const open = !host.collapsed.has(node.path);
        row.classList.add("tree-folder");
        row.setAttribute("aria-expanded", String(open));
        row.insertAdjacentHTML("afterbegin", `<span class="tree-chevron">${chevronIcon}</span>`);
        const toggle = (): void => { if (open) host.collapsed.add(node.path); else host.collapsed.delete(node.path); host.selection.path = node.path; host.rerender(); treeRows(document).find((item) => item.dataset.path === node.path)?.focus(); };
        row.addEventListener("click", (event) => { if (ignore(event)) return; if ((event.target as HTMLElement).closest(".tree-chevron")) toggle(); else select(node.path, pickMode(event)); });
        row.addEventListener("dblclick", (event) => { if (!ignore(event)) toggle(); });
        acceptDrop(row, node.path, host, files);
        list.append(row);
        if (open) draw(node.children, depth + 1);
      } else {
        row.classList.add("tree-file");
        row.addEventListener("click", (event) => { if (!ignore(event)) select(node.path, pickMode(event)); });
        row.addEventListener("dblclick", (event) => { if (!ignore(event)) (host.activate ?? host.open)(entryFile); });
        list.append(row);
      }
    }
  };

  acceptDrop(list, "", host, files, signal);
  list.addEventListener("contextmenu", (event) => { if (!event.defaultPrevented) openMenu(event, null); }, { signal });
  draw(buildTree(files, host.showHidden), 0);
  mark();
  if (host.enabled && !list.childElementCount) list.append(Object.assign(document.createElement("div"), { className: "file-empty", textContent: "No files." }));
  if (pendingRename && treeRows(list).some((row) => row.dataset.path === pendingRename)) {
    const path = pendingRename;
    pendingRename = null;
    queueMicrotask(() => beginRename(path));
  }

  list.addEventListener("keydown", (event) => {
    if (!host.enabled || (event.target as HTMLElement).closest("input")) return;
    const rows = treeRows(list);
    const index = rows.indexOf(document.activeElement as HTMLElement);
    const row = rows[index], path = row?.dataset.path ?? "";
    const paths = row ? group(path) : [];
    if (host.keyDown?.(event, paths)) { event.preventDefault(); return; }
    const command = treeKeyCommand(event);
    if (command) {
      // Commands the host does not offer, or that need a row, leave the key to the page.
      const offered = command === "newFile" ? !!host.newFile : command === "newFolder" ? !!host.newFolder : ["copy", "duplicate"].includes(command) ? !!host.copy : command === "paste" ? !!clipboard : true;
      if (offered && (row || ["paste", "newFolder", "selectAll"].includes(command))) { event.preventDefault(); runCommand(command, paths); }
      return;
    }
    if (index < 0 || event.altKey || event.metaKey || event.ctrlKey) return;
    const go = (target: HTMLElement | undefined): void => { if (target) { select(target.dataset.path!, event.shiftKey ? "range" : "one"); target.focus(); } event.preventDefault(); };
    const folderOpen = row.getAttribute("aria-expanded") === "true";
    const toggleFolder = (): void => { row.dispatchEvent(new MouseEvent("dblclick", { bubbles: true })); };
    if (event.key === "ArrowDown") go(rows[index + 1]);
    else if (event.key === "ArrowUp") go(rows[index - 1]);
    else if (event.key === "Home") go(rows[0]);
    else if (event.key === "End") go(rows[rows.length - 1]);
    else if (event.key === "ArrowRight" && row.dataset.kind === "folder") { if (!folderOpen) toggleFolder(); else go(rows[index + 1]); event.preventDefault(); }
    else if (event.key === "ArrowLeft") {
      if (row.dataset.kind === "folder" && folderOpen) toggleFolder();
      else go(rows.find((item) => path.startsWith(`${item.dataset.path}/`) && item.dataset.path!.split("/").length === path.split("/").length - 1));
      event.preventDefault();
    }
  }, { signal });
}
