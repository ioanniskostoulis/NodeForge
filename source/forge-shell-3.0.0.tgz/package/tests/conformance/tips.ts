import assert from "node:assert/strict";
import { test } from "node:test";
import { checkTipWording, tipText } from "../../source/app/tips";

test("tip text joins label, shortcut and note", () => {
  assert.equal(tipText({ label: "Undo", shortcut: "CmdOrCtrl+Z" }, (key) => key.replace("CmdOrCtrl", "Ctrl")), "Undo (Ctrl+Z)");
  assert.equal(tipText({ label: "Add wire", note: "Click to start." }), "Add wire: Click to start.");
});

test("tip wording rules accept action and sentence tips and flag the rest", () => {
  for (const good of ["Undo (⌘Z)", "Fit", "Set the random seed for reproducible variation.", "Sets language= in the class line of main.tex."]) assert.deepEqual(checkTipWording(good), [], good);
  assert.ok(checkTipWording("set the random seed.").length > 0);
  assert.ok(checkTipWording("Set the random seed for reproducible variation").length > 0);
  assert.ok(checkTipWording(`Set ${"x ".repeat(70)}.`).length > 0);
});
