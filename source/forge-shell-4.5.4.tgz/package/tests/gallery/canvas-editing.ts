// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The canvas editing page of the Gallery (`?canvas=1`): regions of every shape on a dark picture, a light picture and a
// flat surface, with hover, selection, box and point handles with their cursors, a polygon being drawn, a guide line and
// a crop. V selects, C crops, Esc leaves the crop; only the active tool shows its editable form.
import { attachBoxEdit, boxFromDrag, constrainAngle, dragModifiers, HANDLE_HIT } from "../../source/app/box-handles";
import { drawBoxHandles, drawCloseMark, drawGuide, drawPointHandles, drawRegion, drawRegionLabel, labelSize, overlayColor, pictureSurface, traceShape, type OverlaySurface, type RegionShape, type RegionState } from "../../source/app/canvas-overlay";
import { canvasToolForKey, type CanvasTool } from "../../source/app/canvas-tools";
import type { Point, Rect } from "../../source/app/content-selection";

// MARK: given values

/** The picture of each panel, in content units, and its zoom in view px per unit. */
const WIDTH = 320, HEIGHT = 220, SCALE = 1.5;
const PICTURE: Rect = { x: 0, y: 0, width: WIDTH, height: HEIGHT };

interface Region { name: string; shape: RegionShape; fill?: boolean; derived?: boolean }

const wave = (x0: number, y0: number): Point[] => Array.from({ length: 24 }, (_, i) => ({ x: x0 + i * 5, y: y0 + Math.sin(i / 2.2) * 9 + (i % 3) }));
const startRegions = (): Region[] => [
  { name: "Grain", shape: { kind: "rectangle", box: { x: 18, y: 22, width: 92, height: 62 } } },
  { name: "Pore", shape: { kind: "ellipse", box: { x: 136, y: 28, width: 72, height: 52 } } },
  { name: "Phase A", shape: { kind: "polygon", points: [{ x: 232, y: 30 }, { x: 300, y: 44 }, { x: 290, y: 104 }, { x: 240, y: 96 }] }, fill: true },
  { name: "Phase B", shape: { kind: "polygon", points: [{ x: 30, y: 112 }, { x: 98, y: 106 }, { x: 110, y: 160 }, { x: 44, y: 168 }] }, fill: true, derived: true },
  { name: "Edge", shape: { kind: "freehand", points: wave(140, 128) } },
  { name: "Scale", shape: { kind: "line", points: [{ x: 22, y: 198 }, { x: 122, y: 198 }] } },
];

// MARK: pictures

/** A stand-in for a micrograph: a gradient with soft grains, dark or light, from a fixed seed. */
function paintPicture(ctx: CanvasRenderingContext2D, light: boolean): void {
  const g = ctx.createLinearGradient(0, 0, WIDTH, HEIGHT);
  g.addColorStop(0, light ? "#f6f1e7" : "#20293a");
  g.addColorStop(1, light ? "#c9c0ae" : "#06080c");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  let seed = 7;
  const random = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 60; i++) {
    const x = random() * WIDTH, y = random() * HEIGHT, r = 6 + random() * 22;
    const grain = ctx.createRadialGradient(x, y, 0, x, y, r);
    grain.addColorStop(0, light ? "rgba(70, 60, 40, 0.35)" : "rgba(230, 235, 255, 0.28)");
    grain.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = grain;
    ctx.fillRect(x - r, y - r, 2 * r, 2 * r);
  }
}

/** A flat surface with a plot's grid, in the page's own colours. */
function paintSurface(ctx: CanvasRenderingContext2D): void {
  const style = getComputedStyle(document.body);
  ctx.fillStyle = style.getPropertyValue("--well").trim() || "#1e1e1e";
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  ctx.strokeStyle = style.getPropertyValue("--hairline").trim() || "#333333";
  ctx.lineWidth = 1 / SCALE;
  for (let x = 0; x <= WIDTH; x += 40) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, HEIGHT); ctx.stroke(); }
  for (let y = 0; y <= HEIGHT; y += 40) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(WIDTH, y); ctx.stroke(); }
}

// MARK: a panel

type Kind = "dark picture" | "light picture" | "surface";
type ShapeTool = "rectangle" | "ellipse" | "line";

/** The tools the page has: Select and Crop, and three shapes to draw. */
const TOOLS: CanvasTool[] = ["select", "crop", "rectangle", "ellipse", "line"];
const isShapeTool = (tool: CanvasTool): tool is ShapeTool => tool === "rectangle" || tool === "ellipse" || tool === "line";
const capital = (text: string) => `${text[0].toUpperCase()}${text.slice(1)}`;
/** Where a region's label sits: above its box, or above its first point. */
const labelAnchor = (shape: RegionShape): Point => ("box" in shape ? { x: shape.box.x, y: shape.box.y - 3 } : { x: shape.points[0].x, y: shape.points[0].y - 3 });
/** A drawn shape's size, to drop one that is only a click. */
const shapeSize = (shape: RegionShape): number =>
  "box" in shape ? Math.min(shape.box.width, shape.box.height) : Math.hypot(shape.points[1].x - shape.points[0].x, shape.points[1].y - shape.points[0].y);

/** The shape a shape tool draws from `from` to `to` under the modifiers held. */
function draftShape(tool: ShapeTool, from: Point, to: Point, modifiers: { shiftKey: boolean; altKey: boolean }): RegionShape {
  const mods = dragModifiers(modifiers);
  if (tool === "line") return { kind: "line", points: [from, mods.constrain ? constrainAngle(from, to) : to] };
  return { kind: tool, box: boxFromDrag(from.x, from.y, to.x, to.y, PICTURE, mods) };
}

/** One picture or surface with its regions, a crop and a shape being drawn. */
class GalleryPanel {
  private readonly canvas = document.createElement("canvas");
  private readonly caption = Object.assign(document.createElement("figcaption"), { className: "hint-text" });
  private readonly ctx: CanvasRenderingContext2D;
  private readonly regions = startRegions();
  private crop: Rect = { x: 40, y: 30, width: 240, height: 160 };
  private selected: Region | null;
  private hovered: Region | null = null;
  /** A shape being drawn: where the pointer went down, the shape so far and the latest pointer. */
  private draft: { from: Point; shape: RegionShape; last: { clientX: number; clientY: number } } | null = null;
  /** A picture's lightness, read from its pixels once; the flat surface follows the window's appearance. */
  private pictureLightness: OverlaySurface | null = null;

  constructor(host: HTMLElement, private readonly kind: Kind, private readonly tool: () => CanvasTool) {
    const figure = Object.assign(document.createElement("figure"), { className: "gallery-canvas-panel" });
    figure.append(this.canvas, this.caption);
    host.append(figure);
    this.ctx = this.canvas.getContext("2d")!;
    this.selected = kind === "surface" ? null : this.regions[0];
    this.listen();
  }

  private surface(): OverlaySurface {
    if (this.kind === "surface") return document.body.dataset.theme === "light" ? "light" : "dark";
    return this.pictureLightness ?? "dark";
  }

  private toContent(e: { clientX: number; clientY: number }): Point {
    const r = this.canvas.getBoundingClientRect();
    return { x: (e.clientX - r.left) / SCALE, y: (e.clientY - r.top) / SCALE };
  }

  // MARK: drawing

  redraw(): void {
    const ratio = window.devicePixelRatio || 1, { canvas, ctx } = this;
    canvas.width = Math.round(WIDTH * SCALE * ratio);
    canvas.height = Math.round(HEIGHT * SCALE * ratio);
    canvas.style.width = `${WIDTH * SCALE}px`;
    canvas.style.height = `${HEIGHT * SCALE}px`;
    ctx.setTransform(ratio * SCALE, 0, 0, ratio * SCALE, 0, 0);
    this.paintContent();
    this.drawRegions();
    if (this.kind === "surface") this.drawExamples();
    if (this.draft) drawRegion(ctx, this.draft.shape, { color: overlayColor(this.regions.length, this.surface()), state: "drawing", surface: this.surface(), scale: SCALE });
    this.drawEditing();
    this.caption.textContent = `${capital(this.kind)}. ${this.status()}`;
  }

  private paintContent(): void {
    if (this.kind === "surface") { paintSurface(this.ctx); return; }
    paintPicture(this.ctx, this.kind === "light picture");
    this.pictureLightness ??= pictureSurface(this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height));
  }

  /** Only Select shows hover and selection: the edit mode rule. */
  private stateOf(region: Region): RegionState {
    if (this.tool() !== "select") return "normal";
    return region === this.selected ? "selected" : region === this.hovered ? "hovered" : "normal";
  }

  private drawRegions(): void {
    const over = this.surface();
    this.regions.forEach((region, i) => {
      const color = overlayColor(i, over), anchor = labelAnchor(region.shape);
      drawRegion(this.ctx, region.shape, { color, state: this.stateOf(region), surface: over, scale: SCALE, fill: region.fill, derived: region.derived });
      drawRegionLabel(this.ctx, region.name, anchor.x, anchor.y, color, labelSize(Math.min(WIDTH, HEIGHT)));
    });
  }

  /** A polygon being drawn, its first point marked where a click closes it, and a guide line at a level. */
  private drawExamples(): void {
    const over = this.surface(), color = overlayColor(this.regions.length, over);
    const drawing: RegionShape = { kind: "polygon", points: [{ x: 230, y: 150 }, { x: 300, y: 140 }, { x: 290, y: 200 }] };
    drawRegion(this.ctx, drawing, { color, state: "drawing", surface: over, scale: SCALE });
    drawCloseMark(this.ctx, drawing.points[0], color, SCALE);
    drawGuide(this.ctx, { x: 0, y: 116 }, { x: WIDTH, y: 116 }, overlayColor(1, over), SCALE);
  }

  /** The editable form of what the active tool edits: the crop with its handles, or the selected region's handles. */
  private drawEditing(): void {
    const over = this.surface(), tool = this.tool(), selected = this.selected;
    if (tool === "crop") {
      drawRegion(this.ctx, { kind: "rectangle", box: this.crop }, { color: "", state: "selected", surface: over, scale: SCALE });
      drawBoxHandles(this.ctx, this.crop, SCALE, { surface: over });
    } else if (tool === "select" && selected) {
      const points = "box" in selected.shape ? null : selected.shape.points;
      if (points) drawPointHandles(this.ctx, points, SCALE, { surface: over });
      else if ("box" in selected.shape) drawBoxHandles(this.ctx, selected.shape.box, SCALE, { surface: over });
    }
  }

  private status(): string {
    const tool = this.tool();
    if (tool === "crop") return "Crop: drag a handle or the inside; Esc or V leaves.";
    if (isShapeTool(tool)) return `${capital(tool)}: drag to draw; Shift constrains, Option draws from the centre.`;
    return this.selected ? `${this.selected.name} selected.` : "Nothing selected.";
  }

  // MARK: pointer

  /** The topmost region under the pointer: inside a closed shape, or within 5 px of any line. */
  private regionAt(e: PointerEvent): Region | null {
    const r = this.canvas.getBoundingClientRect(), ratio = window.devicePixelRatio || 1, { ctx } = this;
    const x = (e.clientX - r.left) * ratio, y = (e.clientY - r.top) * ratio;
    ctx.save();
    ctx.setTransform(ratio * SCALE, 0, 0, ratio * SCALE, 0, 0);
    ctx.lineWidth = (2 * HANDLE_HIT.fine) / SCALE;
    const found = [...this.regions].reverse().find((region) => {
      traceShape(ctx, region.shape);
      return (region.shape.kind !== "line" && ctx.isPointInPath(x, y)) || ctx.isPointInStroke(x, y);
    }) ?? null;
    ctx.restore();
    return found;
  }

  /** The box the box editor edits: the crop while Crop is on, or the selected rectangle or ellipse under Select. */
  private editedBox(): Rect | null {
    if (this.tool() === "crop") return this.crop;
    const shape = this.selected?.shape;
    return this.tool() === "select" && shape && "box" in shape ? shape.box : null;
  }

  private setEditedBox(box: Rect): void {
    const shape = this.selected?.shape;
    if (this.tool() === "crop") this.crop = box;
    else if (this.selected && shape && "box" in shape) this.selected.shape = { kind: shape.kind, box };
    this.redraw();
  }

  /** Shift and Option apply to a shape being drawn at every move, and when pressed or released mid-drag. */
  private reshape(modifiers: { shiftKey: boolean; altKey: boolean }): void {
    const draft = this.draft, tool = this.tool();
    if (!draft || !isShapeTool(tool)) return;
    draft.shape = draftShape(tool, draft.from, this.toContent(draft.last), modifiers);
    this.redraw();
  }

  private readonly down = (e: PointerEvent): void => {
    const tool = this.tool();
    if (tool === "crop") return;
    if (isShapeTool(tool)) {
      const from = this.toContent(e);
      this.canvas.setPointerCapture?.(e.pointerId);
      this.draft = { from, shape: draftShape(tool, from, from, e), last: e };
      return;
    }
    this.selected = this.regionAt(e);
    this.redraw();
  };

  private readonly move = (e: PointerEvent): void => {
    if (this.draft) { this.draft.last = e; this.reshape(e); return; }
    if (this.tool() !== "select" || e.buttons) return;
    const next = this.regionAt(e);
    if (next !== this.hovered) { this.hovered = next; this.redraw(); }
  };

  private readonly up = (): void => {
    const draft = this.draft;
    if (!draft) return;
    this.draft = null;
    if (shapeSize(draft.shape) >= 2) this.regions.push({ name: `${capital(draft.shape.kind)} ${this.regions.length + 1}`, shape: draft.shape });
    this.redraw();
  };

  private listen(): void {
    // The selected rectangle or ellipse, or the crop while Crop is on, is edited by the shell's box editor.
    attachBoxEdit({ surface: this.canvas, scale: () => SCALE, bounds: () => PICTURE, box: () => this.editedBox(), onDrag: (box) => this.setEditedBox(box) });
    const key = (e: KeyboardEvent) => { if (e.key === "Shift" || e.key === "Alt") this.reshape(e); };
    document.addEventListener("keydown", key);
    document.addEventListener("keyup", key);
    this.canvas.addEventListener("pointerdown", this.down);
    this.canvas.addEventListener("pointermove", this.move);
    this.canvas.addEventListener("pointerup", this.up);
    this.canvas.addEventListener("pointerleave", () => { if (this.hovered) { this.hovered = null; this.redraw(); } });
  }
}

// MARK: the page

/** Mount the canvas editing page in the Gallery's centre. */
export function mountCanvasEditing(host: HTMLElement): void {
  const page = Object.assign(document.createElement("div"), { className: "gallery-canvas" });
  const intro = Object.assign(document.createElement("p"), { className: "hint-text",
    textContent: "Regions take the overlay palette at 1.25 px, bare as traces; selection, hover, handles and the crop take the pick colour. Both follow the lightness of the picture, not the appearance. Click a region to select it and drag its handles (Shift keeps a corner\u2019s proportions or a move on one axis, Option keeps the centre). R, E and L draw a rectangle, ellipse or line (Shift: square, circle, 45\u00b0; Option: from the centre). C crops; V or Esc selects." });
  const grid = Object.assign(document.createElement("div"), { className: "gallery-canvas-grid" });
  page.append(intro, grid);
  host.append(page);
  const asked = new URLSearchParams(location.search).get("tool") as CanvasTool | null;
  let tool: CanvasTool = asked && TOOLS.includes(asked) ? asked : "select";
  const panels = (["dark picture", "light picture", "surface"] as const).map((kind) => new GalleryPanel(grid, kind, () => tool));
  const redraw = () => panels.forEach((panel) => panel.redraw());
  document.addEventListener("keydown", (e) => {
    if (e.target instanceof HTMLElement && e.target.closest("input, textarea, select, [contenteditable=true], .cm-editor")) return;
    const next = e.key === "Escape" ? "select" : canvasToolForKey(e, TOOLS);
    if (next) { tool = next; redraw(); }
  });
  new MutationObserver(redraw).observe(document.body, { attributes: true, attributeFilter: ["data-theme"] });
  redraw();
}
