// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** Tool icons are 16 by 16 px with a 1.25 px line that takes its colour from the button state (`currentColor`). */
export const TOOL_ICON_SIZE = 16;
export const TOOL_ICON_STROKE = 1.25;

/** Wrap path data in the standard icon box. Domain icons use this too, so they share size, stroke and colour. */
export function toolIcon(body: string): string {
  return `<svg width="${TOOL_ICON_SIZE}" height="${TOOL_ICON_SIZE}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${TOOL_ICON_STROKE}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
}

/** The shared set for standard actions. */
export const TOOL_ICONS = {
  undo: toolIcon('<path d="M6 3 3 6l3 3"/><path d="M3 6h6a4 4 0 0 1 0 8H6"/>'),
  redo: toolIcon('<path d="m10 3 3 3-3 3"/><path d="M13 6H7a4 4 0 0 0 0 8h3"/>'),
  cut: toolIcon('<circle cx="4.5" cy="12" r="2"/><circle cx="11.5" cy="12" r="2"/><path d="m5.5 10.3 6-7.3M10.5 10.3l-6-7.3"/>'),
  copy: toolIcon('<rect x="5.5" y="5.5" width="8" height="8" rx="1.5"/><path d="M10.5 3.5v-.5a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h.5"/>'),
  paste: toolIcon('<rect x="3" y="3" width="10" height="11" rx="1.5"/><path d="M6 3V2h4v1M6 8h4M6 11h4"/>'),
  fit: toolIcon('<path d="M2.5 6V2.5H6M10 2.5h3.5V6M13.5 10v3.5H10M6 13.5H2.5V10"/>'),
  zoomIn: toolIcon('<circle cx="7" cy="7" r="4.5"/><path d="m10.5 10.5 3.5 3.5M7 5v4M5 7h4"/>'),
  zoomOut: toolIcon('<circle cx="7" cy="7" r="4.5"/><path d="m10.5 10.5 3.5 3.5M5 7h4"/>'),
} as const;

export type ToolIconName = keyof typeof TOOL_ICONS;

/** Status icons for problems: the same 16 px box and 1.25 px line as the tool icons, coloured by the element they sit in. */
export const STATUS_ICONS = {
  warning: toolIcon('<path d="M8 2.6 14.2 13.4H1.8z"/><path d="M8 6.6v3.2M8 11.7v.1"/>'),
  error: toolIcon('<circle cx="8" cy="8" r="5.9"/><path d="M8 4.9v3.7M8 10.9v.1"/>'),
  info: toolIcon('<circle cx="8" cy="8" r="5.9"/><path d="M8 7.4v3.7M8 5.1v.1"/>'),
} as const;

export type StatusIconName = keyof typeof STATUS_ICONS;

/**
 * The shared set for everything else an application shows: navigation, editing, files and running. An application
 * draws none of these itself; `forge-shell check-app` warns about an inline icon that repeats one of them.
 */
export const UI_ICONS = {
  // navigation
  close: toolIcon('<path d="m4.5 4.5 7 7M11.5 4.5l-7 7"/>'),
  chevronRight: toolIcon('<path d="m6 4 4 4-4 4"/>'),
  chevronLeft: toolIcon('<path d="m10 4-4 4 4 4"/>'),
  chevronUp: toolIcon('<path d="m4 10 4-4 4 4"/>'),
  chevronDown: toolIcon('<path d="m4 6 4 4 4-4"/>'),
  more: toolIcon('<circle cx="3.5" cy="8" r="1" fill="currentColor" stroke="none"/><circle cx="8" cy="8" r="1" fill="currentColor" stroke="none"/><circle cx="12.5" cy="8" r="1" fill="currentColor" stroke="none"/>'),
  // editing
  add: toolIcon('<path d="M8 3v10M3 8h10"/>'),
  remove: toolIcon('<path d="M3 8h10"/>'),
  delete: toolIcon('<path d="M2.5 4h11M6 4V2.5h4V4M4 4l.7 9.5h6.6L12 4M6.6 6.5v4.5M9.4 6.5v4.5"/>'),
  duplicate: toolIcon('<rect x="2" y="2" width="8" height="8" rx="1"/><rect x="6" y="6" width="8" height="8" rx="1"/><path d="M10 8.5v3M8.5 10h3"/>'),
  // three quarters of a circle, clockwise, ending in a head that points along the turn
  rotate: toolIcon('<path d="M14 8A6 6 0 1 1 8 2C9.7 2 11.3 2.7 12.5 3.8L14 5.3M14 2V5.3H10.7"/>'),
  edit: toolIcon('<path d="m3 11 8-8 2 2-8 8-2 .5zM9.5 4.5l2 2"/>'),
  readOnly: toolIcon('<path d="m3 11 8-8 2 2-8 8-2 .5zM9.5 4.5l2 2M2 2l12 12"/>'),
  pointer: toolIcon('<path d="M3.5 2L12 9.4L7.8 9.8L10.2 14.1L8.7 14.9L6.3 10.6L3.5 13.3Z" fill="currentColor" stroke="none"/>'),
  check: toolIcon('<path d="m3.5 8.5 3 3 6-7"/>'),
  // files
  search: toolIcon('<circle cx="7" cy="7" r="4.5"/><path d="m10.5 10.5 3.5 3.5"/>'),
  reveal: toolIcon('<path d="M2.5 4.5a1 1 0 0 1 1-1h3l1.5 1.5h4.5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1z"/><path d="M8 11V7.5M6.5 9 8 7.5 9.5 9"/>'),
  export: toolIcon('<path d="M8 10V2.5M5 5.5l3-3 3 3M3 10v3.5h10V10"/>'),
  import: toolIcon('<path d="M8 2.5V10M5 7l3 3 3-3M3 10v3.5h10V10"/>'),
  link: toolIcon('<path d="M7 9a3 3 0 0 0 4.2 0l2-2A3 3 0 0 0 9 2.8l-.8.8M9 7a3 3 0 0 0-4.2 0l-2 2A3 3 0 0 0 7 13.2l.8-.8"/>'),
  show: toolIcon('<path d="M1.5 8s2.5-4.5 6.5-4.5 6.5 4.5 6.5 4.5-2.5 4.5-6.5 4.5S1.5 8 1.5 8z"/><circle cx="8" cy="8" r="2"/>'),
  hide: toolIcon('<path d="M2.5 2.5l11 11M6.6 4a6.5 6.5 0 0 1 1.4-.5c4 0 6.5 4.5 6.5 4.5a11 11 0 0 1-1.8 2.3M10.4 11.6A6 6 0 0 1 8 12.5C4 12.5 1.5 8 1.5 8a11 11 0 0 1 2.7-3"/>'),
  lock: toolIcon('<rect x="3.5" y="7" width="9" height="6.5" rx="1"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2"/>'),
  unlock: toolIcon('<rect x="3.5" y="7" width="9" height="6.5" rx="1"/><path d="M5.5 7V5a2.5 2.5 0 0 1 4.9-.7"/>'),
  pin: toolIcon('<path d="M6 2.5h4l-.5 4 2 2v1h-7v-1l2-2zM8 9.5v4"/>'),
  checkCircle: toolIcon('<circle cx="8" cy="8" r="5.5"/><path d="m5.5 8 1.8 1.8L10.5 6.5"/>'),
  // running and settings
  refresh: toolIcon('<path d="M13 8a5 5 0 1 1-1.5-3.6M13 2.5v3h-3"/>'),
  settings: toolIcon('<circle cx="8" cy="8" r="2.2"/><path d="M8 1.8v2M8 12.2v2M1.8 8h2M12.2 8h2M3.6 3.6l1.4 1.4M11 11l1.4 1.4M3.6 12.4 5 11M11 5l1.4-1.4"/>'),
} as const;

export type UiIconName = keyof typeof UI_ICONS;

/** Filled 9 px glyphs for the small run controls of a panel button (Run, Pause, Stop, Reset, Step), drawn in the text colour. */
export const BUTTON_GLYPHS = {
  play: '<svg width="9" height="9" viewBox="0 0 9 9" aria-hidden="true"><path d="M1.5 1L8 4.5L1.5 8Z" fill="currentColor"/></svg>',
  pause: '<svg width="9" height="9" viewBox="0 0 9 9" aria-hidden="true"><path d="M1.5 1h2v7h-2zM5.5 1h2v7h-2z" fill="currentColor"/></svg>',
  stop: '<svg width="9" height="9" viewBox="0 0 9 9" aria-hidden="true"><rect x="1.5" y="1.5" width="6" height="6" fill="currentColor"/></svg>',
  reset: '<svg width="9" height="9" viewBox="0 0 9 9" aria-hidden="true"><path d="M1 1V8M8 1L2.5 4.5L8 8Z" fill="currentColor"/></svg>',
  step: '<svg width="9" height="9" viewBox="0 0 9 9" aria-hidden="true"><path d="M1 1L6 4.5L1 8ZM7 1V8" fill="currentColor"/></svg>',
} as const;
