import assert from "node:assert/strict";
import test from "node:test";
import { createDesktopBridge, type IpcRendererPort } from "../../source/desktop/bridge";

test("desktop bridge sends shell IPC channels and forwards events", async () => {
  const sent: [string, ...unknown[]][] = [];
  const invoked: [string, ...unknown[]][] = [];
  const listeners = new Map<string, (event: unknown, ...args: any[]) => void>();
  const ipc: IpcRendererPort = {
    send(channel, ...args) { sent.push([channel, ...args]); },
    async invoke(channel, ...args) { invoked.push([channel, ...args]); return channel === "saveDialog" ? "/tmp/example.nfg" : []; },
    on(channel, listener) { listeners.set(channel, listener); },
  };
  const bridge = createDesktopBridge<"nfg">(ipc, "darwin", "1.2.3");
  assert.equal(bridge.version, "1.2.3");
  bridge.setTitle("Example");
  bridge.setEdited(true);
  bridge.closeCancelled();
  assert.deepEqual(sent, [["setTitle", "Example"], ["setEdited", true], ["closeCancelled"]]);
  assert.equal(await bridge.saveDialog("example.nfg", "nfg"), "/tmp/example.nfg");
  assert.deepEqual(invoked, [["saveDialog", "example.nfg", "nfg"]]);
  let command = "";
  bridge.onCommand((id) => { command = id; });
  listeners.get("command")?.({}, "save");
  assert.equal(command, "save");
});
