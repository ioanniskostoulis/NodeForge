// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { artifactPattern } from "./artifact-name.mjs";
import { DMG_BACKGROUND, DMG_ICON_SIZE, DMG_VOLUME_ICON, dmgContents } from "./dmg-background.mjs";

/** Shared Electron Builder defaults. App-specific metadata and resources come from the profile. */
export function electronBuilderConfig(config) {
  const { identity, document, desktop } = config;
  if (!identity?.name || !identity?.id || !desktop?.appId || !desktop?.copyright) throw new Error("Missing desktop identity or copyright in forge.config.json");
  const doc = desktop.document;
  if (document && (!doc?.name || !doc.description || !doc.iconStem || !doc.typeIdentifier || !doc.mimeType || !doc.conformsTo?.length)) {
    throw new Error("A document app needs its native file association in forge.config.json desktop.document");
  }
  const association = document && doc ? [{
    ext: document.extension,
    name: doc.name,
    description: doc.description,
    icon: doc.iconStem,
    role: doc.role ?? "Editor",
  }] : [];
  const exportedTypes = document && doc ? [{
    UTTypeIdentifier: doc.typeIdentifier,
    UTTypeDescription: doc.name,
    UTTypeIconFile: `${doc.iconStem}.icns`,
    UTTypeConformsTo: doc.conformsTo,
    UTTypeTagSpecification: {
      "public.filename-extension": [document.extension],
      "public.mime-type": doc.mimeType,
    },
  }] : [];
  return {
    appId: desktop.appId,
    productName: identity.name,
    copyright: desktop.copyright,
    directories: { output: "build/release", buildResources: "assets/icon" },
    files: ["build/app/**", "!build/app/release-source/**", "build/desktop/**", "package.json"],
    extraResources: [
      ...(desktop.extraResources ?? []),
      { from: "build/app/release-source", to: "source" },
      { from: "node_modules/electron/dist/LICENSE", to: "licenses/ELECTRON_LICENSE" },
    ],
    // The interface is English: other Chromium locales are left out (about 40 MB on Windows).
    electronLanguages: ["en-US"],
    icon: desktop.appIcon ?? "assets/icon.png",
    ...(association.length ? { fileAssociations: association } : {}),
    mac: {
      target: ["dmg"],
      artifactName: artifactPattern(identity.name),
      category: desktop.macCategory ?? "public.app-category.productivity",
      identity: "-",
      hardenedRuntime: false,
      // The Chromium notices once, in Resources. On Windows they stay beside the executable as LICENSES.chromium.html.
      extraResources: [{ from: "node_modules/electron/dist/LICENSES.chromium.html", to: "licenses/ELECTRON_CHROMIUM_LICENSES.html" }],
      ...(exportedTypes.length ? { extendInfo: { UTExportedTypeDeclarations: exportedTypes } } : {}),
    },
    win: { target: [{ target: "nsis", arch: ["x64"] }], artifactName: artifactPattern(identity.name) },
    nsis: {
      oneClick: false,
      perMachine: false,
      selectPerMachineByDefault: true,
      allowToChangeInstallationDirectory: true,
      deleteAppDataOnUninstall: false,
      ...(desktop.installer?.sidebar ? { installerSidebar: desktop.installer.sidebar } : {}),
      ...(desktop.installer?.header ? { installerHeader: desktop.installer.header } : {}),
      ...(desktop.installer?.include ? { include: desktop.installer.include } : {}),
    },
    // The window drawn by `forge-shell dmg-background` (scripts/dmg-background.mjs), which runs before packaging on macOS.
    dmg: { title: `${identity.name} \${version}`, background: DMG_BACKGROUND, icon: DMG_VOLUME_ICON, iconSize: DMG_ICON_SIZE, iconTextSize: 12, contents: dmgContents(identity.name) },
  };
}
