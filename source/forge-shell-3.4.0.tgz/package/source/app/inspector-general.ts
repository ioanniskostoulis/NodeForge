// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { createButton, createButtonGroup, type ButtonOptions } from "./builders";

// The first section of the inspector. The application names it for what its document is; `General` is the default
// until a better name exists. The helper keeps whatever heading the section has.

/** The default name of the first section, kept until the application has a better one. */
export const FIRST_SECTION_TITLE = "General";

/** One main action of the first section: a text button, with an icon only when its action has a standard symbol. */
export interface GeneralAction extends ButtonOptions {
  /** Standard icon markup (from the shell's icon list), shown before the label. */
  icon?: string;
}

/** The first section holds two or three actions, exactly one of them primary. */
export const GENERAL_MIN_ACTIONS = 2;
export const GENERAL_MAX_ACTIONS = 3;

/** The inspector philosophy's rule for the first section, as a sentence or none. Returns the problem, or null when valid. */
export function generalActionProblem(actions: readonly Pick<GeneralAction, "primary">[]): string | null {
  if (actions.length < GENERAL_MIN_ACTIONS || actions.length > GENERAL_MAX_ACTIONS) {
    return `The first section of the inspector holds ${GENERAL_MIN_ACTIONS} to ${GENERAL_MAX_ACTIONS} actions, not ${actions.length}.`;
  }
  const primaries = actions.filter((action) => action.primary).length;
  if (primaries !== 1) return `The first section of the inspector needs exactly one primary action, not ${primaries}.`;
  return null;
}

/**
 * Fill the first section of the inspector, under the name the application gave it: its main actions as one button group, then the document's rows (its
 * editable name, File, Images, Grid). The section keeps its heading and its fold; the rows go in a body box that the
 * helper owns (`general-body`, with no layout of its own). Throws when the actions break the rule.
 */
export function fillGeneralSection(section: HTMLElement, actions: readonly GeneralAction[], rows: readonly HTMLElement[] = []): void {
  const problem = generalActionProblem(actions);
  if (problem) throw new Error(problem);
  const buttons = actions.map((action) => {
    const button = createButton(action);
    // The icon is the shell's markup; the label is text, so that `&` or `<` in it shows as written.
    if (action.icon) { button.innerHTML = action.icon; button.append(Object.assign(document.createElement("span"), { textContent: action.label })); }
    return button;
  });
  let body = section.querySelector<HTMLElement>(":scope > .general-body");
  if (!body) {
    body = document.createElement("div");
    body.className = "general-body";
    section.append(body);
  }
  body.replaceChildren(createButtonGroup(buttons), ...rows);
}
