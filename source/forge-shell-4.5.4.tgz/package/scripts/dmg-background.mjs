// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The macOS disk image window of a Forge app: its layout, its background drawn as SVG, and the PNG renders of it.
import { spawnSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { resolveTheme } from "./theme.mjs";

// The window, in points. The app icon and the Applications link sit on one row, symmetric about the centre.
// The window height includes the 32 pt title bar, and Finder may add its path and status bars (about 52 pt) at the
// bottom, so everything drawn stays above `DMG_VISIBLE` (400 - 32 - 52 = 316 pt of the background).
export const DMG_WINDOW = { width: 600, height: 400 };
export const DMG_VISIBLE = 316;
export const DMG_ICON_SIZE = 96;
export const DMG_ICON_ROW = 184;
export const DMG_ICON_OFFSET = 150;
// Where the background (1x and 2x in one TIFF) and the volume icon are written, relative to the app.
export const DMG_BACKGROUND = "build/dmg/background.tiff";
export const DMG_VOLUME_ICON = "build/dmg/volume.icns";
// Finder lists the background and the volume icon when hidden files are shown. Electron Builder accepts no position
// for them, so the same files are also listed as contents under their names in the image, placed below the window.
export const DMG_HIDDEN = { ".background.tiff": DMG_BACKGROUND, ".VolumeIcon.icns": DMG_VOLUME_ICON };
export const DMG_HIDDEN_ROW = DMG_WINDOW.height + 200;
// Light appearance of the shell: --panel, --text2, --text3 and --hairline.
const PANEL = "#e8e8e8", TEXT2 = "#555555", TEXT3 = "#6a6a6a", HAIRLINE = "rgba(0, 0, 0, 0.1)";
// The wordmark is fitted into this width, at no more than the largest size, in points.
const WORDMARK_WIDTH = 500, WORDMARK_MAX_SIZE = 10, WORDMARK_TOP = 18, MONO_ADVANCE = 0.6, LINE_HEIGHT = 1.12;
// The hairline under the wordmark and the baselines of the two lines of install text, in points.
const RULE_Y = 112, NOTE_Y = [290, 308];
const UI = `-apple-system, BlinkMacSystemFont, "Helvetica Neue", sans-serif`;
const MONO = `ui-monospace, "SF Mono", Menlo, monospace`;

/** The two icons of the window, as Electron Builder `dmg.contents`, followed by the hidden files moved out of view. */
export function dmgContents(productName) {
  const centre = DMG_WINDOW.width / 2;
  return [
    { x: centre - DMG_ICON_OFFSET, y: DMG_ICON_ROW, type: "file", name: `${productName}.app` },
    { x: centre + DMG_ICON_OFFSET, y: DMG_ICON_ROW, type: "link", path: "/Applications" },
    ...Object.entries(DMG_HIDDEN).map(([name, path], index) => ({ x: centre + (index - 0.5) * 120, y: DMG_HIDDEN_ROW, type: "file", path, name })),
  ];
}

const escapeXml = (text) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/** The background as SVG text: the wordmark in the light accent, an arrow from the app to Applications and the install note. */
export function dmgBackgroundSvg({ name, accent, wordmark }) {
  const { width, height } = DMG_WINDOW;
  const centre = width / 2;
  const lines = (wordmark ?? name).replace(/\s+$/, "").split("\n").map((line) => line.replace(/\s+$/, ""));
  const columns = Math.max(...lines.map((line) => line.length));
  const size = Math.min(WORDMARK_MAX_SIZE, WORDMARK_WIDTH / (columns * MONO_ADVANCE));
  const left = centre - (columns * MONO_ADVANCE * size) / 2;
  const text = lines.map((line, index) => `<text x="${left.toFixed(1)}" y="${(WORDMARK_TOP + (index + 1) * size * LINE_HEIGHT).toFixed(1)}" xml:space="preserve">${escapeXml(line)}</text>`).join("");
  // The arrow runs between the icons, clear of them by 26 pt on each side, with a chevron head.
  const from = centre - DMG_ICON_OFFSET + DMG_ICON_SIZE / 2 + 26, to = centre + DMG_ICON_OFFSET - DMG_ICON_SIZE / 2 - 26;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
<rect width="${width}" height="${height}" fill="${PANEL}"/>
<rect width="${width}" height="2" fill="${accent}"/>
<g font-family='${MONO}' font-size="${size.toFixed(2)}" fill="${accent}">${text}</g>
<line x1="40" y1="${RULE_Y}" x2="${width - 40}" y2="${RULE_Y}" stroke="${HAIRLINE}"/>
<g fill="none" stroke="${accent}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
<line x1="${from}" y1="${DMG_ICON_ROW}" x2="${to}" y2="${DMG_ICON_ROW}"/>
<polyline points="${to - 10},${DMG_ICON_ROW - 10} ${to},${DMG_ICON_ROW} ${to - 10},${DMG_ICON_ROW + 10}"/>
</g>
<g font-family='${UI}' text-anchor="middle">
<text x="${centre}" y="${NOTE_Y[0]}" font-size="12" fill="${TEXT2}">Drag ${escapeXml(name)} to Applications to install it.</text>
<text x="${centre}" y="${NOTE_Y[1]}" font-size="11" fill="${TEXT3}">The app is not signed. On the first launch, right-click it and choose Open.</text>
</g>
</svg>
`;
}

/** The background of the app described by `forge.config.json`. */
export function appDmgBackgroundSvg(configPath = "forge.config.json") {
  const { identity, theme } = JSON.parse(readFileSync(configPath, "utf8"));
  const wordmarkPath = identity.wordmarkPath ? join("assets", identity.wordmarkPath) : "assets/logo.txt";
  const wordmark = existsSync(wordmarkPath) ? readFileSync(wordmarkPath, "utf8") : null;
  return dmgBackgroundSvg({ name: identity.name, accent: resolveTheme(theme).light.accent, wordmark });
}

// Electron draws the SVG once at 2x in an offscreen window; the 1x image is that capture scaled down.
const RENDERER = `const { app, BrowserWindow } = require("electron");
const { writeFileSync } = require("node:fs");
const [pagePath, out1, out2, width, height] = process.argv.slice(-5);
app.disableHardwareAcceleration();
app.whenReady().then(async () => {
  const w = Number(width), h = Number(height);
  const window = new BrowserWindow({ show: false, width: 2 * w, height: 2 * h, useContentSize: true, webPreferences: { offscreen: true } });
  await window.loadFile(pagePath);
  await window.webContents.executeJavaScript("document.fonts.ready.then(() => new Promise((done) => requestAnimationFrame(() => requestAnimationFrame(done))))");
  const image = await window.webContents.capturePage();
  writeFileSync(out2, image.resize({ width: 2 * w, height: 2 * h, quality: "best" }).toPNG());
  writeFileSync(out1, image.resize({ width: w, height: h, quality: "best" }).toPNG());
  app.exit(0);
}).catch((error) => { console.error(error); app.exit(1); });
`;

/**
 * Write the disk image files of the app in the working directory into `build/dmg`: `background.svg`, its 1x and 2x
 * renders, `background.tiff` combining them, and `volume.icns` from the app icon. Needs macOS (`tiffutil`, `sips`, `iconutil`).
 */
export function renderDmgBackground({ configPath = "forge.config.json", outDir = "build/dmg" } = {}) {
  const dir = resolve(outDir);
  mkdirSync(dir, { recursive: true });
  const svgPath = join(dir, "background.svg");
  writeFileSync(svgPath, appDmgBackgroundSvg(configPath));
  const electron = createRequire(join(process.cwd(), "package.json"))("electron");
  const work = mkdtempSync(join(tmpdir(), "forge-dmg-"));
  try {
    const main = join(work, "render.cjs");
    writeFileSync(main, RENDERER);
    // The SVG fills the window, so one page serves both scales.
    const page = join(work, "page.html");
    writeFileSync(page, `<!doctype html><html><body style="margin:0;overflow:hidden">${readFileSync(svgPath, "utf8").replace("<svg ", `<svg style="display:block;width:100vw;height:100vh" `)}</body></html>`);
    const outputs = [join(dir, "background.png"), join(dir, "background@2x.png")];
    const result = spawnSync(electron, [main, page, ...outputs, String(DMG_WINDOW.width), String(DMG_WINDOW.height)], { stdio: "inherit" });
    if (result.status !== 0 || !outputs.every((file) => existsSync(file))) throw new Error(`The disk image background was not rendered (Electron exit code ${result.status}).`);
    const run = (command, args) => {
      const done = spawnSync(command, args, { stdio: ["ignore", "ignore", "inherit"] });
      if (done.status !== 0) throw new Error(`${command} failed with exit code ${done.status}.`);
    };
    const tiff = resolve(DMG_BACKGROUND);
    run("tiffutil", ["-cathidpicheck", ...outputs, "-out", tiff]);
    // The volume icon: every size of a macOS icon set, drawn from the app icon.
    const { desktop = {} } = JSON.parse(readFileSync(configPath, "utf8"));
    const iconset = join(work, "volume.iconset");
    mkdirSync(iconset);
    for (const size of [16, 32, 128, 256, 512]) {
      for (const [scale, suffix] of [[1, ""], [2, "@2x"]]) run("sips", ["-z", String(size * scale), String(size * scale), resolve(desktop.appIcon ?? "assets/icon.png"), "--out", join(iconset, `icon_${size}x${size}${suffix}.png`)]);
    }
    const icns = resolve(DMG_VOLUME_ICON);
    run("iconutil", ["-c", "icns", iconset, "-o", icns]);
    return [tiff, icns];
  } finally {
    rmSync(work, { recursive: true, force: true });
  }
}
