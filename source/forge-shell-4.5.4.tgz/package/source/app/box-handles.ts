// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Editing a rectangle on a canvas: a crop, a region, any box. Eight handles (four corners, four edges) resize it and
// the inside moves it; the shell finds the handle under the pointer, drags it within bounds and sets the cursor, and
// the application stores the box. Geometry is in content units; tolerances are in view px and divided by the scale.
import { DRAG_THRESHOLD, type Point, type Rect } from "./content-selection";

// MARK: given values

export type BoxEdge = "nw" | "n" | "ne" | "e" | "se" | "s" | "sw" | "w";
export type BoxHandle = BoxEdge | "move";

/** The eight resize handles, corners before edges, so that a corner wins where a small box makes them overlap. */
export const BOX_HANDLES: readonly BoxEdge[] = ["nw", "ne", "se", "sw", "n", "e", "s", "w"];
/** The side of a drawn handle, in view px, at any zoom. */
export const HANDLE_SIZE = 7;
/** How far from a handle's centre, in view px, the pointer still takes it: a fine pointer (mouse, trackpad), a coarse one (touch). */
export const HANDLE_HIT = { fine: 5, coarse: 12 } as const;
/** The smallest box a resize leaves, in content units. */
export const MIN_BOX = 1;
/** The cursor over each handle: north-south, east-west and the two diagonals; `move` inside. */
export const BOX_CURSORS: Readonly<Record<BoxHandle, string>> = {
  n: "ns-resize", s: "ns-resize", e: "ew-resize", w: "ew-resize",
  ne: "nesw-resize", sw: "nesw-resize", nw: "nwse-resize", se: "nwse-resize", move: "move",
};

// MARK: method

/** Where a handle sits on a box: a corner, or the middle of an edge. */
export function handlePoint(box: Rect, handle: BoxEdge): Point {
  const x = handle.includes("w") ? box.x : handle.includes("e") ? box.x + box.width : box.x + box.width / 2;
  const y = handle.includes("n") ? box.y : handle.includes("s") ? box.y + box.height : box.y + box.height / 2;
  return { x, y };
}

/**
 * The handle under the point (px, py): the nearest handle whose square of half-side `tolerance` holds it, else `move`
 * inside the box (with `move: true`, the default), else null. Pass the tolerance in the box's units (view px / scale).
 */
export function handleAt(box: Rect, px: number, py: number, tolerance: number = HANDLE_HIT.fine, move = true): BoxHandle | null {
  let best: BoxEdge | null = null, bestDistance = Infinity;
  for (const handle of BOX_HANDLES) {
    const p = handlePoint(box, handle);
    const distance = Math.max(Math.abs(px - p.x), Math.abs(py - p.y));
    if (distance <= tolerance && distance < bestDistance) { best = handle; bestDistance = distance; }
  }
  if (best) return best;
  const inside = px >= box.x && px <= box.x + box.width && py >= box.y && py <= box.y + box.height;
  return move && inside ? "move" : null;
}

/**
 * The modifiers held while drawing or dragging, the same in every application: Shift constrains (a line to steps of
 * 45°, a rectangle to a square, an ellipse to a circle, a corner to the box's proportions, a move to one axis), and
 * Option (Alt) works from the centre. Cmd and Ctrl stay the selection's (toggle) and the shortcuts'.
 */
export interface DragModifiers { constrain?: boolean; fromCenter?: boolean }

/** The drawing modifiers of a pointer or key event. */
export function dragModifiers(event: { shiftKey: boolean; altKey: boolean }): DragModifiers {
  return { constrain: event.shiftKey, fromCenter: event.altKey };
}

/** The end of a line from `from` towards `to`, turned to the nearest multiple of `stepDeg` (45°: level, upright or diagonal). */
export function constrainAngle(from: Point, to: Point, stepDeg = 45): Point {
  const dx = to.x - from.x, dy = to.y - from.y;
  const step = (stepDeg * Math.PI) / 180;
  const angle = Math.round(Math.atan2(dy, dx) / step) * step;
  // the pointer projected onto the chosen direction, so a level line keeps the pointer's x and an upright one its y
  const length = dx * Math.cos(angle) + dy * Math.sin(angle);
  const round = (v: number) => (Math.abs(v) < 1e-9 ? 0 : v);
  return { x: from.x + round(length * Math.cos(angle)), y: from.y + round(length * Math.sin(angle)) };
}

/** The edges a box stays inside: the bounds, or none (infinite) on either side. */
interface Limits { x0: number; y0: number; x1: number; y1: number }
const limitsOf = (bounds?: Rect | null): Limits => bounds
  ? { x0: bounds.x, y0: bounds.y, x1: bounds.x + bounds.width, y1: bounds.y + bounds.height }
  : { x0: -Infinity, y0: -Infinity, x1: Infinity, y1: Infinity };

/** The room from `anchor` to the limits on one axis: forward (+1), back (−1), or both ways (0, the nearer side). */
const room = (anchor: number, lo: number, hi: number, direction: -1 | 0 | 1): number =>
  direction > 0 ? hi - anchor : direction < 0 ? anchor - lo : Math.min(anchor - lo, hi - anchor);

/** The way a handle pulls on each axis: +1 east or south, −1 west or north, 0 not at all. */
const handleSigns = (handle: BoxEdge): { sx: -1 | 0 | 1; sy: -1 | 0 | 1 } => ({
  sx: handle.includes("e") ? 1 : handle.includes("w") ? -1 : 0,
  sy: handle.includes("s") ? 1 : handle.includes("n") ? -1 : 0,
});

/** A move: the whole box shifted, kept inside the limits; constrained, along the axis it moved most. */
function moveBox(start: Rect, dx: number, dy: number, l: Limits, constrain: boolean): Rect {
  const along = Math.abs(dx) >= Math.abs(dy);
  const mx = constrain && !along ? 0 : dx, my = constrain && along ? 0 : dy;
  const x = start.x + Math.min(Math.max(mx, l.x0 - start.x), l.x1 - start.x - start.width);
  const y = start.y + Math.min(Math.max(my, l.y0 - start.y), l.y1 - start.y - start.height);
  return { x, y, width: start.width, height: start.height };
}

/**
 * A corner keeping the proportions: the farther of the two pointer axes sets the scale, about the opposite corner or
 * the centre, then the limits and the minimum size bound it.
 */
function scaleCorner(start: Rect, sx: 1 | -1, sy: 1 | -1, dx: number, dy: number, l: Limits, minSize: number, fromCenter: boolean): Rect {
  const k = fromCenter ? 2 : 1;
  const ax = fromCenter ? start.x + start.width / 2 : sx > 0 ? start.x : start.x + start.width;
  const ay = fromCenter ? start.y + start.height / 2 : sy > 0 ? start.y : start.y + start.height;
  const wanted = Math.max((start.width + k * sx * dx) / start.width, (start.height + k * sy * dy) / start.height);
  const roomX = k * room(ax, l.x0, l.x1, fromCenter ? 0 : sx), roomY = k * room(ay, l.y0, l.y1, fromCenter ? 0 : sy);
  const scale = Math.max(Math.min(wanted, roomX / start.width, roomY / start.height), minSize / Math.min(start.width, start.height));
  const width = start.width * scale, height = start.height * scale;
  const x = fromCenter ? ax - width / 2 : sx > 0 ? ax : ax - width;
  const y = fromCenter ? ay - height / 2 : sy > 0 ? ay : ay - height;
  return { x, y, width, height };
}

/** An edge or corner pulled about the centre: the opposite edge moves the other way. */
function resizeAboutCentre(start: Rect, sx: number, sy: number, dx: number, dy: number, l: Limits, minSize: number): Rect {
  const cx = start.x + start.width / 2, cy = start.y + start.height / 2;
  const half = (size: number, sign: number, d: number, centre: number, lo: number, hi: number) =>
    sign ? Math.min(Math.max(size / 2 + sign * d, minSize / 2), room(centre, lo, hi, 0)) : size / 2;
  const hw = half(start.width, sx, dx, cx, l.x0, l.x1), hh = half(start.height, sy, dy, cy, l.y0, l.y1);
  return { x: cx - hw, y: cy - hh, width: 2 * hw, height: 2 * hh };
}

/** An edge or corner pulled on its own: each pulled edge follows the pointer, inside the limits and short of its opposite. */
function resizeEdges(start: Rect, sx: number, sy: number, dx: number, dy: number, l: Limits, minSize: number): Rect {
  let x0 = start.x, y0 = start.y, x1 = start.x + start.width, y1 = start.y + start.height;
  if (sx < 0) x0 = Math.min(Math.max(x0 + dx, l.x0), x1 - minSize);
  if (sx > 0) x1 = Math.max(Math.min(x1 + dx, l.x1), x0 + minSize);
  if (sy < 0) y0 = Math.min(Math.max(y0 + dy, l.y0), y1 - minSize);
  if (sy > 0) y1 = Math.max(Math.min(y1 + dy, l.y1), y0 + minSize);
  return { x: x0, y: y0, width: x1 - x0, height: y1 - y0 };
}

/**
 * The box after dragging `handle` by (dx, dy) from `start`: an edge follows the pointer and stops `minSize` short of
 * the opposite edge and at the edge of `bounds`; `move` shifts the whole box and keeps it inside `bounds`. With
 * `constrain`, a move keeps to the axis it moved most along and a corner keeps the box's proportions; with
 * `fromCenter`, the opposite edge moves the other way, so the centre stays.
 */
export function dragBox(start: Rect, handle: BoxHandle, dx: number, dy: number, bounds?: Rect | null, minSize = MIN_BOX, modifiers: DragModifiers = {}): Rect {
  const l = limitsOf(bounds);
  if (handle === "move") return moveBox(start, dx, dy, l, !!modifiers.constrain);
  const { sx, sy } = handleSigns(handle);
  const proportional = modifiers.constrain && sx !== 0 && sy !== 0 && start.width > 0 && start.height > 0;
  if (proportional) return scaleCorner(start, sx as 1 | -1, sy as 1 | -1, dx, dy, l, minSize, !!modifiers.fromCenter);
  return modifiers.fromCenter ? resizeAboutCentre(start, sx, sy, dx, dy, l, minSize) : resizeEdges(start, sx, sy, dx, dy, l, minSize);
}

/**
 * The box dragged out from (x0, y0) to (x1, y1), whichever way, cut to `bounds`. With `constrain` it is a square (a
 * circle, for an ellipse) as large as the farther axis and the bounds allow; with `fromCenter`, (x0, y0) is its centre.
 */
export function boxFromDrag(x0: number, y0: number, x1: number, y1: number, bounds?: Rect | null, modifiers: DragModifiers = {}): Rect {
  const l = limitsOf(bounds);
  const ax = Math.min(Math.max(x0, l.x0), l.x1), ay = Math.min(Math.max(y0, l.y0), l.y1);
  const sx = x1 >= ax ? 1 : -1, sy = y1 >= ay ? 1 : -1;
  // half-widths from the centre, or full widths from the corner, each within its room
  const roomX = room(ax, l.x0, l.x1, modifiers.fromCenter ? 0 : sx), roomY = room(ay, l.y0, l.y1, modifiers.fromCenter ? 0 : sy);
  const square = Math.min(Math.max(Math.abs(x1 - ax), Math.abs(y1 - ay)), roomX, roomY);
  const w = modifiers.constrain ? square : Math.min(Math.abs(x1 - ax), roomX);
  const h = modifiers.constrain ? square : Math.min(Math.abs(y1 - ay), roomY);
  if (modifiers.fromCenter) return { x: ax - w, y: ay - h, width: 2 * w, height: 2 * h };
  return { x: sx > 0 ? ax : ax - w, y: sy > 0 ? ay : ay - h, width: w, height: h };
}

/** The hit tolerance of the pointer that is in use, in view px: larger for touch, the same for a mouse and a trackpad. */
export function handleHit(pointerType: string): number {
  return pointerType === "touch" || pointerType === "pen" ? HANDLE_HIT.coarse : HANDLE_HIT.fine;
}

// MARK: editing a box on a surface

export interface BoxEditOptions {
  /** The element over the content: it takes the pointer and the cursor. */
  surface: HTMLElement;
  /** The box being edited, in content units; null while there is none (the handles are then off). */
  box: () => Rect | null;
  /** The area the box stays inside, in content units (the picture); none leaves it free. */
  bounds?: () => Rect | null;
  /** The content point under a pointer position (default: the position in the surface over `scale`). */
  toContent?: (clientX: number, clientY: number) => Point;
  /** View px per content unit (default 1). */
  scale?: () => number;
  /** `resize` (the default): the eight handles and move; `move`: the inside only. */
  handles?: "resize" | "move";
  minSize?: number;
  /** The box during a drag, at every move. */
  onDrag: (box: Rect, handle: BoxHandle) => void;
  /** The drag ended with a change: one step for Undo. */
  onEnd?: (box: Rect, handle: BoxHandle) => void;
  /** Esc during a drag: the box is back at its start (`onDrag` has been given it). */
  onCancel?: () => void;
  document?: Document;
}

/** A drag in progress: the pointer, the handle and the box it started from, and the latest pointer and modifiers. */
interface BoxDrag { id: number; handle: BoxHandle; start: Rect; from: Point; fromView: Point; moved: boolean; last: Point; modifiers: DragModifiers }

/** The handle under a content point, as the editor's `handles` option allows: all eight and move, or move only. */
function editHit(box: Rect, p: Point, handles: "resize" | "move", tolerance: number): BoxHandle | null {
  if (handles === "resize") return handleAt(box, p.x, p.y, tolerance);
  const inside = p.x >= box.x && p.x <= box.x + box.width && p.y >= box.y && p.y <= box.y + box.height;
  return inside ? "move" : null;
}

/** The box editor on one surface: each pointer and key event is one method. */
class BoxEditor {
  private drag: BoxDrag | null = null;
  /** Whether the surface's cursor is the editor's; the surface's own is given back when it is not. */
  private ownsCursor = false;
  private readonly doc: Document;

  constructor(private readonly options: BoxEditOptions) {
    this.doc = options.document ?? document;
  }

  private scale(): number { return this.options.scale?.() ?? 1; }

  private toContent(e: PointerEvent): Point {
    if (this.options.toContent) return this.options.toContent(e.clientX, e.clientY);
    const r = this.options.surface.getBoundingClientRect();
    return { x: (e.clientX - r.left) / this.scale(), y: (e.clientY - r.top) / this.scale() };
  }

  private hit(e: PointerEvent): BoxHandle | null {
    const box = this.options.box();
    return box ? editHit(box, this.toContent(e), this.options.handles ?? "resize", handleHit(e.pointerType) / this.scale()) : null;
  }

  private setCursor(handle: BoxHandle | null): void {
    const { style } = this.options.surface;
    if (handle) { style.cursor = BOX_CURSORS[handle]; this.ownsCursor = true; }
    else if (this.ownsCursor) { style.cursor = ""; this.ownsCursor = false; }
  }

  private apply(): void {
    const d = this.drag;
    if (d) this.options.onDrag(dragBox(d.start, d.handle, d.last.x - d.from.x, d.last.y - d.from.y, this.options.bounds?.(), this.options.minSize, d.modifiers), d.handle);
  }

  private end(): void {
    this.drag = null;
    this.doc.removeEventListener("keydown", this.key, true);
    this.doc.removeEventListener("keyup", this.key, true);
  }

  /** A plain press on a handle starts a drag; Shift, Cmd or Ctrl at the press is the selection's (add, toggle). */
  readonly down = (e: PointerEvent): void => {
    if (e.button !== 0 || this.drag || e.shiftKey || e.metaKey || e.ctrlKey) return;
    const handle = this.hit(e), start = this.options.box();
    if (!handle || !start) return;
    // The press is the box editor's: no other listener, on the surface or above it, takes it for a selection.
    e.preventDefault();
    e.stopImmediatePropagation();
    const from = this.toContent(e);
    this.drag = { id: e.pointerId, handle, start: { ...start }, from, fromView: { x: e.clientX, y: e.clientY }, moved: false, last: from, modifiers: dragModifiers(e) };
    this.options.surface.setPointerCapture?.(e.pointerId);
    this.doc.addEventListener("keydown", this.key, true);
    this.doc.addEventListener("keyup", this.key, true);
  };

  /** Without a drag the cursor follows the handle under the pointer; with one, 5 px starts it and every move applies. */
  readonly move = (e: PointerEvent): void => {
    const d = this.drag;
    if (!d) { this.setCursor(this.hit(e)); return; }
    if (e.pointerId !== d.id) return;
    if (!d.moved && Math.hypot(e.clientX - d.fromView.x, e.clientY - d.fromView.y) < DRAG_THRESHOLD) return;
    d.moved = true;
    d.last = this.toContent(e);
    d.modifiers = dragModifiers(e);
    this.apply();
  };

  /** Release: one Undo step when the box changed. */
  readonly finish = (e: PointerEvent): void => {
    const d = this.drag;
    if (!d || e.pointerId !== d.id) return;
    this.end();
    this.options.surface.releasePointerCapture?.(e.pointerId);
    const box = this.options.box();
    if (d.moved && box) this.options.onEnd?.(box, d.handle);
  };

  /** Esc puts the box back; Shift or Option pressed or released during a drag applies at once, without a move. */
  readonly key = (e: KeyboardEvent): void => {
    const d = this.drag;
    if (!d) return;
    if (e.type === "keydown" && e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      this.end();
      if (d.moved) this.options.onDrag(d.start, d.handle);
      this.options.onCancel?.();
    } else if ((e.key === "Shift" || e.key === "Alt") && d.moved) {
      d.modifiers = dragModifiers(e);
      this.apply();
    }
  };

  readonly leave = (): void => { if (!this.drag) this.setCursor(null); };

  attach(): () => void {
    const { surface } = this.options;
    const events = [["pointermove", this.move], ["pointerup", this.finish], ["pointercancel", this.finish], ["pointerleave", this.leave]] as const;
    surface.addEventListener("pointerdown", this.down, true);
    for (const [type, listener] of events) surface.addEventListener(type, listener as EventListener);
    return () => {
      surface.removeEventListener("pointerdown", this.down, true);
      for (const [type, listener] of events) surface.removeEventListener(type, listener as EventListener);
      this.end();
      this.setCursor(null);
    };
  }
}

/**
 * Edit a box on a surface: the cursor shows the handle under the pointer, a drag of 5 px or more on a handle resizes
 * the box (on the inside, moves it) and Esc puts it back; Shift and Option apply as `dragBox` reads them. A plain press
 * on a handle is the box editor's, not the application's selection. Returns the function that stops it.
 */
export function attachBoxEdit(options: BoxEditOptions): () => void {
  return new BoxEditor(options).attach();
}
