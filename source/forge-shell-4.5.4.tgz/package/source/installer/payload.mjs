// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { createHash } from "node:crypto";
import { createReadStream, createWriteStream } from "node:fs";
import { chmod, mkdir, readdir, stat } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, sep } from "node:path";
import { Transform } from "node:stream";
import { pipeline } from "node:stream/promises";

async function walk(dir, base = dir) {
  const files = [];
  for (const entry of (await readdir(dir, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) files.push(...await walk(path, base));
    else if (entry.isFile()) files.push(relative(base, path).split(sep).join("/"));
  }
  return files;
}

async function sha256(path) {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest("hex");
}

/** List every file under `dir` with its size and SHA-256, for the setup to verify while copying. */
export async function buildManifest(dir, meta = {}) {
  const files = [];
  let bytes = 0;
  for (const path of await walk(dir)) {
    const size = (await stat(join(dir, path))).size;
    files.push({ path, size, sha256: await sha256(join(dir, path)) });
    bytes += size;
  }
  return { ...meta, bytes, files };
}

/** A manifest path must stay inside the destination: no absolute paths, no `..`. */
export function safeRelativePath(path) {
  const parts = String(path).split(/[\\/]/);
  if (!path || isAbsolute(path) || /^[a-zA-Z]:/.test(path) || parts.includes("..")) throw Object.assign(new Error(`Unsafe path in payload: ${path}.`), { code: "UNSAFE" });
  return join(...parts);
}

/**
 * Copy the payload and check every file against its manifest hash as it is written.
 * `onProgress({ done, total, file })` runs per chunk; `signal` aborts between and during files.
 */
export async function copyPayload({ source, manifest, destination, onProgress, signal }) {
  const total = manifest.files.reduce((sum, file) => sum + file.size, 0);
  let done = 0;
  for (const file of manifest.files) {
    signal?.throwIfAborted();
    const relativePath = safeRelativePath(file.path);
    const from = join(source, relativePath);
    const to = join(destination, relativePath);
    await mkdir(dirname(to), { recursive: true });
    const hash = createHash("sha256");
    const meter = new Transform({
      transform(chunk, _encoding, callback) {
        hash.update(chunk);
        done += chunk.length;
        onProgress?.({ done, total, file: file.path });
        callback(null, chunk);
      },
    });
    const streams = [createReadStream(from), meter, createWriteStream(to)];
    if (signal) await pipeline(...streams, { signal });
    else await pipeline(...streams);
    if (hash.digest("hex") !== file.sha256) throw Object.assign(new Error(`Checksum mismatch: ${file.path}.`), { code: "CHECKSUM", file: file.path });
    await chmod(to, (await stat(from)).mode & 0o777);
  }
  return { files: manifest.files.length, bytes: total };
}
