import assert from "node:assert/strict";
import { test } from "node:test";
import { codeShare, fitCode, fitOptions, optionsShare, optionsShareOf, restoreShare, tileMinimum } from "../../source/app/generator-layout";
import { PreviewScheduler, type PreviewBuild } from "../../source/app/preview-scheduler";
import { PREVIEW_MARGIN, PREVIEW_MAX_FIT, fitPreview, keepInView, zoomPreview } from "../../source/app/preview-stage";
import { fieldName, findField, parseValue, shownValue, type GeneratorGroup, type GeneratorValues } from "../../source/app/generator-fields";
import { generatorCompletions, runGeneratorCommand, type GeneratorTarget } from "../../source/app/generator-command";

test("a generator pane's options take a third to a half of it, never under 280 px, and the tiles share the rest", () => {
  assert.equal(fitOptions(1500, optionsShare.initial), 500);
  assert.equal(fitOptions(1500, 0.1), 500, "the tiles never take more than two thirds");
  assert.equal(fitOptions(1500, 0.9), 750);
  assert.equal(fitOptions(600, optionsShare.initial), 280);
  assert.equal(optionsShareOf(1500, 600), 0.4);
  assert.equal(fitCode(1001, codeShare.initial), 500);
  assert.equal(fitCode(1001, 0.9), 750, "the Code share is kept within its limits");
  assert.equal(fitCode(400, 0.5), tileMinimum, "a narrow pane keeps the minimum and scrolls sideways");
  assert.equal(restoreShare(340, optionsShare), optionsShare.initial, "a stored share out of range is dropped");
});

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
function harness(build: (code: string) => Promise<PreviewBuild<string>>) {
  const events: string[] = [];
  const scheduler = new PreviewScheduler<string>({ build, show: (preview) => events.push(`show ${preview}`),
    busy: (running) => events.push(running ? "busy" : "idle"), problem: (text) => events.push(`problem ${text}`) }, 20);
  return { scheduler, events };
}

test("a preview is built once typing pauses, from the newest code, and a build overtaken by newer code is dropped", async () => {
  const built: string[] = [];
  const { scheduler, events } = harness(async (code) => { built.push(code); await wait(code === "first" ? 40 : 0); return { preview: code, error: null }; });
  for (const code of ["a", "ab", "first"]) scheduler.request(code);
  await wait(30);
  scheduler.request("second");
  await wait(150);
  assert.deepEqual(built, ["first", "second"]);
  assert.deepEqual(events.filter((event) => event.startsWith("show")), ["show second"]);
  assert.equal(events.at(-1), "idle");
});

test("a repeated build problem is reported once, without Electron's prefix, and again after a good build", async () => {
  const { scheduler, events } = harness(async (code) => {
    if (code === "throw") throw new Error("Error invoking remote method 'preview': Error: python was not found.");
    return code.startsWith("bad") ? { preview: null, error: "line 2: name 'y' is not defined." } : { preview: code, error: null };
  });
  for (const code of ["bad1", "bad2", "good", "bad3", "throw"]) { scheduler.request(code); await wait(40); }
  assert.deepEqual(events.filter((event) => event.startsWith("problem") || event.startsWith("show")),
    ["problem line 2: name 'y' is not defined.", "show good", "problem line 2: name 'y' is not defined.", "problem python was not found."]);
});

test("a plot or image fits whole and centred, a table fits its width from the top, and neither is blown up", () => {
  const stage = { width: 432, height: 232 };
  const plot = fitPreview({ width: 800, height: 400 }, stage, "contain");
  assert.equal(plot.scale, 0.5, "the width limits it: (432 − 32) / 800");
  assert.equal(plot.oy, (232 - 200) / 2);
  assert.equal(plot.ox, (432 - 400) / 2);
  const table = fitPreview({ width: 800, height: 2000 }, stage, "width");
  assert.equal(table.scale, 0.5);
  assert.equal(table.oy, PREVIEW_MARGIN, "a long table starts at its top");
  assert.equal(fitPreview({ width: 100, height: 40 }, stage, "width").scale, PREVIEW_MAX_FIT.width, "a narrow table stays at its text size");
  assert.equal(fitPreview({ width: 40, height: 20 }, stage, "contain").scale, PREVIEW_MAX_FIT.contain, "a small image at most twice its size");
  assert.deepEqual(fitPreview({ width: 0, height: 0 }, stage, "contain"), { scale: 1, ox: 0, oy: 0, fitting: true });
});

test("zooming a preview keeps the point under the pointer still and stops fitting", () => {
  const view = zoomPreview({ scale: 1, ox: 10, oy: 20, fitting: true }, 2, 110, 120);
  assert.equal(view.scale, 2);
  assert.equal((110 - view.ox) / view.scale, 100 - 0, "the content point (100, 100) stays under (110, 120)");
  assert.equal((120 - view.oy) / view.scale, 100);
  assert.equal(view.fitting, false);
  assert.equal(zoomPreview(view, 1000, 0, 0).scale, 12, "at most 12×");
});

const groups: GeneratorGroup[] = [
  { title: "Data", fields: [{ kind: "select", key: "source", label: "Source", tip: "The data.", choices: [["function", "Function"], ["---", ""], ["data.csv", "data.csv"]] }] },
  { title: "Format", fields: [
    { kind: "text", key: "xlabel", label: "X label", tip: "The x axis label." },
    { kind: "check", key: "grid", label: "Grid", tip: "Grid lines." },
    { kind: "text", key: "locked", label: "Locked", tip: "Not now.", disabled: true },
  ] },
];

test("a pane's fields are named at the prompt by their label in lower case with hyphens, or by their key", () => {
  assert.equal(fieldName({ label: "X label" }), "x-label");
  assert.equal(findField(groups, "X-LABEL")?.key, "xlabel");
  assert.equal(findField(groups, "xlabel")?.key, "xlabel");
  assert.deepEqual(parseValue(findField(groups, "grid")!, "on"), { value: true });
  assert.deepEqual(parseValue(findField(groups, "grid")!, "yes"), { problem: "Grid takes on or off." });
  assert.deepEqual(parseValue(findField(groups, "source")!, "function"), { value: "function" });
  assert.deepEqual(parseValue(findField(groups, "source")!, "nope"), { problem: "Source takes one of: Function, data.csv." }, "the rule between choices is not one");
  assert.deepEqual(parseValue(findField(groups, "xlabel")!, "none"), { value: "" });
  assert.equal(shownValue(findField(groups, "xlabel")!, ""), "none");
  assert.equal(shownValue(findField(groups, "source")!, "function"), "Function");
});

function target(): GeneratorTarget & { opened: number; saved: number } {
  const values: GeneratorValues = { source: "function", xlabel: "Time (s)", grid: true, locked: "" };
  return {
    noun: "plot", opened: 0, saved: 0, values,
    groups: () => groups,
    set(patch) { Object.assign(values, patch); },
    canSave: () => true,
    save() { this.saved++; },
  };
}

test("the Terminal opens a generator pane, and reads and sets its options in the query, change and already forms", async () => {
  const pane = target();
  const open = () => { pane.opened++; };
  assert.deepEqual(await runGeneratorCommand(pane, [], open), {});
  assert.equal(pane.opened, 1, "the noun alone opens the pane");
  assert.deepEqual(await runGeneratorCommand(pane, ["x-label"], open), { lines: ["X label is Time (s)."] });
  assert.deepEqual(await runGeneratorCommand(pane, ["x-label", "Voltage", "(V)"], open), { lines: ["X label set to Voltage (V)."] });
  assert.equal(pane.values.xlabel, "Voltage (V)");
  assert.equal(pane.opened, 2, "a change opens the pane to show it");
  assert.deepEqual(await runGeneratorCommand(pane, ["grid", "on"], open), { lines: ["Grid is already on."] });
  assert.deepEqual(await runGeneratorCommand(pane, ["grid", "off"], open), { lines: ["Grid set to off."] });
  assert.deepEqual(await runGeneratorCommand(pane, ["colour", "red"], open), { lines: ["Unknown plot field: colour. Type plot fields to list them."] });
  assert.deepEqual(await runGeneratorCommand(pane, ["locked", "x"], open), { lines: ["Locked cannot be set now."] });
  await runGeneratorCommand(pane, ["save"], open);
  assert.equal(pane.saved, 1);
  const fields = await runGeneratorCommand(pane, ["fields"], open);
  assert.deepEqual(fields.columns?.map((item) => item.label), ["source", "x-label", "grid", "locked"]);
  assert.deepEqual(generatorCompletions(pane, "g"), ["grid"]);
  assert.deepEqual(generatorCompletions(pane, "grid o"), ["on", "off"]);
  assert.deepEqual(generatorCompletions(pane, "source "), ["function", "data.csv"]);
});

test("a preview cannot be moved away from what it shows: small content stays inside, large content keeps covering", () => {
  const stage = { width: 400, height: 300 };
  const view = (scale: number, ox: number, oy: number) => ({ scale, ox, oy, fitting: false });
  const small = keepInView(view(1, -500, 900), { width: 200, height: 100 }, stage);
  assert.deepEqual([small.ox, small.oy], [PREVIEW_MARGIN, 300 - PREVIEW_MARGIN - 100], "dragged far off, a small image stops at the edge");
  const inside = keepInView(view(1, 100, 80), { width: 200, height: 100 }, stage);
  assert.deepEqual([inside.ox, inside.oy], [100, 80], "within the stage it moves freely");
  const large = keepInView(view(1, 300, -2000), { width: 1000, height: 800 }, stage);
  assert.deepEqual([large.ox, large.oy], [PREVIEW_MARGIN, 300 - PREVIEW_MARGIN - 800], "a large one shows no more than the margin past its edge");
});
