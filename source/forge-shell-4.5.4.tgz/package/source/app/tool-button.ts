// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { shortcutText } from "./menus";

export interface ToolButtonOptions {
  id: string;
  /** SVG markup from `TOOL_ICONS` or `toolIcon`. */
  icon: string;
  /** The action name, as in the action registry. It becomes the accessible name and the start of the tooltip. */
  label: string;
  /** The registry accelerator (`CmdOrCtrl+Z`). It is shown with platform glyphs and never typed by hand. */
  shortcut?: string;
  /** Placement guidance, for a placement mode only. */
  placement?: string;
  enabled?: boolean;
}

/** The tooltip: `Action (shortcut)`, then the placement guidance when there is one. */
export function toolTooltip(options: Pick<ToolButtonOptions, "label" | "shortcut" | "placement">, display: (key: string) => string = shortcutText): string {
  const base = options.shortcut ? `${options.label} (${display(options.shortcut)})` : options.label;
  return options.placement ? `${base}: ${options.placement}` : base;
}

/** A toolbar button with its tooltip and accessible name. States come from the shared `.tool` classes. */
export function createToolButton(options: ToolButtonOptions, doc: Pick<Document, "createElement"> = document): HTMLButtonElement {
  const element = doc.createElement("button");
  element.type = "button";
  element.className = "tool";
  element.dataset.tool = options.id;
  element.innerHTML = options.icon;
  element.title = toolTooltip(options);
  element.setAttribute("aria-label", options.label);
  element.disabled = options.enabled === false;
  return element;
}
