import assert from "node:assert/strict";
import { test } from "node:test";
import { installWorkspaceKeys } from "../../source/app/workspace-keys.js";

test("workspace keys route shell shortcuts and leave canvas navigation to app callbacks", () => {
  const previousDocument = globalThis.document;
  const previousElement = globalThis.Element;
  const previousHTMLElement = globalThis.HTMLElement;
  const listeners = new Map<string, (event: KeyboardEvent) => void>();
  globalThis.document = {
    addEventListener: (name: string, listener: (event: KeyboardEvent) => void) => { listeners.set(name, listener); },
    removeEventListener: (name: string) => { listeners.delete(name); },
  } as unknown as Document;
  globalThis.Element = class {} as typeof Element;
  globalThis.HTMLElement = class {} as typeof HTMLElement;
  try {
    const events: string[] = [];
    let hasDocuments = true;
    const dispose = installWorkspaceKeys({
      desktop: false, hasDocuments: () => hasDocuments, typingInField: () => false,
      shortcuts: () => [], run: (id) => { events.push(id); },
      escape: () => { events.push("escape"); },
      domainKeyDown: (event) => {
        if (event.key === " " && !event.repeat) events.push("space down");
        if (event.key === "ArrowLeft") events.push(`ArrowLeft ${event.shiftKey ? 4 : 1}`);
        if (event.key === "r") events.push("tool:Resistor");
        return [" ", "ArrowLeft", "r"].includes(event.key);
      },
      domainKeyUp: (event) => { if (event.key === " ") events.push("space up"); },
    });
    const send = (name: string, key: string, extras: Record<string, unknown> = {}) => {
      let prevented = false;
      listeners.get(name)!({ key, target: {}, metaKey: false, ctrlKey: false, altKey: false, shiftKey: false,
        repeat: false, preventDefault: () => { prevented = true; }, ...extras } as KeyboardEvent);
      return prevented;
    };
    assert.equal(send("keydown", " "), true);
    assert.equal(send("keydown", " ", { repeat: true }), true);
    send("keyup", " ");
    assert.equal(send("keydown", "ArrowLeft", { shiftKey: true }), true);
    assert.equal(send("keydown", "r"), true);
    assert.equal(send("keydown", "Backspace"), false);
    send("keydown", "Escape");
    hasDocuments = false;
    assert.equal(send("keydown", "r"), false);
    assert.deepEqual(events, ["space down", "space up", "ArrowLeft 4", "tool:Resistor", "escape"]);
    dispose();
    assert.equal(listeners.size, 0);
  } finally {
    globalThis.document = previousDocument;
    globalThis.Element = previousElement;
    globalThis.HTMLElement = previousHTMLElement;
  }
});
