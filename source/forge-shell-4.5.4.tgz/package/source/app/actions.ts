// Licensed under the GNU General Public License v2 or later. See LICENSE.

export interface ShellActions<Document> {
  documents(): readonly Document[];
  activeDocument(): Document;
  activate(document: Document): void;
  createDocument(): void;
  newWindow(): void;
  open(): void | Promise<void>;
  save(as: boolean): void | Promise<unknown>;
  close(document: Document): void | Promise<void>;
  showAbout(): void;
  showWhatsNew(): void;
  showShortcuts(): void;
  showLicenses(): void;
  /** Help › Check for updates…, for an application whose profile names its repository. */
  checkForUpdates?(): void;
}

/** Dispatch the document, tab, and information actions shared by Forge apps. */
export async function dispatchShellAction<Document>(id: string, actions: ShellActions<Document>): Promise<boolean> {
  switch (id) {
    case "file.new": actions.createDocument(); break;
    case "file.newWindow": actions.newWindow(); break;
    case "file.open": void actions.open(); break;
    case "file.save": await actions.save(false); break;
    case "file.saveAs": await actions.save(true); break;
    case "file.close": await actions.close(actions.activeDocument()); break;
    case "tab.next":
    case "tab.prev": {
      const documents = actions.documents();
      if (!documents.length) break;
      const index = documents.indexOf(actions.activeDocument()) + (id === "tab.next" ? 1 : -1);
      actions.activate(documents[(index + documents.length) % documents.length]);
      break;
    }
    case "about": actions.showAbout(); break;
    case "about.whatsNew": actions.showWhatsNew(); break;
    case "about.shortcuts": actions.showShortcuts(); break;
    case "about.licenses": actions.showLicenses(); break;
    case "about.updates": if (!actions.checkForUpdates) return false; actions.checkForUpdates(); break;
    default: return false;
  }
  return true;
}
