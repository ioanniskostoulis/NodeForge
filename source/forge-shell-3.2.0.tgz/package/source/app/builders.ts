// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { attachRename, type RenameOptions } from "./rename";

/** Small DOM builders so apps stop hand-writing chrome markup. Alignment, spacing and text roles come from the shell stylesheet. */
type Doc = Pick<Document, "createElement">;

export interface ButtonOptions {
  label: string;
  primary?: boolean;
  disabled?: boolean;
  title?: string;
  onClick?(event: Event): void;
}

/** A standard panel button; `primary` uses the accent fill. */
export function createButton(options: ButtonOptions, doc: Doc = document): HTMLButtonElement {
  const button = doc.createElement("button");
  button.type = "button";
  button.className = options.primary ? "panel-button primary" : "panel-button";
  button.textContent = options.label;
  if (options.title) button.title = options.title;
  button.disabled = options.disabled === true;
  const onClick = options.onClick;
  if (onClick) button.addEventListener("click", (event) => { if (button.getAttribute("aria-busy") !== "true") onClick(event); });
  return button;
}

/** A button group: one row across the section's width, the buttons sharing it equally (`.buttons`). */
export function createButtonGroup(buttons: readonly HTMLButtonElement[], doc: Doc = document): HTMLDivElement {
  const group = doc.createElement("div");
  group.className = "buttons";
  group.append(...buttons);
  return group;
}

/**
 * Lines that describe the item under the pointer or selected (`.info-lines`): the item's name first, in the UI font,
 * then its values in mono, one per line; with no item, the `empty` sentence in quiet text. `show(null)` returns to it.
 */
export function createInfoLines(empty: string, doc: Doc = document): { element: HTMLDivElement; show(lines: readonly string[] | null): void } {
  const element = doc.createElement("div");
  element.className = "info-lines";
  const show = (lines: readonly string[] | null) => {
    element.replaceChildren(...(lines?.length ? lines.map((line, index) => Object.assign(doc.createElement("span"), { className: index === 0 ? "first" : "", textContent: line }))
      : [Object.assign(doc.createElement("span"), { className: "muted", textContent: empty })]));
  };
  show(null);
  return { element, show };
}

/** A labelled field: the label on the left, the control in the shared 108 px column. */
export function createField(label: string, control: HTMLElement, doc: Doc = document): HTMLLabelElement {
  const row = doc.createElement("label");
  row.className = "field";
  const caption = doc.createElement("span");
  caption.className = "label";
  caption.textContent = label;
  row.append(caption, control);
  return row;
}

/** A property row: label on the left, value on the right. With `rename`, the value renames in place (double-click, F2, context menu). */
export function createRow(label: string, value: string, doc: Doc = document, rename?: RenameOptions): HTMLDivElement {
  const row = doc.createElement("div");
  row.className = "row";
  const caption = doc.createElement("span");
  caption.className = "label";
  caption.textContent = label;
  const text = doc.createElement("span");
  text.className = "value";
  text.textContent = value;
  row.append(caption, text);
  if (rename) attachRename(text, rename);
  return row;
}

/** The numbered-list marker used by Terminal and information dialogs: `[  1]` padded to six characters. */
export function listMarker(index: number): string {
  return `[${index}]`.padStart(6);
}

export interface ListLineOptions {
  marker?: string;
  text: string;
  detail?: string;
}

/** A list line: marker, text in the mono role, and an optional quiet detail. */
export function createListLine(options: ListLineOptions, doc: Doc = document): HTMLDivElement {
  const line = doc.createElement("div");
  line.className = "list-line";
  if (options.marker !== undefined) {
    const marker = doc.createElement("span");
    marker.className = "t-marker";
    marker.textContent = options.marker;
    line.append(marker);
  }
  const text = doc.createElement("span");
  text.className = "t-mono";
  text.textContent = options.text;
  line.append(text);
  if (options.detail) {
    const detail = doc.createElement("span");
    detail.className = "t-quiet";
    detail.textContent = options.detail;
    line.append(detail);
  }
  return line;
}

/** Show a button as busy: the in-progress label, `aria-busy`, and ignored clicks. Pass `null` to restore the label. */
export function setButtonBusy(button: HTMLButtonElement, busyLabel: string | null): void {
  if (busyLabel === null) {
    if (button.dataset.idleLabel !== undefined) button.textContent = button.dataset.idleLabel;
    delete button.dataset.idleLabel;
    button.removeAttribute("aria-busy");
    button.removeAttribute("aria-disabled");
    return;
  }
  if (button.dataset.idleLabel === undefined) button.dataset.idleLabel = button.textContent ?? "";
  button.textContent = busyLabel;
  button.setAttribute("aria-busy", "true");
  button.setAttribute("aria-disabled", "true");
}

/** A checkbox with its label to the right, in the inspector's field style. */
export function createCheckRow(label: string, checked: boolean, onChange: (checked: boolean) => void, doc: Doc = document): HTMLLabelElement {
  const row = doc.createElement("label");
  row.className = "field check";
  const box = doc.createElement("input");
  box.type = "checkbox";
  box.checked = checked;
  box.addEventListener("change", () => onChange(box.checked));
  const text = doc.createElement("span");
  text.className = "label";
  text.textContent = label;
  row.append(box, text);
  return row;
}

/** A row of chips, one of which is chosen, such as a plot's kind; the arrow keys move between them. */
export function createChips(choices: readonly { value: string; label: string }[], chosen: string, onChoose: (value: string) => void, doc: Doc = document): HTMLDivElement {
  const row = doc.createElement("div");
  row.className = "chips";
  row.setAttribute("role", "radiogroup");
  const buttons = choices.map((choice) => {
    const chip = doc.createElement("button");
    chip.type = "button";
    chip.className = "chip";
    chip.textContent = choice.label;
    chip.setAttribute("role", "radio");
    chip.addEventListener("click", () => { select(choice.value); onChoose(choice.value); });
    return chip;
  });
  const select = (value: string) => buttons.forEach((chip, index) => { const on = choices[index].value === value; chip.setAttribute("aria-checked", String(on)); chip.tabIndex = on ? 0 : -1; });
  select(chosen);
  row.addEventListener("keydown", (event) => {
    if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
    const index = buttons.findIndex((chip) => chip.getAttribute("aria-checked") === "true");
    const next = (index + (event.key === "ArrowRight" ? 1 : -1) + buttons.length) % buttons.length;
    event.preventDefault(); buttons[next].click(); buttons[next].focus();
  });
  row.append(...buttons);
  return row;
}

/** A tile: a titled card with an optional readout at the right of its head, and its body. */
export function createTile(title: string, body: HTMLElement[], readout = "", doc: Doc = document): HTMLDivElement {
  const tile = doc.createElement("div");
  tile.className = "tile";
  const head = doc.createElement("div");
  head.className = "tile-head";
  head.append(Object.assign(doc.createElement("span"), { className: "tile-title", textContent: title }), Object.assign(doc.createElement("span"), { className: "tile-readout", textContent: readout }));
  tile.append(head, ...body);
  return tile;
}

/** A heading for a group of fields inside a section, and a problem line under a field (empty hides it). */
export function createGroupHeading(text: string, doc: Doc = document): HTMLDivElement {
  return Object.assign(doc.createElement("div"), { className: "field-group", textContent: text });
}
export function setProblem(element: HTMLElement, text: string): void {
  element.classList.add("field-problem");
  element.textContent = text;
  element.hidden = !text;
}
