# Forge application guidelines: Terminal and messages

Part of [GUIDELINES.md](GUIDELINES.md), sections 7 to 10.

## 7. Terminal and commands

The exact rules of each command's registry entry, forms and help, and the shared commands, are in [TERMINAL.md](TERMINAL.md); this section gives the Terminal itself and the layout of help.

Terminal is the command console of an application and not an operating-system shell. It starts with the decorative text wordmark of the application, a one-line purpose followed by `v<VERSION>`, the line `Type help to list commands.` and a `> ` prompt. The wordmark and the prompt use the accent, an echoed command uses bold `--text`, and explanations use `--text2`. The text is selectable, and the input has autocapitalisation and spellcheck switched off. The default font is 12 px/1.4 mono, and the font-size setting is clamped to 10 to 24 px. The region, the output log, the status and the input have accessible names, and new output is announced politely.

The command verbs are lowercase. The bare `help` overview begins `help <command> for details. <value> required; [value] optional.` and then shows categories with initial capitals: `File`, `Edit` and `View` first when present, then the domain categories in menu order, then categories outside the menus such as `Analysis`, and `Console` last for `help`, `history` and `clear`. Within a category the rows are sorted by bare verb.

| Subject | Specification |
|---|---|
| Overview row | Only the lowercase command verb and one short sentence describing its purpose; no syntax, arguments, placeholders, subcommands, choices, pipes or bracketed options appear in the command column. `theme` is shown instead of `theme [dark|light]`, `insert` instead of `insert section|figure|table`, and `edit` instead of `edit <path>`. The full syntax is stored in the registry and rendered only by `help <command>`. |
| Detail view | The accepted forms, choices, notes and an example. A subcommand may have its own topic (`help plot scale`). `<value>` is required and `[value]` optional. |
| Overview layout | One column below a Terminal container width of 900 px and two columns from 900 px, with a 3ch column gap. A category heading has 0.7em of top spacing and is bold 12 px mono `--text`. A row has a command label column of at least 12ch (or the longest verb plus 1ch, whichever is wider) followed by a muted description. A bare verb is bold 12 px mono `--accent` and a description 12 px mono `--text2`. A row stays within one column, and the description wraps. |
| Detail layout | One column with muted syntax and choice rows and `Example` last |
| Registry | The command registry drives validation, help and Tab completion; compatibility aliases are accepted but absent from the main help list |
| Errors | Invalid syntax shows the valid forms (see Help text); a document-only command without a document answers `Open a <document noun> first.` with the noun of the profile |
| State | A query form reports state without changing it, and a mutation reports the resulting state; binary states are `on` and `off` |

### Standard items

Every standard action has one menu label, one key and one Terminal command, the same in every application (`STANDARD_ITEMS`). An application builds its menu items with `standardItem(action)` and never writes their labels or keys itself; it chooses only which standard items it has. `checkShortcuts` reports a standard action on any other key.

| Action | Menu item | Key (macOS; Ctrl for Cmd on Windows) | Terminal |
|---|---|---|---|
| `file.new`, `file.newWindow` | New `<noun>`, New window | Cmd+N, Shift+Cmd+N | `new` |
| `file.open` | Open… | Cmd+O | `open` |
| `file.save`, `file.saveAs` | Save, Save as… | Cmd+S, Shift+Cmd+S | `save`, `save as` |
| `file.print` | Print… | Cmd+P | `print` |
| `file.close` | Close | Cmd+W | `close` |
| `app.settings` | Settings… | Cmd+, | |
| `edit.undo`, `edit.redo` | Undo, Redo | Cmd+Z, Shift+Cmd+Z | `undo`, `redo` |
| `edit.cut`, `edit.copy`, `edit.paste` | Cut, Copy, Paste (roles) | Cmd+X, Cmd+C, Cmd+V | |
| `edit.duplicate`, `edit.delete` | Duplicate, Delete | Cmd+D; Delete shown as ⌫ on macOS and Delete on Windows, handled by the application | |
| `edit.selectAll` | Select all (role) | Cmd+A | |
| `edit.find`, `edit.findNext`, `edit.findPrevious` | Find…, Find next, Find previous | Cmd+F, Cmd+G, Shift+Cmd+G | |
| `edit.replace` | Replace… | Option+Cmd+F on macOS, Ctrl+H on Windows | |
| `edit.goToLine`, `edit.toggleComment` | Go to line…, Toggle comment | Cmd+L, Cmd+/ | |
| `arrange.bringForward`, `arrange.sendBackward` | Bring forward, Send backward | Cmd+], Cmd+[ | |
| `arrange.bringToFront`, `arrange.sendToBack` | Bring to front, Send to back | Shift+Cmd+], Shift+Cmd+[ | |
| `view.zoomIn`, `view.zoomOut` | Zoom in, Zoom out | Cmd+=, Cmd+- | `zoom in`, `zoom out` |
| `view.fit` | Fit | Cmd+0 | `zoom fit` |
| `view.actualSize` | Actual size | Cmd+1 | `zoom actual` |
| `view.inspector`, `view.bottomPanel` | Show inspector, Show bottom panel (checked) | Cmd+I, Cmd+J | `inspector`, `panel` |
| `view.fullScreen` | Toggle full screen (role) | the platform's own: Ctrl+Cmd+F on macOS, F11 on Windows | |
| `tab.next`, `tab.prev` | Next tab, Previous tab | Ctrl+Tab, Ctrl+Shift+Tab on both | |
| `about`, `about.whatsNew`, `about.shortcuts`, `about.licenses` | About `<product>`, What's new…, Keyboard shortcuts…, Licenses… | none | `about`, `changes`, `shortcuts`, `licenses`, `updates` |

An item with a role is performed by the native menu (and by `EDIT_ROLES` in a drawn one); an application that handles the action itself, such as Copy on a canvas, passes `{ role: undefined }`. `arrangeItems(enabled)` gives the Arrange group in its order.

Fit is Cmd+0 and Actual size Cmd+1 in every application, as in Photoshop and Illustrator, so that one key fits the view everywhere. Space tapped twice within 350 ms on the work surface also runs Fit (`installWorkspaceKeys`; not on a focused control or in the bottom panel, and holding Space still reaches the application). Fit frames the selection when there is one and all the content when there is none (`fitBounds`). `zoomItems(enabled)` gives the View menu's zoom group in its order: Zoom in, Zoom out, Fit, Actual size. On Windows each key is Ctrl in place of Cmd.

### Shared commands

Every application has the shared Terminal commands of the actions it has (`SHARED_COMMANDS`, `sharedCommands(actions)`). Each runs a menu action by its standard identifier (`STANDARD_ACTIONS`), so a command does exactly what its menu item does, and an application lists only the actions it has; the others' commands do not appear. `runSharedCommand()` runs them, and `sharedHelpGroups()` gives their help groups.

| Group | Commands |
|---|---|
| File | `new`, `open`, `recent [number]` (lists the recent files, or opens one by its number), `save [as]`, `close`, `settings [page]` (opens Settings, on a page when named), and `autosave` where the settings have it |
| Edit | `undo`, `redo` |
| View | `zoom in\|out\|fit\|actual`, `panel`, `inspector`, `theme` |
| Help | `about`, `version`, `changes` (What's new), `shortcuts`, `licenses`; updates are offered on the welcome screen, not by a command |
| Console | `help`, `history`, `clear` |

`save`, `close`, `undo`, `redo` and `zoom` need an open document: on the welcome screen they are not listed, and run they answer `Open a <document noun> first.` An application adds its own commands after these, in its own groups.

**Generator panes.** A generator pane (Plots, Tables) is opened and filled from the Terminal by its noun (`runGeneratorCommand`): `plot` opens the pane; `plot fields` lists its options by their prompt names, the label in lower case with hyphens (`X label` is `x-label`); `plot x-label` says the value (`X label is Time (s).`); `plot x-label Time (s)` sets it and opens the pane (`X label set to Time (s).`, or `X label is already Time (s).`); a check takes `on` or `off`, a choice its value or label, and `none` empties a text. `plot save` does what the pane's Save does. `generatorCompletions` completes the field names and the values of checks and choices. An application lists the noun in its own group of help, after the shared commands.

**The prompt's caret.** The Terminal prompt draws the shared editor's caret instead of the native one: 1.5 px in the accent, gliding 80 ms between positions and fading in and out over the 1.2 s blink, solid again after each move and while typing. It is shown only while the prompt has the focus, nothing is selected and no command runs. Under reduced motion it jumps and blinks without fading.

### Help text

This subsection is the single rule for how help is written, laid out and coloured. It covers the Terminal `help` command, and its last part covers the command-line help of build and check scripts. Terminal help follows the conventions of command-line help (description, usage, options, defaults, a pointer to more), adapted to an application console in which commands are words and not flags.

**The three views.** Help has three outputs, all set in 12 px mono (`--console-size`) inside the Terminal.

| View | Command | Content |
|---|---|---|
| Overview | `help` | One legend line, then categories of bare verbs with one-line descriptions |
| Detail | `help <command>`, `help <command> <subcommand>` | Syntax forms, choices, notes and one example |
| Usage error | Any command typed with bad arguments | The valid forms, then a pointer to the detail view |

**Aliases.** `<command> -h`, `<command> --help` and `<command> ?` mean `help <command>`, and `-h` and `--help` alone mean `help`. Applications map them with `helpAlias()` of the shell. Aliases are accepted and never listed.

**Syntax notation.** A syntax string consists of the verb followed by its parts, separated by single spaces.

| Notation | Meaning | Example |
|---|---|---|
| `verb` | A literal lowercase word | `plot`, `list` |
| `<name>` | A required value | `open <file>` |
| `[<name>]` or `[name]` | An optional value | `history [number]` |
| `<name>...` | A required value that may repeat (rare) | `open <file>...` |
| `[<name>...]` | Any number of values, including none | `close [<tab>...]` |
| `a \| b` | A choice between literal words; listing them as choices is preferred | `on \| off` |

A placeholder name is a short, descriptive, lowercase word or hyphenated words (`<number>`, `<part>`, `<file-name>`); it names the kind of value and never an example of one. Literal words inside a form, such as `vs` or `in`, are not bracketed, which is why placeholders keep their angle brackets. `[options]` is not used: commands take subcommands and values and not flags. `checkCommandSyntax()` tests a syntax string against these rules, and every registry entry is expected to pass it.

**Overview layout.**

| Element | Specification |
|---|---|
| Legend line | Exactly `help <command> for details. <value> required; [value] optional.`, in `--text2` |
| Categories | In the order of section 7: `File`, `Edit`, `View`, application categories in menu order, other categories, `Console` last; empty categories are omitted |
| Category heading | The category name with an initial capital, bold `--text`, 0.7 em of space above; nothing follows it on its line |
| Row | One row per command, sorted by bare verb: the verb in bold `--accent`, padded to a shared column of at least 12 characters (or the longest verb plus 1 character, whichever is wider), then ` - ` and a description in `--text2` |
| Content of a row | No syntax, arguments, choices or brackets; the description wraps within its own column and the verb never wraps |
| Columns | One column below a Terminal width of 900 px and two columns from 900 px, with a gap of 3 characters; a row never splits across columns |

**Detail layout.** One column, without blank lines, in the following order.

| Order | Element | Specification |
|---|---|---|
| 1 | Syntax forms | One per line from column 0, in `--text2` at normal weight; a form with a description carries it after ` - `, also in `--text2`; several forms are padded to a common label width so that the dashes align |
| 2 | Choices | One per line, indented 3 characters: label, ` - `, description, padded to the widest choice label. The default choice ends its description with `(default)`, and without a description the row reads `label - (default)`. |
| 3 | Notes | Each a complete sentence on its own line from column 0, ending with a period |
| 4 | Example | Last, at most one: the label `Example`, ` - ` and a realistic command |

A subcommand with its own topic (`help plot scale`) shows only its own forms.

**Usage errors.** Bad arguments print `Invalid arguments. Usage:`, then every valid form indented 3 characters in the detail style (label, ` - `, description, aligned), then `Type help <command> for details.` The argument typed by the user is not repeated, and no stack trace or internal name is shown. A document-only command without a document answers `Open a <document noun> first.` instead.

**Wording.**

| Element | Rule |
|---|---|
| Descriptions | Short fragments of one line (about 70 characters or fewer): initial capital, no final period, beginning with a verb in the imperative (`Stack all scopes in one column`); they state what the command does and not how |
| Notes, errors, results | Sentences with a final period |
| Verbs, choices, placeholders | Lowercase; identifiers and file names keep their case; units are preceded by a space (`5 µs`) |
| Terms | One name for each concept across menu, toolbar, inspector, Terminal and help |
| Booleans and queries | `on` and `off`; a query form reports state without changing it |

**Colour, weight and indentation.** Help uses no other colours than those below, and never `--warning`, `--error`, underlining or uppercase. The only indent is 3 characters per level (`indent: 1` in a list item): choices and the forms of a usage error use level 1, and everything else starts at column 0.

| Element | Weight | Colour |
|---|---|---|
| Legend line, descriptions, syntax forms, choices, notes, `Example` | Normal | `--text2` |
| Category heading | Bold | `--text` |
| Command verb in the overview | Bold | `--accent` |
| Echoed command above the output | Bold | `--text` |
| First line and pointer line of a usage error | Normal | `--text2` |

**Welcome screen.** With no document open, help lists and details only the commands that run without one, in the same layout; a document-only topic answers `Open a <document noun> first.`

**Command-line help of scripts.** Build, check and release scripts (such as `forge-shell`) are programs and follow the usual command-line form: `-h` and `--help` print the help to standard output and exit with 0, and missing or wrong arguments print the help to standard error and exit with 2.

| Order | Section of the help |
|---|---|
| 1 | A one-sentence description of the program |
| 2 | `Usage: <name> command [options]` |
| 3 | `Commands:`, each with a short description |
| 4 | `Options:`, with the `-s, --long` forms on one line (short form first), the value name after the option and `(default: ...)` where one exists |
| 5 | `Environment:`, listing the environment variables that change behaviour |
| 6 | One line pointing to the detailed documentation |

Descriptions are aligned in one column and written as sentences with a final period, placeholders are lowercase `<value>`, and the whole text is narrower than 80 columns. `forge-shell --help` (`scripts/cli-help.mjs`) is the reference.

### Terminal with no document or project open

Terminal is selected and initialised on the welcome screen. It is not blank: unless the person has turned the banner off (`terminal banner off`, Settings › Terminal), it shows the same ASCII wordmark, purpose and version line, `Type help to list commands.`, selectable transcript area and `> ` input as with an open document. `clear` removes only transcript entries, and the banner, the prompt and the command history remain. The Terminal tab stays enabled while the document-only bottom tabs and inspector controls are dimmed.

| Subject | Specification |
|---|---|
| Overview in this state | Lists only the commands and forms that can run without a document. The shared minimum is `help`, `clear` and `history`, with `new` and `open` for applications that create and open documents; application-level appearance, settings, status and import commands are added only when they work in this state. The normal initial-capital headings and bare lowercase verbs are kept, and empty categories are omitted. File edits, builds, analyses and document-view commands are not shown until their document exists. |
| Document-only command | `help <command>` and execution answer `Open a <document noun> first.` with the noun of the profile |
| Completion | The empty prompt offers only the verbs and forms available on the welcome screen and no document-only choices. A command with application-level and document-level forms lists and completes only its application-level forms here. |
| Profile | Enumerates the exact welcome command set, the allowed forms, the response text and the completion behaviour; availability is not inferred from the existence of a menu item |

| Input behaviour | Specification |
|---|---|
| Keys | Enter submits; Up and Down traverse the command history; Tab inserts a sole completion or prints the alternatives; Esc leaves the input; Ctrl+C cancels a busy, cancellable command. |
| Busy state | During work the output is marked busy and the input is read-only. |
| History | At most 100 unique commands, or the 25 or 50 the person chose with `history limit` or in Settings › Terminal; a repeated command moves to the end. History belongs to the current document or session, is not saved, and is cleared when a different document opens. `clear` clears the transcript and preserves banner and history; `history`, `history <number>` and `history clear` manage the history. |
| Results | Console answers stay in Terminal and are not duplicated as status notifications. |

`help`, `clear` and `history` are shared verbs. Document-based applications use `new`, `open`, `save`, `export`, `tabs`, `tab`, `close`, `undo` and `redo` where the operations exist. Every other verb and its grammar belongs to the profile of the application, and circuit or LaTeX commands are not copied between applications merely to fill a catalogue. Names containing spaces are quoted, and command and file identifiers and technical abbreviations are preserved in results.

### Application-wide controls and commands

An application-wide command changes a window or a saved preference without modifying the open document. The inspector, the bottom-panel visibility, the selected utility tab, the appearance and the Terminal history are distinct states. The menu item, the shortcut and the Terminal command invoke the same state-changing operation. The shared forms below are implemented in every Forge application, since the inspector and the bottom panel are required controls of the shell. The profile lists every additional application-wide command with its exact forms, availability without a document, completion choices, output text and persistence. Domain commands such as a solver command or a build control are not shared merely because they can run without a document.

| Control | Terminal forms | Menu and keyboard | Shared behaviour |
|---|---|---|---|
| Inspector | `inspector`, `inspector on`, `inspector off`, `inspector left`, `inspector right` | View › Show inspector, checked while visible; `CmdOrCtrl+I` toggles | The bare verb toggles visibility; `on` and `off` set it explicitly and are idempotent; `left` and `right` set the side and show the inspector. Side and visibility are application preferences, shown in Settings › General as one Inspector row (Right, Left or Hidden). Without a document the inspector may be shown, but its document controls are dimmed and inert. |
| Bottom panel | `panel on`, `panel off`, `panel <pane>` | View › Show bottom panel (an application may name its utilities in the label), checked while visible; `CmdOrCtrl+J` toggles | `on` shows the panel with its previously selected utility; `off` hides the entire panel without clearing the Terminal output or changing the selected utility; `panel terminal` shows the panel and selects Terminal; `panel <pane>` shows the panel and selects that pane of the profile when usable. A click on a bottom tab selects it, and an unavailable tab is disabled. Visibility is an application preference and the selected utility a session state. A bare `panel` is invalid. |
| Appearance | `theme <appearance>` | View › Appearance, one checked choice | Every application accepts `dark` and `light`. Applying an appearance updates the preference and all open views, and `theme` without a value reports the current appearance. |
| Terminal history | `history`, `history <number>`, `history clear`, `clear` | Terminal input; a Clear control for the transcript is optional | `history` lists the previous commands, a non-negative count limits the listing, `history clear` empties the history, `history limit` shows or sets how many commands it keeps (25, 50 or 100) and `clear` empties only the transcript. Neither operation closes or hides Terminal, removes its banner or changes documents. |
| Help | `help`, `help <command>` | Terminal input; the Help menu may link to documentation | `help` lists only the bare verbs currently available, in initial-capital categories; the detailed form shows valid syntax and choices. Availability is checked against the state of the active document before completion is offered. |

The platform display of shortcuts is `⌘I` and `⌘J` on macOS and `Ctrl+I` and `Ctrl+J` on Windows. These are View actions and not text typed into Terminal. The checked menu state mirrors visibility and not the existence of a document. Showing and hiding a panel uses the 150 ms width or height and opacity transition of section 5, and a closed pane and its splitter become hidden and inert; selecting a utility starts no further transition when the panel is already visible. Terminal commands report their results in Terminal only.

| Result | Text |
|---|---|
| Inspector visibility | `Inspector enabled.`, `Inspector disabled.`, `Inspector is already on.`, `Inspector is already off.` |
| Bottom-panel visibility | `Bottom panel enabled.`, `Bottom panel disabled.`, `Bottom panel is already on.`, `Bottom panel is already off.` |
| Panel selection | `Showing terminal panel.`; with differently named panes, `Showing <lowercase pane name> panel.` |
| Inspector side | `Inspector moved to the left.`, `Inspector moved to the right.` |

The detailed topics `help inspector` and `help panel` enumerate these forms, whereas the bare `help` shows only `inspector` and `panel`.

## 8. Listings and reports

Lists and tables are produced with structured result types and are numbered from 1. A marker occupies six monospaced characters and is followed by exactly three spaces and the label. The number formula is `("[" + n + "]").padStart(6) + "   "`, and the state formula is `" ".repeat(Math.max(1, 6 - marker.length)) + marker + "   "`.

```text
   [9]   Item nine
  [10]   Item ten
 [100]   Item one hundred
  [on]   Enabled setting
 [off]   Disabled setting
```

| Element | Rendering |
|---|---|
| Numbers and enabled `[on]` | Bold `--accent` |
| `[off]` | Normal `--text2` |
| Enabled and numbered labels | Bold `--text` |
| Disabled labels and explanations | `--text2` |
| Numbered table | Marker in the accent, primary name bold `--text`, later fields `--text2` |
| Columns | Numeric columns are right-aligned and text columns left-aligned; wide tables scroll horizontally |
| Help and About | Command names in the accent with muted descriptions; the numbered rows of About and What's new use the same marker column and accent colour |
| Empty result | A statement of what is empty, such as `No messages.` or `No commands yet.` |

## 9. Status, Messages, errors and tips

The status bar displays the state of the application, a flexible readout and result field, the count of unseen problems and secondary readouts defined by the application. The result of an action appears in `--accent-light` for 4000 ms and is also added to the Messages log of the active document. The ordinary readout uses `--text2`, and a warning or error count uses `--warning`; a click on it opens Messages. The profile defines the state words and any domain-specific dot colours or measurements.

Messages belong to the active document, are limited to the session and retain the latest 500 entries, the newest last. Each row has the local time `HH:MM:SS`, the kind (`Info`, `Warning`, `Error`) and the text, in a grid with columns `9ch 8ch minmax(0,1fr)`. Info does not increment the count of unseen problems, whereas Warning and Error do, and opening Messages resets it. A referenced object name is an accent link that selects or opens the object. A standing condition is logged once when it appears, under a stable condition key, with a quiet period of 30,000 ms before a flickering condition is repeated. Clear empties the log and the count.

| Event | Destination |
|---|---|
| Result of a user action | Status for 4000 ms and Messages as Info |
| Failed action or document or run problem | Messages as Error; the status counts it |
| Degraded but usable state | Messages as Warning; the status counts it |
| Invalid inspector input | Status and Messages as Error; the inspector size remains fixed |
| Invalid dialog input | Beside the field |
| Terminal command result or invalid command | Terminal only |
| Short usage guidance | Tooltip of the relevant control |

A message states the result or problem first and then a recovery action when one is known. Each sentence has one purpose and a final period, and the same technical term is used everywhere. Saved, Built or Verified is not reported before it has happened. Tooltips are one short sentence, with a second only for an essential condition, and standing explanatory prose is kept out of compact inspector sections when a tooltip gives the guidance needed.

## 10. Dialogs, accessibility and persistence

A focused dialog serves a decision or a longer input. Wrong input is shown beside its field, the primary and cancel actions are distinct, and focus is restored on closing. An About window uses the neutral `--panel` and `--raised` surfaces, an accent wordmark, sentence-case headings, the credits and licensing of the application and the shared numbered-list format. What's new reads the section of the current version in the changelog and falls back to the newest section only when the current one is absent; an unavailable message is shown when neither exists. The third-party assets and licences actually used are documented in the `NOTICE.md` of the application.

| Subject | Specification |
|---|---|
| Focus | Keyboard focus on any element shows the shell's 1 px `--accent-light` ring (`:where(*):focus-visible`), never the browser's own blue ring; a click shows none. A part with its own focus style (a field's accent border, the editor's caret, a slider's thumb) keeps it. A name returned to after a rename has no ring until the next key. |
| Controls | Real buttons and inputs, accessible names for icon-only controls, visible focus rings, `aria-expanded` for folds and flyouts, `aria-live` for Terminal and status output, and text or icon state alongside colour |
| Keyboard | Editing shortcuts leave text fields usable. Menus show `⌘`, `⌥`, `⇧`, `⌃` and `⌫` on macOS and the Ctrl equivalents on Windows; text that names a key writes it out (`Esc`, `Return`, `Cmd + Delete`), never as `⎋`. The profile records exact shortcuts and platform exceptions. |
| Files | Desktop file operations use native dialogs. A browser edition documents its file-access limits and does not claim a save when only a download started. |
| Tests | `tests/conformance/accessibility.mjs` checks the shared focus styles, live output hooks and reduced-motion paths. Interface tests of an application exercise its icon names, tab navigation, flyouts, focus return and announcement text with the renderer running. |

### Remembered settings

A value is stored in exactly one of three places and never in two.

| Place | Holds | Lifetime |
|---|---|---|
| Application preferences | How the application looks and is set up: appearance, panel visibility and sizes, font sizes, the view options and units of the application | Every launch and every window, with or without a document |
| The document | Data, and any view setting that must reopen with it (for example a saved zoom or trigger) | The file |
| The session | Everything transient | Until the window closes |

**Shell preferences.** Every Forge application keeps the following values as preferences.

| Value | Default | Rule |
|---|---|---|
| `appearance` | `dark` | `dark` or `light`; applied before the first paint, so that the wrong theme never flashes. The hidden `pride` appearance, set only by `theme pride`, is stored too, and Settings shows it as Pride only while it is active |
| `showInspector`, `inspectorSide` | visible, right | Written by `inspector on\|off\|left\|right` and View › Show inspector |
| `inspectorWidth` | 246 px | Clamped to 246 to 420 px when loaded and dragged (`panelSize`) |
| `showBottomPanel` | visible | Written by `panel on\|off` and View › Show bottom panel |
| `bottomPanelHeight` | 246 px | Clamped to 246 to 640 px when loaded and dragged (`panelSize`); a short window shrinks a taller panel, never below 246 px |
| `terminalFontSize` | 12 px | Clamped to 10 to 24 px |
| Terminal preferences (`<id>.console.preferences`) | 100 commands, banner on, caret blinking, comfortable spacing, wrapping on | Kept by the shell, not in the application's settings: `historyLimit` is 25, 50 or 100, `lineSpacing` is `comfortable` (1.4 times the text size) or `compact` (1.2), and `banner`, `caretBlink` and `wrap` are booleans. Written by `history limit`, `terminal banner`, `terminal caret`, `terminal spacing`, `terminal wrap` and Settings › Terminal; any other value gives the default |

A splitter stores its size when the pointer is released, and a double click restores the default and stores it.

| Category | Content |
|---|---|
| Application preferences | The `Persistence` row of the profile lists every other preference by name, with default and valid values. The inspector sections are listed there too, each marked persistent or not: a persistent section keeps its folded state as a preference, and a non-persistent one returns to its default at every launch. |
| Session only | Never stored: the selected bottom pane (Terminal at launch and whenever a document becomes active), the active document tab, selection, hover, undo history, Terminal command history and the Messages log. Terminal history belongs to the open document and is not written to disk. |
| Not remembered | Window size and position are not a shell preference, and no Forge application restores them by default; an application that does records this in its profile. |

**Storage.**

| Step | Behaviour |
|---|---|
| 1. One object, one key | Preferences form a single JSON object under `<id>.settings` (`settingsStorageKey`), written through `createSettingsStore`. The whole object is written after each change and listeners are notified. |
| 2. Loading | The defaults are overlaid with the stored object through the `restore` function of the application. A missing or invalid value falls back to its default, and a key the application no longer defines is dropped, so that removed settings do not accumulate. |
| 3. Unavailable storage | Private mode, blocked site data or a command-line run: the application runs on its defaults for that session and shows no error. |
| 4. Renaming or changing a preference | `restore` maps the old name or value to the new one; the choice of a user is never silently reset by an update. |
| 5. Applying | Preferences apply with no document open, and the shell restores the appearance before the pre-paint script of the application (`prePaintScript`) runs. |

The profile of an application fills in the `Persistence` row with its own values, and this section is the only place that defines the shared ones.

