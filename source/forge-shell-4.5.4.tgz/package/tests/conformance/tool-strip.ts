import assert from "node:assert/strict";
import { test } from "node:test";
import { createToolButton, toolTooltip } from "../../source/app/tool-button";
import { createToolModes, modeLabel } from "../../source/app/tool-modes";
import { flyoutItemMarkup, flyoutTip } from "../../source/app/tool-flyout";
import { ICON_EXTENTS, iconScale, lucideIcon, POINTER_NUDGE_Y, POINTER_ROTATION, pointerIcon, STATUS_ICONS, TOOL_ICONS, toolIcon, UI_ICONS } from "../../source/app/tool-icons";

class Element {
  className = ""; title = ""; type = ""; innerHTML = ""; disabled = false; dataset: Record<string, string> = {}; attributes: Record<string, string> = {};
  setAttribute(name: string, value: string) { this.attributes[name] = value; }
}
const doc = { createElement: () => new Element() } as unknown as Pick<Document, "createElement">;
const mac = (key: string) => key.replace("CmdOrCtrl+", "⌘");
const windows = (key: string) => key.replace("CmdOrCtrl", "Ctrl");

test("the tooltip names the action, shows the shortcut from the registry and adds placement only when given", () => {
  assert.equal(toolTooltip({ label: "Undo", shortcut: "CmdOrCtrl+Z" }, mac), "Undo (⌘Z)");
  assert.equal(toolTooltip({ label: "Undo", shortcut: "CmdOrCtrl+Z" }, windows), "Undo (Ctrl+Z)");
  assert.equal(toolTooltip({ label: "Fit" }), "Fit");
  assert.equal(toolTooltip({ label: "Add wire", placement: "click to start, click to end" }), "Add wire: click to start, click to end");
});

test("a tool button has the shared class, an accessible name without the shortcut, and honours enabled", () => {
  const button = createToolButton({ id: "undo", icon: TOOL_ICONS.undo, label: "Undo", shortcut: "CmdOrCtrl+Z", enabled: false }, doc) as unknown as Element;
  assert.equal(button.className, "tool");
  assert.equal(button.attributes["aria-label"], "Undo");
  assert.equal(button.disabled, true);
  assert.equal(button.dataset.tool, "undo");
  assert.match(button.title, /^Undo \(/);
});

test("every shared icon uses the 16 px box, a 1.25 px visible line and currentColor", () => {
  for (const [name, svg] of Object.entries({ ...TOOL_ICONS, ...STATUS_ICONS, ...UI_ICONS })) {
    assert.match(svg, /width="16" height="16" viewBox="-1.3333 -1.3333 26.6667 26.6667"/, name);
    assert.match(svg, /stroke-width="2.0833"/, name);
    assert.match(svg, /stroke="currentColor"/, name);
  }
  assert.match(toolIcon("<path d='M0 0'/>"), /width="16" height="16" viewBox="0 0 16 16"[^>]*stroke-width="1.25"/);
  assert.match(lucideIcon("play", 12), /width="12" height="12"[^>]*stroke-width="2.7778"/);
});

test("the shared pointer uses the macOS rotation as its single source", () => {
  assert.equal(POINTER_ROTATION, 15);
  assert.equal(POINTER_NUDGE_Y, 0.62);
  assert.match(pointerIcon(), new RegExp(`<g transform="translate\\(0 ${POINTER_NUDGE_Y}\\) rotate\\(${POINTER_ROTATION} 12 12\\)">`));
  assert.equal(UI_ICONS.pointer, pointerIcon());
});

test("tool modes keep exactly one tool active and Escape returns to neutral", () => {
  const selected = new Set<string>();
  let label = "x";
  let onKey: (event: Event) => void = () => {};
  const modes = createToolModes({ setSelected: (id, on) => { if (on) selected.add(id); else selected.delete(id); }, setMode: (text) => { label = text; } }, () => {}, { addEventListener: (_n: string, l: unknown) => { onKey = l as (event: Event) => void; } } as never);
  modes.activate("wire", "Add", "wire");
  modes.activate("part", "Place", "resistor");
  assert.deepEqual([...selected], ["part"]);
  assert.equal(label, modeLabel("Place", "resistor"));
  assert.equal(label, "Place resistor. Press Esc to finish");
  onKey({ key: "Escape" } as unknown as Event);
  assert.deepEqual([...selected], []);
  assert.equal(label, "");
  assert.equal(modes.active, null);
});

test("a flyout row is a label and an optional shortcut, and a tool is a plain item, never checked", () => {
  const rect = { id: "rect", label: "Rectangle", icon: toolIcon("<path d='M2 2h12v12H2z'/>"), shortcut: "R" };
  const columns = (markup: string) => [...markup.matchAll(/<span class="(check|label[^"]*|key)"/g)].map((m) => m[1].split(" ")[0]);
  assert.deepEqual(columns(flyoutItemMarkup(rect)), ["label", "key"], "a tool is not checkable, so the row has no check column");
  assert.doesNotMatch(flyoutItemMarkup(rect), /✓/);
  assert.deepEqual(columns(flyoutItemMarkup({ ...rect, shortcut: undefined })), ["label"], "no shortcut, no key column");
  assert.equal(flyoutTip("Shapes", { ...rect, shortcut: undefined }), "Shapes: Rectangle");
});

test("every shared icon is measured for size normalization, except the ones small by design", async () => {
  const { LUCIDE_ICONS } = await import("../../source/app/lucide-icons");
  const smallByDesign = new Set(["close", "chevronRight", "chevronLeft", "chevronUp", "chevronDown", "more", "add", "remove", "check", "pointer"]);
  for (const name of Object.keys(LUCIDE_ICONS) as (keyof typeof LUCIDE_ICONS)[]) {
    if (smallByDesign.has(name)) assert.equal(ICON_EXTENTS[name], undefined, `${name} is left as drawn`);
    else assert.ok(ICON_EXTENTS[name], `${name} needs its measured extent in ICON_EXTENTS`);
  }
  assert.equal(iconScale("undo"), 1.125);
  assert.equal(iconScale("copy"), 0.9);
  assert.equal(iconScale("close"), 1);
  assert.match(lucideIcon("undo"), /scale\(1\.1250\)/);
  assert.doesNotMatch(lucideIcon("fit"), /scale\(/);
});

