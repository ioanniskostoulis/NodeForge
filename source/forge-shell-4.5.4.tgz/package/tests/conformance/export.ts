import assert from "node:assert/strict";
import { test } from "node:test";
import { choiceProblems } from "../../source/app/dialogs";
import { conflictList, conflictTitle, exportFileName, exportProblem, freeName, listFormats, planExport, resolveAsk, type ExportFormat } from "../../source/app/export-plan";
import { exportFiles, joinPath, type ExportBridge } from "../../source/app/export-files";
import { registerExportIpc } from "../../source/desktop/export-main";
import { createDesktopBridge, type IpcRendererPort } from "../../source/desktop/bridge";
import type { ShellIpcEvent } from "../../source/desktop/ipc-main";

const PNG: ExportFormat = { id: "png", name: "PNG image", extensions: ["png"], mime: "image/png" };
const JPEG: ExportFormat = { id: "jpeg", name: "JPEG image", extensions: ["jpg", "jpeg"], mime: "image/jpeg" };
const CSV: ExportFormat = { id: "csv", name: "CSV table", extensions: ["csv"], mime: "text/csv" };
const formats = [PNG, JPEG, CSV];

test("a choice has two or more answers, exactly one Cancel, at most one primary, and no repeated id or key", () => {
  const cancel = { id: "cancel", label: "Cancel", role: "cancel" as const };
  assert.deepEqual(choiceProblems([{ id: "replace", label: "Replace", role: "destructive" }, { id: "keep", label: "Keep both", role: "primary" }, cancel]), []);
  assert.match(choiceProblems([cancel]).join(" "), /at least two answers/);
  assert.match(choiceProblems([{ id: "a", label: "A", role: "primary" }, { id: "b", label: "B", role: "other" }]).join(" "), /exactly one Cancel/);
  assert.match(choiceProblems([{ id: "a", label: "A", role: "primary" }, { id: "b", label: "B", role: "primary" }, cancel]).join(" "), /at most one primary/);
  assert.match(choiceProblems([{ id: "a", label: "A", role: "primary", key: "d" }, { id: "b", label: "B", role: "other", key: "D" }, cancel]).join(" "), /own shortcut/);
});

test("an export never writes a project file or an original, and only the application's formats", () => {
  const rules = { formats, protectedPaths: ["/Users/me/Lens/Photo.PNG"], ignoreCase: true };
  assert.equal(exportProblem("/Users/me/out/photo.png", rules), null);
  assert.match(exportProblem("/Users/me/Lens/photo.png", rules)!, /photo\.png is an original of the document; originals are never written\./, "compared without case on macOS and Windows");
  assert.equal(exportProblem("/Users/me/Lens/photo.png", { ...rules, ignoreCase: false }), null, "Linux tells the cases apart");
  assert.match(exportProblem("/Users/me/out/lens.pfg", rules)!, /project file; projects are written by Save/);
  assert.match(exportProblem("/Users/me/out/lens.tif", rules)!, /^Exports are written as PNG, JPEG or CSV files only\.$/);
  assert.equal(listFormats([PNG]), "PNG");
});

test("exported names are clean, and Keep both writes the first free name without regard to case", () => {
  assert.equal(exportFileName("a/b: c.tif", PNG), "a-b- c.png");
  assert.equal(exportFileName("...", JPEG), "export.jpg");
  assert.equal(freeName("Photo.png", ["photo.png", "photo-1.png"]), "Photo-2.png");
  assert.equal(freeName("new.png", ["photo.png"]), "new.png");
});

test("an export into a folder asks, writes free names, or replaces after a confirmation, as the overwrite choice says", () => {
  const existing = ["a.png", "b.png"];
  const ask = planExport(["a.png", "c.png"], existing, "ask");
  assert.deepEqual([ask.ask, ask.confirm, ask.conflicts], [true, false, ["a.png"]]);
  assert.deepEqual(resolveAsk(["a.png", "c.png"], existing, "keep-both"), [{ name: "a-1.png", replaces: false }, { name: "c.png", replaces: false }]);
  assert.deepEqual(resolveAsk(["a.png", "c.png"], existing, "replace"), [{ name: "a.png", replaces: true }, { name: "c.png", replaces: false }]);
  const overwrite = planExport(["b.png"], existing, "overwrite");
  assert.deepEqual([overwrite.ask, overwrite.confirm], [false, true]);
  const free = planExport(["a.png", "a.png"], existing, "new-name");
  assert.deepEqual(free.writes.map((write) => write.name), ["a-1.png", "a-2.png"], "two exports of one name do not take the same free name");
  assert.deepEqual(planExport(["c.png"], existing, "ask"), { writes: [{ name: "c.png", replaces: false }], confirm: false, ask: false, conflicts: [] });
  assert.equal(conflictTitle(["a.png"]), "a.png already exists.");
  assert.equal(conflictTitle(["a", "b", "c"]), "3 files already exist.");
  assert.equal(conflictList(["1", "2", "3", "4", "5", "6", "7"]), "1, 2, 3, 4, 5 and 2 more");
});

/** The export IPC with a fake disk: the dialogs answer what `answers` holds. */
function harness() {
  const handlers = new Map<string, (event: ShellIpcEvent, ...args: unknown[]) => unknown>();
  const disk = new Map<string, string>([["/out/taken.png", "old"], ["/photos/lens.png", "original"]]);
  const answers = { save: null as string | null, folder: null as string | null };
  const filters: string[][] = [];
  const ipc = { on() {}, handle: (channel: string, handler: (event: ShellIpcEvent, ...args: unknown[]) => unknown) => { handlers.set(channel, handler); } };
  const dirname = (path: string) => path.replace(/\/[^/]*$/, "") || "/";
  const main = registerExportIpc(ipc, {
    formats, ignoreCase: true,
    protectedPaths: () => ["/photos/lens.png"],
    saveDialog: async (_event, options) => { filters.push(options.filters.map((filter) => filter.extensions.join("+"))); return answers.save; },
    folderDialog: async () => answers.folder,
    readdir: async (folder) => [...disk.keys()].filter((path) => dirname(path) === folder).map((path) => path.slice(folder.length + 1)),
    writeFile: async (path, bytes, flag) => {
      if (flag === "wx" && disk.has(path)) throw Object.assign(new Error("exists"), { code: "EEXIST" });
      disk.set(path, new TextDecoder().decode(bytes));
    },
    resolve: (path) => path, dirname,
  });
  const window = { sender: { id: 1 } }, other = { sender: { id: 2 } };
  const call = (channel: string, event: ShellIpcEvent, ...args: unknown[]) => Promise.resolve(handlers.get(channel)!(event, ...args));
  const bytes = (text: string) => new TextEncoder().encode(text);
  return { main, disk, answers, filters, window, other, call, bytes };
}

test("the desktop writes an export only where its window's export dialog chose, and never replaces a file by surprise", async () => {
  const { main, disk, answers, filters, window, other, call, bytes } = harness();
  await assert.rejects(call("writeExport", window, "/out/new.png", bytes("x")), /only where an export dialog chose/);
  answers.save = "/out/chart";
  assert.equal(await call("exportDialog", window, "chart.jpg", ["png", "jpeg"]), "/out/chart.jpg", "a name typed without an extension takes the suggested format's");
  assert.deepEqual(filters[0], ["jpg+jpeg", "png"], "the dialog opens on the suggested name's format and offers only the named ones");
  await call("writeExport", window, "/out/chart.jpg", bytes("chart"));
  assert.equal(disk.get("/out/chart.jpg"), "chart");
  await assert.rejects(call("writeExport", other, "/out/chart.jpg", bytes("x")), /only where an export dialog chose/, "another window's approval is not this one's");
  // its folder takes new files, but replaces one only when the person confirmed
  await assert.rejects(call("writeExport", window, "/out/taken.png", bytes("new")), /taken\.png already exists and was not replaced\./);
  assert.equal(disk.get("/out/taken.png"), "old");
  await call("writeExport", window, "/out/taken.png", bytes("new"), [], true);
  assert.equal(disk.get("/out/taken.png"), "new");
  // a folder chosen for several files lists its names
  answers.folder = "/photos";
  assert.deepEqual(await call("exportFolder", window), { folder: "/photos", names: ["lens.png"] });
  await assert.rejects(call("writeExport", window, "/photos/lens.png", bytes("x"), [], true), /original of the document/, "an original, even when Replace was confirmed");
  await assert.rejects(call("writeExport", window, "/photos/lens.pfg", bytes("x")), /project file/);
  await assert.rejects(call("writeExport", window, "/photos/other.png", bytes("x"), ["/photos/other.png"]), /original/, "the page names more originals");
  await assert.rejects(call("exportFolderNames", window, "/elsewhere/a.png"), /Only a folder an export dialog chose/);
  main.forget(1);
  await assert.rejects(call("writeExport", window, "/out/chart.jpg", bytes("x")), /only where an export dialog chose/, "a closed window's approvals are gone");
});

test("the page exports one file through the dialog, several into a folder, and downloads them in the browser preview", async () => {
  const writes: string[] = [];
  let folderNames = ["a.png"];
  const bridge: ExportBridge = {
    exportDialog: async (name, ids) => { writes.push(`dialog ${name} ${ids?.join(",")}`); return `/out/${name}`; },
    exportFolder: async () => ({ folder: "/out", names: folderNames }),
    exportFolderNames: async () => folderNames,
    writeExport: async (path, _bytes, originals, replace) => { writes.push(`write ${path} ${originals?.join(",")} ${replace}`); },
  };
  const item = (name: string, format = PNG) => ({ name, format, bytes: () => new Uint8Array([1]) });
  const host = { bridge, formats, overwrite: "new-name" as const, protectedPaths: () => ["/photos/lens.png"] };
  assert.deepEqual(await exportFiles(host, [item("chart.tif", JPEG)]), { written: ["/out/chart.jpg"] });
  assert.deepEqual(writes.splice(0), ["dialog chart.jpg jpeg,png,csv", "write /out/chart.jpg /photos/lens.png true"]);
  assert.deepEqual(await exportFiles(host, [item("a"), item("b")]), { written: ["/out/a-1.png", "/out/b.png"] });
  assert.deepEqual(writes.splice(0), ["write /out/a-1.png /photos/lens.png false", "write /out/b.png /photos/lens.png false"]);
  folderNames = [];
  const downloads: string[] = [];
  assert.deepEqual(await exportFiles({ ...host, bridge: null, download: (name, _bytes, mime) => downloads.push(`${name} ${mime}`) }, [item("a"), item("t", CSV)]), { written: ["a.png", "t.csv"] });
  assert.deepEqual(downloads, ["a.png image/png", "t.csv text/csv"]);
  assert.equal(joinPath("C:\\out", "a.png"), "C:\\out\\a.png");
  assert.equal(joinPath("/out/", "a.png"), "/out/a.png");
});

test("the desktop bridge sends the export calls on their channels", async () => {
  const calls: unknown[][] = [];
  const ipc: IpcRendererPort = { send() {}, on() { return undefined; }, invoke: async (...args) => { calls.push(args); return null; } };
  const bridge = createDesktopBridge(ipc, "darwin", "1.0.0");
  await bridge.exportDialog("a.png", ["png"]);
  await bridge.exportFolder("Export images to a folder");
  await bridge.writeExport("/out/a.png", new Uint8Array([1]), ["/o.png"], true);
  assert.deepEqual(calls.map((call) => call[0]), ["exportDialog", "exportFolder", "writeExport"]);
  assert.deepEqual(calls[2].slice(3), [["/o.png"], true]);
});
