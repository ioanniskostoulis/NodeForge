// Licensed under the GNU General Public License v2 or later. See LICENSE.
// What an application draws over its content: regions (rectangles, ellipses, polygons, freehand shapes, lines), their
// labels, and the state of editing them. Two layers that never share a colour: the regions take the overlay palette,
// drawn bare as a plot's traces are, with no edge or halo; selection, hover, a crop and every handle take the pick colour
// (cyan), which the palette leaves out. Both follow the lightness of what lies under them, not the window's appearance.
// Every width is in view px at any zoom: the context is in content units and each function divides by `scale`.
import { SELECTION_BOX, type Point, type Rect } from "./content-selection";
import { BOX_HANDLES, HANDLE_SIZE, handlePoint } from "./box-handles";

// MARK: given values

/** The lightness of what lies under the overlay: a picture (`pictureSurface`) or a flat surface such as a plot. */
export type OverlaySurface = "dark" | "light";

/**
 * The overlay palette, in the order regions take it: the bright set on dark content, the darker set on light content.
 * Cyan is left out: it is the pick colour.
 */
export const OVERLAY_COLORS = {
  bright: ["#ffd23f", "#ff8a3d", "#3be05a", "#5ec8ff", "#ff6bd5", "#b48cff", "#ff5c5c", "#ffffff"],
  light: ["#b47a00", "#ef541b", "#00a83c", "#2a5fd6", "#c0268f", "#6b3fc4", "#ed3434", "#1f1f1f"],
} as const;
/** A region's line, in view px: the weight of a plot's trace, 5 % thicker on a light surface. Joins are round. */
export const REGION_LINE = { width: 1.25, lightFactor: 1.05 } as const;
/** The pick colour on dark and on light content: `--pick` of the dark and of the light appearance. */
export const OVERLAY_PICK = { dark: "#2fd3e6", light: "#007a99" } as const;
/** A handle's fill on dark and on light content, so that it reads as a hollow node. */
export const HANDLE_FILL = { dark: "#000000", light: "#ffffff" } as const;
/** Mean luminance (0 to 1) at or above which a picture is light content. */
export const LIGHT_PICTURE = 0.5;
/** The edge of a handle, in view px, in the pick colour. */
export const HANDLE_EDGE = 1.2;
/** A region being drawn: dashed as the selection box. */
export const DRAWING_DASH = SELECTION_BOX.dash;
/** A derived region (a phase, a mask made from another): dashed in its colour, as a phase trace, in view px. */
export const DERIVED_DASH = [5, 4] as const;
/** A guide line (a level, a measuring line): its colour at 35 %, dotted 2 and 3 px. */
export const GUIDE_LINE = { alpha: 0.35, width: 1, dash: [2, 3] } as const;
/** The optional fill of a region, as the selection box's. */
export const REGION_FILL_ALPHA = SELECTION_BOX.fillAlpha;
/** The square on a polygon's first point, in view px, where a click closes it. */
export const CLOSE_MARK = 6;
/** A label's height as a share of the picture's shorter side. */
export const REGION_LABEL = { size: 1 / 30 } as const;

// MARK: method

export type RegionShape =
  | { kind: "rectangle" | "ellipse"; box: Rect }
  | { kind: "polygon" | "freehand" | "line"; points: readonly Point[] };

/** How a region is shown: as it is, under the pointer, selected, or while it is being drawn. */
export type RegionState = "normal" | "hovered" | "selected" | "drawing";

/** The colour of the `index`th region on a surface: the palette in order, round again after the last. */
export function overlayColor(index: number, surface: OverlaySurface = "dark"): string {
  const colors = surface === "light" ? OVERLAY_COLORS.light : OVERLAY_COLORS.bright;
  return colors[((index % colors.length) + colors.length) % colors.length];
}

/** A region's line width on a surface, in view px. */
export function regionLineWidth(surface: OverlaySurface = "dark"): number {
  return surface === "light" ? REGION_LINE.width * REGION_LINE.lightFactor : REGION_LINE.width;
}

/**
 * Whether a picture is dark or light content: its mean luminance (Rec. 709 weights on the 8-bit channels) against
 * `LIGHT_PICTURE`, from every `step`th pixel. An application calls it once per picture, not per frame.
 */
export function pictureSurface(pixels: { data: ArrayLike<number>; width: number; height: number }, step = 16): OverlaySurface {
  let sum = 0, n = 0;
  for (let i = 0; i < pixels.width * pixels.height; i += step) {
    const o = 4 * i;
    sum += (0.2126 * pixels.data[o] + 0.7152 * pixels.data[o + 1] + 0.0722 * pixels.data[o + 2]) / 255;
    n++;
  }
  return n && sum / n >= LIGHT_PICTURE ? "light" : "dark";
}

/** The label height for a picture whose shorter side is `shortSide`, in content units. */
export function labelSize(shortSide: number): number {
  return shortSide * REGION_LABEL.size;
}

/**
 * The path of a shape. Rectangles and ellipses are always closed; a polygon is closed unless `open` (while it is drawn);
 * a freehand shape likewise; a line never.
 */
export function traceShape(ctx: CanvasRenderingContext2D, shape: RegionShape, open = false): void {
  ctx.beginPath();
  if ("box" in shape) {
    const { x, y, width, height } = shape.box;
    if (shape.kind === "rectangle") ctx.rect(x, y, width, height);
    else ctx.ellipse(x + width / 2, y + height / 2, width / 2, height / 2, 0, 0, 2 * Math.PI);
    return;
  }
  shape.points.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  if (shape.kind !== "line" && !open && shape.points.length > 2) ctx.closePath();
}

// MARK: drawing

export interface RegionStyle {
  /** The region's colour, from `overlayColor`. */
  color: string;
  state?: RegionState;
  surface?: OverlaySurface;
  /** View px per content unit. */
  scale?: number;
  /** Fill the region at 12 % of its colour (a phase, a mask). */
  fill?: boolean;
  /** A region made from another: dashed 5 and 4 px. */
  derived?: boolean;
  /** The selection colour (default the pick colour of the surface). */
  pick?: string;
}

/**
 * Draw a region: its line in its colour, 1.25 px with round joins, bare as a trace. Selected or hovered, the same line in
 * the pick colour: only the colour changes, never the weight. While drawn, dashed 4 and 3 px and left open.
 */
export function drawRegion(ctx: CanvasRenderingContext2D, shape: RegionShape, style: RegionStyle): void {
  const scale = style.scale ?? 1, surface = style.surface ?? "dark", state = style.state ?? "normal";
  const drawing = state === "drawing";
  ctx.save();
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  traceShape(ctx, shape, drawing);
  if (style.fill && !drawing && shape.kind !== "line") {
    ctx.globalAlpha = REGION_FILL_ALPHA;
    ctx.fillStyle = style.color;
    ctx.fill();
    ctx.globalAlpha = 1;
  }
  const marked = state === "selected" || state === "hovered";
  const width = regionLineWidth(surface);
  const dash = drawing ? DRAWING_DASH : style.derived && !marked ? DERIVED_DASH : [];
  ctx.setLineDash(dash.map((length) => length / scale));
  ctx.strokeStyle = marked ? style.pick ?? OVERLAY_PICK[surface] : style.color;
  ctx.lineWidth = width / scale;
  ctx.stroke();
  ctx.restore();
}

export interface HandleStyle {
  /** The lightness of the content under the handles (default dark). */
  surface?: OverlaySurface;
  /** The edge colour (default the pick colour of the surface). */
  color?: string;
  /** The fill (default black on dark content, white on light), so a handle reads as a hollow node. */
  fill?: string;
  /** The smallest side in content units: past it the handle grows with the content, as a schematic's nodes do (0: never). */
  minSide?: number;
  /** The edge in view px when the content is not zoomed in past it (default 1.2). */
  edge?: number;
  /** The thinnest edge in content units: past it the edge thickens with the content, with `minSide` (0: never). */
  minEdge?: number;
}

/** The side of a handle in content units: 7 view px, or `minSide` when the content is zoomed in further. */
export function handleSide(scale = 1, minSide = 0): number {
  return Math.max(HANDLE_SIZE / scale, minSide);
}

/**
 * The edge of a handle in content units: `edge` view px, or `minEdge` when the content is zoomed in further, so a
 * handle that grows with the content keeps its proportions. A schematic with 5-unit nodes passes `minEdge` 1.2: at
 * 24× its handle is 120 px a side with a 28.8 px edge, as a hairline would look lost on it.
 */
export function handleEdge(scale = 1, edge: number = HANDLE_EDGE, minEdge = 0): number {
  return Math.max(edge / scale, minEdge);
}

/**
 * Handles on points, one look for every handle: a square 7 px a side, filled black on dark content or white on light
 * content and edged 1.2 px in the pick colour, at any zoom. A box's eight handles, a polygon's corners and a line's ends all take it.
 */
export function drawPointHandles(ctx: CanvasRenderingContext2D, points: readonly Point[], scale = 1, style: HandleStyle = {}): void {
  const side = handleSide(scale, style.minSide);
  ctx.save();
  const surface = style.surface ?? "dark";
  ctx.fillStyle = style.fill ?? HANDLE_FILL[surface];
  ctx.strokeStyle = style.color ?? OVERLAY_PICK[surface];
  ctx.lineWidth = handleEdge(scale, style.edge, style.minEdge);
  for (const p of points) {
    ctx.fillRect(p.x - side / 2, p.y - side / 2, side, side);
    ctx.strokeRect(p.x - side / 2, p.y - side / 2, side, side);
  }
  ctx.restore();
}

/** The eight handles of a box, at its corners and the middles of its edges. */
export function drawBoxHandles(ctx: CanvasRenderingContext2D, box: Rect, scale = 1, style: HandleStyle = {}): void {
  drawPointHandles(ctx, BOX_HANDLES.map((handle) => handlePoint(box, handle)), scale, style);
}

/** The 6 px square on a polygon's first point while it is drawn: a click there closes it. */
export function drawCloseMark(ctx: CanvasRenderingContext2D, point: Point, color: string, scale = 1): void {
  const side = CLOSE_MARK / scale;
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.25 / scale;
  ctx.strokeRect(point.x - side / 2, point.y - side / 2, side, side);
  ctx.restore();
}

/** A guide line from a to b: its colour at 35 %, 1 px, dotted 2 and 3 px. */
export function drawGuide(ctx: CanvasRenderingContext2D, a: Point, b: Point, color: string, scale = 1): void {
  ctx.save();
  ctx.globalAlpha = GUIDE_LINE.alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = GUIDE_LINE.width / scale;
  ctx.setLineDash(GUIDE_LINE.dash.map((length) => length / scale));
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.stroke();
  ctx.restore();
}

/**
 * A region's label in its colour, `size` content units high (a picture takes `labelSize(shortSide)`), anchored at the
 * left of its baseline at (x, y), bare as a trace's legend.
 */
export function drawRegionLabel(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, color: string, size: number, font = "system-ui, sans-serif"): void {
  ctx.save();
  ctx.font = `600 ${size}px ${font}`;
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
  ctx.fillStyle = color;
  ctx.fillText(text, x, y);
  ctx.restore();
}
