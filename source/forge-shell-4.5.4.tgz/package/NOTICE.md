# Forge UI attribution

forge-shell is licensed under GPL-2.0-or-later; see `LICENSE`. The Forge name, logos and branding are not covered by that licence.

## Third-party work

The package contains no third-party source code and has no runtime dependencies. It contains one third-party data file:

| Work | Licence | Use | Location |
|---|---|---|---|
| Roman FIGlet font by Nick Miners (1994), as modified by Patrick Gillespie (patorjk, 2007) and distributed with [figlet.js](https://github.com/patorjk/figlet.js) | MIT, with figlet.js | The lettering of the application wordmarks | `scripts/fonts/roman.flf` |
 Its build tools (TypeScript, esbuild, electron-builder and Electron) are used to build and test it and are not part of the package. Each app that uses the shell lists the third-party work it adds in its own `NOTICE.md`, and its build writes `THIRD-PARTY-LICENSES.md` with the licence text of every bundled package.
