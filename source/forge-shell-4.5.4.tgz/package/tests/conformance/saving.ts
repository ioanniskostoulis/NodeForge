import assert from "node:assert/strict";
import { test } from "node:test";
import { AUTOSAVE_CHOICES, DRAFT_MAX_AGE_MS, addRecent, autosaveDelayMs, autosaveMenu, createAutosave, createRecentFiles, createRecovery, parseAutosave, recentKey, recentLabels, recentMenu } from "../../source/app/saving";
import { fileKind } from "../../source/app/file-tree";

const memory = () => { const map = new Map<string, string>(); return { getItem: (key: string) => map.get(key) ?? null, setItem: (key: string, value: string) => void map.set(key, value), removeItem: (key: string) => void map.delete(key), map }; };

test("autosave is off by default, or saves 1 or 5 minutes after the last edit, or when the window loses focus", () => {
  assert.deepEqual([...AUTOSAVE_CHOICES], ["off", "1m", "5m", "focus"]);
  assert.deepEqual(AUTOSAVE_CHOICES.map(autosaveDelayMs), [null, 60000, 300000, null]);
  assert.equal(parseAutosave("1 min"), "1m");
  assert.equal(parseAutosave("5 minutes"), "5m");
  assert.equal(parseAutosave("FOCUS"), "focus");
  assert.equal(parseAutosave("hourly"), null);
  assert.deepEqual(autosaveMenu("5m").submenu!.map((item) => [item.id, item.checked]), [["file.autosave.off", false], ["file.autosave.1m", false], ["file.autosave.5m", true], ["file.autosave.focus", false]]);
});

test("autosave restarts its pause at each edit, never saves an untitled document, and saves on blur only when asked", () => {
  let choice: (typeof AUTOSAVE_CHOICES)[number] = "1m";
  const saved: string[] = [], timers: { run: () => void; ms: number; live: boolean }[] = [];
  const autosave = createAutosave<string>({
    choice: () => choice, canSave: (doc) => doc !== "untitled", save: (doc) => void saved.push(doc),
    setTimer: (run, ms) => { const timer = { run, ms, live: true }; timers.push(timer); return timer; },
    clearTimer: (timer) => { (timer as { live: boolean }).live = false; },
  });
  autosave.edited("report"); autosave.edited("report"); autosave.edited("untitled");
  assert.equal(timers.filter((timer) => timer.live).length, 1, "the second edit restarted the pause; untitled has none");
  assert.equal(timers[1].ms, 60000);
  timers.filter((timer) => timer.live).forEach((timer) => { timer.live = false; timer.run(); });
  assert.deepEqual(saved, ["report"]);
  autosave.blurred(["report"]);
  assert.deepEqual(saved, ["report"], "blur saves nothing unless the choice is focus");
  choice = "focus";
  autosave.blurred(["report", "untitled"]);
  assert.deepEqual(saved, ["report", "report"]);
  choice = "off";
  autosave.edited("report");
  assert.equal(timers.filter((timer) => timer.live).length, 0);
});

test("a pause still running when autosave is turned off saves nothing", () => {
  let choice: (typeof AUTOSAVE_CHOICES)[number] = "5m";
  const saved: string[] = [], timers: (() => void)[] = [];
  const autosave = createAutosave<string>({ choice: () => choice, canSave: () => true, save: (doc) => void saved.push(doc), setTimer: (run) => timers.push(run), clearTimer: () => {} });
  autosave.edited("report");
  choice = "off";
  timers[0]();
  assert.deepEqual(saved, [], "turned off before the pause ended");
  choice = "1m";
  autosave.edited("report");
  timers[1]();
  assert.deepEqual(saved, ["report"], "a choice with a pause still saves");
});

test("recovery keeps one draft per document, clears it on save, drops drafts older than 7 days and lists the newest first", () => {
  const storage = memory();
  let clock = 1000;
  const recovery = createRecovery("app.drafts", storage, () => clock);
  recovery.keep({ key: "a", name: "A", path: null, text: "one" });
  clock = 2000; recovery.keep({ key: "b", name: "B", path: "/b.txt", text: "two" });
  clock = 3000; recovery.keep({ key: "a", name: "A", path: null, text: "one, edited" });
  assert.deepEqual(recovery.list().map((draft) => [draft.key, draft.text]), [["a", "one, edited"], ["b", "two"]]);
  recovery.clear("a");
  assert.deepEqual(recovery.list().map((draft) => draft.key), ["b"]);
  clock = 2000 + DRAFT_MAX_AGE_MS;
  assert.deepEqual(recovery.list(), [], "a week-old draft is dropped");
  recovery.clearAll();
  assert.equal(storage.map.has("app.drafts"), false);
  storage.setItem("app.drafts", "not json");
  assert.deepEqual(recovery.list(), [], "a damaged store reads as empty");
});

test("Open recent keeps ten files, newest first, without duplicates, named with their folder where names repeat", () => {
  assert.deepEqual(addRecent(["/a/x.txt", "/b/y.txt"], "/b/y.txt"), ["/b/y.txt", "/a/x.txt"]);
  assert.equal(addRecent(Array.from({ length: 12 }, (_, index) => `/f${index}`), "/new").length, 10);
  assert.deepEqual(recentLabels(["/lab/notes.txt", "/work/notes.txt", "C:\\\\data\\\\run.csv"]), ["notes.txt — lab", "notes.txt — work", "run.csv"]);
  assert.deepEqual(recentMenu([]).submenu, [{ label: "No recent files", enabled: false }]);
  assert.deepEqual(recentMenu(["/a/x.txt"]).submenu!.map((item) => item.id ?? (item.separator ? "—" : "")), ["file.recent.0", "—", "file.recent.clear"]);
  const recent = createRecentFiles("app.recent", memory());
  recent.add("/a"); recent.add("/b"); recent.add("/a");
  assert.deepEqual(recent.list(), ["/a", "/b"]);
  recent.remove("/b");
  assert.deepEqual(recent.list(), ["/a"]);
});

test("recovery keeps no draft of an untitled document without real work", () => {
  const storage = memory();
  const recovery = createRecovery("app.drafts", storage);
  recovery.keep({ key: "a", name: "Untitled 1", path: null, text: "work" });
  recovery.keep({ key: "a", name: "Untitled 1", path: null, text: "  \n" });
  assert.deepEqual(recovery.list(), [], "emptied: its earlier draft goes too");
  recovery.keep({ key: "b", name: "Untitled 2", path: null, text: "% template" }, "% template");
  assert.deepEqual(recovery.list(), []);
  recovery.keep({ key: "c", name: "c.txt", path: "/c.txt", text: "" });
  assert.equal(recovery.list().length, 1, "an emptied saved file keeps its draft");
});

test("Open recent labels add as many folders as tell two files apart", () => {
  assert.deepEqual(recentLabels(["/a/original/x.nfg", "/b/original/x.nfg", "/b/improved/x.nfg"]), ["x.nfg — a/original", "x.nfg — b/original", "x.nfg — improved"]);
  assert.deepEqual(recentLabels(["/x.nfg", "/a/x.nfg"]), ["x.nfg", "x.nfg — a"]);
});

test("Open recent treats two spellings of one file as one entry", () => {
  assert.equal(recentKey("/private/tmp/run.csv", false), recentKey("/tmp//run.csv", false));
  assert.equal(recentKey("C:\\Data\\Run.csv", false), recentKey("c:/data/run.csv", false));
  assert.notEqual(recentKey("/data/Run.csv", false), recentKey("/data/run.csv", false), "case counts where the file system keeps it");
  assert.equal(recentKey("/Data/Run.csv", true), recentKey("/data/run.csv", true));
  assert.deepEqual(addRecent(["/private/tmp/a.txt", "/b.txt"], "/tmp/a.txt", 10, false), ["/tmp/a.txt", "/b.txt"]);
  const storage = memory();
  storage.setItem("app.recent", JSON.stringify(["/Docs/a.txt", "/docs/A.txt", "/b.txt"]));
  const recent = createRecentFiles("app.recent", storage, 10, true);
  assert.deepEqual(recent.list(), ["/Docs/a.txt", "/b.txt"], "a stored list with duplicates reads without them");
  recent.remove("/DOCS/A.TXT");
  assert.deepEqual(recent.list(), ["/b.txt"]);
});

test("a file's kind follows its extension, so the tree shows a fitting icon", () => {
  assert.equal(fileKind("data/run.CSV"), "data");
  assert.equal(fileKind("main.tex"), "text");
  assert.equal(fileKind("scripts/plot.py"), "code");
  assert.equal(fileKind("graphics/photo.jpeg"), "image");
  assert.equal(fileKind("backup.zip"), "archive");
  assert.equal(fileKind("README"), "other");
});
