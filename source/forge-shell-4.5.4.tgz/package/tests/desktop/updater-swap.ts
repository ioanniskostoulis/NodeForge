// Runs the macOS swap script on real folders, with a stand-in for `open`. Shell only: applications' tests touch no files.
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { createHash } from "node:crypto";
import { downloadAsset, macSwapScript } from "../../source/desktop/updater";

test("the macOS script swaps in the new app after the old one quits, then opens it", { skip: process.platform === "win32" }, async () => {
  const root = mkdtempSync(join(tmpdir(), "forge-swap-"));
  try {
    const bundle = join(root, "Example.app"), staged = `${bundle}.new`, work = join(root, "work"), bin = join(root, "bin");
    for (const dir of [bundle, staged, work, bin]) mkdirSync(dir, { recursive: true });
    writeFileSync(join(bundle, "version"), "old");
    writeFileSync(join(staged, "version"), "new");
    writeFileSync(join(bin, "open"), `#!/bin/sh\necho "$1" > '${join(root, "opened")}'\n`);
    chmodSync(join(bin, "open"), 0o755);
    const running = spawn("sleep", ["0.5"]);
    const script = join(root, "update.sh");
    writeFileSync(script, macSwapScript({ pid: running.pid!, bundle, staged, work }));
    // Waited for without blocking, so that the stand-in app is reaped when it quits and the script sees it gone.
    const status = await new Promise<number | null>((done) => spawn("/bin/sh", [script], { env: { ...process.env, PATH: `${bin}:${process.env.PATH}` } }).on("close", done));
    assert.equal(status, 0);
    assert.equal(readFileSync(join(bundle, "version"), "utf8"), "new");
    assert.ok(!existsSync(staged) && !existsSync(`${bundle}.old`) && !existsSync(work));
    assert.equal(readFileSync(join(root, "opened"), "utf8").trim(), bundle);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("a download is kept only when its size and SHA-256 match the release", async () => {
  const root = mkdtempSync(join(tmpdir(), "forge-download-"));
  try {
    const bytes = Buffer.from("installer");
    const serve = (async () => new Response(bytes)) as unknown as typeof fetch;
    const sha256 = createHash("sha256").update(bytes).digest("hex");
    const asset = { name: "a.dmg", url: "https://github.com/o/a/releases/download/v1.0.0/a.dmg", size: bytes.length, sha256 };
    await downloadAsset(asset, join(root, "a.dmg"), serve);
    assert.equal(readFileSync(join(root, "a.dmg"), "utf8"), "installer");
    await assert.rejects(downloadAsset({ ...asset, size: 3 }, join(root, "b.dmg"), serve), /incomplete/);
    await assert.rejects(downloadAsset({ ...asset, sha256: "0".repeat(64) }, join(root, "c.dmg"), serve), /did not match/);
    assert.ok(!existsSync(join(root, "c.dmg")));
  } finally { rmSync(root, { recursive: true, force: true }); }
});
