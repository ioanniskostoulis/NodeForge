import assert from "node:assert/strict";
import test from "node:test";
import { createTerminalPreferences, parseTerminalPreferences, terminalPreferenceCommand, TERMINAL_PREFERENCE_DEFAULTS } from "../../source/app/terminal-preferences";

const memory = () => {
  const data = new Map<string, string>();
  return { getItem: (key: string) => data.get(key) ?? null, setItem: (key: string, value: string) => { data.set(key, value); } };
};

test("stored preferences fall back to the defaults for anything unknown or out of range", () => {
  assert.deepEqual(parseTerminalPreferences(null), TERMINAL_PREFERENCE_DEFAULTS);
  assert.deepEqual(parseTerminalPreferences({ historyLimit: 50, banner: false, caretBlink: false, lineSpacing: "compact", wrap: false }), { historyLimit: 50, banner: false, caretBlink: false, lineSpacing: "compact", wrap: false });
  // 100 is the contract's most; 500 and a string are not choices
  assert.equal(parseTerminalPreferences({ historyLimit: 500 }).historyLimit, 100);
  assert.equal(parseTerminalPreferences({ historyLimit: "50" }).historyLimit, 100);
  assert.equal(parseTerminalPreferences({ banner: "no" }).banner, true);
});

test("the store keeps its values under its key, tells its listeners and survives damaged storage", () => {
  const storage = memory();
  const first = createTerminalPreferences("app.console.preferences", storage);
  let calls = 0;
  const stop = first.subscribe(() => { calls += 1; });
  first.update({ historyLimit: 25, banner: false });
  assert.equal(calls, 1);
  assert.deepEqual(createTerminalPreferences("app.console.preferences", storage).get(), { historyLimit: 25, banner: false, caretBlink: true, lineSpacing: "comfortable", wrap: true });
  stop();
  first.update({ caretBlink: false });
  assert.equal(calls, 1);
  storage.setItem("app.console.preferences", "{not json");
  assert.deepEqual(createTerminalPreferences("app.console.preferences", storage).get(), TERMINAL_PREFERENCE_DEFAULTS);
  // without a key the values last for the session only
  const session = createTerminalPreferences();
  session.update({ banner: false });
  assert.equal(session.get().banner, false);
});

test("history limit, banner and caret report their state, change it, and refuse other values with a sentence", () => {
  const preferences = createTerminalPreferences(undefined, memory());
  assert.deepEqual(terminalPreferenceCommand("history limit", preferences), { lines: ["The history keeps the last 100 commands."] });
  assert.deepEqual(terminalPreferenceCommand("history limit 50", preferences), { lines: ["The history keeps the last 50 commands."] });
  assert.deepEqual(terminalPreferenceCommand("history limit 50", preferences), { lines: ["The history already keeps the last 50 commands."] });
  assert.deepEqual(terminalPreferenceCommand("history limit 7", preferences), { lines: ["The history limit takes 25, 50 or 100."] });
  assert.equal(preferences.get().historyLimit, 50);
  assert.deepEqual(terminalPreferenceCommand("terminal banner", preferences), { lines: ["The banner is on."] });
  assert.deepEqual(terminalPreferenceCommand("terminal banner off", preferences), { lines: ["Banner disabled."] });
  assert.deepEqual(terminalPreferenceCommand("terminal banner off", preferences), { lines: ["Banner is already off."] });
  assert.deepEqual(terminalPreferenceCommand("terminal caret steady", preferences), { lines: ["The caret stays steady."] });
  assert.deepEqual(terminalPreferenceCommand("terminal caret", preferences), { lines: ["The caret is steady."] });
  assert.deepEqual(terminalPreferenceCommand("terminal caret steady", preferences), { lines: ["The caret is already steady."] });
  assert.deepEqual(terminalPreferenceCommand("terminal spacing", preferences), { lines: ["The line spacing is comfortable."] });
  assert.deepEqual(terminalPreferenceCommand("terminal spacing compact", preferences), { lines: ["The line spacing is compact."] });
  assert.deepEqual(terminalPreferenceCommand("terminal spacing compact", preferences), { lines: ["The line spacing is already compact."] });
  assert.deepEqual(terminalPreferenceCommand("terminal wrap off", preferences), { lines: ["Wrapping disabled."] });
  assert.deepEqual(terminalPreferenceCommand("terminal wrap", preferences), { lines: ["Wrapping is off."] });
  assert.deepEqual(preferences.get(), { historyLimit: 50, banner: false, caretBlink: false, lineSpacing: "compact", wrap: false });
  // the same verbs under `terminal`, which is how the registry names them
  assert.deepEqual(terminalPreferenceCommand("terminal wrap on", preferences), { lines: ["Wrapping enabled."] });
  assert.deepEqual(terminalPreferenceCommand("terminal banner", preferences), { lines: ["The banner is off."] });
  assert.deepEqual(terminalPreferenceCommand("terminal", preferences)?.lines?.length, 5);
});

test("terminal font shows and sets the text size within 10 to 24 px", () => {
  const preferences = createTerminalPreferences(undefined, memory());
  let size = 12;
  const font = { fontSize: () => size, setFontSize: (value: number) => { size = value; } };
  assert.deepEqual(terminalPreferenceCommand("terminal font", preferences, font), { lines: ["The text size is 12 px."] });
  assert.deepEqual(terminalPreferenceCommand("terminal font 30", preferences, font), { lines: ["Text size set to 24 px."] });
  assert.deepEqual(terminalPreferenceCommand("terminal font 24", preferences, font), { lines: ["The text size is already 24 px."] });
  assert.deepEqual(terminalPreferenceCommand("terminal font smaller", preferences, font), { lines: ["Text size set to 23 px."] });
  assert.deepEqual(terminalPreferenceCommand("terminal font bigger", preferences, font), { lines: ["Text size set to 24 px."] });
  assert.equal(terminalPreferenceCommand("terminal font huge", preferences, font), null);
  assert.equal(terminalPreferenceCommand("font 14", preferences, font), null, "font alone is free for an application");
  assert.deepEqual(terminalPreferenceCommand("terminal", preferences, font)?.lines?.[0], "The text size is 24 px.");
});

test("lines that are not these verbs, or forms they do not take, are left to the Terminal and the registry", () => {
  const preferences = createTerminalPreferences(undefined, memory());
  for (const line of ["terminal -h", "terminal history", "terminal font 14", "history", "history 5", "history clear", "terminal banner maybe", "terminal caret wide", "terminal spacing tight", "terminal wrap maybe", "banner off", "wrap on", "font 14", ""]) assert.equal(terminalPreferenceCommand(line, preferences), null, line);
});
