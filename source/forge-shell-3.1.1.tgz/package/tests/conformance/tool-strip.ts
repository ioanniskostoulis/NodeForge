import assert from "node:assert/strict";
import { test } from "node:test";
import { createToolButton, toolTooltip } from "../../source/app/tool-button";
import { createToolModes, modeLabel } from "../../source/app/tool-modes";
import { flyoutItemMarkup, flyoutTip } from "../../source/app/tool-flyout";
import { TOOL_ICONS, toolIcon } from "../../source/app/tool-icons";

class Element {
  className = ""; title = ""; type = ""; innerHTML = ""; disabled = false; dataset: Record<string, string> = {}; attributes: Record<string, string> = {};
  setAttribute(name: string, value: string) { this.attributes[name] = value; }
}
const doc = { createElement: () => new Element() } as unknown as Pick<Document, "createElement">;
const mac = (key: string) => key.replace("CmdOrCtrl+", "⌘");
const windows = (key: string) => key.replace("CmdOrCtrl", "Ctrl");

test("the tooltip names the action, shows the shortcut from the registry and adds placement only when given", () => {
  assert.equal(toolTooltip({ label: "Undo", shortcut: "CmdOrCtrl+Z" }, mac), "Undo (⌘Z)");
  assert.equal(toolTooltip({ label: "Undo", shortcut: "CmdOrCtrl+Z" }, windows), "Undo (Ctrl+Z)");
  assert.equal(toolTooltip({ label: "Fit" }), "Fit");
  assert.equal(toolTooltip({ label: "Add wire", placement: "click to start, click to end" }), "Add wire: click to start, click to end");
});

test("a tool button has the shared class, an accessible name without the shortcut, and honours enabled", () => {
  const button = createToolButton({ id: "undo", icon: TOOL_ICONS.undo, label: "Undo", shortcut: "CmdOrCtrl+Z", enabled: false }, doc) as unknown as Element;
  assert.equal(button.className, "tool");
  assert.equal(button.attributes["aria-label"], "Undo");
  assert.equal(button.disabled, true);
  assert.equal(button.dataset.tool, "undo");
  assert.match(button.title, /^Undo \(/);
});

test("every shared icon uses the 16 px box, the 1.25 px line and currentColor", () => {
  for (const [name, svg] of Object.entries({ ...TOOL_ICONS, domain: toolIcon("<path d='M0 0'/>") })) {
    assert.match(svg, /width="16" height="16"/, name);
    assert.match(svg, /stroke-width="1.25"/, name);
    assert.match(svg, /stroke="currentColor"/, name);
  }
});

test("tool modes keep exactly one tool active and Escape returns to neutral", () => {
  const selected = new Set<string>();
  let label = "x";
  let onKey: (event: Event) => void = () => {};
  const modes = createToolModes({ setSelected: (id, on) => { if (on) selected.add(id); else selected.delete(id); }, setMode: (text) => { label = text; } }, () => {}, { addEventListener: (_n: string, l: unknown) => { onKey = l as (event: Event) => void; } } as never);
  modes.activate("wire", "Add", "wire");
  modes.activate("part", "Place", "resistor");
  assert.deepEqual([...selected], ["part"]);
  assert.equal(label, modeLabel("Place", "resistor"));
  assert.equal(label, "Place resistor. Press Esc to finish");
  onKey({ key: "Escape" } as unknown as Event);
  assert.deepEqual([...selected], []);
  assert.equal(label, "");
  assert.equal(modes.active, null);
});

test("a flyout row has the three columns of every menu row, and a tool is a plain item, never checked", () => {
  const rect = { id: "rect", label: "Rectangle", icon: toolIcon("<path d='M2 2h12v12H2z'/>"), shortcut: "R" };
  const columns = (markup: string) => [...markup.matchAll(/<span class="(check|label[^"]*|key)"/g)].map((m) => m[1].split(" ")[0]);
  assert.deepEqual(columns(flyoutItemMarkup(rect)), ["check", "label", "key"], "the check column comes first, as in menus.ts, so the icon is not squeezed into it");
  assert.match(flyoutItemMarkup(rect), /<span class="check" aria-hidden="true"><\/span>/, "the column is kept for alignment and stays empty");
  assert.doesNotMatch(flyoutItemMarkup(rect), /✓/);
  assert.deepEqual(columns(flyoutItemMarkup({ ...rect, shortcut: undefined })), ["check", "label"], "no shortcut, no key column");
  assert.equal(flyoutTip("Shapes", { ...rect, shortcut: undefined }), "Shapes: Rectangle");
});
