// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Health: the local record of active use, the Settings page that shows it, and the optional break reminder. Collection
// is always on and stays on this device; only the reminder can be turned off.
import { UI_ICONS } from "./tool-icons";
import { settingsField, type SettingsPage } from "./settings-dialog";
import type { ConsoleResult } from "./terminal";

// MARK: given values

/** A person counts as active until this long after the last pointer, key or wheel event, in ms. */
const IDLE_AFTER_MS = 5 * 60_000;
/** Active time is added to the record, and saved, this often while the window is in use, in ms. */
const SAVE_EVERY_MS = 15_000;
/** The record keeps this many days, newest last. */
const MAX_DAYS = 400;
const DEFAULT_THRESHOLD_HOURS = 4;
/** The hours of active use in one day after which the reminder is offered. */
const THRESHOLD_CHOICES = [2, 3, 4, 5, 6] as const;
type ReminderHours = typeof THRESHOLD_CHOICES[number];
/** The chart covers 52 weeks of 7 days; the colour of a tile is its share of a full day, a full week or the running total. */
const CHART_WEEKS = 52;
const CHART_DAYS = CHART_WEEKS * 7;
const FULL_DAY_SECONDS = 6 * 3600;
const FULL_WEEK_SECONDS = 30 * 3600;
/** A tile has this many colour levels above empty. */
const TILE_LEVELS = 4;
/** The events that count as use. */
const ACTIVITY_EVENTS = ["pointerdown", "keydown", "wheel"] as const;

export interface HealthDay { date: string; seconds: number }
export interface HealthPreferences { reminderAfterHours: number | null; days: HealthDay[]; remindedDate?: string }
export interface HealthTracker {
  reminderAfterHours(): number | null;
  setReminderAfterHours(hours: number | null): void;
  days(): readonly HealthDay[];
  activeSecondsToday(): number;
  subscribe(listener: () => void): () => void;
  dispose(): void;
}

export interface HealthTrackerOptions {
  /** A unique per-application key. Usage data stays in that application's local storage. */
  storageKey: string;
  storage?: Pick<Storage, "getItem" | "setItem">;
  /** Testable wall clock; defaults to `Date.now`. */
  now?: () => number;
  /**
   * What "Take a short break" does after the reminder closes. By default it closes the window the usual way
   * (`closeForBreak`), so a window with unsaved work asks to save it first, as Close window does.
   */
  onTakeBreak?: () => void;
}

// MARK: the record (pure)

/** The local calendar date of a time, as `2026-11-13`. */
const localDate = (time: number): string => {
  const date = new Date(time);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
};

const isReminderHours = (value: unknown): value is ReminderHours => THRESHOLD_CHOICES.includes(value as ReminderHours);

/** The seconds from `from` to `to` (ms) that fall on each local date, so time across midnight is shared between both days. */
export function healthSecondsPerDate(from: number, to: number): HealthDay[] {
  const parts: HealthDay[] = [];
  for (let cursor = from; cursor < to;) {
    const midnight = new Date(cursor);
    midnight.setHours(24, 0, 0, 0);
    const segmentEnd = Math.min(to, midnight.getTime());
    parts.push({ date: localDate(cursor), seconds: (segmentEnd - cursor) / 1000 });
    cursor = segmentEnd;
  }
  return parts;
}

type StoredPreferences = Partial<HealthPreferences> & { enabled?: boolean; thresholdHours?: number };

/** The reminder choice of a stored record; the first Health release kept it as `enabled` and `thresholdHours`. */
const storedReminderHours = (saved: StoredPreferences): number | null => {
  if (saved.enabled === false || saved.reminderAfterHours === null) return null;
  if (isReminderHours(saved.reminderAfterHours)) return saved.reminderAfterHours;
  if (isReminderHours(saved.thresholdHours)) return saved.thresholdHours;
  return DEFAULT_THRESHOLD_HOURS;
};

/** The stored record, or the defaults when it is missing or damaged. A former off choice stays off, but collection resumes. */
function readPreferences(key: string, storage: Pick<Storage, "getItem" | "setItem">): HealthPreferences {
  try { return parsePreferences(storage.getItem(key)); } catch { return { reminderAfterHours: DEFAULT_THRESHOLD_HOURS, days: [] }; }
}

/** A stored record's text as preferences; damaged or missing parts take their defaults. */
export function parsePreferences(text: string | null): HealthPreferences {
  let saved: StoredPreferences | null = null;
  try { saved = JSON.parse(text ?? "null") as StoredPreferences | null; } catch { /* A damaged value gives the defaults. */ }
  const days = Array.isArray(saved?.days) ? saved.days.filter((day): day is HealthDay =>
    typeof day?.date === "string" && Number.isFinite(day.seconds) && day.seconds >= 0) : [];
  return {
    reminderAfterHours: storedReminderHours(saved ?? {}),
    days: days.slice(-MAX_DAYS),
    ...(typeof saved?.remindedDate === "string" ? { remindedDate: saved.remindedDate } : {}),
  };
}

/** Add seconds to a date of a record, keeping its days in date order and no more than `MAX_DAYS` of them. */
export function addHealthSeconds(days: readonly HealthDay[], parts: readonly HealthDay[]): HealthDay[] {
  const byDate = new Map(days.map((day) => [day.date, { ...day }]));
  for (const part of parts) {
    const day = byDate.get(part.date) ?? { date: part.date, seconds: 0 };
    day.seconds += part.seconds;
    byDate.set(part.date, day);
  }
  return [...byDate.values()].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0)).slice(-MAX_DAYS);
}

// MARK: the tracker

/**
 * Start counting foreground time while the window is visible, focused and recently used. Every save reads the stored
 * record first and adds only the time since the last save, so that several windows, or an app restarted by an update,
 * never write over each other's time; the last stretch is saved when the page is hidden or closed.
 */
export function createHealthTracker(options: HealthTrackerOptions): HealthTracker {
  const storage = options.storage ?? localStorage;
  const now = options.now ?? Date.now;
  let preferences = readPreferences(options.storageKey, storage);
  const listeners = new Set<() => void>();
  let lastActivity = now();
  let lastTick = now();
  let disposed = false;
  let reminder: HTMLElement | null = null;
  /** False after a save failed: the stored record is then behind this window's, which stays the one added to. */
  let stores = true;

  /**
   * Apply a change to the newest stored record, then save it. When storage cannot be read or the last save failed, the
   * change goes to this window's copy, so the time of the session is kept although it cannot be stored.
   */
  const commit = (change: (record: HealthPreferences) => void) => {
    const own = (): HealthPreferences => ({ ...preferences, days: preferences.days.map((day) => ({ ...day })) });
    let record: HealthPreferences;
    try { record = stores ? parsePreferences(storage.getItem(options.storageKey)) : own(); } catch { record = own(); }
    change(record);
    record.days = addHealthSeconds(record.days, []);
    preferences = record;
    try { storage.setItem(options.storageKey, JSON.stringify(preferences)); stores = true; } catch { stores = false; /* Storage can be unavailable in private or embedded contexts. */ }
    listeners.forEach((listener) => listener());
  };
  const secondsOn = (date: string) => preferences.days.find((day) => day.date === date)?.seconds ?? 0;
  const engaged = (time: number) => document.visibilityState === "visible" && document.hasFocus() && time - lastActivity < IDLE_AFTER_MS;

  const showReminder = () => {
    if (reminder || preferences.reminderAfterHours === null) return;
    reminder = showHealthBreakReminder(preferences.reminderAfterHours, () => { reminder = null; }, options.onTakeBreak);
  };
  /** Offer the break once per local day, when the day's active time reaches the chosen hours. */
  const remindIfDue = (time: number) => {
    const today = localDate(time);
    const hours = preferences.reminderAfterHours;
    if (hours === null || preferences.remindedDate === today || secondsOn(today) < hours * 3600) return;
    commit((record) => { record.remindedDate = today; });
    showReminder();
  };

  /** Add the time since the last tick to the record when the window was in use, then offer a due reminder. */
  const tick = () => {
    if (disposed) return;
    const end = now();
    if (engaged(end)) {
      const parts = healthSecondsPerDate(lastTick, end);
      commit((record) => { record.days = addHealthSeconds(record.days, parts); });
      remindIfDue(end);
    }
    lastTick = end;
  };
  // Input only marks the person active; the interval saves. Returning after an idle stretch first closes that stretch,
  // so it is not counted, without a save on every key, click or wheel turn.
  const activity = () => {
    const time = now();
    if (time - lastActivity >= IDLE_AFTER_MS) tick();
    lastActivity = time;
  };
  const visibility = () => { tick(); if (document.visibilityState === "visible") lastActivity = now(); };
  /** Another window saved: show its time and choices here too. */
  const stored = (event: StorageEvent) => {
    if (event.key !== options.storageKey) return;
    preferences = parsePreferences(event.newValue);
    listeners.forEach((listener) => listener());
  };

  const interval = window.setInterval(tick, SAVE_EVERY_MS);
  document.addEventListener("visibilitychange", visibility);
  window.addEventListener("focus", visibility);
  window.addEventListener("blur", tick);
  window.addEventListener("pagehide", tick);
  window.addEventListener("storage", stored);
  for (const event of ACTIVITY_EVENTS) window.addEventListener(event, activity, { passive: true });
  requestAnimationFrame(() => { if (!disposed) remindIfDue(now()); });

  return {
    reminderAfterHours: () => preferences.reminderAfterHours,
    setReminderAfterHours(value) {
      if (value !== null && !isReminderHours(value)) return;
      commit((record) => {
        record.reminderAfterHours = value;
        if (value === null) delete record.remindedDate;
      });
      if (value !== null) remindIfDue(now());
    },
    days: () => preferences.days.map((day) => ({ ...day })),
    activeSecondsToday: () => secondsOn(localDate(now())),
    subscribe(listener) { listeners.add(listener); return () => { listeners.delete(listener); }; },
    dispose() {
      tick();
      disposed = true;
      window.clearInterval(interval);
      document.removeEventListener("visibilitychange", visibility);
      window.removeEventListener("focus", visibility);
      window.removeEventListener("blur", tick);
      window.removeEventListener("pagehide", tick);
      window.removeEventListener("storage", stored);
      for (const event of ACTIVITY_EVENTS) window.removeEventListener(event, activity);
      reminder?.remove();
      reminder = null;
      listeners.clear();
    },
  };
}

// MARK: the break reminder

/**
 * The default break: close the window through its normal close flow. On the desktop the window's close is held while
 * it has unsaved work, and the application's own save prompt answers it; a browser tab the page did not open stays open.
 */
export const closeForBreak = (): void => { window.close(); };

/**
 * Show the standard local-use break prompt. Applications normally receive it from `createHealthTracker`. Keep working,
 * Escape and a click beside the dialog only close it and return the focus; Take a short break closes it, then runs `onTakeBreak`.
 */
export function showHealthBreakReminder(hours: number, onClose: () => void = () => {}, onTakeBreak: () => void = closeForBreak): HTMLElement {
  const backdrop = Object.assign(document.createElement("div"), { className: "modal-backdrop info health-reminder" });
  const dialog = Object.assign(document.createElement("section"), { className: "about health-reminder-dialog" });
  dialog.setAttribute("role", "dialog"); dialog.setAttribute("aria-modal", "true"); dialog.setAttribute("aria-labelledby", "health-reminder-title");
  dialog.innerHTML = `<div class="health-reminder-copy"><div class="health-plant" aria-hidden="true">${UI_ICONS.plant}</div><div class="health-reminder-message"><h2 id="health-reminder-title">A little break can help.</h2><p>You have been active for ${hours} hours today. Take a moment to stretch, rest your eyes, or get a drink.</p></div></div>`;
  const actions = Object.assign(document.createElement("div"), { className: "health-reminder-actions" });
  const rest = Object.assign(document.createElement("button"), { type: "button", className: "panel-button primary", textContent: "Take a short break" });
  const continueButton = Object.assign(document.createElement("button"), { type: "button", className: "panel-button", textContent: "Keep working" });
  const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    document.removeEventListener("keydown", keys, true);
    backdrop.remove();
    onClose();
  };
  /** Back to work: close the reminder and return the focus to where it was. */
  const resume = () => { close(); if (previousFocus?.isConnected) previousFocus.focus(); };
  const keys = (event: KeyboardEvent) => {
    if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); resume(); }
  };
  rest.addEventListener("click", () => { close(); onTakeBreak(); });
  continueButton.addEventListener("click", resume);
  actions.append(rest, continueButton); dialog.append(actions); backdrop.append(dialog);
  backdrop.addEventListener("mousedown", (event) => { if (event.target === backdrop) resume(); });
  (document.getElementById("overlay-root") ?? document.body).append(backdrop);
  document.addEventListener("keydown", keys, true);
  rest.focus();
  return backdrop;
}

// MARK: the Terminal command

/** Run the `health reminder` Terminal command that backs the Health page. */
export function healthCommand(arg: string, tracker: HealthTracker): ConsoleResult {
  const [setting, value, extra] = arg.trim().split(/\s+/);
  const choices = ["off", ...THRESHOLD_CHOICES].join("|");
  if (!setting) return { lines: [tracker.reminderAfterHours() === null ? "Break reminders are off." : `Break reminder set for after ${tracker.reminderAfterHours()} hours.`] };
  if (setting !== "reminder" || !value || extra) return { lines: [`Usage: health reminder <${choices}>.`] };
  if (value === "off") { tracker.setReminderAfterHours(null); return { lines: ["Break reminders disabled."] }; }
  const hours = Number(value);
  if (!isReminderHours(hours)) return { lines: ["Break reminder takes off, 2, 3, 4, 5 or 6."] };
  tracker.setReminderAfterHours(hours);
  return { lines: [`Break reminder set for after ${hours} hours.`] };
}

// MARK: the activity chart (pure)

export type HealthChartMode = "daily" | "weekly" | "cumulative";

export interface HealthChartTile {
  /** The day, or the first day of the week in the weekly view. */
  date: Date;
  /** The seconds the tile stands for: the day, the week or, cumulatively, everything up to and including it. */
  seconds: number;
  /** 0 for none, up to 4 for a full day, a full week or the whole total. */
  level: number;
  /** The seconds of that day or week alone, for its description. */
  ownSeconds: number;
}

/** The last 364 days ending `today`, oldest first, each with its recorded seconds. */
export function healthChartDays(days: readonly HealthDay[], today: Date): { date: Date; seconds: number }[] {
  const byDate = new Map(days.map((day) => [day.date, day.seconds]));
  const start = new Date(today);
  start.setHours(0, 0, 0, 0);
  return Array.from({ length: CHART_DAYS }, (_, index) => {
    const date = new Date(start);
    date.setDate(start.getDate() - (CHART_DAYS - 1 - index));
    return { date, seconds: byDate.get(localDate(date.getTime())) ?? 0 };
  });
}

/** The tile level of a share of `full` seconds: the share rounded up to a quarter, and 0 only for none. */
export const healthTileLevel = (seconds: number, full: number): number => (seconds <= 0 ? 0 : Math.min(TILE_LEVELS, Math.ceil((seconds / full) * TILE_LEVELS)));

/** The tiles of a view: 364 days, 52 weeks of 7 days, or 364 days drawn as the running total against the whole total. */
export function healthChartTiles(days: readonly { date: Date; seconds: number }[], mode: HealthChartMode): HealthChartTile[] {
  const units = mode === "weekly"
    ? Array.from({ length: CHART_WEEKS }, (_, week) => ({ date: days[week * 7].date, seconds: days.slice(week * 7, week * 7 + 7).reduce((sum, day) => sum + day.seconds, 0) }))
    : days;
  const full = mode === "daily" ? FULL_DAY_SECONDS : mode === "weekly" ? FULL_WEEK_SECONDS : Math.max(1, days.reduce((sum, day) => sum + day.seconds, 0));
  let running = 0;
  return units.map((unit) => {
    running += unit.seconds;
    const seconds = mode === "cumulative" ? running : unit.seconds;
    return { date: unit.date, seconds, level: healthTileLevel(seconds, full), ownSeconds: unit.seconds };
  });
}

/** A month name needs this many week columns to itself, so that it neither meets the next name nor runs past the chart. */
const MONTH_LABEL_WEEKS = 3;

/**
 * The label beneath each of the 52 weeks: the short month name where a week starts a new month, otherwise empty. A
 * month with too few weeks before the next name (the partial month at the start) or before the end of the chart has none.
 */
export function healthMonthLabels(days: readonly { date: Date }[], locale?: string): string[] {
  const starts = Array.from({ length: CHART_WEEKS }, (_, week) => week).filter((week) => !week || days[week * 7].date.getMonth() !== days[(week - 1) * 7].date.getMonth());
  const labels: string[] = Array.from({ length: CHART_WEEKS }, () => "");
  starts.forEach((week, at) => {
    const room = (starts[at + 1] ?? CHART_WEEKS) - week;
    if (room >= MONTH_LABEL_WEEKS) labels[week] = days[week * 7].date.toLocaleDateString(locale, { month: "short" });
  });
  return labels;
}

/** Seconds as `42 min` under an hour, and otherwise as hours with one decimal under ten. */
const hoursText = (seconds: number): string => {
  const hours = seconds / 3600;
  return hours < 1 ? `${Math.round(seconds / 60)} min` : `${hours.toFixed(hours < 10 ? 1 : 0)} h`;
};

// MARK: the Health page

const MODES: readonly HealthChartMode[] = ["daily", "weekly", "cumulative"];
const sentenceCase = (text: string): string => text[0].toUpperCase() + text.slice(1);

/** The Activity element: the interval choices, the chart, the months beneath it and the three summary lines. `view`
 * keeps the chosen interval, so a page redrawn after an outside change shows the same one. */
function activityElement(tracker: HealthTracker, view: { mode: HealthChartMode }): HTMLElement {
  const make = <K extends keyof HTMLElementTagNameMap>(tag: K, props: Partial<HTMLElementTagNameMap[K]> & { className?: string }) => Object.assign(document.createElement(tag), props);
  const root = make("section", { className: "health-activity" });
  root.setAttribute("aria-label", "Active app use");
  const modes = make("div", { className: "health-modes" });
  modes.setAttribute("role", "tablist"); modes.setAttribute("aria-label", "Activity interval");
  const heading = settingsField("View", modes);
  heading.classList.add("health-heading");
  const chart = make("div", { className: "health-chart" });
  chart.setAttribute("role", "grid"); chart.setAttribute("aria-label", "Daily active app use for the last 12 months");
  const months = make("div", { className: "health-months" });
  months.setAttribute("aria-hidden", "true");
  const chartScroll = make("div", { className: "health-chart-scroll" });
  chartScroll.append(chart, months);
  const values = [make("output", { className: "settings-value" }), make("output", { className: "settings-value" }), make("output", { className: "settings-value" })];
  const [todayValue, daysValue, totalValue] = values;
  const summary = make("div", { className: "health-summary" });
  summary.append(settingsField("Active today", todayValue), settingsField("Active days", daysValue), settingsField("Total tracked", totalValue));
  const caption = make("p", { className: "health-caption", textContent: "Records active use while this window is visible, focused and in use. It stays on this device." });
  root.append(heading, chartScroll, summary, caption);

  const render = () => {
    const days = healthChartDays(tracker.days(), new Date());
    const mode = view.mode;
    chart.dataset.mode = mode;
    months.replaceChildren(...healthMonthLabels(days).map((text) => make("span", { textContent: text })));
    chart.replaceChildren(...healthChartTiles(days, mode).map((tile) => {
      const text = `${tile.date.toLocaleDateString()}: ${hoursText(tile.ownSeconds)} active`;
      const element = make("span", { className: "health-day", title: text });
      element.dataset.level = String(tile.level);
      element.setAttribute("role", "gridcell"); element.setAttribute("aria-label", text);
      return element;
    }));
    const recorded = tracker.days().filter((day) => day.seconds > 0);
    todayValue.textContent = hoursText(tracker.activeSecondsToday());
    daysValue.textContent = String(recorded.length);
    totalValue.textContent = hoursText(recorded.reduce((sum, day) => sum + day.seconds, 0));
  };

  // The choices act as tabs: one is in the tab order, and Left and Right move between them.
  const buttons = MODES.map((name) => make("button", { type: "button", textContent: sentenceCase(name) }));
  const choose = (index: number) => {
    view.mode = MODES[index];
    buttons.forEach((button, at) => { button.setAttribute("aria-selected", String(at === index)); button.tabIndex = at === index ? 0 : -1; });
    render();
  };
  buttons.forEach((button, index) => {
    button.setAttribute("role", "tab");
    button.addEventListener("click", () => choose(index));
    button.addEventListener("keydown", (event) => {
      const step = event.key === "ArrowRight" ? 1 : event.key === "ArrowLeft" ? -1 : 0;
      if (!step) return;
      event.preventDefault();
      const next = (index + step + buttons.length) % buttons.length;
      choose(next);
      buttons[next].focus();
    });
  });
  modes.append(...buttons);
  choose(MODES.indexOf(view.mode));

  // The record updates the page while it is open; a page that has left the document stops listening at the next update.
  const unsubscribe = tracker.subscribe(() => { if (root.isConnected) render(); else unsubscribe(); });
  return root;
}

/** Make a Health Settings page that records active use continuously and makes break reminders optional. */
export function healthPage(tracker: HealthTracker): SettingsPage {
  const view: { mode: HealthChartMode } = { mode: "daily" };
  return {
    id: "health", title: "Health", icon: UI_ICONS.plant, subscribe: (listener) => tracker.subscribe(listener),
    sections: [
      { title: "Activity", rows: [{ kind: "element", element: () => activityElement(tracker, view) }] },
      { title: "Break reminder", rows: [{
        kind: "select", label: "Remind me", tip: "Show a gentle break reminder after this much active use in one day.",
        choices: [["off", "Off"], ...THRESHOLD_CHOICES.map((hours) => [String(hours), `After ${hours} hours`] as const)],
        value: () => String(tracker.reminderAfterHours() ?? "off"),
        set: (value) => tracker.setReminderAfterHours(value === "off" ? null : Number(value)),
        command: (value) => `health reminder ${value}`,
        default: String(DEFAULT_THRESHOLD_HOURS),
      }] },
    ],
  };
}
