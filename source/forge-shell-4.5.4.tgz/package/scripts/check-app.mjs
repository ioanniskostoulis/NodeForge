// Licensed under the GNU General Public License v2 or later. See LICENSE.
import assert from "node:assert/strict";
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { brandCss } from "./theme.mjs";
import { lintApp, checkDataColors } from "./style-lint.mjs";

const sharedStyle = (name) => fileURLToPath(new URL(`../source/styles/${name}`, import.meta.url));
const read = (path) => readFileSync(path, "utf8");
const shellSource = fileURLToPath(new URL("../source/", import.meta.url));

const escape = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** Catch product identifiers and formats accidentally copied into shared source. */
export function checkShellSource(sourceDir = shellSource, { name, id, extension } = {}) {
  const terms = [name, id, id && `${id.toUpperCase()}_[A-Z_]+`, "CircuitJS", extension && `\\.${escape(extension.replace(/^\./, ""))}`]
    .filter(Boolean).map((term, index) => (index === 2 || term.startsWith("\\.")) ? term : escape(term));
  const forbidden = new RegExp(terms.map((term) => term.startsWith("\\.") ? `${term}\\b` : `\\b${term}\\b`).join("|"), "i");
  const visit = (dir) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name);
      if (entry.isDirectory()) visit(path);
      else if (/\.(?:ts|js|mjs|css|html)$/.test(entry.name)) {
        assert.doesNotMatch(read(path), forbidden, `app-specific text in shared shell source: ${path}`);
      }
    }
  };
  visit(sourceDir);
}

/**
 * Where an application did itself what a shell part does: each entry is a pattern in its source, and the shell part it
 * must use instead (GUIDELINES.md, "The shell is binding"). A part that does not fit is changed in the shell, never
 * replaced in the application.
 */
export const SHELL_SUBSTITUTES = [
  { pattern: /\bdialog\.showMessageBox(?:Sync)?\s*\(/, use: "askToChoose (dialogs.ts), drawn in the page: a native message box does not exist in the browser preview" },
  { pattern: /\b(?:window\.)?(?:confirm|alert|prompt)\s*\(\s*[`"']/, use: "askToChoose or askToApply (dialogs.ts) for a question, Messages and the status bar for a report" },
  { pattern: /\bshowSaveDialog\s*\([^)]*\btitle:\s*[`"']Export/, use: "exportFiles (export-files.ts) and registerExportIpc (desktop/export-main.ts)" },
  // A select element made with createElement or an element helper (el, element, h), or written as markup; a "select"
  // tool or mode (setTool("select")) is not one.
  { pattern: /\b(?:createElement|el|element|h)\(\s*["'`]select["'`]\s*[,)]|<select[\s>]/, use: "createSelectControl (select-control.ts): a select is drawn in the shell's menu, never the operating system's option list" },
];

/** The places in an application's source that use a substitute for a shell part, as `path:line: what to use`. */
export function shellUseProblems(sourceDir = "source") {
  const problems = [];
  const visit = (dir) => {
    if (!existsSync(dir)) return;
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name);
      if (entry.isDirectory()) { if (entry.name !== "node_modules") visit(path); continue; }
      if (!/\.(?:ts|js|mjs)$/.test(entry.name)) continue;
      read(path).split("\n").forEach((line, index) => {
        for (const { pattern, use } of SHELL_SUBSTITUTES) if (pattern.test(line)) problems.push(`${path}:${index + 1}: use ${use}`);
      });
    }
  };
  visit(sourceDir);
  return problems;
}

/** All of an application's source text (ts, js, mjs), for the checks that look for a call anywhere in it. */
function sourceText(sourceDir) {
  const parts = [];
  const visit = (dir) => {
    if (!existsSync(dir)) return;
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name);
      if (entry.isDirectory()) { if (entry.name !== "node_modules") visit(path); }
      else if (/\.(?:ts|js|mjs)$/.test(entry.name)) parts.push(read(path));
    }
  };
  visit(sourceDir);
  return parts.join("\n");
}

/**
 * Settings is the shell's (GUIDELINES-SHELL.md, Settings): every application has Settings… (`app.settings`), opens it
 * with `showSettings`, includes the shell's General and Terminal pages, and Updates when its profile names a
 * repository, and draws no settings dialog of its own. Returns what is missing, as sentences.
 */
export function settingsProblems(sourceDir = "source", config = {}) {
  const text = sourceText(sourceDir);
  const problems = [];
  if (!/["']app\.settings["']/.test(text)) problems.push("Settings… is missing: add standardItem(\"app.settings\") to File and handle the app.settings action.");
  if (!/\bshowSettings\s*\(/.test(text)) problems.push("Settings is not the shell's: open it with showSettings from forge-shell/app/settings-dialog.");
  if (!/\bgeneralPage\s*\(/.test(text)) problems.push("Settings lacks the shell's General page: add generalPage(...).");
  if (!/\bterminalPage\s*\(/.test(text)) problems.push("Settings lacks the shell's Terminal page: add terminalPage(...).");
  if (config.identity?.repository && !/\bupdatesPage\s*\(/.test(text)) problems.push("Settings lacks the Updates page, though the profile names a repository: add updatesPage(...).");
  if (/className\s*[:=]\s*["'`][^"'`]*\b(?:settings-dialog|preferences-dialog|prefs-dialog)\b/.test(text) && !/\bshowSettings\s*\(/.test(text)) problems.push("The application draws a settings dialog of its own: use showSettings instead.");
  return problems;
}

/** A project file's extension: one letter and `fg`. */
export const PROJECT_EXTENSION = /^[a-z]fg$/;

/** Check the built app's shell boundary, using the app's own profile and generated output. */
export function checkForgeApp({ configPath = "forge.config.json", appDir = "build/app", renderer = "app.js", sourceDir = "source", appCss = "public/app.css", strictStyle = process.env.FORGE_STYLE_LINT === "error", warn = console.warn } = {}) {
  const config = JSON.parse(read(configPath));
  checkShellSource(shellSource, { name: config.identity.name, id: config.identity.id, extension: config.document?.extension });
  if (config.document) {
    assert.ok(config.document.noun && config.document.plural && config.document.extension, "incomplete saved-document profile");
    assert.match(String(config.document.extension), PROJECT_EXTENSION, `the project file is .<letter>fg, such as .${config.identity.id[0]}fg, not .${config.document.extension}`);
    assert.equal(typeof config.document.containsMultipleFiles, "boolean", "document profile must say whether it contains multiple files");
    assert.ok(config.document.tabs?.noun && config.document.tabs?.newTitle && config.document.tabs?.closeTitle,
      "document profile must describe its tab noun and controls");
  }
  const html = read(join(appDir, "index.html"));
  const css = read(join(appDir, "app.css"));
  const productName = config.identity.name.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
  assert.ok(!html.includes("__FORGE_"), "unfilled shell HTML slot");
  assert.ok(html.includes(`<title>${productName}</title>`), "built page has the wrong product name");
  assert.ok(html.includes(`localStorage.getItem("${config.identity.id}.settings")`), "built page uses the wrong settings key");
  for (const id of ["menubar", "toolstrip", "doc-tabs", "workspace", "center", "bottom", "bottom-tabs", "terminal-pane", "messages-pane", "inspector", "statusbar", "overlay-root"]) {
    assert.match(html, new RegExp(`id="${id}"`), `missing shared ${id} element`);
  }
  for (const slot of [config.html.center, config.html.panes]) {
    assert.ok(html.includes(read(slot).trim()), `built page does not contain ${slot}`);
  }
  assert.match(css, /^@import url\("forge-tokens\.css"\);\s*@import url\("forge-brand\.css"\);\s*@import url\("forge-shell\.css"\);/,
    "app CSS must load shared tokens, brand accents, and chrome in order");
  assert.equal(read(join(appDir, "forge-brand.css")), brandCss(config.theme), "built brand accents differ from the app profile");
  for (const name of ["tokens.css", "shell.css"]) {
    const output = join(appDir, `forge-${name === "tokens.css" ? "tokens" : "shell"}.css`);
    assert.equal(read(output), read(sharedStyle(name)), `${output} differs from the installed forge-shell package`);
  }
  assert.ok(!/(?:^|[;{\s])--(?:window|panel|raised|control|control-hover|well|separator|hairline|text|text-strong|text2|text3|warning)\s*:/m.test(css),
    "app CSS overrides a shared neutral chrome token");
  // The shell is binding: an application uses its parts wherever they apply and never a substitute.
  assert.deepEqual(shellUseProblems(sourceDir), [], "the application replaces a shell part (GUIDELINES.md, The shell is binding)");
  assert.deepEqual(settingsProblems(sourceDir, config), [], "Settings is not the shell's (GUIDELINES-SHELL.md, Settings)");
  const styleProblems = lintApp({ cssFiles: [appCss], sourceDir, dataColors: checkDataColors(config.dataColors) });
  if (strictStyle) assert.deepEqual(styleProblems, [], "style lint failed");
  for (const problem of styleProblems) warn(`style: ${problem}`);
  if (renderer) assert.ok(existsSync(join(appDir, renderer)), `missing renderer ${renderer}`);
  return { product: config.identity.name, appDir };
}
