import assert from "node:assert/strict";
import { test } from "node:test";
import { PROGRESS_WIDTH, progressBarParts, progressLine } from "../../source/app/progress-bar";
import { lastCheckedText, lastUpdateCheck, readUpdatePreferences, rememberUpdateCheck, writeUpdatePreferences } from "../../source/app/updates";
import { visiblePages, type SettingsPage } from "../../source/app/settings-dialog";

test("the progress bar is the setup's line: = filling 30 places, a turning end, the percent and the label", () => {
  assert.equal(progressLine(0, 0, "Downloading"), `[|${" ".repeat(29)}]   0%  Downloading`);
  assert.equal(progressLine(0.5, 1, "Downloading"), `[${"=".repeat(15)}/${" ".repeat(14)}]  50%  Downloading`);
  assert.equal(progressLine(1, 3, "Done"), `[${"=".repeat(30)}] 100%  Done`, "full: no turning end");
  assert.equal(progressBarParts(0.4, 0, true).filled, `${"=".repeat(12)}>`, "under reduced motion the end is >");
  for (const p of [0, 0.01, 0.33, 0.99, 1, 2, -1, NaN]) {
    const { filled, rest } = progressBarParts(p, 2);
    assert.equal(filled.length + rest.length, PROGRESS_WIDTH, `always ${PROGRESS_WIDTH} wide (p = ${p})`);
  }
});

test("Settings shows only the pages that have rows, in their order", () => {
  const page = (id: string, rows: number): SettingsPage => ({ id, title: id, icon: "", sections: [{ rows: Array.from({ length: rows }, () => ({ kind: "value" as const, label: "x", value: () => "" })) }] });
  assert.deepEqual(visiblePages([page("general", 2), page("display", 0), page("updates", 1)]).map((item) => item.id), ["general", "updates"]);
});

test("update preferences check at launch unless turned off, and remember the last check", () => {
  const map = new Map<string, string>();
  const storage = { getItem: (key: string) => map.get(key) ?? null, setItem: (key: string, value: string) => void map.set(key, value) };
  assert.deepEqual(readUpdatePreferences("app.updates", storage), { atLaunch: true, lastChecked: null });
  writeUpdatePreferences("app.updates", { atLaunch: false }, storage);
  rememberUpdateCheck({ status: "current" }, "app.updates", storage, 1_000);
  assert.deepEqual(readUpdatePreferences("app.updates", storage), { atLaunch: false, lastChecked: 1_000 });
  assert.deepEqual(lastUpdateCheck(), { status: "current" }, "the page shows this launch's result");
  map.set("app.updates", "not json");
  assert.deepEqual(readUpdatePreferences("app.updates", storage), { atLaunch: true, lastChecked: null }, "an unreadable value is the default");
  const now = new Date(2026, 10, 8, 15, 0).getTime();
  assert.equal(lastCheckedText(null, now), "Never");
  assert.match(lastCheckedText(new Date(2026, 10, 8, 9, 14).getTime(), now), /^Today, /);
  assert.match(lastCheckedText(new Date(2026, 10, 7, 18, 2).getTime(), now), /^Yesterday, /);
});

test("each shell setting names its Terminal command, and Restore page defaults sees which rows changed", async () => {
  const { changedRows, generalPage, terminalPage } = await import("../../source/app/settings-dialog");
  const settings = { showBottomPanel: true, showInspector: true, inspectorSide: "right" as const, appearance: "dark" as const, autosave: "off" as const };
  const general = generalPage({ settings, update: (change) => Object.assign(settings, change) });
  const rows = general.sections.flatMap((section) => section.rows);
  const hint = (label: string) => { const row = rows.find((item) => "label" in item && item.label === label)!; return row.kind === "select" ? row.command!(row.value()) : row.kind === "check" ? row.command!(row.value()) : ""; };
  assert.deepEqual(["Appearance", "Inspector", "Show bottom panel", "Autosave"].map(hint), ["theme dark", "inspector right", "panel on", "autosave off"]);
  assert.deepEqual(changedRows(general), [], "at the defaults nothing is to restore");
  Object.assign(settings, { appearance: "light", showInspector: false });
  assert.deepEqual(changedRows(general).map((row) => "label" in row && row.label), ["Appearance", "Inspector"]);
  assert.equal(hint("Inspector"), "inspector off");
  // the one Inspector row shows it on a side, or hides it, as `inspector left|right|off` does
  const inspector = rows.find((item) => "label" in item && item.label === "Inspector")!;
  assert.ok(inspector.kind === "select");
  inspector.set("left");
  assert.deepEqual([settings.showInspector, settings.inspectorSide], [true, "left"]);
  inspector.set("hidden");
  assert.deepEqual([settings.showInspector, settings.inspectorSide, inspector.value()], [false, "left", "hidden"]);
  let size = 16;
  const terminal = terminalPage({ fontSize: () => size, setFontSize: (value) => { size = value; } });
  const [font] = changedRows(terminal);
  assert.ok(font.kind === "select" && font.command!(font.value()) === "terminal font 16" && font.default === "12");
});

test("text and number rows hold typed values, restore to their defaults, and read a number within its bounds", async () => {
  const { changedRows, readNumberField } = await import("../../source/app/settings-dialog");
  const state = { title: "Report", decimals: -1 };
  const text = { kind: "text" as const, label: "Title", value: () => state.title, set: (value: string) => { state.title = value; }, command: (value: string) => `title ${value}`, default: "Untitled" };
  const number = { kind: "number" as const, label: "Decimals", min: 0, max: 10, auto: { value: -1, word: "auto" }, value: () => state.decimals, set: (value: number) => { state.decimals = value; }, command: (value: number) => `measure decimals ${value < 0 ? "auto" : value}`, default: -1 };
  const page: SettingsPage = { id: "measure", title: "Measure", icon: "", sections: [{ rows: [text, number] }] };
  assert.deepEqual(changedRows(page).map((row) => "label" in row && row.label), ["Title"], "the number is at its default");
  state.decimals = 3;
  assert.equal(changedRows(page).length, 2);
  assert.equal(readNumberField(number, " 4 "), 4);
  assert.equal(readNumberField(number, "25"), 10, "kept within max");
  assert.equal(readNumberField(number, "-2"), 0, "kept within min");
  assert.equal(readNumberField(number, "AUTO"), -1, "the auto word reads as its value");
  assert.equal(readNumberField(number, "4px"), null, "not a number");
  assert.equal(readNumberField(number, ""), null);
  assert.equal(number.command(-1), "measure decimals auto");
});

test("settings opens Settings, on a page when one is named, and lists the pages for an unknown one", async () => {
  const { runSharedCommand } = await import("../../source/app/shared-commands");
  const opened: (string | undefined)[] = [];
  const host = { run() {}, actions: ["app.settings"], hasDocument: false, noun: "document", productName: "Example", version: "1.0.0", fontSize: () => 12, setFontSize() {},
    openSettings: (page?: string) => { opened.push(page); }, settingsPages: () => ["general", "terminal", "updates"] };
  assert.deepEqual(runSharedCommand("settings", "", host), { lines: [] });
  assert.deepEqual(runSharedCommand("settings", "updates", host), { lines: [] });
  assert.deepEqual(opened, [undefined, "updates"]);
  assert.deepEqual(runSharedCommand("settings", "colours", host), { lines: ["No settings page colours. Pages: general, terminal, updates."] });
  let ran = "";
  assert.deepEqual(runSharedCommand("settings", "", { ...host, openSettings: undefined, run: (action: string) => { ran = action; } }), { lines: [] });
  assert.equal(ran, "app.settings", "without openSettings it runs the menu action");
  assert.equal(runSharedCommand("settings", "", { ...host, actions: [] }), null, "an app without Settings has no settings command");
});
