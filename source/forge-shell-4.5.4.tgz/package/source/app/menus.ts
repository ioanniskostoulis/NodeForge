// Licensed under the GNU General Public License v2 or later. See LICENSE.
export interface MenuNode {
  label?: string;
  /** Command id sent back when clicked. */
  id?: string;
  /** Electron accelerator syntax, e.g. "CmdOrCtrl+R". */
  key?: string;
  /** A key shown beside the item but not bound by the menu (the app handles it: Esc, ⌫). */
  hint?: string;
  checked?: boolean;
  enabled?: boolean;
  submenu?: MenuNode[];
  separator?: boolean;
  /** Electron role for standard items (quit, close, togglefullscreen, …); desktop only. */
  role?: string;
}

const isMac = /Mac/.test(navigator.platform);

// MARK: shortcut text

// macOS menus show glyphs for named keys; Windows menus show their names. A letter is upper case on both.
const MENU_KEY_GLYPHS: Record<string, string> = { Enter: "↩", Return: "↩", Right: "→", Left: "←", Up: "↑", Down: "↓", Tab: "⇥", Escape: "⎋", Esc: "⎋",
  Backspace: "⌫", Delete: "⌦", Space: "Space", Home: "↖", End: "↘", PageUp: "⇞", PageDown: "⇟" };
const MENU_KEY_NAMES: Record<string, string> = { Enter: "Enter", Return: "Enter", Escape: "Esc", Esc: "Esc", Backspace: "Backspace", Delete: "Del", Space: "Space",
  Home: "Home", End: "End", PageUp: "PgUp", PageDown: "PgDn", Tab: "Tab", Right: "→", Left: "←", Up: "↑", Down: "↓" };
const MENU_MODIFIER_GLYPHS: Record<string, string> = { Alt: "⌥", Shift: "⇧", CmdOrCtrl: "⌘", Ctrl: "⌃" };
const MENU_MODIFIER_ORDER = ["Ctrl", "Alt", "Shift", "CmdOrCtrl"];

const keyLabel = (key: string, table: Record<string, string>) => table[key] ?? (key.length === 1 ? key.toUpperCase() : key);

/** "CmdOrCtrl+Shift+R" → "⇧⌘R" on Mac, "Ctrl+Shift+R" elsewhere. */
export function displayKey(key: string): string {
  const parts = key.split("+");
  const last = parts.pop()!;
  if (!isMac) return [...parts.map((part) => (part === "CmdOrCtrl" ? "Ctrl" : part)), keyLabel(last, MENU_KEY_NAMES)].join("+");
  const modifiers = parts.sort((a, b) => MENU_MODIFIER_ORDER.indexOf(a) - MENU_MODIFIER_ORDER.indexOf(b)).map((part) => MENU_MODIFIER_GLYPHS[part] ?? part);
  return modifiers.join("") + keyLabel(last, MENU_KEY_GLYPHS);
}

// Key names written out, as macOS and Windows name them in their own help: modifiers in the platform's order.
const MAC_MODIFIERS: [string, string][] = [["Ctrl", "Control"], ["Alt", "Option"], ["Shift", "Shift"], ["CmdOrCtrl", "Cmd"], ["Cmd", "Cmd"]];
const WIN_MODIFIERS: [string, string][] = [["CmdOrCtrl", "Ctrl"], ["Ctrl", "Ctrl"], ["Alt", "Alt"], ["Shift", "Shift"]];
const KEY_NAMES: Record<string, [mac: string, win: string]> = {
  Enter: ["Return", "Enter"], Return: ["Return", "Enter"], Escape: ["Esc", "Esc"], Esc: ["Esc", "Esc"], Backspace: ["Delete", "Backspace"],
  Delete: ["Forward Delete", "Delete"], Tab: ["Tab", "Tab"], Space: ["Space", "Space"], Right: ["Right", "Right"], Left: ["Left", "Left"],
  Up: ["Up", "Up"], Down: ["Down", "Down"], Home: ["Home", "Home"], End: ["End", "End"], PageUp: ["Page Up", "Page Up"], PageDown: ["Page Down", "Page Down"],
};
// Glyphs an app may have written as a hint, read back as accelerator names.
const GLYPHS: Record<string, string> = { "⌫": "Backspace", "⎋": "Escape", "↩": "Enter", "⏎": "Enter", "⇥": "Tab", "→": "Right", "←": "Left", "↑": "Up", "↓": "Down" };

/**
 * A shortcut written out for help text and tooltips: "CmdOrCtrl+Shift+Z" is "Cmd + Shift + Z" on macOS and
 * "Ctrl + Shift + Z" elsewhere, with a space either side of each plus. Menus keep `displayKey`, as native menus do.
 */
export function shortcutText(key: string, mac = isMac): string {
  const parts = key.split(/\+(?!$)/).map((part) => GLYPHS[part] ?? part);
  const last = parts.pop()!;
  const order = mac ? MAC_MODIFIERS : WIN_MODIFIERS;
  const modifiers = order.filter(([name]) => parts.includes(name)).map(([, label]) => label).filter((label, index, all) => all.indexOf(label) === index);
  const named = KEY_NAMES[last]?.[mac ? 0 : 1] ?? (last.length === 1 ? last.toUpperCase() : last);
  return [...modifiers, named].join(" + ");
}

// MARK: matching key events

// Named keys and punctuation by their physical code, so that they match on every keyboard layout (Greek included).
const KEY_CODES: Record<string, string> = { Enter: "Enter", Return: "Enter", Right: "ArrowRight", Left: "ArrowLeft", Up: "ArrowUp", Down: "ArrowDown", "=": "Equal", "-": "Minus",
  "[": "BracketLeft", "]": "BracketRight", "/": "Slash", ",": "Comma", ".": "Period", ";": "Semicolon", "'": "Quote", "`": "Backquote", "\\": "Backslash",
  Tab: "Tab", Escape: "Escape", Esc: "Escape", Backspace: "Backspace", Delete: "Delete", Space: "Space", Home: "Home", End: "End", PageUp: "PageUp", PageDown: "PageDown" };

/**
 * Do the event's modifiers match an accelerator's? CmdOrCtrl is Cmd on macOS and Ctrl elsewhere; outside macOS a plain
 * Ctrl is the same key, and on macOS Control must match on its own.
 */
function modifiersMatch(e: KeyboardEvent, parts: readonly string[]): boolean {
  const wantsCtrl = parts.includes("Ctrl");
  const commandKey = isMac ? e.metaKey : e.ctrlKey;
  const wantsCommandKey = parts.includes("CmdOrCtrl") || (!isMac && wantsCtrl);
  const controlMatches = !isMac || e.ctrlKey === wantsCtrl;
  return [commandKey === wantsCommandKey, controlMatches, e.altKey === parts.includes("Alt"), e.shiftKey === parts.includes("Shift")].every(Boolean);
}

/** Does a keyboard event match an accelerator? */
export function matchesKey(e: KeyboardEvent, key: string): boolean {
  const parts = key.split("+");
  const last = parts.pop()!;
  if (!modifiersMatch(e, parts)) return false;
  const code = KEY_CODES[last];
  if (code) return e.code === code || e.key === code;
  return e.code === `Key${last.toUpperCase()}` || e.code === `Digit${last}` || e.key.toLowerCase() === last.toLowerCase();
}

const hasModifier = (e: KeyboardEvent) => [e.shiftKey, e.metaKey, e.ctrlKey, e.altKey].some(Boolean);

// MARK: the drawn menu bar

/** Where the menu bar is drawn by the page: the browser, and Windows desktop, where native menus cannot be styled. */
export function drawsMenubar(platform: string, desktop: boolean): boolean {
  return !desktop || platform === "win32";
}

/** The colours of the native window controls beside a drawn title bar, from the page's current theme. */
export function titleBarColors(element: HTMLElement = document.getElementById("menubar") ?? document.body): { color: string; symbolColor: string } {
  const style = getComputedStyle(element);
  return { color: style.backgroundColor, symbolColor: getComputedStyle(document.body).color };
}

/** The standard edit roles a drawn menu performs itself, as the native menu does. */
export const EDIT_ROLES: Record<string, () => void> = {
  undo: () => document.execCommand("undo"),
  redo: () => document.execCommand("redo"),
  cut: () => document.execCommand("cut"),
  copy: () => document.execCommand("copy"),
  paste: () => { void navigator.clipboard.readText().then((text) => document.execCommand("insertText", false, text)).catch(() => document.execCommand("paste")); },
  pasteAndMatchStyle: () => EDIT_ROLES.paste(),
  delete: () => document.execCommand("delete"),
  selectAll: () => document.execCommand("selectAll"),
};

export interface MenubarOptions {
  /** The bar is the window's title bar (Windows desktop): it drags the window and leaves room for its controls. */
  titleBar?: boolean;
  /** Actions for role items beyond `EDIT_ROLES`, such as `togglefullscreen`; a role without an action is left out. */
  roles?: Record<string, () => void>;
}

/** A row of an open popup, with what Enter and the arrow keys do to it. */
interface MenuRow { el: HTMLElement; disabled: boolean; openSub?: () => void; activate?: () => void }
interface OpenPopup { el: HTMLElement; rows: MenuRow[] }

/** A menu item's row: its check column, label, key and submenu arrow. The label is set as text, never as markup. */
function rowElement(item: MenuNode, disabled: boolean): HTMLElement {
  const row = document.createElement("div");
  const checkable = "checked" in item;
  const key = item.key ?? item.hint;
  row.className = "menu-item" + (disabled ? " disabled" : "");
  row.setAttribute("role", checkable ? "menuitemcheckbox" : "menuitem");
  if (checkable) row.setAttribute("aria-checked", String(!!item.checked));
  if (disabled) row.setAttribute("aria-disabled", "true");
  row.innerHTML = `<span class="check" aria-hidden="true">${item.checked ? "✓" : ""}</span><span class="label"></span>`
    + (key ? `<span class="key">${displayKey(key)}</span>` : "") + (item.submenu ? '<span class="sub">›</span>' : "");
  row.children[1].textContent = item.label ?? "";
  row.title = item.label ?? "";
  return row;
}

/** Move a popup back inside the window when it would run off its right or bottom edge. */
function keepInViewport(el: HTMLElement): void {
  const bounds = el.getBoundingClientRect();
  if (bounds.right > innerWidth) el.style.left = `${Math.max(0, innerWidth - bounds.width - 4)}px`;
  if (bounds.bottom > innerHeight) el.style.top = `${Math.max(0, innerHeight - bounds.height - 4)}px`;
}

/** One drawn menu bar: its titles, the stack of open popups, and the pointer and keyboard handling. */
class Menubar {
  private open: OpenPopup[] = [];
  private openTitle: HTMLElement | null = null;
  private readonly titles: HTMLElement[] = [];
  private altAlone = false;
  private readonly root = document.getElementById("overlay-root")!;
  private readonly menus: MenuNode[];
  private readonly run: (id: string) => void;
  private readonly roles: Record<string, () => void>;

  constructor(bar: HTMLElement, menus: MenuNode[], run: (id: string) => void, options: MenubarOptions) {
    this.menus = menus;
    this.run = run;
    this.roles = { ...EDIT_ROLES, ...options.roles };
    bar.hidden = false;
    bar.replaceChildren(...menus.map((menu) => this.title(menu)));
    bar.classList.toggle("title-bar", !!options.titleBar);
    bar.setAttribute("role", "menubar");
  }

  /** Listen to the document; the returned function stops listening and closes any open popup. */
  attach(): () => void {
    document.addEventListener("mousedown", this.outside);
    document.addEventListener("keydown", this.keys, true);
    document.addEventListener("keyup", this.keys, true);
    return () => {
      this.closeAll();
      document.removeEventListener("mousedown", this.outside);
      document.removeEventListener("keydown", this.keys, true);
      document.removeEventListener("keyup", this.keys, true);
    };
  }

  private readonly outside = (e: MouseEvent) => {
    if (!(e.target as HTMLElement).closest(".menu-popup, .menu-title")) this.closeAll();
  };

  private readonly keys = (e: KeyboardEvent) => {
    if (e.type === "keyup") this.keyUp(e);
    else this.keyDown(e);
  };

  // MARK: titles and popups

  private title(menu: MenuNode): HTMLElement {
    const title = document.createElement("div");
    title.className = "menu-title";
    title.textContent = menu.label ?? "";
    title.setAttribute("role", "menuitem");
    this.titles.push(title);
    if (!menu.submenu && menu.id) {
      title.addEventListener("mousedown", (e) => { e.preventDefault(); this.closeAll(); this.run(menu.id!); });
      return title;
    }
    title.setAttribute("aria-haspopup", "menu");
    title.addEventListener("mousedown", (e) => {
      e.preventDefault();
      if (this.openTitle === title) this.closeAll();
      else this.show(title, menu);
    });
    title.addEventListener("mouseenter", () => {
      if (this.openTitle && this.openTitle !== title) this.show(title, menu);
    });
    return title;
  }

  private show(title: HTMLElement, menu: MenuNode): void {
    this.closeAll();
    this.openTitle = title;
    title.classList.add("open");
    const bounds = title.getBoundingClientRect();
    this.popup(menu.submenu ?? [], bounds.left, bounds.bottom + 4, 0);
  }

  private popup(items: MenuNode[], x: number, y: number, level: number): void {
    this.closeFrom(level);
    const el = document.createElement("div");
    // The check column is reserved only when an item in this popup can be checked, so that a menu of plain actions has no gap.
    el.className = "menu-popup" + (items.some((item) => "checked" in item) ? " has-checks" : "");
    el.setAttribute("role", "menu");
    el.style.left = `${x}px`;
    el.style.top = `${y}px`;
    const rows: MenuRow[] = [];
    for (const item of items) {
      if (item.separator) { el.append(Object.assign(document.createElement("div"), { className: "menu-sep" })); continue; }
      const row = this.row(item, level, rows.length);
      if (!row) continue;
      rows.push(row);
      el.append(row.el);
    }
    this.root.append(el);
    keepInViewport(el);
    this.open.push({ el, rows });
  }

  /** A popup row, or null for a role item the page cannot perform. */
  private row(item: MenuNode, level: number, index: number): MenuRow | null {
    const role = item.role ? this.roles[item.role] : undefined;
    if (item.role && !role) return null;
    const disabled = item.enabled === false || !(item.id || item.submenu || role);
    const el = rowElement(item, disabled);
    const openSub = item.submenu && !disabled ? () => {
      const bounds = el.getBoundingClientRect();
      this.popup(item.submenu!, bounds.right - 2, bounds.top - 5, level + 1);
    } : undefined;
    // An enabled item without a submenu has an id or a role to run.
    const activate = disabled || item.submenu ? undefined : () => {
      this.closeAll();
      if (role) role();
      else this.run(item.id!);
    };
    el.addEventListener("mouseenter", () => {
      this.highlight(level, index);
      if (openSub) openSub();
      else this.closeFrom(level + 1);
    });
    if (activate) el.addEventListener("click", activate);
    return { el, disabled, openSub, activate };
  }

  private closeFrom(level: number): void {
    for (const popup of this.open.splice(level)) popup.el.remove();
  }

  private closeAll(): void {
    this.closeFrom(0);
    this.openTitle?.classList.remove("open");
    this.openTitle = null;
  }

  /** Highlight a row of the popup at `level` for the keyboard, as the pointer does. */
  private highlight(level: number, index: number): void {
    this.open[level]?.rows.forEach((row, at) => row.el.classList.toggle("active", at === index));
  }

  private activeIndex(level: number): number {
    return this.open[level]?.rows.findIndex((row) => row.el.classList.contains("active")) ?? -1;
  }

  // MARK: keyboard

  /** Open the menu `step` titles away from the open one, wrapping around, and highlight its first row. */
  private moveTitle(step: number): void {
    const at = this.openTitle ? this.titles.indexOf(this.openTitle) : -1;
    const next = (at + step + this.titles.length) % this.titles.length;
    const menu = this.menus[next];
    if (menu?.submenu) { this.show(this.titles[next], menu); this.highlight(0, 0); }
  }

  private toggleFirstMenu(): void {
    if (this.open.length) this.closeAll();
    else this.moveTitle(1);
  }

  // Outside macOS, Alt pressed and released alone, or F10, opens the first menu, as Windows does.
  private keyUp(e: KeyboardEvent): void {
    if (e.key === "Alt" && this.altAlone && !isMac) { e.preventDefault(); this.toggleFirstMenu(); }
    this.altAlone = false;
  }

  private keyDown(e: KeyboardEvent): void {
    this.altAlone = e.key === "Alt" && !e.repeat;
    if (e.key === "F10" && !isMac && !hasModifier(e)) { e.preventDefault(); this.toggleFirstMenu(); return; }
    if (!this.open.length) return;
    const action = this.navigation(this.open.length - 1).get(e.key);
    if (!action) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    action();
  }

  /** What each key does in the deepest open popup. */
  private navigation(level: number): Map<string, () => void> {
    const at = this.activeIndex(level);
    const row = this.open[level].rows[at] as MenuRow | undefined;
    const back = (orElse: () => void) => () => (level > 0 ? this.closeFrom(level) : orElse());
    const enterSubmenu = (orElse: () => void) => () => {
      if (row?.openSub) { row.openSub(); this.highlight(level + 1, 0); } else orElse();
    };
    const choose = enterSubmenu(() => row?.activate?.());
    return new Map<string, () => void>([
      ["Escape", back(() => this.closeAll())],
      ["ArrowDown", () => this.step(level, at, 1)],
      ["ArrowUp", () => this.step(level, at, at < 0 ? 0 : -1)],
      ["ArrowRight", enterSubmenu(() => this.moveTitle(1))],
      ["ArrowLeft", back(() => this.moveTitle(-1))],
      ["Enter", choose],
      [" ", choose],
    ]);
  }

  /** Highlight the next enabled row `delta` rows away from `from`, wrapping around. */
  private step(level: number, from: number, delta: number): void {
    const rows = this.open[level].rows;
    for (let tries = 1, index = from; tries <= rows.length; tries++) {
      index = (index + delta + rows.length) % rows.length;
      if (!rows[index].disabled) { this.highlight(level, index); return; }
    }
  }
}

const menubarCleanup = new WeakMap<HTMLElement, () => void>();

/** Render the menus as an HTML menu bar with nested pop-ups. Alt, F10 or the arrow keys move through it from the keyboard. */
export function renderMenubar(bar: HTMLElement, menus: MenuNode[], run: (id: string) => void, options: MenubarOptions = {}): void {
  menubarCleanup.get(bar)?.();
  menubarCleanup.set(bar, new Menubar(bar, menus, run, options).attach());
}

// MARK: shortcuts

/** Does a menu item bind its key for the application? Role items' keys belong to the focused field and the browser. */
const bindsKey = (item: MenuNode): item is MenuNode & { key: string; id: string } => !!(item.key && item.id) && !item.role && item.enabled !== false;

/**
 * Find all items with accelerators (for keyboard handling in the browser). Items with a role are left out: their keys
 * (Cmd+C, Cmd+V, Cmd+A…) belong to the focused text field and the browser, never to the application's handler.
 */
export function collectShortcuts(menus: MenuNode[], out: { key: string; id: string }[] = []): { key: string; id: string }[] {
  for (const m of menus) {
    if (bindsKey(m)) out.push({ key: m.key, id: m.id });
    if (m.submenu) collectShortcuts(m.submenu, out);
  }
  return out;
}

/** Menu shortcuts for the keyboard-help window, in app-supplied category order. */
export function menuShortcutRows(commands: readonly { id: string; label: string; key?: string; hint?: string }[], order: readonly string[]): [string, string][] {
  const seen = new Set<string>();
  const rank = (id: string) => {
    const index = order.indexOf(id.split(".")[0]);
    return index < 0 ? order.length : index;
  };
  const keyOf = (command: (typeof commands)[number]) => command.key ?? command.hint;
  return commands.filter((command) => {
    const key = keyOf(command);
    return !!key && !seen.has(key) && !!seen.add(key);
  }).sort((a, b) => rank(a.id) - rank(b.id))
    .map((command) => [shortcutText(keyOf(command)!), command.label.replace(/\s+\(.*\)$/, "").replace(/…$/, "")]);
}
