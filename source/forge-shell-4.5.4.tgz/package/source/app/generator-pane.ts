// Licensed under the GNU General Public License v2 or later. See LICENSE.
// A generator pane of the bottom panel, beside the Terminal: one layout for every pane that makes something from a few
// options. On the left are the options, rows of a label and a control in titled groups;
// on the right two tiles side by side: Code (editable in the shared editor, with Save) and Preview (an image, a table
// or the application's own element, panned and zoomed by `PreviewStage`). The options write the code, the code builds
// the preview. Each document keeps its own options, code and undo history for the session. The Terminal opens the
// pane and sets its options by name with `runGeneratorCommand`.
// It imports the shared code editor, so CodeMirror is needed: import it from `forge-shell/app/generator-pane`.
import { Compartment, EditorState, type Extension } from "@codemirror/state";
import { EditorView } from "@codemirror/view";
import { codeEditorSetup } from "./code-editor";
import { followPointer } from "./pointer-drag";
import { setTip } from "./tips";
import { CHOICE_RULE, type GeneratorField, type GeneratorGroup, type GeneratorValues } from "./generator-fields";
import { createSelectControl } from "./select-control";
import type { GeneratorTarget } from "./generator-command";
import { codeShare, fitCode, fitOptions, optionsShare, optionsShareOf } from "./generator-layout";
import { PreviewScheduler, buildProblem, type PreviewBuild } from "./preview-scheduler";
import { PreviewStage, type PreviewContent, type PreviewFit } from "./preview-stage";

export interface GeneratorPaneHost {
  /** The pane's noun in lower case, as typed in the Terminal and said in sentences: `plot`, `table`. */
  readonly noun: string;
  /** "contain" for a plot or an image, "width" for a table. */
  readonly fit: PreviewFit;
  /** The options of a document seen for the first time. */
  defaults(): GeneratorValues;
  /** The options to draw for these values; called again after every change, so fields can appear and go. */
  form(values: GeneratorValues): GeneratorGroup[];
  /** The code for these values. Throw (or reject) with a sentence when they are incomplete: it shows under the options. */
  code(values: GeneratorValues): string | Promise<string>;
  /** Build the preview of the code; without it the Preview tile says `previewNote`. */
  build?(code: string, values: GeneratorValues): Promise<PreviewBuild<PreviewContent>>;
  /** What the Preview tile says when there is no `build` (the browser preview of a desktop application). */
  previewNote?: string;
  /** Save the code; without it there is no Save button. `saveTip` says where it goes. */
  save?(code: string, values: GeneratorValues): Promise<void> | void;
  saveTip?: string;
  /** Why there is nothing to make yet (no data file), or null. The options but the first group grey out and both tiles say it. */
  idle?(values: GeneratorValues): string | null;
  /** A preview that failed: sent to Messages and the status bar. */
  problem(text: string): void;
  /** The options' share of the pane and the Code tile's share of the tiles, remembered as application preferences. */
  optionsShare(): number;
  saveOptionsShare(share: number): void;
  codeShare(): number;
  saveCodeShare(share: number): void;
  /** The code's language, such as `python()`; plain text without it. */
  language?: Extension;
  /** The code's text size in px; 12 when not given. */
  codeSize?(): number;
}

type DocumentState = { values: GeneratorValues; editor: EditorState | null };

const capital = (text: string) => text.charAt(0).toUpperCase() + text.slice(1);

export class GeneratorPane implements GeneratorTarget {
  private readonly form = element("div", "generator-fields");
  private readonly problemLine = element("div", "generator-problem");
  private readonly tiles = element("div", "generator-tiles");
  private readonly codeHost = element("div", "generator-code-editor");
  private readonly codeNote = element("div", "generator-note");
  private readonly lineCount = element("span", "generator-tile-readout");
  private readonly saveButton: HTMLButtonElement | null;
  private readonly status = element("span", "generator-tile-readout");
  private readonly fitButton: HTMLButtonElement;
  private readonly note = element("div", "generator-note");
  private readonly preview: PreviewStage;
  private readonly view: EditorView;
  private readonly editable = new Compartment();
  private readonly scheduler: PreviewScheduler<PreviewContent>;
  private readonly states = new Map<string, DocumentState>();
  private document: string | null = null;
  private idleText: string | null = null;
  /** The code is being replaced by the options or a document switch, not typed. */
  private setting = false;
  private generation = 0;
  private codeTimer: ReturnType<typeof setTimeout> | undefined;
  private problemText = "";
  private building = false;

  constructor(private readonly root: HTMLElement, private readonly host: GeneratorPaneHost) {
    root.classList.add("generator");
    const noun = capital(host.noun);
    const options = element("div", "generator-options");
    this.problemLine.setAttribute("role", "status");
    this.problemLine.hidden = true;
    options.append(this.form, this.problemLine);

    // Code tile: title, line count, Save
    const codeTile = element("section", "generator-tile");
    codeTile.setAttribute("aria-label", "Code");
    this.saveButton = host.save ? chip("Save", host.saveTip ?? `Save this ${host.noun}.`, () => { void this.save(); }) : null;
    this.saveButton?.classList.add("primary");
    codeTile.append(tileHead("Code", this.lineCount, this.saveButton ? [this.saveButton] : []), this.codeHost, this.codeNote);
    // Preview tile: title, zoom or build state, Fit
    const previewTile = element("section", "generator-tile");
    previewTile.setAttribute("aria-label", "Preview");
    this.status.setAttribute("aria-live", "polite");
    this.fitButton = chip("Fit", "Fit the preview to the tile.", () => this.preview.fit(true));
    const stage = element("div", "generator-stage");
    stage.setAttribute("role", "img");
    stage.setAttribute("aria-label", `${noun} preview`);
    this.preview = new PreviewStage(stage, {
      mode: () => host.fit,
      changed: () => this.updateReadout(),
      failed: (error) => this.failed(`The ${host.noun} preview could not be shown: ${buildProblem(error)}`),
    });
    previewTile.append(tileHead("Preview", this.status, [this.fitButton]), stage, this.note);
    this.tiles.append(codeTile, this.splitter("code"), previewTile);
    root.replaceChildren(options, this.splitter("options"), this.tiles);
    new ResizeObserver(() => this.applyLayout()).observe(root);

    this.view = new EditorView({ parent: this.codeHost, state: this.createState("") });
    this.scheduler = new PreviewScheduler<PreviewContent>({
      build: (code) => host.build!(code, this.values),
      show: (content) => { this.problemText = ""; void this.preview.show(content).then(() => this.updateReadout()); },
      busy: (running) => { this.building = running; this.updateReadout(); },
      problem: (text) => this.failed(`The ${host.noun} preview did not build: ${text}`),
    });
    this.showDocument(null);
  }

  get noun(): string { return this.host.noun; }
  /** The options of the shown document; empty when none is shown. */
  get values(): GeneratorValues { return this.current()?.values ?? {}; }
  get code(): string { return this.view.state.doc.toString(); }
  groups(): GeneratorGroup[] { return this.document ? this.host.form(this.values) : []; }

  /** Change options, as the form does: the form is drawn again and the code written again. */
  set(patch: GeneratorValues): void {
    const state = this.current();
    if (!state) return;
    Object.assign(state.values, patch);
    this.renderForm();
    this.scheduleCode();
  }

  canSave(): true | string {
    if (!this.host.save) return `A ${this.host.noun} cannot be saved here.`;
    if (!this.document) return "Open a document first.";
    if (this.idleText) return this.idleText;
    if (!this.code.trim()) return `The ${this.host.noun} has no code yet.`;
    return true;
  }

  async save(): Promise<void> {
    if (this.canSave() !== true) return;
    await this.host.save!(this.code, { ...this.values });
  }

  /** Show the options, code and preview of a document, or an empty pane when none is open. */
  showDocument(id: string | null): void {
    const previous = this.current();
    if (previous) previous.editor = this.view.state;
    this.document = id;
    this.scheduler.cancel();
    this.preview.clear();
    this.problemText = "";
    let state = id ? this.states.get(id) : undefined;
    if (id && !state) { state = { values: { ...this.host.defaults() }, editor: null }; this.states.set(id, state); }
    this.setting = true;
    this.view.setState(state?.editor ?? this.createState(""));
    this.setting = false;
    this.renderForm();
    if (state && !state.editor) this.regenerate(); else this.requestPreview();
    this.updateButtons();
    this.updateReadout();
  }

  /** The application's data changed (files, sheets): draw the options again and write the code again. */
  refresh(): void {
    if (!this.document) return;
    this.renderForm();
    this.scheduleCode();
  }

  /** Forget a closed document. */
  forget(id: string): void {
    this.states.delete(id);
    if (this.document === id) this.showDocument(null);
  }

  /** Fit the preview to its tile. */
  fitPreview(): void { this.preview.fit(true); }

  /** The code's text size changed. */
  configureEditor(): void { this.root.style.setProperty("--generator-code-size", `${this.host.codeSize?.() ?? 12}px`); }

  /** Set the widths: the options a third to a half of the pane, the tiles sharing the rest. */
  applyLayout(): void {
    const total = this.root.clientWidth;
    if (total <= 0) return;
    const optionsWidth = fitOptions(total, this.host.optionsShare());
    this.root.style.setProperty("--generator-options", `${optionsWidth}px`);
    this.tiles.style.setProperty("--generator-code", `${fitCode(total - optionsWidth - 1, this.host.codeShare())}px`);
  }

  // MARK: options and code

  private current(): DocumentState | undefined { return this.document ? this.states.get(this.document) : undefined; }

  private createState(text: string): EditorState {
    return EditorState.create({ doc: text, extensions: [
      codeEditorSetup({ onChange: () => this.codeChanged() }),
      this.host.language ?? [],
      this.editable.of(EditorView.editable.of(true)),
      EditorView.contentAttributes.of({ "aria-label": `${capital(this.host.noun)} code`, autocapitalize: "off", autocorrect: "off" }),
    ] });
  }

  private codeChanged(): void {
    this.updateButtons();
    if (!this.setting) this.requestPreview();
  }

  /** Replace the code as one undoable change, so Undo in the Code tile brings back hand edits. */
  private setCode(text: string): void {
    if (this.code === text) return;
    this.view.dispatch({ changes: { from: 0, to: this.view.state.doc.length, insert: text } });
  }

  private renderForm(): void {
    const state = this.current();
    if (!state) { this.form.replaceChildren(); this.formProblem(""); this.setIdle(null); return; }
    const idle = this.host.idle?.(state.values) ?? null;
    const groups = this.host.form(state.values).map((group, index) => {
      // With nothing to read, every group but the first (where the source is chosen) greys out.
      const greyed = group.idle ?? (!!idle && index > 0);
      const box = renderGroup(group, state.values, (key, value, redraw) => {
        state.values[key] = value;
        if (redraw) this.renderForm();
        this.scheduleCode();
      }, greyed);
      return box;
    });
    this.form.replaceChildren(...groups);
    this.setIdle(idle);
  }

  /** Grey the Code tile and show why, or restore it. */
  private setIdle(text: string | null): void {
    this.idleText = text;
    this.codeHost.classList.toggle("idle", !!text);
    this.view.dispatch({ effects: this.editable.reconfigure(EditorView.editable.of(!text)) });
    this.updateButtons();
    this.updateReadout();
  }

  private scheduleCode(): void {
    if (this.codeTimer) clearTimeout(this.codeTimer);
    this.codeTimer = setTimeout(() => this.regenerate(), 250);
  }

  /** Write the code from the options. A problem in the options is shown under them, and the code is left as it is. */
  private regenerate(): void {
    const state = this.current();
    if (!state) return;
    const generation = ++this.generation;
    if (this.idleText) { this.formProblem(""); this.setCode(""); this.scheduler.cancel(); this.preview.clear(); this.updateReadout(); return; }
    Promise.resolve().then(() => this.host.code({ ...state.values })).then((text) => {
      if (generation !== this.generation) return;
      this.formProblem("");
      this.setCode(text);
      this.requestPreview();
    }, (error) => { if (generation === this.generation) this.formProblem(sentence(buildProblem(error))); });
  }

  private formProblem(text: string): void {
    this.problemLine.textContent = text;
    this.problemLine.hidden = !text;
  }

  private requestPreview(): void {
    if (!this.host.build || !this.document || this.idleText || !this.code.trim()) { this.scheduler.cancel(); return; }
    this.scheduler.request(this.code);
  }

  private failed(text: string): void {
    this.problemText = text;
    this.host.problem(text);
    this.updateReadout();
  }

  private updateButtons(): void {
    const empty = !this.document || !this.code.trim();
    if (this.saveButton) this.saveButton.disabled = this.canSave() !== true;
    const lines = this.view.state.doc.lines;
    this.lineCount.textContent = empty ? "" : `${lines} ${lines === 1 ? "line" : "lines"}`;
  }

  /** The Preview tile's readout (the build state, else the zoom) and the notes of both tiles. */
  private updateReadout(): void {
    const loaded = this.preview.loaded;
    this.status.textContent = this.building ? "Building…" : this.problemText ? "Failed" : loaded ? `${this.preview.percent}%` : "";
    // The shell's tile rule: work in progress reads in the accent, a failure in the error colour; the reason is in Messages.
    this.status.classList.toggle("busy", this.building);
    // The Preview tile is busy while it builds: for assistive technology, and the progress cursor over the tile.
    const tile = this.status.closest(".generator-tile");
    if (this.building) tile?.setAttribute("aria-busy", "true"); else tile?.removeAttribute("aria-busy");
    this.status.classList.toggle("failed", !!this.problemText && !this.building);
    this.fitButton.setAttribute("aria-pressed", String(loaded && this.preview.view.fitting));
    this.fitButton.disabled = !loaded;
    const text = !this.document ? "" : this.idleText ?? (!this.host.build ? this.host.previewNote ?? "" : loaded ? "" : `The preview appears here once the ${this.host.noun} builds.`);
    this.note.textContent = text;
    this.note.hidden = !text;
    this.codeNote.textContent = this.idleText ?? "";
    this.codeNote.hidden = !this.idleText;
  }

  /** A splitter after the options or between the tiles: drag, arrow keys, or a double click for the default. */
  private splitter(which: "options" | "code"): HTMLElement {
    const split = element("div", "split vertical generator-split");
    split.setAttribute("role", "separator");
    split.setAttribute("aria-orientation", "vertical");
    split.setAttribute("aria-label", which === "options" ? "Resize the options" : "Resize the code and the preview");
    setTip(split, which === "options" ? "Sets the width of the options; double-click restores the default." : "Sets the widths of the code and the preview; double-click restores the default.");
    split.tabIndex = 0;
    const widths = () => {
      const total = this.root.clientWidth, optionsWidth = fitOptions(total, this.host.optionsShare());
      return { total, optionsWidth, room: total - optionsWidth - 1, codeWidth: fitCode(total - optionsWidth - 1, this.host.codeShare()) };
    };
    const set = (width: number) => {
      const { total, room } = widths();
      if (which === "options") this.host.saveOptionsShare(optionsShareOf(total, width));
      else this.host.saveCodeShare(Math.max(codeShare.min, Math.min(codeShare.max, width / Math.max(1, room - 1))));
      this.applyLayout();
    };
    const current = () => which === "options" ? widths().optionsWidth : widths().codeWidth;
    split.addEventListener("pointerdown", (event) => {
      const start = event.clientX, width = current();
      followPointer(split, event, { move: (next) => set(width + next.clientX - start) });
    });
    split.addEventListener("dblclick", () => {
      if (which === "options") this.host.saveOptionsShare(optionsShare.initial); else this.host.saveCodeShare(codeShare.initial);
      this.applyLayout();
    });
    split.addEventListener("keydown", (event) => {
      if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
      event.preventDefault();
      set(current() + (event.key === "ArrowRight" ? 16 : -16));
    });
    return split;
  }
}

// MARK: parts

function element(tag: string, className: string): HTMLElement { const node = document.createElement(tag); node.className = className; return node; }
const sentence = (text: string) => (/[.!?]$/.test(text) ? text : `${text}.`);

/** A tile's header: the title, a quiet readout, then its buttons at the right. */
function tileHead(title: string, readout: HTMLElement, buttons: HTMLElement[]): HTMLElement {
  const head = element("div", "generator-tile-head");
  const name = element("h3", "generator-tile-title");
  name.textContent = title;
  head.append(name, element("span", "generator-tile-space"), readout, ...buttons);
  return head;
}

/** A small header button: outlined, filled with the accent when primary or on (`aria-pressed`). */
function chip(label: string, tip: string, onClick: () => void): HTMLButtonElement {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "generator-chip";
  button.textContent = label;
  setTip(button, tip);
  button.addEventListener("click", onClick);
  return button;
}

type Change = (key: string, value: string | boolean, redraw: boolean) => void;

/** A titled group: its rows, then its on-off options side by side in one row. */
function renderGroup(group: GeneratorGroup, values: GeneratorValues, change: Change, idle: boolean): HTMLElement {
  const box = element("section", "generator-group");
  box.setAttribute("aria-label", group.title);
  box.classList.toggle("idle", idle);
  const heading = element("h3", "generator-group-title t-section");
  heading.textContent = group.title;
  box.append(heading);
  let checks: HTMLElement | null = null;
  for (const field of group.fields) {
    if (field.kind === "check") {
      if (!checks) { checks = element("div", "generator-checks"); box.append(checks); }
      checks.append(renderCheck(field, values, change, idle));
      continue;
    }
    checks = null;
    const row = element("div", "generator-field");
    const caption = element("span", "generator-label");
    caption.textContent = field.label;
    row.append(caption, renderControl(field, values, change, idle));
    box.append(row);
  }
  return box;
}

function renderCheck(field: GeneratorField, values: GeneratorValues, change: Change, idle: boolean): HTMLElement {
  const box = element("div", "generator-check");
  setTip(box, field.tip);
  const input = document.createElement("input");
  input.type = "checkbox";
  input.setAttribute("aria-label", field.label);
  input.checked = !!values[field.key];
  input.disabled = idle || !!field.disabled;
  input.addEventListener("change", () => change(field.key, input.checked, false));
  const caption = element("span", "generator-label");
  caption.textContent = field.label;
  box.append(input, caption);
  return box;
}

function renderControl(field: GeneratorField, values: GeneratorValues, change: Change, idle: boolean): HTMLElement {
  const value = String(values[field.key] ?? "");
  if (field.kind === "select") {
    const control = createSelectControl({
      choices: field.choices.map(([choice, label]) => choice === CHOICE_RULE ? { value: choice, label, separator: true } : { value: choice, label }),
      value, label: field.label, className: "generator-input select-control", disabled: idle || !!field.disabled,
      title: field.tip, onChange: (next) => change(field.key, next, true),
    });
    return control;
  }
  const control = field.kind === "area" ? Object.assign(document.createElement("textarea"), { rows: field.rows ?? 3 }) : Object.assign(document.createElement("input"), { type: "text" });
  control.value = value;
  control.setAttribute("aria-label", field.label);
  control.spellcheck = false;
  control.placeholder = ("placeholder" in field ? field.placeholder : undefined) ?? "";
  control.addEventListener("input", () => change(field.key, control.value, false));
  control.className = "generator-input";
  setTip(control, field.tip);
  // The first group stays usable while the pane is idle: it is where the source is chosen.
  control.disabled = idle || !!field.disabled;
  return control;
}
