# Forge application guidelines: shell

Part of [GUIDELINES.md](GUIDELINES.md), sections 4 and 5.

## 4. Shared shell and geometry

The desktop shell is ordered as tool strip, document-tab row (for document-based applications), central work surface, inspector, bottom panel, status bar and overlay root. The inspector and the bottom panel, with their visibility controls, belong to every Forge application, even when a document has no editable properties. The desktop menu is native; a browser edition renders the same menu definition in a menu bar of 26 px above the strip. An application without documents has no document tabs and defines its centre context in the profile. Terminal and Messages are the required bottom utilities, and an application-specific domain pane such as Scopes or Figures lies between them.

| Element | Geometry or conditional rule |
|---|---|
| Tool strip | 36 px high; on macOS desktop 42 px with 96 px of left padding for the window buttons and a drag region; in macOS full screen 12 px of left padding |
| Toolbar button | 32 × 26 px, 4 px radius; action icon 16 × 16 px with a 1.25 px visible line (Lucide, stroke 1.875 on its 24 px grid); domain icons are sized by the profile |
| Toolbar separator | 1 × 20 px hairline, 6 px side margins (8 px on macOS desktop) |
| Document-tab row (when used) | 30 px high, 6 px left padding, horizontal scroll with a hidden scrollbar |
| Document tab (when used) | Width 90 to 220 px, 12 px left and 6 px right padding, 6 px gap; close control 18 × 18 px; active top accent line 2 px high, flush with the tab face between its borders; dirty dot 6 px |
| Bottom tab row | 26 px high, 12 px horizontal padding per tab, active bottom accent line 2 px |
| Bottom panel | Default and minimum 246 px high, maximum 640 px; a short window shrinks a taller panel to leave 140 px of central workspace, but never below 246 px |
| Inspector | Default and minimum 246 px wide, maximum 420 px, on the right |
| Splitter | 1 px visible, pointer hit area extended by 4 px on each side; a double click restores the recorded default |
| Closing by dragging | The inspector and the bottom panel never become smaller than their default size: a drag below it holds them at that size, and they close when the drag takes them more than 96 px beyond it (`dragOutcome`, `CLOSE_PAST`). The panel hides with the normal 150 ms transition as soon as the pointer passes that point and reappears if the pointer returns before release. Release while closed saves the panel as hidden (the View menu item is unchecked), and the panel reopens at its last size from View, its shortcut or Terminal. A drag back inside the range never changes the saved size beyond its limits. |
| Inspector section | 12 px padding, 10 px gap, 1 px bottom border; the heading is a button with a chevron and keyboard focus |
| Property field | Label and a 108 px value column, 8 px gap, input or closed select 22 px high |
| Panel button | 24 px high, 4 px radius; the foreground and background states are given in section 6 |
| Status bar | 24 px high, 12 px horizontal padding, 14 px gap, 11 px mono text |
| Narrow window | The centre column clips its contents to its own bounds instead of drawing them under the inspector (`#center { overflow: hidden }`). The shared code editor takes its pane's width, never its longest line's, so long lines scroll inside it. Its find bar keeps the search field at least 120 px wide; in an editor narrower than 480 px it spans the editor less 8 px each side, and below 360 px it has two rows, the field and Close above, the options, count and arrows below. A Terminal wordmark wider than the pane scrolls on its own, and the transcript stays in place. The welcome actions wrap and are centred, with 16 px of side padding. The bottom tabs scroll sideways without a visible scrollbar, as the document tabs do, and keep their size (`flex: none`). The mode label of the tool strip is hidden below a window width of 1200 px. |

### Inspector rows, buttons and options

The inspector geometry of the shell applies in every Forge application. At the default inspector width of 246 px a section has 12 px of padding on each side and therefore 222 px of content width. Its contents form a vertical flex column with a gap of 10 px, and sections have a 1 px `--separator` bottom border. The dimensions are unchanged by content, selection, theme or window size, and a field or button is not sized by its label: long labels wrap in the label column while the control keeps its fixed width and height.

| Item | Layout and size | Text, colour and interaction |
|---|---|---|
| Section heading | Full section width including the 12 px side padding; heading button with 12 px padding and a 5 px icon–text gap; chevron 10 × 10 px, 1.4 px stroke, left margin −2 px | 10 px, weight 600, 0.6 px tracking, uppercase by CSS, `--text2`. Hover and focus brighten the title to `--text-strong` and the chevron to `--accent-light` without filling the heading. An expanded chevron points down and a collapsed one points right. |
| Read-only label and value row | Flex row, `justify-content: space-between`, minimum gap 8 px, full content width (`createRow`) | Label 12 px UI `--text2`; value 12 px UI `--text`, right-aligned by layout and truncated with an ellipsis on one line. Used for Name, Time, counts and measured values; the detail of a value (its window, its method) is the row's tooltip and not a second line. Values are never set in a card or tile inside the inspector. |
| Item under the pointer | A section of its own whose lines describe the item under the pointer or selected (`createInfoLines`): the name first in weight-600 11 px UI `--text`, then one value per line in 11 px mono `--text2`, 3 px apart and selectable; with no item, one quiet sentence such as `Hover or click a part.` The section title may name the state (`Part under pointer`, `Selected part`). | The lines follow hover and selection; nothing in them is editable. |
| Editable text and select row | Grid `minmax(0,1fr) 108px`, column gap 8 px, vertically centred; at 246 px the label column is 106 px and the control 108 px | Label 12 px UI `--text2`, wrapping; text input 11.5 px mono; select 12 px UI. The case and units of options are preserved. A select is not widened for a long choice and the control of another row is not shortened. |
| Text input and closed select | Exactly 108 × 22 px in the standard row, `box-sizing: border-box`, 4 px radius, 1 px `--separator` border, 6 px horizontal padding | `--well` fill, `--text` value. Focus uses an `--accent` border and a 1 px ring. The select arrow stays at the right and the selected label stays within the same width. The option menu of the operating system may extend beyond 108 px, but the closed control never grows. |
| Checkbox row | Grid `auto minmax(0,1fr)`, checkbox and label in one row with an 8 px gap. In Dark the checked square is 13 × 13 px, 3 px radius, 1 px `--accent-fill` border and background, with a centred white check of 11 × 11 px | Label 12 px UI `--text2`. An unchecked box uses the platform square; Light uses the native checkbox with the shared accent. Focus remains visible; a disabled box uses `--text3` and does not toggle. |
| Button group | Flex row across the full content width, 6 px gap; every button has `flex: 1` and a height of exactly 24 px, radius 4 px. Two or three buttons share the width equally; a single button fills it. | 12 px UI, weight 500, centred label. A button shows text only, unless its action has a standard symbol in the shell's icon list (play, pause, step, reset, stop and the like); then the icon sits before the label with a 5 px gap. An action without a standard symbol, such as Measurements, is text only. Ordinary fill `--control` with `--text`; primary fill `--accent-fill` with `--accent-foreground`. Hover, focus and disabled states follow section 6. Built with `createButtonGroup` and `createButton`. The first section of an inspector holds the main actions of the document in one such group. |
| Slider row | Vertical stack with a 5 px gap between readout and track. The readout is a flex row with the label on the left and an 11 px mono value on the right. The slider area is 16 px high; track and fill start 6 px from the top and are 4 px high; the normal thumb is 8 × 14 px, 1 px from the top. | Track `--well`, fill `--accent`, thumb `--text`; when disabled, fill and thumb are `--text3`. The Light thumb is 10 px wide, white, with a 1 px `#929292` border. |

Adjacent field rows share the same right edge and the same 108 px control width. All inspector buttons are 24 px high, including a full-width action such as `Recommend settings…` or `New seed`; ordinary fields and buttons receive no width or height overrides per application, and a multiline textarea occupies its own full-width row. The unit of a row belongs to its displayed or editable value (`25 °C`, `5 µs`, `0.1%`) and not to a second, misaligned label. A choice list uses the domain terms of the application, while its closed control, typography, selection and spacing follow this rule. On the empty screen the inspector geometry is unchanged: its children receive `opacity: 0.35` and `pointer-events: none`, and no row is collapsed, removed or resized.

### Persistence and the empty screen

Appearance, pane visibility, pane sizes and the inspector side are saved as application preferences. Document data and any view settings that must reopen with it are saved in the document. Message logs, command history, pointer location and the state of running animations are transient and are not stored in the document. Section 10 (Remembered settings) lists each remembered value and how it is stored. A visible document tab shows a dirty mark until the save succeeds. Closing unsaved work offers save, discard and cancel, and a failed or cancelled save keeps the window open.

When no document or project is open, the centre shows the New and Open actions of the application.

| Element | Specification |
|---|---|
| Heading | 15 px semibold, `--text2` |
| Supporting text | 11 px, `--text3` |
| Spacing | 8 px between action buttons, 14 px vertical gap between welcome elements |
| Surface | `--empty-sheet` with a dotted grid of 16 px in `--empty-grid-dot` and a major grid of 128 px in `--empty-grid-line` (section 2). The tokens are set on `body` in each appearance, so that a canvas drawing the same sheet reads them there; the test `the welcome surface takes its sheet and grid from the theme tokens, not from colours of its own` enforces it. |
| Inspector, tool-strip contents, bottom tabs other than Terminal | Visible, with `opacity: 0.35` and `pointer-events: none`; the Terminal tab and the application-level Terminal commands remain available |
| Status bar | Contents hidden with `visibility: hidden`; the height is retained |
| Menus | Document-only actions are present and disabled |

A domain that requires a different empty surface records it in the profile. Normal opacity, pointer behaviour and status contents are restored when a document opens. An application without documents defines its equivalent inactive context in the profile. When an application keeps several files within one project, the profile states whether the top tabs represent projects or internal files; one tab row never serves both without a distinct label and close and save rule.


### Code editor

An application that edits code or text uses the shared editor (`createCodeEditor`, or `codeEditorSetup` in its own CodeMirror view) and its find bar (`createFindBar`, `FindController`). CodeMirror is an optional peer dependency of the shell: an application that does not use the editor never loads it.

| Part | Rule |
|---|---|
| Base | Line numbers, the active line (`--text` at 5 %, 4 px radius), history, bracket matching (`--text` at 14 % with an outline; an unmatched bracket outlined in `--error`), indentation on input, Tab to indent, 13 px mono (`--editor-size`) at a line height of 1.5, on `--well` |
| Caret | 1.5 px in `--accent-light`. It blinks at CodeMirror's 1.2 s rate with an eased fade instead of on and off, stays solid while typing, and glides 80 ms to its next position. Under reduced motion it blinks on and off and jumps. |
| Selection | One rounded shape in `--selection` (`roundedSelection`), with the shell's selection geometry; a selected empty line shows a 6 px stub. |
| Find bar | At the top right of the editor: the query, the match-case, whole-word and pattern toggles, `n of m` (or `No results`, `Invalid pattern`), previous, next and close, and a replace row opened by its chevron with Replace (Return) and Replace all (Cmd or Ctrl+Return). Matches are the accent at 22 %, the current one at 45 %. Esc closes it. |
| Syntax | The tokens of "Syntax colours"; brackets may be coloured by depth (`cm-bracket-1` to `3`) or dimmed by depth (`cm-bracket-dim-1` to `6`). |

The tests `every syntax kind has highlighting tags, no tag has two colours, and each tag gets its kind's class` and `the find bar counts the matches of its query and which one is selected` check the editor.

### Syntax colours

The shared code editor (`code-editor.ts`) colours code with these tokens, through the classes `syntax-<kind>` that `shellHighlightStyle` gives the Lezer highlighting tags (`SYNTAX_TAGS`). Each colour has at least 4.5:1 contrast on `--well`, the editor background, in its appearance.

| Token | Dark | Light | Use |
|---|---|---|---|
| `--syntax-keyword` | `#f97583` | `#c62a3c` | Keywords and literal words (`if`, `true`, `null`) |
| `--syntax-name` | `#79b8ff` | `#005cc5` | Function, class, macro and command names |
| `--syntax-string` | `#9ecbff` | `#032f62` | Strings, characters, regular expressions and escapes |
| `--syntax-number` | `#ffab70` | `#b35000` | Numbers, units and constants |
| `--syntax-comment` | `#8b949e` | `#6a737d` | Comments and meta lines |
| `--syntax-type` | `#b392f0` | `#6f42c1` | Types, namespaces, attributes and annotations |
| `--syntax-operator` | `#c9c9c9` | `#444d56` | Operators, punctuation and separators |
| `--syntax-heading` | `#e1e4e8` | `#24292e` | Headings and strong text (bold) |
| `--syntax-link` | `#79b8ff` | `#005cc5` | Links and URLs (underlined) |
| `--syntax-invalid` | `#ff7b72` | `#b31d28` | Invalid code |
| `--syntax-bracket-1` | `#e5c07b` | `#8a5a00` | Brackets at depth 1, 4, 7 … |
| `--syntax-bracket-2` | `#c678dd` | `#a626a4` | Brackets at depth 2, 5, 8 … |
| `--syntax-bracket-3` | `#56b6c2` | `#0b7380` | Brackets at depth 3, 6, 9 … |
| `--syntax-bracket-dim` | `#f3e9a8` | `#7a6a10` | Dimmed brackets, fading with depth (opacity 1 to 0.42) |

### Selecting and rearranging content

Content (parts on a canvas, points of a plot, scopes, rows, tabs) is selected and rearranged the same way in every application (`content-selection.ts`, `reorder.ts`, `viewport.ts`).

| Part | Rule |
|---|---|
| Colour | Selected and hovered content, its handles and the selection box use `--pick` (cyan), never the accent, which marks the interface's own selection (menus, tabs, tree rows). |
| Click and drag | A pointer that moves 5 px or more from where it went down starts a drag (`DRAG_THRESHOLD`, `dragStarted`); less is a click. |
| Selection box | A drag on empty space draws a box: `--pick` at 12 % fill with a 1 px outline dashed 4 and 3 px at any zoom (`SELECTION_BOX`, `drawSelectionBox`). It takes the items wholly inside it (`boxHits`; `touch` takes those it touches, for an application that needs it). |
| Modifiers | Shift adds to the selection, Cmd on macOS or Ctrl on Windows toggles, and a plain click or box replaces it (`selectionMode`, `nextSelection`). Esc clears the selection. |
| Rearranging | A dragged item stays in place; a 2 px line in `--accent-light` shows where it lands (`attachReorder`), the list scrolls within 24 px of its ends, a drop that would not move it shows no line, and Esc cancels. In a row or column the item lands before the item whose middle the pointer has not passed (`dropIndex`); on a grid of panels it lands on the side of the target within 20 % of its width (at most 40 px), otherwise above or below its middle (`dropEdge`). Document tabs rearrange this way when the application gives `onReorder`. |
| Pan and zoom | A canvas maps content to the view with `Viewport`: zoom keeps the point under the pointer still, between 0.05× and 12×, and Fit centres the content without magnifying beyond 2.5×. |

The tests `a selection box takes the items wholly inside it, or those it touches, whichever way it was dragged`, `Shift adds to the selection, Cmd or Ctrl toggles, and a plain click or box replaces it`, `a drag starts after 5 px, and a drop lands on the side within 20 % (at most 40 px) or above and below the middle`, `a dragged item lands before the item whose middle it has not passed, and moving keeps the others in order` and `the viewport zooms about the pointer within its limits and fits a rectangle without over-magnifying` enforce the rules.

### Panes, dialogs and form blocks

The pieces an application builds around its work come from the shell, so that they look and behave the same in every application.

| Piece | Rule |
|---|---|
| Splitter | Two panes side by side or one above the other (`createSplitter`): a 1 px `--separator` line with a 9 px pointer target, each pane at least 160 px (`splitShare`), a double click restores the default share, and the focused divider moves 2 % per arrow key. |
| View header | The header of a view beside the main work (`createViewHeader`): 28 px on `--raised`, the unsaved dot of the document tabs, the title, the view's icon actions and the close control at the right. It carries no editable or read-only icon: a file's status is shown in the file tree only. |
| Review and apply | Proposed changes before they are applied (`askToApply`): what was found, a table of each change (current and proposed, the proposed value in `--accent-light`, unchanged rows in `--text3`), Apply (Return) and Cancel (Esc) in the platform's order. |
| Table picker | A searchable table to pick from (`askToPick`): the search field filters as it is typed, keeping the rows that contain every word (`filterRows`); Up and Down move, a click or Return picks one row, or ticks rows with `multiple`, and the action and Cancel follow the platform's order. |
| Form blocks | A checkbox row (`createCheckRow`), chips for one of a few choices, drawn as a button group (24 px, radius 4 px, sharing the width; the chosen chip in `--accent-fill` with `--accent-foreground`, the others `--control` with `--text`), with the arrow keys moving between them (`createChips`), a tile for a content region beside the work (`createTile`, see Tiles; not for values in the inspector), a group heading (`createGroupHeading`) and a problem line under a field in `--error` (`setProblem`). |
| Outline | A document's structure (`renderOutline`): numbered by level (`outlineNumbers`: `1`, `1.1`, `1.2`, `2`), indented 12 px per level, the current entry in `--accent-fill`. |
| Text styles | `.link-button`, a link that runs an action, in `--accent-light` and underlined; `.hint-text`, quiet supporting text in `--text3` at 11 px. |

The tests `a divider keeps each pane at least 160 px, and an area too small for both splits in half`, `an outline is numbered by level, and a deeper level restarts when a shallower one advances` and `a table picker keeps the rows that contain every word typed, ignoring case` enforce the rules.

### Saving

Saving works the same in every application (`saving.ts`).

| Part | Rule |
|---|---|
| Writing | `saveDocument` asks for the path first and makes the text after it (`serialize(document, path)`, `path` null for a browser download), once per place written, so that a document that stores paths relative to itself is written once and correctly. A cancelled dialog writes nothing and reports nothing; a format the document cannot be saved in is reported after the path is chosen, and nothing is written. |
| Autosave | A preference with four choices (`AUTOSAVE_CHOICES`): **Off**, the default; **After 1 minute** and **After 5 minutes**, which save a document that long after its last edit, the pause restarting at each edit; and **When the window loses focus**. File › Autosave lists them with the current one checked (`autosaveMenu`), and the shared Terminal verb `autosave [off\|1m\|5m\|focus]` reads or sets it (`shellPreferenceCommand`, when the settings have `autosave`; it answers `Autosave is off.`, `Autosave set to after 1 minute.` or `Autosave takes off, 1m, 5m or focus.`). An untitled document is never autosaved: it has no file yet, and recovery keeps it instead (`createAutosave`). |
| Recovery | While a document has unsaved edits its text is kept as a draft in the application's storage, and cleared when it is saved or its changes are discarded (`createRecovery`). After a crash the next launch offers the drafts, all ticked: **Restore** reopens the ticked ones and **Cancel** keeps them for the next launch (`askToRecover`). Drafts older than seven days are dropped. |
| Open recent | File › Open recent lists the last ten files opened or saved, newest first and without duplicates (`addRecent`, `createRecentFiles`); where two files share a name, the folder follows it (`notes.txt — lab`, `recentLabels`); a separator and **Clear menu** end the list, and an empty list shows `No recent files` (`recentMenu`). On the desktop each file is also added to the system's recent documents (`addRecentDocument`). |

The tests `the text is made once, after the dialog, for the path it is written to`, `cancelled dialog and unsupported format keep a document unsaved, and nothing is written`, `autosave is off by default, or saves 1 or 5 minutes after the last edit, or when the window loses focus`, `autosave restarts its pause at each edit, never saves an untitled document, and saves on blur only when asked`, `recovery keeps one draft per document, clears it on save, drops drafts older than 7 days and lists the newest first` and `Open recent keeps ten files, newest first, without duplicates, named with their folder where names repeat` enforce the rules.

### Order and placement

Things every application shows are ordered and placed the same way (`layout-order.ts`).

| Element | Rule |
|---|---|
| Tool strip groups | Left to right: history (Undo, Redo), clipboard, view (zoom, fit), the application's tools, search at the right (`TOOL_GROUP_ORDER`). `strip.group(items, className, kind)` places a group by its kind, whatever order the application adds it in, and a separator follows each group. |
| Dialog buttons | In the platform's order (`dialogButtonOrder`, `dialogActions`). macOS: the destructive choice (Don't save) at the left, a gap, then Cancel and the primary action at the right. Windows: right-aligned, the primary action first, then the destructive choice and Cancel last. Return chooses the primary action and Esc chooses Cancel on both. |
| Close controls | A close control (×) is always at the top right of what it closes: a document tab's at its right end, shown on hover and on the active tab; a panel's, a popover's, a side view's and a banner's at the top right. It is never at the left on either platform. |

The tests `tool strip groups take the shared order whatever order an application adds them in` and `dialog buttons follow the platform: macOS ends with Cancel and the primary action, Windows starts with it` enforce the order.

## 5. Motion

Motion is limited to state changes in chrome. The initial layout appears without an entrance animation. Under `prefers-reduced-motion: reduce` the final state is applied immediately and the focus and visibility behaviour is preserved. A repeated action cancels or replaces the running animation.

| Transition | Duration | Easing | Property |
|---|---:|---|---|
| Document tab added or removed (when used) | 150 ms | `cubic-bezier(0.2, 0, 0, 1)` | Width, side padding, border width and opacity |
| Active document accent line | 150 ms | `cubic-bezier(0.2, 0, 0, 1)` | Transform and width; fractional tab bounds are measured and only the tab borders are excluded throughout the motion |
| Dirty dot | 150 ms | `ease-out` | Background colour |
| Active bottom-tab line | 150 ms | `ease` | Transform and width |
| Inspector section chevron | 150 ms | `ease` | Rotation from 0° (closed) to 90° (open) |
| Inspector section height | 150 ms | `cubic-bezier(0.2, 0, 0, 1)` | Height after a heading click |
| Inspector and bottom panel show and hide | 150 ms | CSS `ease` | Width or height and opacity; a closed pane becomes hidden and inert |

Decorative looping animation of the chrome is not used. Data animation, such as a simulation trace or a progress indicator, belongs to the profile and has a pause or off rule where the user can control it.

