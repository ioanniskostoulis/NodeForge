// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Files dropped on a window or a view: the extensions it accepts, a drop target while files are dragged over it, a
// sentence for the files it refuses, and the path of each file from the desktop bridge.

/** Names listed by name in a refusal before the rest are counted (`and 2 more`). */
export const DROP_NAMES_LISTED = 3;

// MARK: method

/** The lowercase extension of a file name with its dot (`.tif`), or "" when it has none. */
export function fileExtension(name: string): string {
  const base = name.slice(Math.max(name.lastIndexOf("/"), name.lastIndexOf("\\")) + 1);
  const dot = base.lastIndexOf(".");
  return dot > 0 ? base.slice(dot).toLowerCase() : "";
}

/** Whether a file name has one of the accepted extensions, ignoring case (`accept` as `[".png", ".tif"]`). */
export function acceptsFile(name: string, accept: readonly string[]): boolean {
  const extension = fileExtension(name);
  return extension !== "" && accept.some((item) => item.toLowerCase() === extension);
}

/** `a, b and c` (or `a, b or c`), the way a sentence lists names. */
function listed(items: readonly string[], last: "and" | "or"): string {
  return items.length < 2 ? items.join("") : `${items.slice(0, -1).join(", ")} ${last} ${items[items.length - 1]}`;
}

/** The sentence for refused files: `Cannot open notes.docx. Drop a .png or .tif file.` */
export function dropMessage(refused: readonly string[], accept: readonly string[]): string {
  const names = refused.length <= DROP_NAMES_LISTED ? [...refused] : [...refused.slice(0, DROP_NAMES_LISTED), `${refused.length - DROP_NAMES_LISTED} more`];
  return `Cannot open ${listed(names, "and")}. Drop a ${listed(accept.map((item) => item.toLowerCase()), "or")} file.`;
}

export interface DropOutcome {
  accepted: string[];
  refused: string[];
  /** The sentence for the person, or null when every file was accepted. */
  message: string | null;
}

/**
 * Sort dropped names into accepted and refused. With `multiple` false, a drop of more than one accepted file opens
 * none of them and says so, so that the person chooses which.
 */
export function sortDrop(names: readonly string[], accept: readonly string[], multiple = true): DropOutcome {
  const accepted = names.filter((name) => acceptsFile(name, accept));
  const refused = names.filter((name) => !acceptsFile(name, accept));
  if (!multiple && accepted.length > 1) return { accepted: [], refused: [...names], message: "Drop one file at a time." };
  return { accepted, refused, message: refused.length ? dropMessage(refused, accept) : null };
}

/** Whether a drag carries files from the system (and not text or rows dragged inside the page). */
export function dragHasFiles(transfer: Pick<DataTransfer, "types"> | null): boolean {
  return !!transfer && Array.from(transfer.types).includes("Files");
}

// MARK: the drop target

export interface DroppedFile {
  name: string;
  /** The path on disk on the desktop (`bridge.pathForFile`); null in the browser, where only the contents are known. */
  path: string | null;
  /** The file itself, for reading its contents (`file.arrayBuffer()`, `file.text()`). */
  file: File;
}

export interface FileDropOptions {
  /** The accepted extensions with their dots, such as `[".png", ".jpg", ".tif"]`. */
  accept: readonly string[];
  /** What the drop target says while files are over it, a sentence: `Drop images to open them.` */
  label: string;
  /** Whether several files may be dropped at once (default true). */
  multiple?: boolean;
  onFiles(files: DroppedFile[]): void;
  /** The sentence for refused files, for Messages and the status bar. */
  onRefused(message: string): void;
  /** The path of a dropped file: `bridge.pathForFile` on the desktop. Omitted in the browser. */
  pathFor?(file: File): string;
}

type Target = Pick<HTMLElement, "addEventListener" | "removeEventListener" | "append" | "classList">;

/**
 * Accept files dropped on `target`. A drag that carries files shows the drop target over it; text and rows dragged
 * inside the page do not. A drop that an inner element has handled (`preventDefault`, as the file tree does) is left
 * to it. Returns a function that removes the handlers and the drop target.
 */
export function attachFileDrop(target: Target, options: FileDropOptions, doc: Pick<Document, "createElement"> = document): () => void {
  const overlay = doc.createElement("div");
  overlay.className = "file-drop";
  overlay.hidden = true;
  const label = doc.createElement("div");
  label.className = "file-drop-label";
  label.textContent = options.label;
  overlay.append(label);
  target.classList.add("file-drop-host");
  target.append(overlay);
  // dragenter and dragleave fire for every child crossed, so the target counts them and hides at zero.
  let depth = 0;
  const show = (on: boolean) => { overlay.hidden = !on; target.classList.toggle("file-drop-over", on); };
  const enter = (event: DragEvent) => {
    if (!dragHasFiles(event.dataTransfer)) return;
    depth += 1;
    show(true);
  };
  const over = (event: DragEvent) => {
    if (!dragHasFiles(event.dataTransfer)) return;
    // Without this the browser opens the file in place of the page.
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = "copy";
  };
  const leave = (event: DragEvent) => {
    if (!dragHasFiles(event.dataTransfer)) return;
    depth = Math.max(0, depth - 1);
    if (depth === 0) show(false);
  };
  const drop = (event: DragEvent) => {
    depth = 0;
    show(false);
    if (event.defaultPrevented || !dragHasFiles(event.dataTransfer)) return;
    event.preventDefault();
    const files = Array.from(event.dataTransfer?.files ?? []);
    const outcome = sortDrop(files.map((file) => file.name), options.accept, options.multiple ?? true);
    if (outcome.message) options.onRefused(outcome.message);
    const accepted = files.filter((file) => outcome.accepted.includes(file.name));
    if (accepted.length) options.onFiles(accepted.map((file) => ({ name: file.name, path: options.pathFor?.(file) || null, file })));
  };
  const handlers: [string, (event: DragEvent) => void][] = [["dragenter", enter], ["dragover", over], ["dragleave", leave], ["drop", drop]];
  for (const [name, handler] of handlers) target.addEventListener(name, handler as EventListener);
  return () => {
    for (const [name, handler] of handlers) target.removeEventListener(name, handler as EventListener);
    overlay.remove();
    target.classList.remove("file-drop-host", "file-drop-over");
  };
}
