import assert from "node:assert/strict";
import { test } from "node:test";
import { setButtonBusy, createButton, createField, createListLine, createRow, listMarker } from "../../source/app/builders";

class Node {
  attributes: Record<string, string> = {}; dataset: Record<string, string> = {};
  getAttribute(name: string) { return this.attributes[name] ?? null; }
  setAttribute(name: string, value: string) { this.attributes[name] = value; }
  removeAttribute(name: string) { delete this.attributes[name]; }
  className = ""; textContent = ""; title = ""; type = ""; disabled = false; children: Node[] = [];
  listeners: Record<string, (event?: unknown) => void> = {};
  constructor(readonly tag: string) {}
  append(...nodes: Node[]) { this.children.push(...nodes); }
  addEventListener(name: string, listener: (event?: unknown) => void) { this.listeners[name] = listener; }
}
const doc = { createElement: (tag: string) => new Node(tag) } as unknown as Pick<Document, "createElement">;
const node = (value: unknown) => value as Node;

test("builders produce the shared class structure", () => {
  let clicks = 0;
  const button = node(createButton({ label: "Save", primary: true, onClick: () => { clicks += 1; } }, doc));
  assert.equal(button.className, "panel-button primary");
  button.listeners.click();
  assert.equal(clicks, 1);
  assert.equal(node(createButton({ label: "Cancel", disabled: true }, doc)).disabled, true);

  const field = node(createField("Maximum time step", new Node("input") as unknown as HTMLElement, doc));
  assert.deepEqual([field.className, field.children[0].className, field.children[1].tag], ["field", "label", "input"]);

  const row = node(createRow("Size", "4.7 kΩ", doc));
  assert.deepEqual(row.children.map((child) => [child.className, child.textContent]), [["label", "Size"], ["value", "4.7 kΩ"]]);

  const line = node(createListLine({ marker: listMarker(3), text: "Name", detail: "note" }, doc));
  assert.deepEqual(line.children.map((child) => child.className), ["t-marker", "t-mono", "t-quiet"]);
  assert.equal(line.children[0].textContent, "   [3]");
  assert.equal(node(createListLine({ text: "Only" }, doc)).children.length, 1);
});

test("a busy button shows the in-progress label, ignores clicks and restores its label", () => {
  let clicks = 0;
  const button = createButton({ label: "Build PDF", primary: true, onClick: () => { clicks += 1; } }, doc);
  const node = button as unknown as Node;
  setButtonBusy(button, "Building PDF…");
  assert.equal(button.textContent, "Building PDF…");
  assert.equal(node.attributes["aria-busy"], "true");
  assert.equal(node.attributes["aria-disabled"], "true");
  assert.equal(button.disabled, false);
  node.listeners.click();
  assert.equal(clicks, 0);
  setButtonBusy(button, null);
  assert.equal(button.textContent, "Build PDF");
  assert.equal(node.attributes["aria-busy"], undefined);
  node.listeners.click();
  assert.equal(clicks, 1);
});
