import assert from "node:assert/strict";
import { test } from "node:test";
import { BOX_CURSORS, BOX_HANDLES, HANDLE_HIT, HANDLE_SIZE, boxFromDrag, constrainAngle, dragBox, dragModifiers, handleAt, handleHit, handlePoint } from "../../source/app/box-handles";
import { HANDLE_EDGE, handleSide, DERIVED_DASH, DRAWING_DASH, GUIDE_LINE, HANDLE_FILL, LIGHT_PICTURE, OVERLAY_COLORS, OVERLAY_PICK, REGION_FILL_ALPHA, REGION_LINE, labelSize, overlayColor, pictureSurface, regionLineWidth } from "../../source/app/canvas-overlay";
import { CANVAS_TOOLS, canvasToolForKey, toolKeyProblems } from "../../source/app/canvas-tools";

const box = (x: number, y: number, width: number, height: number) => ({ x, y, width, height });
const key = (k: string, mods: Partial<{ metaKey: boolean; ctrlKey: boolean; altKey: boolean; shiftKey: boolean }> = {}) =>
  ({ key: k, metaKey: false, ctrlKey: false, altKey: false, shiftKey: false, ...mods });

test("a box has eight handles at its corners and edge middles, taken within 5 px, and moves from inside", () => {
  const b = box(10, 20, 100, 60);
  assert.equal(BOX_HANDLES.length, 8);
  assert.deepEqual(handlePoint(b, "nw"), { x: 10, y: 20 });
  assert.deepEqual(handlePoint(b, "e"), { x: 110, y: 50 });
  assert.deepEqual(handlePoint(b, "s"), { x: 60, y: 80 });
  assert.equal(HANDLE_SIZE, 7);
  assert.equal(HANDLE_HIT.fine, 5);
  assert.equal(handleAt(b, 15, 25), "nw", "5 px off on both axes still takes the corner");
  assert.equal(handleAt(b, 16, 25), "move", "6 px off is inside the box, not on the handle");
  assert.equal(handleAt(b, 4, 20), null, "6 px outside the left edge takes nothing");
  assert.equal(handleAt(b, 5, 20), "nw");
  assert.equal(handleAt(b, 60, 22), "n");
  assert.equal(handleAt(b, 60, 50, 5, false), null, "a box without move takes only its handles");
  // a tiny box: corners win over edges, the nearest handle over the others
  assert.equal(handleAt(box(0, 0, 4, 4), 0, 0), "nw");
  assert.equal(handleAt(box(0, 0, 4, 4), 4, 4), "se");
  assert.equal(handleHit("touch"), HANDLE_HIT.coarse);
  assert.equal(handleHit("mouse"), HANDLE_HIT.fine);
});

test("a handle shows the resize cursor of its direction, and the inside shows move", () => {
  assert.deepEqual(BOX_CURSORS, {
    n: "ns-resize", s: "ns-resize", e: "ew-resize", w: "ew-resize",
    ne: "nesw-resize", sw: "nesw-resize", nw: "nwse-resize", se: "nwse-resize", move: "move",
  });
});

test("dragging a handle moves its edges within the bounds and never past the opposite edge", () => {
  const start = box(10, 10, 50, 40), bounds = box(0, 0, 100, 80);
  assert.deepEqual(dragBox(start, "se", 5, 5, bounds), box(10, 10, 55, 45));
  assert.deepEqual(dragBox(start, "e", 100, 9, bounds), box(10, 10, 90, 40), "an edge stops at the bounds; e ignores dy");
  assert.deepEqual(dragBox(start, "nw", -20, -20, bounds), box(0, 0, 60, 50));
  assert.deepEqual(dragBox(start, "w", 49, 0, bounds), box(59, 10, 1, 40), "1 unit short of the opposite edge");
  assert.deepEqual(dragBox(start, "w", 60, 0, bounds), box(59, 10, 1, 40), "and no further");
  assert.deepEqual(dragBox(start, "n", 0, 50, bounds, 10), box(10, 40, 50, 10), "a larger minimum is kept");
  assert.deepEqual(dragBox(start, "move", 100, -100, bounds), box(50, 0, 50, 40), "a move keeps the whole box inside");
  assert.deepEqual(dragBox(start, "move", -5, 3), box(5, 13, 50, 40), "without bounds a move is free");
  assert.deepEqual(boxFromDrag(90, 70, -10, 20, bounds), box(0, 20, 90, 50), "a box dragged out is cut to the bounds");
});

test("regions take the overlay palette as traces are drawn, and selection keeps cyan to itself", () => {
  assert.equal(REGION_LINE.width, 1.25);
  assert.equal(regionLineWidth("light"), 1.3125, "5 % thicker on a light surface");
  assert.equal(regionLineWidth("dark"), 1.25);
  assert.deepEqual([...DRAWING_DASH], [4, 3]);
  assert.deepEqual([...DERIVED_DASH], [5, 4]);
  assert.deepEqual({ ...GUIDE_LINE, dash: [...GUIDE_LINE.dash] }, { alpha: 0.35, width: 1, dash: [2, 3] });
  assert.equal(REGION_FILL_ALPHA, 0.12);
  assert.equal(OVERLAY_COLORS.bright.length, OVERLAY_COLORS.light.length);
  for (const color of [...OVERLAY_COLORS.bright, ...OVERLAY_COLORS.light]) assert.notEqual(color.toLowerCase(), "#2fd3e6", "the palette leaves out --pick");
  assert.equal(overlayColor(0), "#ffd23f");
  assert.equal(overlayColor(8), overlayColor(0), "round again after the last");
  assert.equal(overlayColor(-1), "#ffffff");
  assert.equal(overlayColor(0, "light"), "#b47a00");
  assert.equal(labelSize(600), 20, "1/30 of the shorter side");
  assert.deepEqual(OVERLAY_PICK, { dark: "#2fd3e6", light: "#007a99" }, "spec-sync checks these against --pick");
  assert.deepEqual(HANDLE_FILL, { dark: "#000000", light: "#ffffff" });
});

test("the canvas tools keep their keys in every application that has them, and that application cannot take them", () => {
  assert.deepEqual(Object.fromEntries(Object.entries(CANVAS_TOOLS).map(([tool, t]) => [tool, t.key])),
    { select: "V", crop: "C", rectangle: "R", ellipse: "E", polygon: "P", freehand: "F", line: "L" });
  assert.equal(canvasToolForKey(key("c"), ["select", "crop"]), "crop");
  assert.equal(canvasToolForKey(key("r"), ["select", "crop"]), null, "a tool the application does not have");
  assert.equal(canvasToolForKey(key("c", { metaKey: true }), ["crop"]), null, "Cmd+C is Copy");
  assert.equal(canvasToolForKey(key("C", { shiftKey: true }), ["crop"]), null);
  assert.deepEqual(toolKeyProblems([{ key: "V", id: "tool.select" }, { key: "CmdOrCtrl+C", id: "edit.copy" }], ["select", "crop"]), []);
  assert.deepEqual(toolKeyProblems([{ key: "c", id: "view.center" }], ["crop"]), ["The key C of view.center is the shell's key for the Crop tool (tool.crop)."]);
  assert.deepEqual(toolKeyProblems([{ key: "C", id: "part.capacitor" }, { key: "L", id: "part.inductor" }], ["select"]), [], "a tool the application does not have leaves its letter free");
});

test("Shift constrains a drawing or a drag and Option works from the centre, within the bounds", () => {
  assert.deepEqual(dragModifiers({ shiftKey: true, altKey: false }), { constrain: true, fromCenter: false });
  // a line: level, upright or diagonal, the pointer projected onto the chosen direction
  assert.deepEqual(constrainAngle({ x: 0, y: 0 }, { x: 10, y: 3 }), { x: 10, y: 0 });
  assert.deepEqual(constrainAngle({ x: 0, y: 0 }, { x: 2, y: -9 }), { x: 0, y: -9 });
  const diagonal = constrainAngle({ x: 0, y: 0 }, { x: 10, y: 8 });
  assert.ok(Math.abs(diagonal.x - 9) < 1e-9 && Math.abs(diagonal.y - 9) < 1e-9, "45° keeps the projected length");
  assert.deepEqual(constrainAngle({ x: 0, y: 0 }, { x: 10, y: 4.1 }), { x: 10, y: 0 }, "22.4° is still level");
  // a box dragged out: a square, from the centre, and cut to the bounds
  const bounds = box(0, 0, 100, 80);
  assert.deepEqual(boxFromDrag(10, 10, 40, 20, bounds, { constrain: true }), box(10, 10, 30, 30));
  assert.deepEqual(boxFromDrag(50, 40, 60, 45, bounds, { fromCenter: true }), box(40, 35, 20, 10));
  assert.deepEqual(boxFromDrag(50, 40, 90, 45, bounds, { constrain: true, fromCenter: true }), box(10, 0, 80, 80), "the square stops at the nearer bound");
  assert.deepEqual(boxFromDrag(10, 10, 40, 20, bounds), box(10, 10, 30, 10), "without modifiers it follows the pointer");
  // a handle dragged: a corner keeps the proportions, a move keeps to one axis, Option keeps the centre
  const start = box(10, 10, 40, 20);
  assert.deepEqual(dragBox(start, "se", 20, 2, bounds, 1, { constrain: true }), box(10, 10, 60, 30));
  assert.deepEqual(dragBox(start, "se", 200, 0, bounds, 1, { constrain: true }), box(10, 10, 90, 45), "the bounds stop the scale, not one side");
  assert.deepEqual(dragBox(start, "move", 12, 5, bounds, 1, { constrain: true }), box(22, 10, 40, 20));
  assert.deepEqual(dragBox(start, "e", 5, 0, bounds, 1, { fromCenter: true }), box(5, 10, 50, 20));
  assert.deepEqual(dragBox(start, "nw", -2, -1, bounds, 1, { constrain: true, fromCenter: true }), box(8, 9, 44, 22), "each side grows by twice the move, about the centre");
});

test("every handle is a node: a 7 px square edged 1.2 px, growing with the content past its smallest side", () => {
  assert.equal(HANDLE_EDGE, 1.2);
  assert.equal(handleSide(1), 7);
  assert.equal(handleSide(2), 3.5, "7 view px at 2x zoom");
  assert.equal(handleSide(2, 5), 5, "a schematic's 5-unit node grows with the content");
  assert.equal(handleSide(0.5, 5), 14);
});

test("a picture is light content from a mean luminance of 0.5, and its overlay follows it, not the appearance", () => {
  const picture = (r: number, g: number, b: number) => ({ width: 4, height: 4, data: Array.from({ length: 64 }, (_, i) => [r, g, b, 255][i % 4]) });
  assert.equal(LIGHT_PICTURE, 0.5);
  assert.equal(pictureSurface(picture(240, 230, 210), 1), "light");
  assert.equal(pictureSurface(picture(20, 25, 35), 1), "dark");
  assert.equal(pictureSurface(picture(128, 128, 128), 1), "light", "0.502 is light");
  assert.equal(pictureSurface(picture(127, 127, 127), 1), "dark", "0.498 is dark");
  assert.equal(pictureSurface(picture(0, 0, 255), 1), "dark", "pure blue is dark by luminance");
});
