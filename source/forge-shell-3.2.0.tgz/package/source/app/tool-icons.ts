// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { LUCIDE_ICONS, type LucideIconName } from "./lucide-icons";

/** Icons are drawn at 16 px with a 1.25 px visible line that takes its colour from the button state (`currentColor`). */
export const TOOL_ICON_SIZE = 16;
export const TOOL_ICON_STROKE = 1.25;

/** Wrap path data in the 16 px icon box. Domain icons drawn on a 16 px grid use this; they share size, stroke and colour. */
export function toolIcon(body: string): string {
  return `<svg width="${TOOL_ICON_SIZE}" height="${TOOL_ICON_SIZE}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${TOOL_ICON_STROKE}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
}

/**
 * A Lucide icon of the shell's list at `size` px. Lucide draws on a 24 px grid, so the stroke is scaled to keep the
 * visible line at `TOOL_ICON_STROKE` (1.25 px at 16 px gives 1.875 on the grid; 12 px gives 2.5).
 */
export function lucideIcon(name: LucideIconName, size = TOOL_ICON_SIZE): string {
  const stroke = (TOOL_ICON_STROKE * 24) / size;
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${LUCIDE_ICONS[name]}</svg>`;
}

/** The shared set for standard actions. */
export const TOOL_ICONS = {
  undo: lucideIcon("undo"), redo: lucideIcon("redo"), cut: lucideIcon("cut"), copy: lucideIcon("copy"), paste: lucideIcon("paste"),
  fit: lucideIcon("fit"), zoomIn: lucideIcon("zoomIn"), zoomOut: lucideIcon("zoomOut"),
} as const;

export type ToolIconName = keyof typeof TOOL_ICONS;

/** Status icons for problems, coloured by the element they sit in. */
export const STATUS_ICONS = {
  warning: lucideIcon("warning"), error: lucideIcon("error"), info: lucideIcon("info"),
} as const;

export type StatusIconName = keyof typeof STATUS_ICONS;

/**
 * The shared set for everything else an application shows: navigation, editing, files and running. An application
 * draws none of these itself; `forge-shell check-app` warns about an inline icon that repeats one of them.
 */
export const UI_ICONS = {
  close: lucideIcon("close"), chevronRight: lucideIcon("chevronRight"), chevronLeft: lucideIcon("chevronLeft"),
  chevronUp: lucideIcon("chevronUp"), chevronDown: lucideIcon("chevronDown"), more: lucideIcon("more"),
  add: lucideIcon("add"), remove: lucideIcon("remove"), delete: lucideIcon("delete"), duplicate: lucideIcon("duplicate"),
  rotate: lucideIcon("rotate"), edit: lucideIcon("edit"), readOnly: lucideIcon("readOnly"), pointer: lucideIcon("pointer"), check: lucideIcon("check"),
  search: lucideIcon("search"), reveal: lucideIcon("reveal"), export: lucideIcon("export"), import: lucideIcon("import"), link: lucideIcon("link"),
  show: lucideIcon("show"), hide: lucideIcon("hide"), lock: lucideIcon("lock"), unlock: lucideIcon("unlock"), pin: lucideIcon("pin"),
  checkCircle: lucideIcon("checkCircle"), refresh: lucideIcon("refresh"), settings: lucideIcon("settings"),
} as const;

export type UiIconName = keyof typeof UI_ICONS;

/** The run controls of a panel button (Run, Pause, Stop, Reset, Step), drawn at 12 px in the text colour. */
export const BUTTON_GLYPHS = {
  play: lucideIcon("play", 12), pause: lucideIcon("pause", 12), stop: lucideIcon("stop", 12), reset: lucideIcon("reset", 12), step: lucideIcon("step", 12),
} as const;
