// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { compareVersions } from "./version.mjs";

const VERBS = { install: "Install", upgrade: "Upgrade", repair: "Repair", downgrade: "Downgrade" };

/**
 * What running this setup would do to what is already installed.
 * `blocked` is set when the app is running: its files cannot be replaced.
 */
export function decideInstall({ installed, incoming, running = false }) {
  let kind = "install";
  if (installed) {
    const order = compareVersions(installed, incoming);
    kind = order < 0 ? "upgrade" : order === 0 ? "repair" : "downgrade";
  }
  return { kind, verb: VERBS[kind], installed: installed ?? null, incoming, blocked: running ? "running" : null, keepsPrevious: kind === "upgrade" || kind === "downgrade" };
}
