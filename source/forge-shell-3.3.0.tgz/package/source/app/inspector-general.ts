// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { createButton, createButtonGroup, type ButtonOptions } from "./builders";

/** One main action of the General section: a text button, with an icon only when its action has a standard symbol. */
export interface GeneralAction extends ButtonOptions {
  /** Standard icon markup (from the shell's icon list), shown before the label. */
  icon?: string;
}

/** The General section holds two or three actions, exactly one of them primary. */
export const GENERAL_MIN_ACTIONS = 2;
export const GENERAL_MAX_ACTIONS = 3;

/** The inspector philosophy's rule for the General section, as a sentence or none. Returns the problem, or null when valid. */
export function generalActionProblem(actions: readonly Pick<GeneralAction, "primary">[]): string | null {
  if (actions.length < GENERAL_MIN_ACTIONS || actions.length > GENERAL_MAX_ACTIONS) {
    return `The General section holds ${GENERAL_MIN_ACTIONS} to ${GENERAL_MAX_ACTIONS} actions, not ${actions.length}.`;
  }
  const primaries = actions.filter((action) => action.primary).length;
  if (primaries !== 1) return `The General section needs exactly one primary action, not ${primaries}.`;
  return null;
}

/**
 * Fill the first section of the inspector: its main actions as one button group, then the document's rows (its
 * editable name, File, Images, Grid). Throws when the actions break the rule, so an application cannot drift.
 */
export function fillGeneralSection(section: HTMLElement, actions: readonly GeneralAction[], rows: readonly HTMLElement[] = []): void {
  const problem = generalActionProblem(actions);
  if (problem) throw new Error(problem);
  const buttons = actions.map((action) => {
    const button = createButton(action);
    if (action.icon) button.innerHTML = `${action.icon}<span>${action.label}</span>`;
    return button;
  });
  section.replaceChildren(createButtonGroup(buttons), ...rows);
}
