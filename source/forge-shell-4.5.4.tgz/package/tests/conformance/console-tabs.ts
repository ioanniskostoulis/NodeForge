import assert from "node:assert/strict";
import { test } from "node:test";
import { consoleTabCommand } from "../../source/app/console-tabs.js";

test("Terminal tab verbs use one-based tabs, active and unsaved states, and close outcomes", async () => {
  const first = { displayTitle: "One", dirty: false };
  const second = { displayTitle: "Two", dirty: true };
  const documents = [first, second];
  let active = first;
  let keepOpen = false;
  const host = {
    documents: () => documents,
    activeDocument: () => active,
    activate: (document: typeof first) => { active = document; },
    close: async (document: typeof first) => { if (!keepOpen) documents.splice(documents.indexOf(document), 1); },
    documentNoun: "report",
  };
  assert.deepEqual((await consoleTabCommand("tabs", "", host))?.tables?.[0].rows,
    [["   [1]   ", "One", "Active"], ["   [2]   ", "Two", "Unsaved"]]);
  assert.deepEqual(await consoleTabCommand("tab", "2", host), { lines: ["Tab 2: Two."] });
  assert.equal(active, second);
  keepOpen = true;
  assert.deepEqual(await consoleTabCommand("close", "", host), { lines: ["Tab kept open."] });
  keepOpen = false;
  assert.deepEqual(await consoleTabCommand("close", "", host), { lines: ["Closed Two."] });
  assert.deepEqual(await consoleTabCommand("clear", "", host), { clear: true });
  assert.equal(await consoleTabCommand("domain", "", host), null);
});
