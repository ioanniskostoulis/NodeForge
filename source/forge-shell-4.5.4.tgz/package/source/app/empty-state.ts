// Licensed under the GNU General Public License v2 or later. See LICENSE.
export interface EmptyStateOptions {
  title: string;
  newLabel: string;
  openLabel: string;
  detail: string;
  newShortcut: string;
  openShortcut: string;
  onNew(): void;
  onOpen(): void;
}

/** The welcome state shown when no document tab is open. */
export function createEmptyState(center: HTMLElement, options: EmptyStateOptions): HTMLElement {
  const box = document.createElement("div");
  box.id = "empty-state";
  box.hidden = true;
  box.innerHTML = `
      <div class="title"></div>
      <div class="actions">
        <button class="panel-button primary new"><span class="label"></span> <kbd></kbd></button>
        <button class="panel-button open"><span class="label"></span> <kbd></kbd></button>
      </div>
      <div class="detail"></div>`;
  box.querySelector(".title")!.textContent = options.title;
  box.querySelector(".new .label")!.textContent = options.newLabel;
  box.querySelector(".new kbd")!.textContent = options.newShortcut;
  box.querySelector(".open .label")!.textContent = options.openLabel;
  box.querySelector(".open kbd")!.textContent = options.openShortcut;
  box.querySelector(".detail")!.textContent = options.detail;
  box.querySelector(".new")!.addEventListener("click", options.onNew);
  box.querySelector(".open")!.addEventListener("click", options.onOpen);
  center.prepend(box);
  return box;
}
