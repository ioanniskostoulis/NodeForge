// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

/** The family registry: which apps are installed, at which version. */
export async function readRegistry(path) {
  try {
    const data = JSON.parse(await readFile(path, "utf8"));
    return data && typeof data === "object" && data.apps ? data : { format: 1, apps: {} };
  } catch {
    return { format: 1, apps: {} };
  }
}

/** Write through a temporary file so an interrupted write leaves the old registry. */
export async function writeRegistry(path, registry) {
  await mkdir(dirname(path), { recursive: true });
  const temporary = `${path}.${process.pid}.tmp`;
  await writeFile(temporary, `${JSON.stringify(registry, null, 2)}\n`);
  await rename(temporary, path);
}
