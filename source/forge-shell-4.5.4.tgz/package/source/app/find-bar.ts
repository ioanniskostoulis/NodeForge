// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The Find and replace bar of the shared editor, one per CodeMirror view, shown as its search panel: the query, the
// case, word and pattern toggles, the match count, previous, next and close, and a replace row that can be shown.
import { EditorState, Prec, type Extension } from "@codemirror/state";
import { EditorView, keymap } from "@codemirror/view";
import { SearchQuery, closeSearchPanel, findNext, findPrevious, getSearchQuery, openSearchPanel, replaceAll, replaceNext, search, searchPanelOpen, setSearchQuery } from "@codemirror/search";
import { setTip } from "./tips";
import { UI_ICONS } from "./tool-icons";

export interface FindBar {
  root: HTMLElement;
  find: HTMLInputElement;
  replace: HTMLInputElement;
  replaceRow: HTMLElement;
  replaceToggle: HTMLButtonElement;
  count: HTMLElement;
  caseSensitive: HTMLButtonElement;
  wholeWord: HTMLButtonElement;
  regexp: HTMLButtonElement;
  previous: HTMLButtonElement;
  next: HTMLButtonElement;
  close: HTMLButtonElement;
  replaceOne: HTMLButtonElement;
  replaceEvery: HTMLButtonElement;
}

/** Matches of the current query, counted up to 9999, and the index of the selected one. */
export function searchCount(state: EditorState): { total: number; current: number; valid: boolean } {
  const query = getSearchQuery(state);
  if (!query.search || !query.valid) return { total: 0, current: 0, valid: query.valid || !query.search };
  const { from, to } = state.selection.main;
  let total = 0, current = 0;
  const cursor = query.getCursor(state);
  for (let step = cursor.next(); !step.done && total < 9999; step = cursor.next()) {
    total++;
    if (step.value.from === from && step.value.to === to) current = total;
  }
  return { total, current, valid: true };
}

/**
 * The match a query typed in the bar selects: the first at or after `from` (the start of the selection, so that the
 * match already under it is kept as the query grows), wrapping to the start of the document; null when there is none.
 */
export function matchFrom(state: EditorState, from: number): { from: number; to: number } | null {
  const query = getSearchQuery(state);
  if (!query.search || !query.valid) return null;
  for (const start of [from, 0]) {
    const step = query.getCursor(state, start).next();
    if (!step.done) return { from: step.value.from, to: step.value.to };
  }
  return null;
}

/** Shortcuts shown in the tips, by action id, as written for the platform. Set once by the application. */
let tipKeys: ReadonlyMap<string, string> = new Map();

/** Name each button's action and shortcut in its tooltip. */
export function applyFindTips(bar: FindBar, keys: ReadonlyMap<string, string> = tipKeys): void {
  tipKeys = keys;
  setTip(bar.replaceToggle, { label: "Toggle replace", shortcut: keys.get("replace") });
  setTip(bar.previous, { label: "Previous match", shortcut: keys.get("findPrevious") });
  setTip(bar.next, { label: "Next match", shortcut: keys.get("findNext") });
  setTip(bar.close, { label: "Close Find", shortcut: "Escape" });
  setTip(bar.replaceOne, { label: "Replace", shortcut: "Enter" });
  setTip(bar.replaceEvery, { label: "Replace all", shortcut: "CmdOrCtrl+Enter" });
}

function element<K extends keyof HTMLElementTagNameMap>(tag: K, className?: string, label?: string): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (label) node.setAttribute("aria-label", label);
  if (node instanceof HTMLButtonElement) node.type = "button";
  return node;
}

/** A new bar with the same parts as the one in the page, for a view that has none of its own. */
export function createFindBar(subject: string): FindBar {
  const root = element("div", "find-tile"); root.setAttribute("role", "search"); root.setAttribute("aria-label", "Find and replace"); root.hidden = true;
  const replaceToggle = element("button", "find-expand", "Toggle replace"); replaceToggle.setAttribute("aria-expanded", "false");
  const findRow = element("div", "find-row");
  const field = (label: string, placeholder: string) => {
    const input = element("input", undefined, label); input.type = "text"; input.placeholder = placeholder; input.autocomplete = "off"; input.spellcheck = false;
    return input;
  };
  const toggle = (text: string, label: string) => {
    const button = element("button", "find-toggle", label); button.setAttribute("aria-pressed", "false"); button.title = label; button.textContent = text;
    return button;
  };
  const find = field(`Find in ${subject}`, "Find");
  const caseSensitive = toggle("Aa", "Match case"), wholeWord = toggle("ab", "Match whole word"), regexp = toggle(".*", "Use regular expression");
  const count = element("span", "find-count"); count.setAttribute("aria-live", "polite"); count.textContent = "No results";
  const previous = element("button", "find-icon", "Previous match"), next = element("button", "find-icon", "Next match"), close = element("button", "find-icon", "Close Find");
  replaceToggle.innerHTML = UI_ICONS.chevronRight;
  previous.innerHTML = UI_ICONS.chevronUp;
  next.innerHTML = UI_ICONS.chevronDown;
  close.innerHTML = UI_ICONS.close;
  close.classList.add("find-close");
  findRow.append(find, caseSensitive, wholeWord, regexp, count, previous, next, close);
  const replaceRow = element("div", "find-row"); replaceRow.hidden = true;
  const replace = field("Replace with", "Replace");
  const replaceOne = element("button", "find-text"), replaceEvery = element("button", "find-text");
  replaceOne.textContent = "Replace"; replaceEvery.textContent = "Replace all";
  replaceRow.append(replace, replaceOne, replaceEvery);
  root.append(replaceToggle, findRow, replaceRow);
  const bar: FindBar = { root, find, replace, replaceRow, replaceToggle, count, caseSensitive, wholeWord, regexp, previous, next, close, replaceOne, replaceEvery };
  applyFindTips(bar);
  return bar;
}

/** Find and replace for one CodeMirror view. `extensions()` goes into the view's state, `openFind` shows the bar. */
export class FindController {
  constructor(private readonly view: () => EditorView, readonly bar: FindBar) { this.wire(); }

  /** CodeMirror shows its search highlights only while a search panel exists, so the tile is that panel, floated by shell.css. */
  extensions(): Extension[] {
    return [
      search({ top: true, createPanel: () => ({ dom: this.bar.root, top: true, mount: () => { this.bar.root.hidden = false; this.bar.find.focus(); } }) }),
      Prec.highest(keymap.of([{ key: "Escape", run: view => searchPanelOpen(view.state) && closeSearchPanel(view) }])),
      EditorView.updateListener.of(update => {
        if ((update.docChanged || update.selectionSet || update.transactions.some(tr => tr.effects.some(effect => effect.is(setSearchQuery)))) && searchPanelOpen(update.state)) this.updateCount();
      }),
    ];
  }

  /** True when the bar is open and focus is inside it. */
  contains(node: Node | null): boolean { return !!node && this.bar.root.contains(node); }

  /** Open the bar; `replace` also shows the replace row. A single-line selection becomes the query. */
  openFind(replace: boolean): void {
    const view = this.view();
    const { from, to } = view.state.selection.main;
    const selected = view.state.sliceDoc(from, to);
    this.showReplace(replace);
    openSearchPanel(view);
    if (selected && !selected.includes("\n")) { this.bar.find.value = selected; this.commitQuery(); }
    (replace && this.bar.find.value ? this.bar.replace : this.bar.find).focus();
    this.bar.find.select();
    this.updateCount();
  }

  findNext(): void { const view = this.view(); if (!searchPanelOpen(view.state)) this.openFind(false); else findNext(view); }
  findPrevious(): void { const view = this.view(); if (!searchPanelOpen(view.state)) this.openFind(false); else findPrevious(view); }
  closeFind(): void { const view = this.view(); closeSearchPanel(view); view.focus(); }

  private showReplace(show: boolean): void {
    this.bar.replaceRow.hidden = !show;
    this.bar.replaceToggle.setAttribute("aria-expanded", String(show));
  }

  private commitQuery(): void {
    const view = this.view();
    const toggled = (button: HTMLButtonElement) => button.getAttribute("aria-pressed") === "true";
    const query = new SearchQuery({ search: this.bar.find.value, replace: this.bar.replace.value, caseSensitive: toggled(this.bar.caseSensitive),
      wholeWord: toggled(this.bar.wholeWord), regexp: toggled(this.bar.regexp) });
    if (!query.eq(getSearchQuery(view.state))) view.dispatch({ effects: setSearchQuery.of(query) });
  }

  private updateCount(): void {
    const { total, current, valid } = searchCount(this.view().state);
    this.bar.find.classList.toggle("invalid", !valid);
    this.bar.count.textContent = !valid ? "Invalid pattern" : total ? `${current || "?"} of ${total}${total >= 9999 ? "+" : ""}` : "No results";
  }

  private wire(): void {
    const bar = this.bar;
    bar.root.remove();
    bar.find.addEventListener("input", () => {
      this.commitQuery();
      const view = this.view();
      const match = matchFrom(view.state, view.state.selection.main.from);
      if (match) view.dispatch({ selection: { anchor: match.from, head: match.to }, scrollIntoView: true, userEvent: "select.search" });
      bar.find.focus();
    });
    bar.replace.addEventListener("input", () => this.commitQuery());
    for (const toggle of [bar.caseSensitive, bar.wholeWord, bar.regexp]) toggle.addEventListener("click", () => {
      toggle.setAttribute("aria-pressed", String(toggle.getAttribute("aria-pressed") !== "true"));
      this.commitQuery(); this.updateCount();
    });
    bar.find.addEventListener("keydown", event => {
      if (event.key === "Enter") { event.preventDefault(); (event.shiftKey ? findPrevious : findNext)(this.view()); bar.find.focus(); }
    });
    bar.replace.addEventListener("keydown", event => {
      if (event.key === "Enter") { event.preventDefault(); ((event.metaKey || event.ctrlKey) ? replaceAll : replaceNext)(this.view()); bar.replace.focus(); }
    });
    bar.previous.addEventListener("click", () => findPrevious(this.view()));
    bar.next.addEventListener("click", () => findNext(this.view()));
    bar.replaceOne.addEventListener("click", () => replaceNext(this.view()));
    bar.replaceEvery.addEventListener("click", () => replaceAll(this.view()));
    bar.close.addEventListener("click", () => this.closeFind());
    bar.replaceToggle.addEventListener("click", () => {
      const show = bar.replaceToggle.getAttribute("aria-expanded") !== "true";
      this.showReplace(show);
      (show ? bar.replace : bar.find).focus();
    });
    // Esc closes the bar from any of its fields or buttons.
    bar.root.addEventListener("keydown", event => { if (event.key === "Escape") { event.preventDefault(); this.closeFind(); } });
  }
}
