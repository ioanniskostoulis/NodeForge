import assert from "node:assert/strict";
import { test } from "node:test";

test("a download reports its progress as the bytes arrive, and once at the end", async () => {
  const { downloadAsset } = await import("../../source/desktop/updater");
  const { mkdtempSync, readFileSync, rmSync } = await import("node:fs");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const dir = mkdtempSync(join(tmpdir(), "download-"));
  try {
    const parts = [new Uint8Array(4).fill(1), new Uint8Array(6).fill(2)];
    const body = new ReadableStream<Uint8Array>({ start(controller) { for (const part of parts) controller.enqueue(part); controller.close(); } });
    const seen: { done: number; total: number }[] = [];
    await downloadAsset({ name: "a.exe", url: "https://x/a.exe", size: 10, sha256: null }, join(dir, "a.exe"), (async () => new Response(body)) as unknown as typeof fetch, (progress) => seen.push(progress));
    assert.deepEqual(seen.at(-1), { done: 10, total: 10 });
    assert.ok(seen.every((progress) => progress.total === 10));
    assert.equal(readFileSync(join(dir, "a.exe")).length, 10);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
