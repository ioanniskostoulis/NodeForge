import assert from "node:assert/strict";
import { test } from "node:test";
import { wheelIntent } from "../../source/app/wheel";

let clock = 0;
/** A wheel event 1 s after the last, so that each one starts a gesture of its own. */
const wheel = (fields: Partial<{ deltaX: number; deltaY: number; deltaMode: number; wheelDeltaY: number; ctrlKey: boolean; metaKey: boolean; shiftKey: boolean }>) => {
  clock += 1000;
  return { deltaX: 0, deltaY: 0, deltaMode: 0, ctrlKey: false, metaKey: false, shiftKey: false, ...fields } as unknown as WheelEvent;
};
(globalThis as { performance: { now(): number } }).performance = { now: () => clock };
const factor = (event: WheelEvent) => { const intent = wheelIntent(event, false); assert.equal(intent.kind, "zoom"); return (intent as { factor: number }).factor; };

test("Ctrl or Cmd with a mouse wheel zooms one notch at a time, as the plain wheel does", () => {
  const plain = factor(wheel({ deltaY: 100, wheelDeltaY: -120 }));
  assert.ok(Math.abs(plain - 1 / 1.15) < 1e-9, "a plain notch zooms out by 1.15");
  assert.ok(Math.abs(factor(wheel({ deltaY: 100, wheelDeltaY: -120, ctrlKey: true })) - plain) < 1e-9, "Ctrl + notch: 1.15, not exp(−1) = 0.37");
  assert.ok(Math.abs(factor(wheel({ deltaY: -100, wheelDeltaY: 120, metaKey: true })) - 1.15) < 1e-9);
  assert.ok(Math.abs(factor(wheel({ deltaY: 3, deltaMode: 1, ctrlKey: true })) - 1 / 1.15) < 1e-9, "one line-mode notch (3 lines)");
});

test("a pinch zooms exp(−deltaY × 0.03) a step, three times the fingers' own scale, never a mouse notch", () => {
  // A trackpad pinch: Ctrl + small pixel deltas, the legacy delta exactly −3 × deltaY.
  assert.ok(Math.abs(factor(wheel({ deltaY: 2, wheelDeltaY: -6, ctrlKey: true })) - Math.exp(-0.06)) < 1e-9);
  assert.ok(Math.abs(factor(wheel({ deltaY: -1.5, ctrlKey: true })) - Math.exp(0.045)) < 1e-9);
  // Chromium on macOS, recorded: every pinch step carries a legacy delta of ±120, as a mouse notch does.
  assert.ok(Math.abs(factor(wheel({ deltaY: -1.8144928216934204, wheelDeltaY: 120, ctrlKey: true })) - Math.exp(3 * 0.018144928216934204)) < 1e-9, "not 1.15");
  const recorded = [-0.63, -1.81, -3.94, -2.17, -2.03, -1.78, -2.36, -1.8, -1.82, -1.44, -1.7, -1.51];
  const total = recorded.reduce((zoom, deltaY) => zoom * factor(wheel({ deltaY, wheelDeltaY: 120, ctrlKey: true })), 1);
  assert.ok(total > 1.9 && total < 2.1, `a short recorded pinch zooms about 2×, not 1.15^12 = 5.4× (got ${total.toFixed(2)})`);
});
