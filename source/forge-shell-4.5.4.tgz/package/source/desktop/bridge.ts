// Licensed under the GNU General Public License v2 or later. See LICENSE.
import type { MenuNode } from "../app/menus";
import type { InstallResult, ReleaseAsset } from "../app/updates";

export interface OpenedFile { path: string; text: string }

export interface ForgeDesktopBridge<SaveFormat extends string = string> {
  platform: "darwin" | "win32" | "linux";
  version: string;
  setMenu(menu: MenuNode[]): void;
  /** Recolour the Windows window controls beside the drawn menu bar; ignored elsewhere. */
  setTitleBar(colors: { color: string; symbolColor: string }): void;
  /** Add an opened or saved file to the system's recent documents (the Dock menu, Jump Lists). */
  addRecentDocument(path: string): void;
  onCommand(fn: (id: string) => void): void;
  onFullScreen(fn: (on: boolean) => void): void;
  initialFiles(): Promise<OpenedFile[]>;
  onOpenFiles(fn: (files: OpenedFile[]) => void): void;
  openFileDialog(): Promise<OpenedFile[]>;
  saveDialog(defaultName: string, format?: SaveFormat): Promise<string | null>;
  writeFile(path: string, text: string): Promise<void>;
  /** The export dialog offering these formats (all of them when none are named): the chosen path, or null. */
  exportDialog(suggestedName: string, formatIds?: readonly string[]): Promise<string | null>;
  /** A folder for several exported files, with the names already in it, or null. */
  exportFolder(title?: string): Promise<{ folder: string; names: string[] } | null>;
  /** The names in the folder of `path`, which an export dialog chose. */
  exportFolderNames(path: string): Promise<string[]>;
  /** Write an export where an export dialog chose; never a project file or an original; `replace` after the person confirmed. */
  writeExport(path: string, bytes: Uint8Array, originals?: readonly string[], replace?: boolean): Promise<void>;
  newWindow(): void;
  setTitle(title: string): void;
  setEdited(edited: boolean): void;
  onCloseRequest(fn: () => void): void;
  closeWindow(): void;
  closeCancelled(): void;
  /** Download and install an update (`registerUpdater` in the main process); the app quits and restarts into it. */
  installUpdate(asset: ReleaseAsset): Promise<InstallResult>;
  /** Follow the download of `installUpdate`: bytes received and the whole size (0 when not known). */
  onUpdateProgress(fn: (progress: { done: number; total: number }) => void): void;
  /** The path on disk of a file dropped on the page (Electron's `webUtils.getPathForFile`), or "" when it has none. */
  pathForFile(file: File): string;
}

/** Electron's `webUtils`, which the preload passes so that dropped files have their paths. */
export interface WebUtilsPort {
  getPathForFile(file: File): string;
}

/** The small IPC surface needed by a preload without importing Electron into the renderer package. */
export interface IpcRendererPort {
  send(channel: string, ...args: unknown[]): void;
  invoke(channel: string, ...args: unknown[]): Promise<unknown>;
  on(channel: string, fn: (event: unknown, ...args: any[]) => void): unknown;
}

export function createDesktopBridge<SaveFormat extends string>(ipc: IpcRendererPort, platform: ForgeDesktopBridge["platform"], version: string, webUtils?: WebUtilsPort): ForgeDesktopBridge<SaveFormat> {
  return {
    platform, version,
    setMenu: (menu) => ipc.send("setMenu", menu),
    setTitleBar: (colors) => ipc.send("setTitleBar", colors),
    addRecentDocument: (path) => ipc.send("addRecentDocument", path),
    onCommand: (fn) => { ipc.on("command", (_event, id: string) => fn(id)); },
    onFullScreen: (fn) => { ipc.on("fullScreen", (_event, on: boolean) => fn(on)); },
    initialFiles: () => ipc.invoke("initialFiles") as Promise<OpenedFile[]>,
    onOpenFiles: (fn) => { ipc.on("openFiles", (_event, files: OpenedFile[]) => fn(files)); },
    openFileDialog: () => ipc.invoke("openFileDialog") as Promise<OpenedFile[]>,
    saveDialog: (name, format) => ipc.invoke("saveDialog", name, format) as Promise<string | null>,
    writeFile: (path, contents) => ipc.invoke("writeFile", path, contents) as Promise<void>,
    exportDialog: (name, formatIds) => ipc.invoke("exportDialog", name, formatIds ? [...formatIds] : undefined) as Promise<string | null>,
    exportFolder: (title) => ipc.invoke("exportFolder", title) as Promise<{ folder: string; names: string[] } | null>,
    exportFolderNames: (path) => ipc.invoke("exportFolderNames", path) as Promise<string[]>,
    writeExport: (path, bytes, originals, replace) => ipc.invoke("writeExport", path, bytes, originals ? [...originals] : [], replace === true) as Promise<void>,
    newWindow: () => ipc.send("newWindow"),
    setTitle: (title) => ipc.send("setTitle", title),
    setEdited: (edited) => ipc.send("setEdited", edited),
    onCloseRequest: (fn) => { ipc.on("closeRequest", () => fn()); },
    closeWindow: () => ipc.send("closeWindow"),
    closeCancelled: () => ipc.send("closeCancelled"),
    installUpdate: (asset) => ipc.invoke("installUpdate", asset) as Promise<InstallResult>,
    onUpdateProgress: (fn) => { ipc.on("updateProgress", (_event, progress: { done: number; total: number }) => fn(progress)); },
    // A file that does not come from the disk (one made in the page) has no path; webUtils answers "" for it.
    pathForFile: (file) => { try { return webUtils?.getPathForFile(file) ?? ""; } catch { return ""; } },
  };
}
