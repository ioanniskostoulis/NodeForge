// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { AUTOSAVE_CHOICES, AUTOSAVE_LABELS, parseAutosave, type AutosaveChoice } from "./saving";

export interface ShellPreferenceState {
  showBottomPanel: boolean;
  showInspector: boolean;
  inspectorSide: "left" | "right";
  appearance: "dark" | "light" | "pride";
  /** Present when the application offers autosave; `autosave` then reads and sets it. */
  autosave?: AutosaveChoice;
}

export interface ShellPreferenceHost<Pane extends string, State extends ShellPreferenceState> {
  settings: State;
  update: (change: Partial<State>) => void;
  panes: readonly Pane[];
  selectPane: (pane: Pane) => void;
}

const switchStatus = (label: string, before: boolean, after: boolean): string =>
  before === after ? `${label[0].toUpperCase()}${label.slice(1)} is already ${after ? "on" : "off"}.` : `${label[0].toUpperCase()}${label.slice(1)} ${after ? "enabled" : "disabled"}.`;

/** Execute the shared panel, inspector, appearance and autosave Terminal verbs. */
export function shellPreferenceCommand<Pane extends string, State extends ShellPreferenceState>(
  command: string, arg: string, host: ShellPreferenceHost<Pane, State>,
): { lines: string[] } | null {
  const { settings, update, panes, selectPane } = host;
  if (command === "panel" && !arg) return { lines: [`The bottom panel is ${settings.showBottomPanel ? "on" : "off"}.`] };
  if (command === "panel" && (arg === "on" || arg === "off" || panes.includes(arg as Pane))) {
    const before = settings.showBottomPanel;
    update({ showBottomPanel: arg !== "off" } as Partial<State>);
    if (panes.includes(arg as Pane)) selectPane(arg as Pane);
    return { lines: [panes.includes(arg as Pane) ? `Showing ${arg} panel.` : switchStatus("bottom panel", before, settings.showBottomPanel)] };
  }
  if (command === "inspector" && !arg) return { lines: [settings.showInspector ? `The inspector is on, on the ${settings.inspectorSide}.` : "The inspector is off."] };
  if (command === "inspector" && (arg === "on" || arg === "off")) {
    const before = settings.showInspector;
    update({ showInspector: arg === "on" } as Partial<State>);
    return { lines: [switchStatus("inspector", before, settings.showInspector)] };
  }
  if (command === "inspector" && (arg === "left" || arg === "right")) {
    update({ showInspector: true, inspectorSide: arg } as Partial<State>);
    return { lines: [`Inspector moved to the ${arg}.`] };
  }
  if (command === "theme" && !arg) return { lines: [`The appearance is ${settings.appearance}.`] };
  if (command === "theme" && (arg === "light" || arg === "dark" || arg === "pride")) {
    const before = settings.appearance === arg;
    update({ appearance: arg } as Partial<State>);
    return { lines: [switchStatus(`${arg} mode`, before, settings.appearance === arg)] };
  }
  if (command === "autosave" && settings.autosave !== undefined) {
    if (!arg) return { lines: [`Autosave is ${settings.autosave === "off" ? "off" : AUTOSAVE_LABELS[settings.autosave].toLowerCase()}.`] };
    const choice = parseAutosave(arg);
    if (!choice) return { lines: [`Autosave takes ${AUTOSAVE_CHOICES.join(", ").replace(/, (?=[^,]*$)/, " or ")}.`] };
    const before = settings.autosave;
    update({ autosave: choice } as Partial<State>);
    if (before === choice) return { lines: [`Autosave is already ${choice === "off" ? "off" : AUTOSAVE_LABELS[choice].toLowerCase()}.`] };
    return { lines: [choice === "off" ? "Autosave disabled." : `Autosave set to ${AUTOSAVE_LABELS[choice].toLowerCase()}.`] };
  }
  return null;
}
