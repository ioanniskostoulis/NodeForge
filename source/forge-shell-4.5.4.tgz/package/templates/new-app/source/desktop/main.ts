// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Electron main process: the windows (documents open as tabs inside them), the native menu bar, file dialogs and
// recent documents. The interface is the same web app as the browser version, served from the app:// protocol.
import { app, BrowserWindow, dialog, ipcMain, Menu, type MenuItemConstructorOptions, net, protocol, shell } from "electron";
import { existsSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { readdir, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import type { OpenedFile } from "forge-shell/desktop/bridge";
import type { MenuNode } from "forge-shell/app/menus";
import { createNativeMenuTemplate } from "forge-shell/desktop/native-menu";
import { DesktopWindowState } from "forge-shell/desktop/window-state";
import { forwardFullScreen } from "forge-shell/desktop/full-screen";
import { DARK_WINDOW_BACKGROUND, registerTitleBarIpc, usesNativeMenu, windowChrome } from "forge-shell/desktop/title-bar";
import { documentArguments, readOpenedFiles } from "forge-shell/desktop/files";
import { registerShellMainIpc } from "forge-shell/desktop/ipc-main";
import { registerExportIpc } from "forge-shell/desktop/export-main";
import type { ExportFormat } from "forge-shell/app/export-plan";
import { registerUpdater } from "forge-shell/desktop/updater";
import config from "../../forge.config.json";

const isMac = process.platform === "darwin";
const devUrl = !app.isPackaged ? process.env.FORGE_DEV_URL : undefined;
if (devUrl) app.setPath("userData", join(app.getPath("appData"), `${config.identity.name} Dev`));
/** Root of the bundled files: build/ in development, resources/app.asar/build when packaged. */
const buildRoot = join(__dirname, "..");
const extension = config.document.extension;
const DOCUMENT_FILE = new RegExp(`\\.${extension}$`, "i");

const windows = new DesktopWindowState<OpenedFile>();
const allowedWrites = new Map<number, Set<string>>();
let pendingOpen: string[] = [];

protocol.registerSchemesAsPrivileged([{ scheme: "app", privileges: { standard: true, secure: true, supportFetchAPI: true } }]);

function readFiles(paths: string[]): OpenedFile[] {
  return readOpenedFiles(paths, (path) => readFileSync(path, "utf8"),
    (path, error) => dialog.showErrorBox(`Can't open ${config.document.noun}`, `${path}\n${error.message}`));
}

/** Open files as tabs in the frontmost window, or in a new window when there is none. */
function openFiles(paths: string[]): void {
  const files = readFiles(paths);
  if (!files.length) return;
  for (const file of files) app.addRecentDocument(file.path);
  const win = BrowserWindow.getFocusedWindow() ?? BrowserWindow.getAllWindows()[0];
  if (win) {
    win.webContents.send("openFiles", files);
    if (win.isMinimized()) win.restore();
    win.focus();
  } else openWindow(files);
}

function openWindow(files: OpenedFile[] = []): void {
  const win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 1000, minHeight: 600,
    backgroundColor: DARK_WINDOW_BACKGROUND,
    title: config.identity.name,
    ...windowChrome(process.platform),
    show: false,
    webPreferences: { preload: join(__dirname, "preload.cjs"), contextIsolation: true, sandbox: false },
  });
  const id = win.webContents.id;
  windows.setStartupFiles(id, files);
  win.once("ready-to-show", () => win.show());
  forwardFullScreen(win);
  // Unsaved documents: the window asks in its own prompt (save the chosen ones, discard or cancel).
  win.on("close", (event) => {
    if (!windows.needsClosePrompt(id)) return;
    event.preventDefault();
    win.webContents.send("closeRequest");
  });
  win.on("closed", () => {
    allowedWrites.delete(id);
    exportIpc.forget(id);
    if (windows.closed(id, BrowserWindow.getAllWindows().length)) app.quit();
  });
  // Links (the About window's credits) open in the browser.
  win.webContents.setWindowOpenHandler(({ url }) => { void shell.openExternal(url); return { action: "deny" }; });
  win.loadURL(`${devUrl ?? `app://${config.identity.id}`}/index.html`);
  // A launch capture, used by the desktop smoke checks.
  const capture = process.env.FORGE_CAPTURE;
  if (capture) {
    win.webContents.once("did-finish-load", () => setTimeout(async () => {
      try {
        const image = await win.webContents.capturePage();
        // Publish only the complete PNG: CI polls for its existence before opening it.
        writeFileSync(`${capture}.tmp`, image.toPNG());
        renameSync(`${capture}.tmp`, capture);
        console.log(`capture: wrote ${capture}`);
      } catch (error) { console.error(`capture: ${String(error)}`); }
    }, Number(process.env.FORGE_CAPTURE_DELAY ?? 5000)));
  }
}

// MARK: native menu from the renderer's menu definition

function installMenu(nodes: MenuNode[]): void {
  // Windows draws the menus in the page; no native menu bar is installed.
  if (!usesNativeMenu(process.platform)) { Menu.setApplicationMenu(null); return; }
  const template = createNativeMenuTemplate(nodes, {
    productName: config.identity.name, isMac, isPackaged: app.isPackaged,
    onCommand: (id, win) => (win as BrowserWindow | undefined)?.webContents.send("command", id),
  });
  Menu.setApplicationMenu(Menu.buildFromTemplate(template as MenuItemConstructorOptions[]));
}

// MARK: IPC

registerShellMainIpc(ipcMain, {
  windows,
  windowFor: (event) => BrowserWindow.fromWebContents(event.sender as Electron.WebContents),
  focusedWindow: () => BrowserWindow.getFocusedWindow(),
  installMenu,
  newWindow: () => openWindow(),
  canWriteFile: (event, path) => allowedWrites.get(event.sender.id)?.has(path) ?? false,
  writeFile: (path, text) => writeFile(path, text, "utf8"),
  addRecentDocument: (path) => app.addRecentDocument(path),
});
// Exports: the formats the application writes besides its project file (`.${extension}`, written only by Save). The
// shell's export dialog, folder dialog and guarded binary writes; an export never writes a project file or an original.
const EXPORT_FORMATS: ExportFormat[] = [];
const exportIpc = registerExportIpc(ipcMain, {
  formats: EXPORT_FORMATS,
  ignoreCase: process.platform !== "linux",
  saveDialog: async (event, options) => {
    const win = BrowserWindow.fromWebContents(event.sender as Electron.WebContents);
    const result = win ? await dialog.showSaveDialog(win, options) : await dialog.showSaveDialog(options);
    return result.canceled || !result.filePath ? null : result.filePath;
  },
  folderDialog: async (event, options) => {
    const win = BrowserWindow.fromWebContents(event.sender as Electron.WebContents);
    const settings = { ...options, properties: ["openDirectory", "createDirectory"] as ("openDirectory" | "createDirectory")[] };
    const result = win ? await dialog.showOpenDialog(win, settings) : await dialog.showOpenDialog(settings);
    return result.canceled ? null : result.filePaths[0] ?? null;
  },
  readdir: (folder) => readdir(folder),
  writeFile: (path, bytes, flag) => writeFile(path, bytes, { flag }),
  resolve: (path) => resolve(path),
  dirname: (path) => dirname(path),
});
// One-click updates from the releases of the repository named in the profile (Settings › Updates).
const repository = (config.identity as { repository?: string }).repository;
if (repository && app.isPackaged) registerUpdater(ipcMain, { repository, executable: process.execPath, platform: process.platform, quit: () => app.quit(), hasUnsavedWork: () => windows.hasEdited(), openPath: (path) => shell.openPath(path) });
// The colours of the Windows window controls follow the page's appearance.
registerTitleBarIpc(ipcMain, (event) => BrowserWindow.fromWebContents(event.sender as Electron.WebContents));
ipcMain.handle("openFileDialog", async (event) => {
  const win = BrowserWindow.fromWebContents(event.sender)!;
  const result = await dialog.showOpenDialog(win, {
    title: `Open ${config.document.noun}`,
    filters: [{ name: config.desktop.document.name, extensions: [extension] }],
    properties: ["openFile", "multiSelections"],
  });
  return result.canceled ? [] : readFiles(result.filePaths);
});
ipcMain.handle("saveDialog", async (event, defaultName: string) => {
  const win = BrowserWindow.fromWebContents(event.sender)!;
  const result = await dialog.showSaveDialog(win, { title: `Save ${config.document.noun}`, defaultPath: defaultName, filters: [{ name: config.desktop.document.name, extensions: [extension] }] });
  if (result.canceled || !result.filePath) return null;
  const path = DOCUMENT_FILE.test(result.filePath) ? result.filePath : `${result.filePath}.${extension}`;
  const approved = allowedWrites.get(event.sender.id) ?? new Set<string>();
  approved.add(path);
  allowedWrites.set(event.sender.id, approved);
  return path;
});

// MARK: app lifecycle

/** Document files among command-line arguments. */
function argFiles(argv: string[], cwd = process.cwd()): string[] {
  return documentArguments(argv, cwd, (path) => DOCUMENT_FILE.test(path), resolve, existsSync);
}

// One instance: a second launch (opening a file from the command line) adds tabs here.
if (!app.requestSingleInstanceLock()) app.quit();
app.on("second-instance", (_event, argv, cwd) => {
  const files = argFiles(argv.slice(1), cwd);
  if (files.length) openFiles(files);
  else BrowserWindow.getAllWindows()[0]?.focus();
});
// macOS: files opened from Finder, before or after launch.
app.on("open-file", (event, path) => {
  event.preventDefault();
  if (app.isReady()) openFiles([path]);
  else pendingOpen.push(path);
});
app.whenReady().then(() => {
  protocol.handle("app", (request) => net.fetch(pathToFileURL(join(buildRoot, "app", decodeURIComponent(new URL(request.url).pathname))).toString()));
  // Windows and Linux: files passed on the command line.
  const files = [...pendingOpen, ...argFiles(process.argv.slice(app.isPackaged ? 1 : 2))];
  pendingOpen = [];
  openWindow(readFiles(files));
});
app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) openWindow(); });
app.on("before-quit", () => windows.beginQuit());
app.on("window-all-closed", () => { if (!isMac) app.quit(); });
