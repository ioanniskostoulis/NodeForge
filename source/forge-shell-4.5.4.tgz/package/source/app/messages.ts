// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { attachSelectionShape } from "./selection-shape";
// The Messages log: one place for everything the app tells about a document. Each open document
// keeps its own log; the bottom panel's Messages tab shows the active one, newest last, and the
// status bar counts the problems not yet seen there.

/** error: something failed or can't run. warning: it runs, but not as asked. info: a result. */
export type MessageKind = "error" | "warning" | "info";

export interface Message {
  readonly kind: MessageKind;
  readonly text: string;
  /** Wall-clock time it was logged. */
  readonly time: Date;
  /** The document object it is about, if any: the entry then selects it. */
  readonly subject?: object;
}

export class MessageLog {
  static readonly LIMIT = 500;
  readonly entries: Message[] = [];
  /** Errors and warnings logged since the log was last shown. */
  unseen = 0;
  private unseenError = false;
  /** Goes up with every change: what the pane redraws on. */
  revision = 0;

  add(kind: MessageKind, text: string, subject?: object): Message {
    const message: Message = { kind, text, time: new Date(), subject };
    this.entries.push(message);
    if (this.entries.length > MessageLog.LIMIT) this.entries.splice(0, this.entries.length - MessageLog.LIMIT);
    if (kind !== "info") this.unseen++;
    if (kind === "error") this.unseenError = true;
    this.revision++;
    return message;
  }

  /** The worst kind among the unseen problems: `error`, else `warning`, else `null`. Feeds the status bar icon. */
  get worstUnseen(): "error" | "warning" | null {
    return this.unseen === 0 ? null : this.unseenError ? "error" : "warning";
  }

  markSeen(): void {
    this.unseenError = false;
    if (this.unseen) { this.unseen = 0; this.revision++; }
  }

  clear(): void {
    this.entries.length = 0;
    this.unseen = 0;
    this.unseenError = false;
    this.revision++;
  }
}

/**
 * Logs the conditions of a document that come and go with its state once each, when they appear, rather than on every check. One that flickers
 * (a speed limit near its threshold) is logged again only after it has been gone a while.
 */
export class ConditionWatch {
  static readonly QUIET_MS = 30_000;
  /** Each condition logged, with when it was last there. */
  private seen = new Map<string, number>();

  /** Log the conditions in `now` that weren't there lately. */
  update(log: MessageLog, now: Iterable<[key: string, kind: MessageKind, text: string, subject?: object]>, time = Date.now()): void {
    for (const [key, kind, text, subject] of now) {
      const last = this.seen.get(key);
      if (last === undefined || time - last > ConditionWatch.QUIET_MS) log.add(kind, text, subject);
      this.seen.set(key, time);
    }
    for (const [key, last] of this.seen) if (time - last > ConditionWatch.QUIET_MS) this.seen.delete(key);
  }
}

const KIND_LABEL: Record<MessageKind, string> = { error: "Error", warning: "Warning", info: "Info" };

const two = (number: number) => String(number).padStart(2, "0");
export const messageTime = (time: Date) => `${two(time.getHours())}:${two(time.getMinutes())}:${two(time.getSeconds())}`;

/** The log as plain text lines (the console's `messages` and copying). */
export function messageLines(log: MessageLog, name: (subject: object) => string | null): string[] {
  return log.entries.map((message) => {
    const subjectName = message.subject ? name(message.subject) : null;
    return `${messageTime(message.time)}  ${KIND_LABEL[message.kind].padEnd(7)}  ${subjectName ? `${subjectName}: ` : ""}${message.text}`;
  });
}

export interface MessagesHost {
  /** Name of a linked object (null once it is gone from the document). */
  subjectName(subject: object): string | null;
  selectSubject(subject: object): void;
}

/** The Messages tab: the active document's log. */
export class MessagesPanel {
  private log: MessageLog | null = null;
  private shown = -1;
  private readonly list: HTMLElement;
  private readonly empty: HTMLElement;

  /** `clear`: the Clear button, in the panel's tab bar; disabled while the log is empty. */
  constructor(private readonly host: HTMLElement, private readonly owner: MessagesHost, private readonly clear: HTMLButtonElement) {
    clear.addEventListener("click", () => { this.log?.clear(); this.refresh(true); });
    this.list = document.createElement("div");
    this.list.className = "messages-list";
    this.list.setAttribute("role", "log");
    this.empty = Object.assign(document.createElement("div"), { className: "pane-empty", textContent: "No messages." });
    host.replaceChildren(this.list, this.empty);
    attachSelectionShape(host);
  }

  setLog(log: MessageLog | null): void {
    this.log = log;
    this.refresh(true);
  }

  /** Redraw when the log changed; called every frame while the tab is visible. */
  refresh(force = false): void {
    const log = this.log;
    if (!force && log?.revision === this.shown) return;
    this.shown = log?.revision ?? -1;
    const entries = log?.entries ?? [];
    this.empty.hidden = entries.length > 0;
    this.clear.disabled = entries.length === 0;
    const atEnd = this.host.scrollTop + this.host.clientHeight >= this.host.scrollHeight - 4;
    this.list.replaceChildren(...entries.map((message) => this.row(message)));
    if (atEnd || force) this.host.scrollTop = this.host.scrollHeight;
  }

  private row(message: Message): HTMLElement {
    const row = document.createElement("div");
    row.className = `message ${message.kind}`;
    const time = Object.assign(document.createElement("span"), { className: "message-time", textContent: messageTime(message.time) });
    const kind = Object.assign(document.createElement("span"), { className: "message-kind", textContent: KIND_LABEL[message.kind] });
    const text = Object.assign(document.createElement("span"), { className: "message-text" });
    const name = message.subject ? this.owner.subjectName(message.subject) : null;
    if (name) {
      const link = Object.assign(document.createElement("button"), { className: "message-subject", textContent: name, title: `Select ${name}.` });
      link.addEventListener("click", () => this.owner.selectSubject(message.subject!));
      text.append(link, ": ");
    }
    text.append(message.text);
    row.append(time, kind, text);
    return row;
  }
}
