// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The header of a view beside the main work, such as a file opened next to the editor or a preview: its title, the
// unsaved dot of the document tabs, the view's own icon actions and its close control. A file's status (editable,
// read-only) is shown in the file tree only, never here.
import { setTip } from "./tips";
import { UI_ICONS } from "./tool-icons";

export interface ViewAction { icon: string; label: string; run(): void }
export interface ViewHeaderOptions {
  title: string;
  /** Shows the unsaved dot. */
  dirty?: boolean;
  /** @deprecated Ignored: a file's status is shown in the file tree only (`FileTreeHost.status`). */
  mode?: "editable" | "readOnly";
  actions?: ViewAction[];
  /** Given, the header has a close control at the right. */
  onClose?(): void;
  closeLabel?: string;
}

/** A view header: the title and its marks at the left, the actions and the close control at the right. */
export function createViewHeader(options: ViewHeaderOptions): HTMLElement {
  const header = document.createElement("div");
  header.className = "view-header";
  const mark = Object.assign(document.createElement("span"), { className: `view-dirty${options.dirty ? " on" : ""}` });
  mark.setAttribute("aria-hidden", "true");
  const title = Object.assign(document.createElement("span"), { className: "view-title", textContent: options.title });
  setTip(title, options.title);
  header.append(mark, title);
  header.append(Object.assign(document.createElement("span"), { className: "view-space" }));
  const button = (icon: string, label: string, run: () => void, className = "view-action") => {
    const element = Object.assign(document.createElement("button"), { type: "button", className, innerHTML: icon });
    element.setAttribute("aria-label", label);
    setTip(element, label);
    element.addEventListener("click", run);
    header.append(element);
  };
  for (const action of options.actions ?? []) button(action.icon, action.label, action.run);
  if (options.onClose) button(UI_ICONS.close, options.closeLabel ?? "Close", options.onClose, "view-action view-close");
  return header;
}
