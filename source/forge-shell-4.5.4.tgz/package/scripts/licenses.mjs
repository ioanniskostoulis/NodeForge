// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";

const textFile = /^(?:licen[cs]e|copying|notice)(?:[-._].*)?$/i;

/**
 * The production packages an app ships, with the licence text each one carries. Dev-only and linked packages are
 * skipped, and so are the names in `skip` (the shell itself, which has its own LICENSE). A package with no licence
 * field at all is reported in `missing`.
 */
export function collectLicenses({ lockfile = "package-lock.json", modules = "node_modules", skip = ["forge-shell"] } = {}) {
  const packages = JSON.parse(readFileSync(lockfile, "utf8")).packages ?? {};
  const entries = [];
  const missing = [];
  for (const [key, info] of Object.entries(packages)) {
    if (!key || info.dev || info.link || !key.includes("node_modules/")) continue;
    const name = key.slice(key.lastIndexOf("node_modules/") + "node_modules/".length);
    if (skip.includes(name)) continue;
    const dir = join(key.startsWith("node_modules/") ? modules : key.slice(0, key.indexOf("node_modules/")), key.startsWith("node_modules/") ? key.slice("node_modules/".length) : key.slice(key.indexOf("node_modules/") + "node_modules/".length));
    const meta = existsSync(join(dir, "package.json")) ? JSON.parse(readFileSync(join(dir, "package.json"), "utf8")) : {};
    const license = typeof info.license === "string" ? info.license : typeof meta.license === "string" ? meta.license : null;
    if (!license) { missing.push(`${name}@${info.version}`); continue; }
    const texts = existsSync(dir) ? readdirSync(dir).filter((file) => textFile.test(file) && statSync(join(dir, file)).isFile()).sort().map((file) => ({ file, text: readFileSync(join(dir, file), "utf8").trim() })) : [];
    const repository = typeof meta.repository === "string" ? meta.repository : meta.repository?.url ?? meta.homepage ?? null;
    entries.push({ name, version: info.version, license, repository: repository?.replace(/^git\+/, "").replace(/\.git$/, "") ?? null, texts });
  }
  entries.sort((a, b) => a.name.localeCompare(b.name));
  return { entries, missing };
}

/** The third-party licence file shipped inside an app. */
export function licensesMarkdown(entries) {
  const head = "# Third-party licenses\n\nThis app includes the following third-party packages. Each is used under its own licence, reproduced below.\n";
  if (!entries.length) return `${head}\nNo third-party packages are bundled.\n`;
  const body = entries.map((entry) => {
    const lines = [`## ${entry.name} ${entry.version}`, "", `Licence: ${entry.license}${entry.repository ? `  \nSource: ${entry.repository}` : ""}`, ""];
    if (!entry.texts.length) lines.push("The package carries no separate licence text; its licence is named above.", "");
    for (const { file, text } of entry.texts) lines.push(`### ${file}`, "", "```text", text, "```", "");
    return lines.join("\n");
  });
  return `${head}\n${body.join("\n")}`;
}
