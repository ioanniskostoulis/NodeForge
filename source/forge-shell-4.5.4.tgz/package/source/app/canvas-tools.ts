// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The tools that edit a canvas and their keys, the same in every application: Select V, Crop C, and the region shapes.
// An application opts into the tools it has and gives their letters to nothing else, so that a tool it shares with
// another application has the same key in both. The eyedropper keeps 1, 3 and 5 for its sizes.

// MARK: given values

export type CanvasTool = "select" | "crop" | "rectangle" | "ellipse" | "polygon" | "freehand" | "line";

/** Each canvas tool's id, name and single-letter key. */
export const CANVAS_TOOLS: Readonly<Record<CanvasTool, { id: string; label: string; key: string }>> = {
  select: { id: "tool.select", label: "Select", key: "V" },
  crop: { id: "tool.crop", label: "Crop", key: "C" },
  rectangle: { id: "tool.rectangle", label: "Rectangle", key: "R" },
  ellipse: { id: "tool.ellipse", label: "Ellipse", key: "E" },
  polygon: { id: "tool.polygon", label: "Polygon", key: "P" },
  freehand: { id: "tool.freehand", label: "Freehand", key: "F" },
  line: { id: "tool.line", label: "Line", key: "L" },
};
/** The region shapes, in the order of their flyout. */
export const SHAPE_TOOLS: readonly CanvasTool[] = ["rectangle", "ellipse", "polygon", "freehand", "line"];

// MARK: method

/**
 * The canvas tool of a key press among the tools an application has: a plain letter, without Cmd, Ctrl, Alt or Shift;
 * null for anything else.
 */
export function canvasToolForKey(event: { key: string; metaKey: boolean; ctrlKey: boolean; altKey: boolean; shiftKey: boolean }, tools: readonly CanvasTool[]): CanvasTool | null {
  if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey || event.key.length !== 1) return null;
  const key = event.key.toUpperCase();
  return tools.find((tool) => CANVAS_TOOLS[tool].key === key) ?? null;
}

/**
 * The application's shortcuts that take the key of a canvas tool it has for something else: one sentence each, empty
 * when none. A tool the application does not have leaves its letter free (a schematic may give C to a part).
 */
export function toolKeyProblems(shortcuts: readonly { key: string; id: string }[], tools: readonly CanvasTool[]): string[] {
  const problems: string[] = [];
  for (const tool of tools.map((name) => CANVAS_TOOLS[name])) {
    for (const shortcut of shortcuts) {
      if (shortcut.key.toUpperCase() === tool.key && shortcut.id !== tool.id) {
        problems.push(`The key ${tool.key} of ${shortcut.id} is the shell's key for the ${tool.label} tool (${tool.id}).`);
      }
    }
  }
  return problems;
}
