// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The component page: every part of the shell in the frame of an application, with long names, many tabs and every
// kind of message, so that rendering, centring and narrow windows can be checked in one place (scripts/gallery.mjs).
import { helpMenu, menuShortcutGroups, showAbout, showLicenses, showShortcuts, showWhatsNew, type InfoOptions } from "../../source/app/about";
import { createBottomTabs } from "../../source/app/bottom-tabs";
import { createButton, createButtonGroup, setButtonBusy, createCheckRow, createChips, createField, createGroupHeading, createInfoLines, createRow, setProblem } from "../../source/app/builders";
import { createCodeEditor } from "../../source/app/code-editor";
import { showContextMenu } from "../../source/app/context-menu";
import { applyDesktopClasses } from "../../source/app/desktop-classes";
import { askToApply, askToPick, askToSave, askToSaveAll } from "../../source/app/dialogs";
import { askReplace } from "../../source/app/export-files";
import { createEmptyState } from "../../source/app/empty-state";
import { createFindBar, FindController } from "../../source/app/find-bar";
import { attachFileDrop } from "../../source/app/file-drop";
import { renderFileTree, type FileSelection, type TreeFile } from "../../source/app/file-tree";
import { InspectorSections } from "../../source/app/inspector-sections";
import { createColourPicker } from "../../source/app/colour-picker";
import { sliderRow } from "../../source/app/inspector-widgets";
import { rangeSliderRow } from "../../source/app/range-slider";
import { renderMenubar, shortcutText, type MenuNode } from "../../source/app/menus";
import { MessageLog, MessagesPanel } from "../../source/app/messages";
import { renderOutline } from "../../source/app/outline-list";
import { createPanelLayout } from "../../source/app/panel-layout";
import { installScrollbars } from "../../source/app/scrollbars";
import { showUpdateNotice, type InstallResult } from "../../source/app/updates";
import { createTerminalPreferences } from "../../source/app/terminal-preferences";
import { generalPage, showSettings, terminalPage, updatesPage } from "../../source/app/settings-dialog";
import { OVERWRITE_CHOICES, OVERWRITE_LABELS } from "../../source/app/export-plan";
import type { AutosaveChoice } from "../../source/app/saving";
import { autosaveMenu, recentMenu } from "../../source/app/saving";
import { createSplitter } from "../../source/app/splitter";
import { StatusBar } from "../../source/app/status-bar";
import { DocumentTabs, type TabDocument } from "../../source/app/tabs";
import { TerminalPanel } from "../../source/app/terminal";
import { setTip } from "../../source/app/tips";
import { TOOL_ICONS, UI_ICONS } from "../../source/app/tool-icons";
import { createFlyoutGroup } from "../../source/app/tool-flyout";
import { createToolStrip } from "../../source/app/tool-strip";
import { createUnitField } from "../../source/app/unit-field";
import { createViewHeader } from "../../source/app/view-header";
import { GeneratorPane, type GeneratorPaneHost } from "../../source/app/generator-pane";
import { generatorCompletions, runGeneratorCommand } from "../../source/app/generator-command";
import { createHealthTracker, healthCommand, healthPage, showHealthBreakReminder } from "../../source/app/health";
import type { GeneratorValues } from "../../source/app/generator-fields";
import { restoreShare, codeShare as codeShareLimits, optionsShare as optionsShareLimits } from "../../source/app/generator-layout";
import { mountCanvasEditing } from "./canvas-editing";

declare const __APP_LOGO__: string;
declare const __FORGE_VERSION__: string;
const $ = (id: string) => document.getElementById(id)!;
const params = new URLSearchParams(location.search);
const info: InfoOptions = { productName: "Gallery", purpose: "component page", logo: __APP_LOGO__, version: __FORGE_VERSION__ };
// A browser tab, not an application window: a break leaves the page open.
const healthTracker = createHealthTracker({ storageKey: "forge.gallery.health", onTakeBreak: () => {} });
document.body.dataset.theme = params.get("theme") ?? "dark";
applyDesktopClasses(undefined);

// MARK: menus and tool strip

let galleryAutosave: AutosaveChoice = "off";
let galleryAppearance: "dark" | "light" = document.body.dataset.theme === "light" ? "light" : "dark";
const layout = { showInspector: true, inspectorSide: "right" as "left" | "right", inspectorWidth: 246, showBottomPanel: true, bottomPanelHeight: 246 };
let applyPanelLayout: () => void = () => {};
const galleryMenus = (): MenuNode[] => [
  { label: "File", submenu: [{ id: "new", label: "New document", key: "CmdOrCtrl+N" }, { id: "open", label: "Open…", key: "CmdOrCtrl+O" }, recentMenu(["/a/notes.txt", "/b/notes.txt", "/c/report with a long name.txt"]), { separator: true },
    { id: "save", label: "Save", key: "CmdOrCtrl+S" }, { id: "saveAs", label: "Save as…", key: "CmdOrCtrl+Shift+S", enabled: false }, autosaveMenu(galleryAutosave), { separator: true }, { id: "close", label: "Close", key: "CmdOrCtrl+W" }, { separator: true }, { id: "app.settings", label: "Settings…", key: "CmdOrCtrl+," }] },
  { label: "Edit", submenu: [{ role: "undo", label: "Undo", key: "CmdOrCtrl+Z" }, { role: "redo", label: "Redo", key: "CmdOrCtrl+Shift+Z" }, { separator: true }, { role: "selectAll", label: "Select all", key: "CmdOrCtrl+A" }] },
  { label: "View", submenu: [{ id: "inspector", label: "Show inspector", key: "CmdOrCtrl+I", checked: layout.showInspector }, { id: "panel", label: "Show bottom panel", key: "CmdOrCtrl+J", checked: layout.showBottomPanel }, { separator: true },
    { label: "Appearance", submenu: [{ id: "dark", label: "Dark", checked: galleryAppearance === "dark" }, { id: "light", label: "Light", checked: galleryAppearance === "light" }] }] },
  { label: "Simulate", submenu: [{ id: "run", label: "Run", key: "CmdOrCtrl+Return" }, { id: "step", label: "Step", key: "CmdOrCtrl+Shift+T" }] },
  helpMenu("Gallery", false, true),
];
let menus = galleryMenus();
const renderGalleryMenubar = () => renderMenubar($("menubar"), menus, run);
function rerenderMenus(): void { menus = galleryMenus(); renderGalleryMenubar(); }
function run(id: string): void {
  if (id === "about") showAbout(info, `<div class="block"><p class="about-intro">The component page of the shell.</p></div>`);
  else if (id === "about.whatsNew") void showWhatsNew(info);
  else if (id === "about.shortcuts") showShortcuts(info, menuShortcutGroups(menus, (key) => shortcutText(key)));
  else if (id === "about.licenses") void showLicenses(info);
  else if (id === "app.settings") showSettings({ pages: settingsPages() });
  else if (id === "new") { documents.push({ name: `Untitled ${documents.length + 1}`, dirty: false, path: null }); active = documents[documents.length - 1] ?? null; renderDocuments(); log.add("info", "Created a new document."); }
  else if (id === "open") { log.add("info", "Open… (no file picker in the gallery)."); }
  else if (id === "save") { if (active) { active.dirty = false; renderDocuments(); log.add("info", `Saved ${active.name}.`); } }
  else if (id === "saveAs") { log.add("info", "Save as… (no file picker in the gallery)."); }
  else if (id === "close") { if (active) { const index = documents.indexOf(active); documents.splice(index, 1); active = documents[0] ?? null; renderDocuments(); log.add("info", "Closed the document."); } }
  else if (id.startsWith("file.autosave.")) {
    galleryAutosave = id.slice("file.autosave.".length) as AutosaveChoice;
    preferences.autosave = galleryAutosave;
    rerenderMenus();
  } else if (id === "inspector") {
    layout.showInspector = !layout.showInspector;
    preferences.showInspector = layout.showInspector;
    applyPanelLayout();
    rerenderMenus();
  } else if (id === "panel") {
    layout.showBottomPanel = !layout.showBottomPanel;
    preferences.showBottomPanel = layout.showBottomPanel;
    applyPanelLayout();
    rerenderMenus();
  } else if (id === "dark" || id === "light") {
    galleryAppearance = id;
    preferences.appearance = id;
    document.body.dataset.theme = id;
    rerenderMenus();
  } else if (id === "run") { log.add("info", "Running…"); }
  else if (id === "step") { log.add("info", "Stepped one unit."); }
  else if (id === "pointer" || id === "rotate" || id === "duplicate" || id === "delete" || id === "undo" || id === "redo" || id === "cut" || id === "copy" || id === "paste" || id === "zoomIn" || id === "zoomOut" || id === "fit") {
    log.add("info", `Ran ${id}.`);
  } else {
    log.add("info", `Ran ${id}.`);
  }
}
renderGalleryMenubar();
const strip = createToolStrip($("toolstrip"), run);
strip.group([strip.tool({ id: "undo", label: "Undo", icon: TOOL_ICONS.undo, shortcut: "CmdOrCtrl+Z" }), strip.tool({ id: "redo", label: "Redo", icon: TOOL_ICONS.redo, shortcut: "CmdOrCtrl+Shift+Z" })], "", "history");
strip.group([strip.tool({ id: "cut", label: "Cut", icon: TOOL_ICONS.cut }), strip.tool({ id: "copy", label: "Copy", icon: TOOL_ICONS.copy }), strip.tool({ id: "paste", label: "Paste", icon: TOOL_ICONS.paste })], "", "clipboard");
strip.group([strip.tool({ id: "zoomIn", label: "Zoom in", icon: TOOL_ICONS.zoomIn }), strip.tool({ id: "zoomOut", label: "Zoom out", icon: TOOL_ICONS.zoomOut }), strip.tool({ id: "fit", label: "Fit", icon: TOOL_ICONS.fit })], "", "view");
strip.group([strip.tool({ id: "pointer", label: "Select", icon: UI_ICONS.pointer, shortcut: "V" }), strip.tool({ id: "rotate", label: "Rotate", icon: UI_ICONS.rotate }), strip.tool({ id: "duplicate", label: "Duplicate", icon: UI_ICONS.duplicate }), strip.tool({ id: "delete", label: "Delete", icon: UI_ICONS.delete })]);
// A palette family with tools of long and short names, so that the flyout menu's columns can be checked.
const shapes = createFlyoutGroup({ id: "shapes", label: "Shapes", onSelect(id) { log.add("info", `Selected shape ${id}.`); }, tools: [
  { id: "rect", label: "Rectangle", icon: UI_ICONS.add, shortcut: "R" }, { id: "ellipse", label: "Ellipse", icon: UI_ICONS.remove },
  { id: "polygon", label: "Polygon with a long name", icon: UI_ICONS.edit, shortcut: "P" }] });
strip.group([shapes.button], "flyout-group");
strip.finish();

// MARK: documents

interface Doc extends TabDocument { name: string; dirty: boolean; path: string | null }
const documents: Doc[] = params.get("docs") === "0" ? [] : [
  { name: "Untitled 1", dirty: false, path: null }, { name: "lorenz-attractor.nfg", dirty: true, path: "/Users/me/Documents/lorenz-attractor.nfg" },
  { name: "a report with a very long name that is cut off.lfg", dirty: false, path: "/Users/me/a report with a very long name that is cut off.lfg" }, { name: "notes.txt", dirty: false, path: "/notes.txt" },
];
let active: Doc | null = documents[1] ?? null;
const tabs = new DocumentTabs<Doc>($("doc-tabs"), {
  newTitle: `New document (${shortcutText("CmdOrCtrl+N")})`, closeTitle: `Close document (${shortcutText("CmdOrCtrl+W")})`,
  onNew: () => { documents.push({ name: `Untitled ${documents.length + 1}`, dirty: false, path: null }); renderDocuments(); },
  onActivate: (document) => { active = document; renderDocuments(); },
  onClose: (document) => { documents.splice(documents.indexOf(document), 1); if (active === document) active = documents[0] ?? null; renderDocuments(); },
  onReorder: (from, to) => { const [moved] = documents.splice(from, 1); documents.splice(to > from ? to - 1 : to, 0, moved); renderDocuments(); },
});
const empty = createEmptyState($("center"), { title: "No document open", newLabel: "New document", openLabel: "Open…", detail: "Create or open a .gfg document",
  newShortcut: shortcutText("CmdOrCtrl+N"), openShortcut: shortcutText("CmdOrCtrl+O"), onNew: () => {}, onOpen: () => {} });
function renderDocuments(): void {
  tabs.render(documents, active);
  empty.hidden = documents.length > 0;
  document.body.classList.toggle("no-docs", documents.length === 0);
}
(window as unknown as { gallery: unknown }).gallery = { documents, tabs, renderDocuments, log: () => log };

// MARK: centre: a view header, an editor with its find bar, and an outline, side by side

const work = $("work");
work.append(createViewHeader({ title: "main.tex", dirty: true, actions: [{ icon: UI_ICONS.export, label: "Export", run() {} }, { icon: UI_ICONS.close, label: "Close", run() {} }] }));
const split = Object.assign(document.createElement("div"), { className: "gallery-split" });
const editorHost = Object.assign(document.createElement("div"), { className: "gallery-editor" });
const outline = document.createElement("div");
split.append(editorHost, outline);
work.append(split);
createSplitter(split, editorHost, outline, { axis: "x", share: 0.7 });
const bar = createFindBar("the document");
let editor: ReturnType<typeof createCodeEditor>;
const find = new FindController(() => editor, bar);
editor = createCodeEditor({ parent: editorHost, extensions: find.extensions(), doc: [
  "% A report", "\\documentclass[preset=default, language=greek]{report}", "\\begin{document}", "\\section{Introduction}",
  "The section explains the setup. A long line that wraps or scrolls sideways, depending on the editor's settings, to test the view.",
  "\\subsection{Method}", "\\section{Results}", "\\end{document}",
].join("\n") });
if (params.get("find") !== "0") { find.openFind(params.get("replace") === "1"); bar.find.value = "section"; bar.find.dispatchEvent(new Event("input")); }
renderOutline(outline, [{ title: "Introduction", level: 1, id: "a" }, { title: "Method", level: 2, id: "b" }, { title: "Results with a long heading that wraps", level: 1, id: "c" }], "b", () => {});
// `?canvas=1` shows the canvas editing page in place of the editor: regions, selection, handles and a crop.
if (params.get("canvas") === "1") { split.hidden = true; mountCanvasEditing(work); }
// Files dropped on the centre; `?drop=1` shows the drop target, as while files are dragged over it.
attachFileDrop(work, { accept: [".png", ".jpg", ".tif"], label: "Drop images to open them.", onFiles: (dropped) => log.add("info", `Opened ${dropped.map((f) => f.name).join(", ")}.`),
  onRefused: (message) => log.add("error", message) });
if (params.get("drop") === "1") {
  const transfer = new DataTransfer();
  transfer.items.add(new File([""], "cells.tif"));
  work.dispatchEvent(new DragEvent("dragenter", { dataTransfer: transfer, bubbles: true }));
}

// MARK: inspector

const open = new Set(["run", "buttons", "document", "fields", "measurements", "files", "pointer"]);
const sections = new InspectorSections({ root: $("inspector"), keys: ["run", "buttons", "document", "fields", "measurements", "files", "pointer", "closed"], isOpen: (key) => open.has(key), setOpen: (key, value) => { if (value) open.add(key); else open.delete(key); } });
// The standard top section: the main actions of the document, one button group across the width.
sections.create("Run", "run").append(createButtonGroup([createButton({ label: "Run", primary: true }), createButton({ label: "Step" }), createButton({ label: "Reset" })]));
// Every state of the two kinds of button: enabled, disabled and busy, ordinary and primary.
const busy = createButton({ label: "Building PDF…", primary: true });
setButtonBusy(busy, "Building PDF…");
sections.create("Button states", "buttons").append(
  createButtonGroup([createButton({ label: "Build PDF", primary: true }), createButton({ label: "Open PDF" })]),
  createButtonGroup([createButton({ label: "Build PDF", primary: true, disabled: true }), createButton({ label: "Open PDF", disabled: true })]),
  createButtonGroup([busy, createButton({ label: "Cancel" })]));
const documentSection = sections.create("Document", "document");
let documentName = "lorenz-attractor.nfg";
const nameRow = createRow("Name", documentName, document, { label: "Document name", current: () => documentName,
  apply: (name) => { documentName = name; nameRow.querySelector(".value")!.textContent = name; }, onError: (text) => log.add("error", text) });
documentSection.append(nameRow, createRow("Path", "/Users/me/Documents/a very long folder name/lorenz-attractor.nfg"), createGroupHeading("Grid"),
  createCheckRow("Snap to grid", true, () => {}), createChips([{ value: "s", label: "Small" }, { value: "m", label: "Medium" }, { value: "l", label: "Large" }], "m", () => {}));
const fields = sections.create("Fields and sliders", "fields");
const name = Object.assign(document.createElement("input"), { type: "text", value: "R1" });
const broken = Object.assign(document.createElement("input"), { type: "text", value: "12 kΩ x" });
const problem = document.createElement("div");
broken.classList.add("invalid");
setProblem(problem, "Type a number with a unit, such as 12 kΩ.");
fields.append(createField("Name", name), createField("A label that is long enough to wrap", broken), problem);
fields.append(createUnitField({ label: "Resistance", unit: "Ω", value: 1000, format: (value, unit) => `${value} ${unit}`, parse: Number.parseFloat, apply() {}, reportError() {}, invalidMessage: "Type a resistance." }).row);
fields.append(sliderRow("Speed", 40, 0, 100, () => {}).row);
fields.append(rangeSliderRow("Threshold", [64, 192], 0, 255, () => {}).row, rangeSliderRow("Hue", [300, 40], 0, 360, () => {}, { wrap: true, format: (v) => `${v}°` }).row);
// The colour picker with a target, its tolerance ring and three samples.
sections.create("Colour", "colour").append(createColourPicker({ value: "#3a7bd5", target: "#2f9e6a", tolerance: 0.12, samples: ["#c0392b", "#d35400", "#b03a2e"] }).element);
// Values are read-only rows; a row's tooltip gives the detail on hover.
const measurements = sections.create("Measurements", "measurements");
const measured = (label: string, value: string, tip: string) => { const row = createRow(label, value); setTip(row, tip); return row; };
measurements.append(measured("Mean", "1.25 V", "The mean of the trace over the last 10 ms."), measured("Peak", "3.30 V", "The largest value of the trace over the last 10 ms."), measured("Samples", "4096", "Values in the window, at 409.6 kHz."));
const files = sections.create("Files", "files");
const treeList = document.createElement("div");
files.append(treeList);
const treeFiles: TreeFile[] = [{ path: "main.tex", kind: "tex" }, { path: "figures", kind: "folder" }, { path: "figures/plot with a long name.png", kind: "image" }, { path: "data", kind: "folder" }, { path: "data/run.csv", kind: "data" }];
const selection: FileSelection = { path: "main.tex" };
renderFileTree(treeList, treeFiles, { enabled: true, showHidden: false, selection, collapsed: new Set(), label: "Files", dragType: "application/x-gallery",
  open() {}, reveal() {}, trash() {}, add() {}, drop() {}, rename() {}, warn() {}, problem() {}, rerender() {},
  status: (file) => file.path === "main.tex" ? "editable" : "readOnly" });
// The item under the pointer, as the apps show it: the name first, then its values; quiet text when there is none.
const pointer = createInfoLines("Hover or click a file.");
sections.create("File under pointer", "pointer").append(pointer.element);
treeList.addEventListener("pointerover", (event) => {
  const path = (event.target as HTMLElement).closest<HTMLElement>(".tree-row")?.dataset.path;
  const file = treeFiles.find((item) => item.path === path);
  pointer.show(file ? [file.path.split("/").pop()!, `Kind     ${file.kind}`, `Folder   ${file.path.includes("/") ? file.path.slice(0, file.path.lastIndexOf("/")) : "project"}`] : null);
});
treeList.addEventListener("pointerleave", () => pointer.show(null));
sections.create("Closed section", "closed");

// MARK: bottom panel and status bar

const log = new MessageLog();
log.add("info", "Saved lorenz-attractor.nfg.");
log.add("warning", "The simulation step is larger than the smallest time constant; results may be inaccurate.");
log.add("error", "Could not open data/run.csv: the file is not valid CSV on line 12.");
const clear = Object.assign(document.createElement("button"), { className: "tab-action messages-clear", textContent: "Clear" });
setTip(clear, "Clear the messages.");
const messages = new MessagesPanel($("messages-pane"), { subjectName: () => null, selectSubject: () => {} }, clear);
messages.setLog(log);
// Two generator panes, as an application adds them beside the Terminal: a plot drawn to an image, and a table.
const shares = { options: restoreShare(undefined, optionsShareLimits), code: restoreShare(undefined, codeShareLimits) };
const sampled = (values: GeneratorValues) => {
  const amplitude = Number(values.amplitude), frequency = Number(values.frequency);
  const shape = (x: number) => values.shape === "cos" ? Math.cos(x) : values.shape === "decay" ? Math.exp(-x / 4) * Math.sin(x) : Math.sin(x);
  return Array.from({ length: 41 }, (_, i) => { const x = i / 4; return [x, amplitude * shape(frequency * x)] as const; });
};
const checkNumbers = (values: GeneratorValues) => {
  for (const key of ["amplitude", "frequency"]) if (!Number.isFinite(Number(values[key])) || values[key] === "") throw new Error(`${key[0].toUpperCase() + key.slice(1)} takes a number, such as 2.`);
};
/** The plot drawn to a canvas, as an application's own renderer would, and handed over as an image. */
function drawPlot(values: GeneratorValues): string {
  const canvas = Object.assign(document.createElement("canvas"), { width: 640, height: 400 });
  const ctx = canvas.getContext("2d")!;
  const style = getComputedStyle(document.body);
  ctx.fillStyle = style.getPropertyValue("--panel"); ctx.fillRect(0, 0, 640, 400);
  const points = sampled(values), top = Math.max(1, ...points.map(([, y]) => Math.abs(y)));
  const px = (x: number) => 60 + (x / 10) * 550, py = (y: number) => 200 - (y / top) * 160;
  ctx.strokeStyle = style.getPropertyValue("--hairline");
  if (values.grid) for (let i = 0; i <= 10; i++) { ctx.beginPath(); ctx.moveTo(px(i), 40); ctx.lineTo(px(i), 360); ctx.stroke(); }
  ctx.strokeStyle = style.getPropertyValue("--text3"); ctx.strokeRect(60, 40, 550, 320);
  ctx.strokeStyle = style.getPropertyValue("--accent-light"); ctx.lineWidth = 2; ctx.beginPath();
  points.forEach(([x, y], i) => (i ? ctx.lineTo(px(x), py(y)) : ctx.moveTo(px(x), py(y)))); ctx.stroke();
  ctx.fillStyle = style.getPropertyValue("--text2"); ctx.font = "13px system-ui";
  ctx.fillText(String(values.xlabel || ""), 300, 388); ctx.save(); ctx.translate(20, 220); ctx.rotate(-Math.PI / 2); ctx.fillText(String(values.ylabel || ""), 0, 0); ctx.restore();
  return canvas.toDataURL("image/png");
}
const paneHost = (noun: "plot" | "table"): GeneratorPaneHost => ({
  noun, fit: noun === "plot" ? "contain" : "width",
  defaults: () => ({ source: "function", shape: "sin", amplitude: "1", frequency: "1", xlabel: "Time (s)", ylabel: "Voltage (V)", grid: true, header: true }),
  form: (values) => [
    { title: "Data", fields: [
      { kind: "select", key: "source", label: "Source", tip: "The data: a function typed here, or a spreadsheet beside the document.", choices: [["function", "Function"], ["---", ""], ["", "No spreadsheets"]] },
      ...(values.source === "function" ? [{ kind: "select" as const, key: "shape", label: "Function", tip: "The function of x to draw.", choices: [["sin", "Sine"], ["cos", "Cosine"], ["decay", "Damped sine"]] as [string, string][] }] : []),
    ] },
    { title: "Shape", fields: [
      { kind: "text", key: "amplitude", label: "Amplitude", tip: "The height of the curve, such as 2.", placeholder: "1" },
      { kind: "text", key: "frequency", label: "Frequency", tip: "Cycles per unit of x, such as 0.5.", placeholder: "1" },
    ] },
    noun === "plot"
      ? { title: "Format", fields: [
        { kind: "text", key: "xlabel", label: "X label", tip: "The x axis label, with its unit, such as Time (s).", placeholder: "None" },
        { kind: "text", key: "ylabel", label: "Y label", tip: "The y axis label, with its unit, such as Voltage (V).", placeholder: "None" },
        { kind: "check", key: "grid", label: "Grid", tip: "Lines at the major ticks." },
      ] }
      : { title: "Format", fields: [{ kind: "check", key: "header", label: "Header row", tip: "The first row names the columns." }] },
  ],
  idle: (values) => (values.source ? null : "No spreadsheets. Save the document beside one, or choose a function."),
  code: (values) => {
    checkNumbers(values);
    const call = { sin: "np.sin", cos: "np.cos", decay: "np.exp(-x / 4) * np.sin" }[String(values.shape)] ?? "np.sin";
    const body = `x = np.linspace(0, 10, 41)\ny = ${values.amplitude} * ${call}(${values.frequency} * x)\n`;
    return noun === "plot"
      ? `import numpy as np\nimport matplotlib.pyplot as plt\n\n${body}plt.plot(x, y)\nplt.xlabel(${JSON.stringify(values.xlabel)})\nplt.ylabel(${JSON.stringify(values.ylabel)})\nplt.grid(${values.grid ? "True" : "False"})\n`
      : `import numpy as np\n\n${body}table = np.column_stack([x, y])\n`;
  },
  build: async (_code, values) => {
    await new Promise((resolve) => setTimeout(resolve, 150));
    if (noun === "plot") return { preview: { kind: "image", src: drawPlot(values), alt: "Plot preview" }, error: null };
    return { preview: { kind: "table", headers: values.header ? ["x", "y"] : [], rows: sampled(values).map(([x, y]) => [x.toFixed(2), y.toFixed(4)]) }, error: null };
  },
  save: () => log.add("info", `Saved ${noun}s/${noun}-1.py.`),
  saveTip: `Save this code as a new file in ${noun}s/.`,
  problem: (text) => log.add("error", text),
  optionsShare: () => shares.options, saveOptionsShare: (share) => { shares.options = share; },
  codeShare: () => shares.code, saveCodeShare: (share) => { shares.code = share; },
});
const panes = (["plot", "table"] as const).map((noun) => {
  const element = Object.assign(document.createElement("div"), { id: `${noun}s-pane`, className: "pane", hidden: true });
  $("messages-pane").before(element);
  return new GeneratorPane(element, paneHost(noun));
});
for (const pane of panes) pane.showDocument("lorenz-attractor.nfg");
const selectBottom = createBottomTabs<"terminal" | "plots" | "tables" | "messages">($("bottom-tabs"), [
  { name: "terminal", element: $("terminal-pane"), onSelect: () => terminal.show() },
  { name: "plots", element: $("plots-pane"), onSelect: () => panes[0].applyLayout() },
  { name: "tables", element: $("tables-pane"), onSelect: () => panes[1].applyLayout() },
  { name: "messages", element: $("messages-pane"), onSelect: () => messages.refresh(true) },
]);
$("bottom-tabs").append(clear);
const terminalPreferences = createTerminalPreferences();
// One Terminal text size for the panel, `terminal font`, Cmd+= and Cmd+- and the Settings row, as in an application.
let terminalSize = 12;
const terminalSizeListeners = new Set<() => void>();
const terminalFont = {
  fontSize: () => terminalSize,
  setFontSize: (size: number) => { terminalSize = Math.min(24, Math.max(10, Math.round(size))); terminalSizeListeners.forEach((listener) => listener()); },
  onFontSizeChange: (listener: () => void) => { terminalSizeListeners.add(listener); },
  subscribe: (listener: () => void) => { terminalSizeListeners.add(listener); return () => { terminalSizeListeners.delete(listener); }; },
};
const terminal = new TerminalPanel($("terminal-pane"), __APP_LOGO__, __FORGE_VERSION__, {
  execute: async (line) => {
    const [verb, ...args] = line.trim().split(/\s+/);
    const pane = panes.find((item) => item.noun === verb);
    if (pane) return runGeneratorCommand(pane, args, () => selectBottom(`${pane.noun}s` as "plots"));
    if (verb === "health") return healthCommand(args.join(" "), healthTracker);
    if (verb === "settings") { showSettings({ pages: settingsPages(), page: args[0] }); return {}; }
    if (verb === "new") { run("new"); return { lines: ["Created a new document."] }; }
    if (verb === "open") { run("open"); return { lines: ["Open… (no file picker in the gallery)."] }; }
    if (verb === "save") { run("save"); return { lines: [active ? `Saved ${active.name}.` : "No document open."] }; }
    if (verb === "close") { run("close"); return { lines: ["Closed the document."] }; }
    if (verb === "run") { run("run"); return { lines: ["Running…"] }; }
    if (verb === "step") { run("step"); return { lines: ["Stepped one unit."] }; }
    if (verb === "inspector") { run("inspector"); return { lines: [`Inspector ${layout.showInspector ? "shown" : "hidden"}.`] }; }
    if (verb === "panel") { run("panel"); return { lines: [`Bottom panel ${layout.showBottomPanel ? "shown" : "hidden"}.`] }; }
    return { lines: ["help <command> for details. <value> required; [value] optional."], groups: [{ title: "File", items: [{ label: "new", comment: "Create a new document" }, { label: "open", comment: "Open a document" }, { label: "save", comment: "Save the document" }, { label: "close", comment: "Close the document" }] }, { title: "Generators", items: [{ label: "plot", comment: "Open the Plots pane, or set one of its options" }, { label: "table", comment: "Open the Tables pane, or set one of its options" }] }, { title: "Shell", items: [{ label: "inspector", comment: "Toggle the inspector" }, { label: "panel", comment: "Toggle the bottom panel" }, { label: "terminal", comment: "Show or set a Terminal preference" }, { label: "health", comment: "Health tracker commands" }, { label: "settings", comment: "Open Settings" }] }] };
  },
  complete: (line) => {
    const [verb, ...rest] = line.split(" ");
    const pane = panes.find((item) => item.noun === verb);
    if (verb === "health") return ["health reminder off", "health reminder 2", "health reminder 3", "health reminder 4", "health reminder 5", "health reminder 6"].filter((word) => word.startsWith(line));
    return pane && rest.length ? generatorCompletions(pane, rest.join(" ")).map((word) => [verb, ...rest.slice(0, -1), word].join(" ")) : ["health", "new", "open", "save", "close", "run", "step", "inspector", "panel", "terminal", "plot", "table", "settings"].filter((word) => word.startsWith(line));
  },
}, { appName: "Gallery", tagline: "component page", historyStorageKey: "gallery.history", fontSize: terminalFont.fontSize, setFontSize: terminalFont.setFontSize, onFontSizeChange: terminalFont.onFontSizeChange, preferences: terminalPreferences });
selectBottom((["messages", "plots", "tables"] as const).find((name) => params.get("pane") === name) ?? "terminal");
if (params.get("pane") !== "messages") void terminal.run("help");
new StatusBar($("statusbar"), () => selectBottom("messages")).render({ stateLabel: "Running", stateColor: "var(--accent-light)", summary: "1.25 s",
  detail: "Simulating lorenz-attractor.nfg with a step of 5 µs and three scopes", hint: null, unseenProblems: 2, problemKind: "error", readouts: ["Grid 16", "44 %"] });
renderDocuments();
applyPanelLayout = createPanelLayout({ center: $("center"), inspector: $("inspector"), inspectorSplit: $("inspector-split"), bottom: $("bottom"), bottomSplit: $("bottom-split"),
  settings: layout, defaults: { inspectorWidth: 246, bottomPanelHeight: 246 }, save: (change) => Object.assign(layout, change) });
installScrollbars();

// MARK: dialogs and menus on request (?show=)

const show = params.get("show");
if (show === "choice") void askReplace(["lens.png", "lens-2.png", "chart.png"]);
if (show === "about") run("about");
if (show === "shortcuts") run("about.shortcuts");
if (show === "licenses") run("about.licenses");
if (show === "whatsNew") run("about.whatsNew");
// A stand-in release and download, so that update and current states can be inspected in the browser: use
// `?updates=current` to make the stand-in match the installed version; otherwise the download takes 3 s, then fails
// (`?install=fail`) or restarts.
const releaseVersion = params.get("updates") === "current" ? info.version : "9.0.0";
const release = { tag_name: `v${releaseVersion}`, html_url: `https://github.com/owner/gallery/releases/tag/v${releaseVersion}`, name: releaseVersion,
  assets: [{ name: `Gallery-v${releaseVersion}.dmg`, browser_download_url: `https://github.com/owner/gallery/releases/download/v${releaseVersion}/Gallery-v${releaseVersion}.dmg`, size: 48_000_000 }] };
let progressListener: ((progress: { done: number; total: number }) => void) | null = null;
const standInUpdates = {
  platform: "darwin", storageKey: "gallery.updates",
  request: (async () => new Response(JSON.stringify(release))) as unknown as typeof fetch,
  onProgress: (listener: (progress: { done: number; total: number }) => void) => { progressListener = listener; },
  install: async (): Promise<InstallResult> => {
    const total = 48_000_000;
    for (let step = 1; step <= 30; step++) { await new Promise((resolve) => setTimeout(resolve, 100)); progressListener?.({ done: (total * step) / 30, total }); }
    return params.get("install") === "fail" ? { status: "failed", reason: "The download did not match the release." } : { status: "restarting" };
  },
};
if (show === "updates") {
  // The welcome screen, with the update card at its top.
  documents.splice(0, documents.length);
  renderDocuments();
  void showUpdateNotice(document.getElementById("empty-state")!, info, "owner/gallery", standInUpdates);
}
// Settings: the shell's pages and two of an application's own.
const preferences = { ...layout, appearance: galleryAppearance as "dark" | "light" | "pride", autosave: galleryAutosave };
const gallerySettings = { symbolStyle: "iec", temperatureUnit: "C", showCurrent: true, showValues: false, exportFormat: "png", overwrite: "ask", includeOverlays: true };
const appearance = (value: string) => { galleryAppearance = value === "light" ? "light" : "dark"; document.body.dataset.theme = galleryAppearance; };
function settingsPages() {
  return [
  generalPage({
    settings: preferences,
    update: (change) => {
      Object.assign(preferences, change);
      // The layout rows act on the page itself, as they do in an application.
      if (change.showInspector !== undefined) layout.showInspector = change.showInspector;
      if (change.inspectorSide) { layout.inspectorSide = change.inspectorSide; document.body.dataset.inspectorSide = change.inspectorSide; }
      if (change.showBottomPanel !== undefined) layout.showBottomPanel = change.showBottomPanel;
      if (change.appearance) appearance(change.appearance);
      applyPanelLayout();
    },
  }),
  { id: "display", title: "Display", icon: UI_ICONS.show, sections: [{ rows: [
    { kind: "select" as const, label: "Symbol style", choices: [["us", "US"], ["iec", "IEC"]] as const, value: () => gallerySettings.symbolStyle, set: (value) => { gallerySettings.symbolStyle = value; }, command: (value: string) => `display symbols ${value}` },
    { kind: "select" as const, label: "Temperature unit", choices: [["C", "°C"], ["F", "°F"], ["K", "K"]] as const, value: () => gallerySettings.temperatureUnit, set: (value) => { gallerySettings.temperatureUnit = value; }, command: (value: string) => `display temperature ${value}` },
    { kind: "check" as const, label: "Show current", value: () => gallerySettings.showCurrent, set: (value) => { gallerySettings.showCurrent = value; }, command: (value: boolean) => `display current ${value ? "on" : "off"}` },
    { kind: "check" as const, label: "Show values", value: () => gallerySettings.showValues, set: (value) => { gallerySettings.showValues = value; }, command: (value: boolean) => `display values ${value ? "on" : "off"}` },
  ] }] },
  { id: "export", title: "Export", icon: UI_ICONS.export, sections: [{ rows: [
    { kind: "select" as const, label: "Format", choices: [["png", "PNG"], ["jpeg", "JPEG"]] as const, value: () => gallerySettings.exportFormat, set: (value) => { gallerySettings.exportFormat = value; }, command: (value: string) => `export format ${value}` },
    { kind: "select" as const, label: "If the file exists", choices: OVERWRITE_CHOICES.map((choice) => [choice, OVERWRITE_LABELS[choice]] as const), value: () => gallerySettings.overwrite, set: (value) => { gallerySettings.overwrite = value; }, command: (value: string) => `export overwrite ${value}` },
    { kind: "check" as const, label: "Include overlays", value: () => gallerySettings.includeOverlays, set: (value) => { gallerySettings.includeOverlays = value; }, command: (value: boolean) => `export overlays ${value ? "on" : "off"}` },
  ] }] },
  terminalPage({ fontSize: terminalFont.fontSize, setFontSize: terminalFont.setFontSize, subscribe: terminalFont.subscribe, preferences: terminalPreferences }),
  healthPage(healthTracker),
  updatesPage({ info, repository: "owner/gallery", ...standInUpdates }),
  ];
}
if (show === "settings") showSettings({ pages: settingsPages(), page: params.get("page") ?? undefined });
// The gallery has no window to close: the break only says what an application would do.
if (show === "health-break") showHealthBreakReminder(4, undefined, () => void terminal.run("help"));
if (show === "save") void askToSave("lorenz-attractor.nfg");
if (show === "saveAll") void askToSaveAll(documents.filter((item) => item.dirty).concat(documents.slice(0, 2)), "documents");
if (show === "apply") void askToApply("Apply the recommended settings?", ["The step is too large."], [["Step", "50 µs", "5 µs"], ["Tolerance with a long name", "0.001", "0.0001"]]);
if (show === "pick") void askToPick({ title: "Choose files to restore", columns: ["Document", "Last change", "File"], rows: [{ id: "a", cells: ["notes.txt", "today 14:05", "/a/notes.txt"] }, { id: "b", cells: ["a very long document name.lfg", "yesterday 09:12", "/Users/me/Documents/a very long folder name/a very long document name.lfg"] }], multiple: true, ticked: ["a"], action: "Restore", placeholder: "Search" });
if (show === "context") showContextMenu(300, 200, [{ label: "Open", action() {} }, { label: "Rename…", key: "Return", action() {} }, { separator: true, label: "" }, { label: "Delete", action() {} }]);
if (show === "flyout") shapes.button.click();
if (show === "menu") (document.querySelector("#menubar .menu-title, #menubar [role=menuitem]") as HTMLElement | null)?.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));

// MARK: measured checks (galleryChecks() in the console)

/** The problems the page can measure: content cut off or spilling out, and parts that should be centred but are not. */
function galleryChecks(): string[] {
  const problems: string[] = [];
  const name = (element: Element) => `${element.tagName.toLowerCase()}${element.id ? `#${element.id}` : ""}${element.className && typeof element.className === "string" ? `.${element.className.trim().split(/\s+/).join(".")}` : ""}`;
  // Elements that must never spill sideways: frame rows, buttons, menu items, inspector rows and dialog parts.
  for (const element of document.querySelectorAll<HTMLElement>("#toolstrip, #doc-tabs, #statusbar, #bottom-tabs, #menubar, .panel-button, .menu-item, #inspector .row, #inspector label, .about .body, .find-tile, .find-row, .view-header, #empty-state")) {
    if (!element.offsetParent && getComputedStyle(element).position !== "fixed") continue;
    const style = getComputedStyle(element);
    const scrolls = /auto|scroll/.test(style.overflowX);
    if (!scrolls && element.scrollWidth > element.clientWidth + 1 && style.textOverflow !== "ellipsis") problems.push(`${name(element)} spills ${element.scrollWidth - element.clientWidth} px sideways.`);
    const box = element.getBoundingClientRect();
    if (box.right > innerWidth + 1) problems.push(`${name(element)} reaches ${Math.round(box.right - innerWidth)} px past the window.`);
  }
  // Parts wider than the pane that holds them, which a clipping ancestor would cut off.
  for (const element of document.querySelectorAll<HTMLElement>(".cm-editor, .find-tile, #empty-state, .view-header, .outline-list, .tree-row, .messages-list, .console-output")) {
    if (!element.offsetParent) continue;
    const box = element.getBoundingClientRect();
    for (let parent = element.parentElement; parent && parent !== document.body; parent = parent.parentElement) {
      if (getComputedStyle(parent).overflowX === "visible") continue;
      const frame = parent.getBoundingClientRect();
      if (box.right > frame.right + 1 || box.left < frame.left - 1) problems.push(`${name(element)} is cut off by ${name(parent)} (${Math.round(Math.max(box.right - frame.right, frame.left - box.left))} px).`);
      break;
    }
  }
  // Text inputs too narrow to show a word.
  for (const input of document.querySelectorAll<HTMLInputElement>("input[type=text], input:not([type])")) {
    if (input.offsetParent && input.clientWidth < 100) problems.push(`${name(input)} is ${input.clientWidth} px wide.`);
  }
  // Centred parts: the welcome screen's contents and every open dialog.
  const centred = (element: Element | null, within: DOMRect, label: string) => {
    if (!element || !(element as HTMLElement).offsetParent && getComputedStyle(element).position !== "fixed") return;
    const box = element.getBoundingClientRect();
    const dx = Math.abs(box.left + box.width / 2 - (within.left + within.width / 2));
    if (dx > 2) problems.push(`${label} is ${Math.round(dx)} px off centre.`);
  };
  const emptyState = document.getElementById("empty-state");
  if (emptyState && !emptyState.hidden) for (const part of emptyState.children) centred(part, emptyState.getBoundingClientRect(), `#empty-state .${(part as HTMLElement).className}`);
  for (const dialog of document.querySelectorAll(".modal-backdrop > *")) centred(dialog, new DOMRect(0, 0, innerWidth, innerHeight), name(dialog));
  const drop = document.querySelector<HTMLElement>(".file-drop:not([hidden])");
  if (drop) centred(drop.firstElementChild, drop.getBoundingClientRect(), ".file-drop-label");
  // Icons inside buttons centred in their button.
  for (const icon of document.querySelectorAll<SVGElement>(".tool svg, .find-icon svg, .new-tab svg, .doc-tab .close svg")) {
    const button = icon.closest("button");
    if (!button || !button.offsetParent) continue;
    const a = icon.getBoundingClientRect(), b = button.getBoundingClientRect();
    const dx = Math.abs(a.left + a.width / 2 - (b.left + b.width / 2)), dy = Math.abs(a.top + a.height / 2 - (b.top + b.height / 2));
    if (dx > 1 || dy > 1) problems.push(`${name(button)} icon is ${dx.toFixed(1)}, ${dy.toFixed(1)} px off centre.`);
  }
  return problems;
}
(window as unknown as { galleryChecks: typeof galleryChecks }).galleryChecks = galleryChecks;
