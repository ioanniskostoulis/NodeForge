// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** One line of selected text: its horizontal extent and the vertical band it fills. */
export interface LineRect { left: number; right: number; top: number; bottom: number }
type Point = [number, number];

/** Merge the client rectangles of a selection into one band per line: rectangles that share a line become one. */
export function bandsFromRects(rects: readonly LineRect[]): LineRect[] {
  const sorted = rects.filter((rect) => rect.right - rect.left > 0.5 && rect.bottom - rect.top > 0.5).map((rect) => ({ ...rect })).sort((a, b) => a.top - b.top || a.left - b.left);
  const lines: LineRect[] = [];
  for (const rect of sorted) {
    const line = lines[lines.length - 1];
    const overlap = line ? Math.min(line.bottom, rect.bottom) - Math.max(line.top, rect.top) : 0;
    if (line && overlap > Math.min(line.bottom - line.top, rect.bottom - rect.top) / 2) {
      line.left = Math.min(line.left, rect.left); line.right = Math.max(line.right, rect.right);
      line.top = Math.min(line.top, rect.top); line.bottom = Math.max(line.bottom, rect.bottom);
    } else lines.push(rect);
  }
  return lines;
}

/** Stack neighbouring bands so each line's bottom meets the next line's top; the gap is split evenly. */
export function joinBands(rects: LineRect[]): LineRect[] {
  const out = rects.map((rect) => ({ ...rect }));
  for (let index = 0; index + 1 < out.length; index++) {
    const seam = (out[index].bottom + out[index + 1].top) / 2;
    out[index].bottom = seam; out[index + 1].top = seam;
  }
  return out;
}

/** Consecutive lines whose text overlaps horizontally form one shape; a line that does not touch the one above starts another. */
export function groupRects(rects: LineRect[]): LineRect[][] {
  const groups: LineRect[][] = [];
  for (const rect of rects) {
    const group = groups[groups.length - 1];
    const previous = group?.[group.length - 1];
    if (previous && Math.min(previous.right, rect.right) - Math.max(previous.left, rect.left) > 0.5) group.push(rect);
    else groups.push([rect]);
  }
  return groups;
}

/** The outline of stacked lines, clockwise from the top left, without repeated or collinear points. */
export function outline(group: LineRect[]): Point[] {
  const raw: Point[] = [[group[0].left, group[0].top]];
  for (const rect of group) raw.push([rect.right, rect.top], [rect.right, rect.bottom]);
  for (let index = group.length - 1; index >= 0; index--) raw.push([group[index].left, group[index].bottom], [group[index].left, group[index].top]);
  const points = raw.filter((point, index) => index === 0 || point[0] !== raw[index - 1][0] || point[1] !== raw[index - 1][1]);
  if (points.length > 1 && points[0][0] === points[points.length - 1][0] && points[0][1] === points[points.length - 1][1]) points.pop();
  return points.filter((point, index) => {
    const before = points[(index + points.length - 1) % points.length], after = points[(index + 1) % points.length];
    return !((before[0] === point[0] && point[0] === after[0]) || (before[1] === point[1] && point[1] === after[1]));
  });
}

/** An SVG path that rounds every corner of the lines' outline, the inner corners between lines of different length too. */
export function roundedPath(rects: LineRect[], radius: number): string {
  let path = "";
  for (const group of groupRects(rects)) {
    const points = outline(group);
    const corners = points.map((point, index) => {
      const before = points[(index + points.length - 1) % points.length], after = points[(index + 1) % points.length];
      const toBefore = Math.hypot(before[0] - point[0], before[1] - point[1]), toAfter = Math.hypot(after[0] - point[0], after[1] - point[1]);
      const reach = Math.min(radius, toBefore / 2, toAfter / 2);
      return { point, start: [point[0] + (before[0] - point[0]) / toBefore * reach, point[1] + (before[1] - point[1]) / toBefore * reach] as Point,
        end: [point[0] + (after[0] - point[0]) / toAfter * reach, point[1] + (after[1] - point[1]) / toAfter * reach] as Point };
    });
    corners.forEach((corner, index) => {
      path += `${index === 0 ? "M" : "L"}${corner.start[0]} ${corner.start[1]}Q${corner.point[0]} ${corner.point[1]} ${corner.end[0]} ${corner.end[1]}`;
    });
    path += "Z";
  }
  return path;
}

/**
 * Draw the page's text selection inside `container` as one rounded shape in the `--selection` colour, instead of the
 * browser's square per-line boxes. The native highlight is made transparent in the container (`.selection-shape`).
 * Use it on any read-only or selectable text region, such as Terminal and Messages.
 */
export function attachSelectionShape(container: HTMLElement, radius = 4): () => void {
  container.classList.add("selection-shape");
  const svgNs = "http://www.w3.org/2000/svg";
  const layer = document.createElement("div");
  layer.className = "selection-shape-layer";
  layer.setAttribute("aria-hidden", "true");
  const svg = document.createElementNS(svgNs, "svg");
  const path = document.createElementNS(svgNs, "path");
  svg.append(path);
  layer.append(svg);
  container.prepend(layer);

  const draw = (): void => {
    const selection = document.getSelection();
    path.setAttribute("d", "");
    if (!selection || selection.isCollapsed || selection.rangeCount === 0 || !selection.containsNode(container, true)) return;
    const range = selection.getRangeAt(0);
    const origin = container.getBoundingClientRect();
    const rects: LineRect[] = [];
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      // Text that cannot be selected (user-select: none), such as the > before a Terminal command, is left out of the shape.
      if (!range.intersectsNode(node) || !node.textContent?.trim() || layer.contains(node)) continue;
      if (node.parentElement && getComputedStyle(node.parentElement).userSelect === "none") continue;
      const part = document.createRange();
      part.selectNodeContents(node);
      if (node === range.startContainer) part.setStart(node, range.startOffset);
      if (node === range.endContainer) part.setEnd(node, range.endOffset);
      for (const box of Array.from(part.getClientRects())) {
        rects.push({ left: box.left - origin.left + container.scrollLeft, right: box.right - origin.left + container.scrollLeft, top: box.top - origin.top + container.scrollTop, bottom: box.bottom - origin.top + container.scrollTop });
      }
    }
    const bands = joinBands(bandsFromRects(rects));
    if (!bands.length) return;
    svg.setAttribute("width", String(container.scrollWidth));
    svg.setAttribute("height", String(container.scrollHeight));
    path.setAttribute("d", roundedPath(bands, radius));
  };
  const listener = (): void => draw();
  document.addEventListener("selectionchange", listener);
  container.addEventListener("scroll", listener, { passive: true });
  // Output added below a selection, or a new text size, moves the lines: draw again.
  const resized = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(listener);
  resized?.observe(container);
  return () => { document.removeEventListener("selectionchange", listener); container.removeEventListener("scroll", listener); resized?.disconnect(); layer.remove(); container.classList.remove("selection-shape"); };
}
