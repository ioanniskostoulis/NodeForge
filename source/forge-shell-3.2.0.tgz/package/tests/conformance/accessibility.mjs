import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";

const read = (name) => readFileSync(new URL(`../../${name}`, import.meta.url), "utf8");

test("shared chrome exposes keyboard focus, live output and reduced motion", () => {
  const css = read("source/styles/shell.css");
  for (const selector of [".doc-tab:focus-visible", ".tab:focus-visible", ".menu-popup.context .menu-item:focus-visible"])
    assert.ok(css.includes(selector), `missing visible focus state for ${selector}`);
  assert.match(css, /@media\s*\(prefers-reduced-motion:\s*reduce\)/);
  assert.match(read("source/app/motion.ts"), /reducedMotion\(\)/);
  assert.match(read("source/app/panel-layout.ts"), /reducedMotion\.matches/);
  assert.match(read("source/app/terminal.ts"), /setAttribute\("aria-live", "polite"\)/);
  assert.match(read("source/app/status-bar.ts"), /setAttribute\("aria-live", "polite"\)/);
});

test("tool buttons, flyouts and search expose names, ARIA state and visible focus", () => {
  const css = read("source/styles/shell.css");
  assert.ok(css.includes(".tool:focus-visible"), "tool buttons need a visible focus ring");
  for (const state of [".tool:hover:not(:disabled)", ".tool:disabled", ".tool.selected", ".tool.selected:hover:not(:disabled)"]) assert.ok(css.includes(state), state);
  assert.match(read("source/app/tool-button.ts"), /setAttribute\("aria-label", options\.label\)/);
  const flyout = read("source/app/tool-flyout.ts");
  for (const attribute of ['"aria-haspopup", "menu"', '"aria-expanded"']) assert.ok(flyout.includes(attribute), attribute);
  assert.match(flyout, /key === "Escape"/);
  const search = read("source/app/tool-search.ts");
  for (const attribute of ['"role", "combobox"', '"aria-controls"', '"aria-expanded"', '"aria-label"']) assert.ok(search.includes(attribute), attribute);
});

test("rename field is named, marks invalid input and is styled like the shared fields", () => {
  const rename = read("source/app/rename.ts");
  for (const text of ['"aria-label"', '"aria-invalid"', 'key === "Escape"', 'key !== "F2"', '"dblclick"', '"contextmenu"']) assert.ok(rename.includes(text), text);
  const css = read("source/styles/shell.css");
  assert.match(css, /\.field input\[type=text\], \.field select, \.name-edit \{/);
  assert.match(css, /\.name-edit\.invalid/);
});

test("flyout items show shortcuts, stay in the window and can be set from outside", () => {
  const flyout = read("source/app/tool-flyout.ts");
  for (const text of ["displayKey(tool.shortcut)", "window.innerWidth", "window.innerHeight", "setTool(id: string)", "setSelected(selected: boolean)"]) assert.ok(flyout.includes(text), text);
});

