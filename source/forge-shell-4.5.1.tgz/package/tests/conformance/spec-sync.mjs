import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { contrastRatio } from "../../scripts/theme.mjs";

const read = (path) => readFileSync(new URL(`../../${path}`, import.meta.url), "utf8");
const tokens = read("source/styles/tokens.css");
const guide = ["GUIDELINES.md", "GUIDELINES-APPEARANCE.md", "GUIDELINES-SHELL.md", "GUIDELINES-TABS-MENUS.md", "GUIDELINES-TERMINAL.md", "GUIDELINES-PREVIEW.md", "GUIDELINES-CONTRACT.md"].map((name) => read(`documentation/${name}`)).join("\n");

const block = (selector) => {
  const start = tokens.indexOf(`${selector} {`);
  assert.ok(start >= 0, `missing ${selector}`);
  return Object.fromEntries([...tokens.slice(start, tokens.indexOf("}", start)).matchAll(/(--[\w-]+):\s*([^;]+);/g)].map((m) => [m[1], m[2].trim()]));
};
const dark = block(":root");
const light = { ...dark, ...block('body[data-theme="light"]') };
const pride = block('body[data-theme="pride"]');
const normal = (value) => value.replace(/\s+/g, "").toLowerCase();

/** Rows of the markdown table that follows `heading`, as arrays of cells with backticks removed. */
function table(heading) {
  const rest = guide.slice(guide.indexOf(heading));
  assert.ok(guide.includes(heading), `missing heading ${heading}`);
  const rows = [];
  for (const line of rest.split("\n").slice(1)) {
    if (line.startsWith("|")) rows.push(line.split("|").slice(1, -1).map((cell) => cell.trim().replace(/`/g, "")));
    else if (rows.length) break;
  }
  return rows.slice(2);
}

const neutrals = ["window", "panel", "raised", "control", "control-hover", "well", "separator", "hairline", "text", "text-strong", "text2", "text3", "warning", "error", "accent-foreground", "pick", "empty-sheet", "empty-grid-dot", "empty-grid-line"];

test("every shared colour token is defined for Dark and Light, and Pride defines the accents", () => {
  for (const name of neutrals) {
    assert.ok(dark[`--${name}`], `Dark --${name}`);
    assert.ok(block('body[data-theme="light"]')[`--${name}`] || name === "accent-foreground", `Light --${name}`);
  }
  for (const name of ["accent", "accent-light", "accent-about", "accent-fill", "accent-hover", "accent-foreground"]) assert.ok(pride[`--${name}`], `Pride --${name}`);
  for (const name of neutrals.filter((n) => n !== "accent-foreground")) assert.equal(pride[`--${name}`], undefined, `Pride must keep the Dark --${name}`);
});

test("GUIDELINES colour tables equal the CSS", () => {
  for (const [token, darkValue, lightValue] of table("### Shared neutral tokens")) {
    assert.equal(normal(darkValue), normal(dark[token]), `${token} Dark`);
    assert.equal(normal(lightValue), normal(light[token]), `${token} Light`);
  }
  const foreground = table("### Accent substitution only").find((row) => row[0] === "--accent-foreground");
  assert.equal(normal(foreground[1]), normal(dark["--accent-foreground"]));
});

test("GUIDELINES type, shape and motion table equals the CSS and lists every such token", () => {
  const rows = table("### Type, shape and motion tokens");
  for (const [token, value] of rows) assert.equal(normal(value), normal(dark[token]), token);
  const colour = new Set([...neutrals.map((n) => `--${n}`), ...Object.keys(dark).filter((token) => token.startsWith("--syntax-")), "--accent", "--accent-light", "--accent-about", "--accent-fill", "--accent-hover", "--ui", "--mono", "--console-size"]);
  const documented = new Set(rows.map((row) => row[0]));
  for (const token of Object.keys(dark)) if (!colour.has(token) && token !== "color-scheme") assert.ok(documented.has(token), `${token} is not in GUIDELINES.md`);
});

// Pairs that are below 4.5:1 today. The palette is fixed by the family model, so each is recorded with its
// measured floor: the test fails if a pair gets worse, and the list is the owner's to-do list for a palette decision.
const knownLow = {
  "Dark text2 on control": 4.1, "Dark text3 on window": 2.9, "Dark text3 on panel": 2.5, "Dark text3 on raised": 2.3,
  "Dark text3 on control": 1.9, "Dark text3 on well": 3.0, "Dark error on panel": 3.9, "Dark error on raised": 3.5, "Dark error on control": 3.0,
  "Light text3 on window": 4.1, "Light text3 on panel": 4.4, "Light text3 on raised": 4.0, "Light text3 on control": 3.5,
  "Light warning on window": 4.0, "Light warning on panel": 4.2, "Light warning on raised": 3.8, "Light warning on control": 3.4,
  "Light error on control": 4.1,
};

test("text meets contrast on every surface it is drawn on, apart from the recorded exceptions", () => {
  const surfaces = ["window", "panel", "raised", "control", "well"];
  for (const [mode, colours] of [["Dark", dark], ["Light", light]]) {
    for (const name of ["text", "text-strong", "text2", "text3", "warning", "error"]) {
      for (const surface of surfaces) {
        const key = `${mode} ${name === "text-strong" ? "text-strong" : name} on ${surface}`;
        const found = contrastRatio(colours[`--${name}`], colours[`--${surface}`]);
        assert.ok(found >= (knownLow[key] ? knownLow[key] - 0.05 : 4.5), `${key}: ${found.toFixed(2)}:1`);
        if (knownLow[key]) assert.ok(found < 4.5, `${key} now passes; remove it from knownLow`);
      }
    }
  }
  for (const [mode, colours] of [["Pride", { ...dark, ...pride }]]) {
    assert.ok(contrastRatio(colours["--accent-foreground"], colours["--accent-fill"]) >= 4.5, `${mode} label on accent fill`);
    assert.ok(contrastRatio(colours["--accent-foreground"], colours["--accent-hover"]) >= 4.5, `${mode} label on accent hover`);
    for (const name of ["accent", "accent-light", "accent-about"]) assert.ok(contrastRatio(colours[`--${name}`], colours["--well"]) >= 4.5, `${mode} --${name} on --well`);
  }
});

test("GUIDELINES syntax colours equal the CSS, and each has 4.5:1 contrast on the editor background", () => {
  const rows = table("### Syntax colours");
  assert.deepEqual(rows.map((row) => row[0]).sort(), Object.keys(dark).filter((token) => token.startsWith("--syntax-")).sort());
  for (const [token, darkValue, lightValue] of rows) {
    assert.equal(normal(darkValue), normal(dark[token]), `Dark ${token}`);
    assert.equal(normal(lightValue), normal(light[token]), `Light ${token}`);
    if (token !== "--syntax-comment") {
      assert.ok(contrastRatio(darkValue, dark["--well"]) >= 4.5, `Dark ${token} on --well`);
      assert.ok(contrastRatio(lightValue, light["--well"]) >= 4.5, `Light ${token} on --well`);
    }
  }
});

test("the welcome surface takes its sheet and grid from the theme tokens, not from colours of its own", () => {
  const shell = read("source/styles/shell.css");
  const rules = [...shell.matchAll(/#empty-state\s*\{([^}]*)\}/g)].map((m) => m[1]).join("\n");
  assert.doesNotMatch(rules, /--empty-[\w-]+\s*:/, "#empty-state defines no --empty-* token");
  assert.match(rules, /background-color: var\(--empty-sheet\)/);
  for (const [theme, values] of [["Dark", dark], ["Light", light]]) for (const name of ["--empty-sheet", "--empty-grid-dot", "--empty-grid-line"]) assert.ok(values[name], `${theme} ${name}`);
});

test("the welcome grid's geometry is the tokens', set once for every appearance, and the CSS has no length of its own", () => {
  const geometry = ["--empty-grid-origin", "--empty-grid-dot-step", "--empty-grid-line-step", "--empty-grid-dot-radius", "--empty-grid-line-width"];
  const px = (name) => Number(/^([\d.]+)px$/.exec(dark[name] ?? "")?.[1]);
  for (const name of geometry) {
    assert.ok(Number.isFinite(px(name)), `${name} is a length in px in :root`);
    for (const selector of ['body[data-theme="light"]', 'body[data-theme="pride"]']) assert.equal(block(selector)[name], undefined, `${selector} keeps ${name}`);
  }
  // The values the welcome grid had before they became tokens: dots 16 px from 32 px, lines 128 px from 40 px.
  assert.deepEqual(geometry.map(px), [40, 16, 128, 1.1, 1]);
  assert.equal(px("--empty-grid-origin") - px("--empty-grid-dot-step") / 2, 32, "the dot tile starts half a step before the origin");
  const shell = read("source/styles/shell.css");
  const rules = [...shell.matchAll(/#empty-state\s*\{([^}]*)\}/g)].map((m) => m[1]).join("\n");
  for (const property of ["background-size", "background-position", "background-image"]) {
    const value = new RegExp(`${property}:([^;]+);`).exec(rules)?.[1] ?? "";
    assert.ok(value, `#empty-state sets ${property}`);
    assert.doesNotMatch(value.replace(/\+ 0\.1px/g, ""), /\d+(\.\d+)?px/, `${property} takes its lengths from the tokens`);
  }
  for (const name of geometry) assert.match(rules, new RegExp(`var\\(${name}\\)`), `#empty-state uses ${name}`);
});
