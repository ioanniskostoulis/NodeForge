// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Rebuild and reload a Forge app preview as its project inputs change.
import { spawn } from "node:child_process";
import { readdir, stat } from "node:fs/promises";
import { join } from "node:path";

export async function startForgePreview({ productName, desktop = false, electronPath, startServer, buildScript = "scripts/build.mjs", watchPaths }) {
  let child;
  let app;
  let timer;
  let building = false;
  let pending = false;
  let stopping = false;
  let preview;
  let poll;
  let scanning = false;
  let previous;

  async function rebuild() {
    if (stopping) return;
    if (building) { pending = true; return; }
    building = true;
    do {
      pending = false;
      const ok = await new Promise((resolve) => {
        child = spawn(process.execPath, [buildScript], { stdio: "inherit" });
        child.once("error", (error) => { console.error(error); resolve(false); });
        child.once("exit", (code) => resolve(code === 0));
      });
      child = undefined;
      if (stopping) break;
      if (ok) {
        if (!preview) {
          preview = startServer({ liveReload: true });
          preview.server.on("error", (error) => { console.error(error.message); stop(1); });
          if (desktop) preview.server.once("listening", () => {
            app = spawn(electronPath, ["."], {
              stdio: "inherit",
              env: { ...process.env, FORGE_DEV_URL: `http://127.0.0.1:${preview.server.address().port}` },
            });
            app.once("error", (error) => { console.error(error); stop(1); });
            app.once("exit", () => { if (!stopping) stop(); });
          });
        } else {
          console.log(`${desktop ? "Desktop" : "Web"} preview updated.`);
          preview.reload();
        }
      } else console.error("Build failed; waiting for the next edit.");
    } while (pending && !stopping);
    building = false;
  }

  function changed() {
    clearTimeout(timer);
    timer = setTimeout(() => void rebuild(), 200);
  }

  function stop(code = 0) {
    stopping = true;
    clearTimeout(timer);
    clearInterval(poll);
    child?.kill();
    app?.kill();
    preview?.server.closeAllConnections();
    preview?.server.close();
    process.exit(code);
  }

  // Poll only project inputs to avoid macOS file-watcher limits on large asset collections.
  async function fingerprint() {
    const entries = [];
    async function visit(path) {
      const info = await stat(path);
      if (info.isDirectory()) {
        for (const name of (await readdir(path)).sort()) {
          if (name !== ".DS_Store")
            await visit(join(path, name));
        }
      } else entries.push(`${path}:${info.mtimeMs}:${info.size}`);
    }
    for (const path of watchPaths) await visit(path);
    return entries.join("\n");
  }
  previous = await fingerprint();
  poll = setInterval(async () => {
    if (scanning || stopping) return;
    scanning = true;
    try {
      const next = await fingerprint();
      if (next !== previous) { previous = next; changed(); }
    } catch { /* a file may be moved during an edit; retry on the next poll */ }
    finally { scanning = false; }
  }, 1000);
  process.once("SIGINT", () => stop());
  process.once("SIGTERM", () => stop());
  console.log(`Watching ${productName} source and static files; ${desktop ? "the desktop app refreshes" : "browsers refresh"} after successful builds.`);
  await rebuild();
}
