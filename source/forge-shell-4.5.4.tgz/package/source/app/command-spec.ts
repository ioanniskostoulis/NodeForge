// Licensed under the GNU General Public License v2 or later. See LICENSE.

export interface MenuCommandSpec {
  id: string;
  label: string;
  key?: string;
  /** A key shown beside the item that the app handles itself (Esc, ⌫). */
  hint?: string;
}

export interface CommandSpec {
  name: string;
  legacy?: boolean;
  syntax: string;
  description: string;
  args: RegExp;
  example?: string;
  choices?: string[];
  action?: string;
  menu?: MenuCommandSpec;
  subcommands?: { syntax: string; description: string }[];
}
