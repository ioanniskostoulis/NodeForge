import assert from "node:assert/strict";
import test from "node:test";
import { nextPatchVersion } from "../../scripts/version-hook.mjs";

test("patch bump leaves major and minor versions untouched", () => {
  assert.equal(nextPatchVersion("2.7.9"), "2.7.10");
  assert.equal(nextPatchVersion("0.1.99999999999999999999"), "0.1.100000000000000000000");
  assert.throws(() => nextPatchVersion("2.7"), /major.minor.patch/);
});
