// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { displayKey } from "./menus";
export interface MenuEntry {
  label: string;
  title?: string;
  action?: () => void;
  header?: boolean;
  separator?: boolean;
  key?: string;
  checked?: boolean;
  items?: MenuEntry[];
}

let dismissContextMenu: (() => void) | null = null;
let fieldPopoverSerial = 0;

/**
 * A small panel of typed values, opened at (x, y) or above `top` when
 * there's no room below. Enter applies: `apply` returns an error for the field it names (it stays
 * open, the field marked) or null (it closes). Esc or a click outside closes it.
 */
export function showFieldPopover(
  x: number, y: number, title: string, fields: { label: string; value: string }[],
  apply: (values: string[]) => { field: number; error: string } | null, top?: number,
): void {
  dismissContextMenu?.();
  const el = document.createElement("div");
  el.className = "menu-popup field-popover";
  el.append(Object.assign(document.createElement("div"), { className: "menu-item header", textContent: title }));
  const inputs = fields.map((f) => {
    const row = Object.assign(document.createElement("label"), { className: "field" });
    const input = Object.assign(document.createElement("input"), { type: "text", value: f.value, spellcheck: false });
    const error = Object.assign(document.createElement("span"), { className: "field-error" });
    error.id = `field-popover-error-${++fieldPopoverSerial}`;
    error.setAttribute("aria-live", "polite");
    input.setAttribute("aria-describedby", error.id);
    row.append(Object.assign(document.createElement("span"), { className: "label", textContent: f.label }), input, error);
    el.append(row);
    return input;
  });
  const close = () => {
    el.remove();
    document.removeEventListener("mousedown", outside);
    if (dismissContextMenu === close) dismissContextMenu = null;
  };
  const outside = (event: MouseEvent) => { if (!el.contains(event.target as Node)) close(); };
  el.addEventListener("keydown", (event) => {
    event.stopPropagation();
    if (event.key === "Escape") close();
    if (event.key !== "Enter") return;
    const problem = apply(inputs.map((i) => i.value));
    inputs.forEach((i, k) => {
      i.classList.toggle("invalid", problem?.field === k);
      i.setAttribute("aria-invalid", String(problem?.field === k));
      i.title = problem?.field === k ? problem.error : "";
      const error = i.parentElement?.querySelector<HTMLElement>(".field-error");
      if (error) error.textContent = problem?.field === k ? problem.error : "";
    });
    if (problem) inputs[problem.field]?.focus();
    if (!problem) close();
  });
  el.style.left = `${x}px`;
  el.style.top = `${y}px`;
  document.getElementById("overlay-root")!.append(el);
  const r = el.getBoundingClientRect();
  if (r.right > innerWidth) el.style.left = `${Math.max(4, innerWidth - r.width - 4)}px`;
  if (r.bottom > innerHeight) el.style.top = `${Math.max(4, top !== undefined ? top - r.height - 4 : innerHeight - r.height - 4)}px`;
  dismissContextMenu = close;
  setTimeout(() => { if (el.isConnected) document.addEventListener("mousedown", outside); });
  inputs[0]?.focus();
  inputs[0]?.select();
}

/**
 * A small context menu in the same style as the HTML menus. Given a function instead of a list,
 * it's a panel: choosing an item keeps it open and rebuilds it (Esc or a click outside closes it).
 */
export function showContextMenu(x: number, y: number, entries: MenuEntry[] | (() => MenuEntry[]), anchorTop?: number): void {
  const build = typeof entries === "function" ? entries : null;
  const items = build ? build() : entries as MenuEntry[];
  dismissContextMenu?.();
  const root = document.getElementById("overlay-root")!;
  const returnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const open: HTMLElement[] = [];
  const closeFrom = (level: number) => {
    for (const el of open.splice(level)) el.remove();
    if (level > 0) open[level - 1]?.querySelectorAll("[aria-expanded=true]").forEach((row) => row.setAttribute("aria-expanded", "false"));
  };
  const close = (restoreFocus = true) => {
    closeFrom(0);
    document.removeEventListener("mousedown", outside);
    document.removeEventListener("keydown", escape);
    if (dismissContextMenu === close) dismissContextMenu = null;
    if (restoreFocus && returnFocus?.isConnected) returnFocus.focus();
  };
  const outside = (event: MouseEvent) => {
    if (!open.some((el) => el.contains(event.target as Node))) close(false);
  };
  const escape = (event: KeyboardEvent) => { if (event.key === "Escape") { event.preventDefault(); close(); } };
  const popup = (entries: MenuEntry[], px: number, py: number, level: number, parent?: DOMRect) => {
    closeFrom(level);
    const el = document.createElement("div");
    el.className = "menu-popup context" + (entries.some((item) => "checked" in item) ? " has-checks" : "");
    el.setAttribute("role", "menu");
    el.style.left = `${px}px`;
    el.style.top = `${py}px`;
    for (const item of entries) {
      if (item.separator) {
        el.append(Object.assign(document.createElement("div"), { className: "menu-sep" }));
        continue;
      }
      const row = document.createElement("div");
      row.className = "menu-item" + (item.header ? " header" : !item.action && !item.items ? " disabled" : "");
      if (!item.header && (item.action || item.items)) {
        row.setAttribute("role", "menuitem");
        row.tabIndex = -1;
        if (item.items) row.setAttribute("aria-haspopup", "menu");
      }
      if (item.title) row.title = item.title;
      row.append(Object.assign(document.createElement("span"), { className: "check", textContent: item.checked ? "✓" : "" }));
      row.append(Object.assign(document.createElement("span"), { className: "label", textContent: item.label }));
      // An accelerator ("CmdOrCtrl+O") is shown with the platform glyphs, as in the menu bar.
      if (item.key) row.append(Object.assign(document.createElement("span"), { className: "key", textContent: displayKey(item.key) }));
      const showChild = () => {
        const r = row.getBoundingClientRect();
        popup(item.items!, r.right - 2, r.top - 4, level + 1, r);
        row.setAttribute("aria-expanded", "true");
      };
      if (item.items) row.append(Object.assign(document.createElement("span"), { className: "sub", textContent: "›" }));
      row.addEventListener("mouseenter", () => item.items ? showChild() : closeFrom(level + 1));
      if (item.items) row.addEventListener("click", showChild);
      else if (item.action) {
        row.addEventListener("click", () => {
          if (build && level === 0) {
            item.action!();
            popup(build(), x, y, 0);
            return;
          }
          close();
          item.action!();
        });
      }
      el.append(row);
    }
    el.addEventListener("keydown", (event) => {
      const rows = [...el.querySelectorAll<HTMLElement>(":scope > [role=menuitem]")];
      const index = rows.indexOf(document.activeElement as HTMLElement);
      const next = event.key === "ArrowDown" ? (index + 1) % rows.length
        : event.key === "ArrowUp" ? (index - 1 + rows.length) % rows.length
        : event.key === "Home" ? 0 : event.key === "End" ? rows.length - 1 : -1;
      if (next >= 0 && rows.length) { event.preventDefault(); event.stopPropagation(); rows[next].focus(); }
      else if (event.key === "ArrowRight") {
        const item = entries[[...el.children].indexOf(document.activeElement as Element)];
        if (item?.items) { event.preventDefault(); event.stopPropagation(); (document.activeElement as HTMLElement).click(); open[level + 1]?.querySelector<HTMLElement>("[role=menuitem]")?.focus(); }
      } else if (event.key === "ArrowLeft" && level > 0) {
        event.preventDefault();
        event.stopPropagation();
        const parent = open[level - 1]?.querySelector<HTMLElement>("[aria-expanded=true]");
        closeFrom(level);
        parent?.focus();
      } else if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        event.stopPropagation();
        (document.activeElement as HTMLElement).click();
      }
    });
    root.append(el);
    const r = el.getBoundingClientRect();
    if (r.right > innerWidth) el.style.left = `${Math.max(4, parent ? parent.left - r.width + 2 : innerWidth - r.width - 4)}px`;
    // under a control near the bottom of the window: above it instead
    if (r.bottom > innerHeight) el.style.top = `${Math.max(4, level === 0 && anchorTop !== undefined ? anchorTop - r.height - 4 : innerHeight - r.height - 4)}px`;
    open.push(el);
    if (level === 0) el.querySelector<HTMLElement>("[role=menuitem]")?.focus();
  };
  popup(items, x, y, 0);
  dismissContextMenu = close;
  document.addEventListener("mousedown", outside);
  document.addEventListener("keydown", escape);
}
