// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The interface's few animations (document tabs, folding inspector sections): short, ease-out,
// and none at all when the system asks for reduced motion.

export const MOTION_MS = 150;
export const MOTION_EASING = "cubic-bezier(0.2, 0, 0, 1)";

export function reducedMotion(): boolean {
  return typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
}

/** Run `keyframes` unless motion is reduced; resolve when the animation finishes. */
export function animate(element: HTMLElement, keyframes: Keyframe[], duration = MOTION_MS, fill: FillMode = "none"): Promise<void> {
  if (reducedMotion() || typeof element.animate !== "function") return Promise.resolve();
  const animation = element.animate(keyframes, { duration, easing: MOTION_EASING, fill });
  return animation.finished.then(() => undefined, () => undefined);
}
