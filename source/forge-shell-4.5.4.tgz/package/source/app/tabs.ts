// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { UI_ICONS } from "./tool-icons";
import { animate, MOTION_MS } from "./motion";
import { attachReorder } from "./reorder";

export interface TabDocument {
  readonly name: string;
  readonly title?: string | null;
  readonly path?: string | null;
  readonly dirty: boolean;
}

export interface DocumentTabsOptions<T extends TabDocument> {
  newTitle: string;
  closeTitle: string;
  onNew(): void;
  onActivate(document: T): void;
  onClose(document: T): void;
  /** Move the tab at `from` to before the tab at `to`; given, tabs can be dragged to rearrange them. */
  onReorder?(from: number, to: number): void;
}

/** Render document tabs, including their width animation and active accent. */
export class DocumentTabs<T extends TabDocument> {
  private readonly elements = new Map<T, HTMLElement>();
  private readonly accent = Object.assign(document.createElement("span"), { className: "doc-tab-accent" });
  private readonly newButton: HTMLButtonElement;
  private documents: readonly T[] = [];
  private active: T | null = null;
  private accentFollow = 0;
  private shown = false;

  constructor(private readonly bar: HTMLElement, private readonly options: DocumentTabsOptions<T>) {
    bar.setAttribute("role", "tablist");
    bar.setAttribute("aria-label", "Documents");
    this.accent.setAttribute("aria-hidden", "true");
    this.newButton = Object.assign(document.createElement("button"), { className: "new-tab", title: options.newTitle, innerHTML: UI_ICONS.add });
    this.newButton.addEventListener("click", () => options.onNew());
    bar.append(this.newButton, this.accent);
    new ResizeObserver(() => this.placeAccent(false)).observe(bar);
    if (options.onReorder) {
      attachReorder(bar, { axis: "x", items: () => this.documents.map((item) => this.elements.get(item)).filter((tab): tab is HTMLElement => !!tab), onMove: options.onReorder });
    }
  }

  /** Position the active line using the tab's fractional pixel geometry. */
  private placeAccent(glide: boolean): void {
    const active = this.active ? this.elements.get(this.active) : undefined;
    this.accent.hidden = !active || !this.documents.includes(this.active!);
    if (!active || this.accent.hidden) return;
    this.accent.classList.toggle("glide", glide && this.accent.classList.contains("ready"));
    const tabRect = active.getBoundingClientRect();
    const barRect = this.bar.getBoundingClientRect();
    const style = getComputedStyle(active);
    const leftBorder = parseFloat(style.borderLeftWidth) || 0;
    const rightBorder = parseFloat(style.borderRightWidth) || 0;
    this.accent.style.width = `${Math.max(0, tabRect.width - leftBorder - rightBorder)}px`;
    this.accent.style.transform = `translateX(${tabRect.left - barRect.left + this.bar.scrollLeft + leftBorder}px)`;
    if (!this.accent.classList.contains("ready")) requestAnimationFrame(() => this.accent.classList.add("ready"));
  }

  private followAccent(): void {
    const until = performance.now() + MOTION_MS + 40;
    cancelAnimationFrame(this.accentFollow);
    const step = () => {
      this.placeAccent(false);
      if (performance.now() < until) this.accentFollow = requestAnimationFrame(step);
    };
    step();
  }

  private makeTab(document: T): HTMLElement {
    const tab = window.document.createElement("div");
    tab.setAttribute("role", "tab");
    tab.addEventListener("keydown", (event) => {
      if (event.target !== tab) return;
      const index = this.documents.indexOf(document);
      const next = event.key === "ArrowRight" ? (index + 1) % this.documents.length
        : event.key === "ArrowLeft" ? (index - 1 + this.documents.length) % this.documents.length
        : event.key === "Home" ? 0 : event.key === "End" ? this.documents.length - 1 : -1;
      if (next >= 0 && this.documents.length) {
        event.preventDefault();
        const target = this.documents[next];
        this.options.onActivate(target);
        this.elements.get(target)?.focus();
      } else if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        this.options.onActivate(document);
      }
    });
    const close = Object.assign(window.document.createElement("button"), { className: "close", title: this.options.closeTitle, innerHTML: UI_ICONS.close });
    close.addEventListener("mousedown", (event) => { if (event.button === 0) event.stopPropagation(); });
    close.addEventListener("click", (event) => {
      event.stopPropagation();
      this.options.onClose(document);
    });
    tab.append(Object.assign(window.document.createElement("span"), { className: "mark" }), Object.assign(window.document.createElement("span"), { className: "name" }), close);
    tab.addEventListener("mousedown", (event) => {
      if (event.button === 1) {
        event.preventDefault();
        this.options.onClose(document);
      } else if (event.button === 0 && document !== this.active) this.options.onActivate(document);
    });
    return tab;
  }

  render(documents: readonly T[], active: T | null): void {
    const focusedTabWasRemoved = [...this.elements].some(([document, tab]) =>
      !documents.includes(document) && tab.contains(window.document.activeElement));
    this.documents = documents;
    this.active = active;
    let changedWidths = false;
    for (const [document, tab] of this.elements) {
      if (documents.includes(document)) continue;
      this.elements.delete(document);
      const width = tab.offsetWidth;
      tab.getAnimations().forEach((animation) => animation.cancel());
      tab.classList.remove("active");
      tab.classList.add("leaving", "anim");
      tab.style.width = `${width}px`;
      changedWidths = true;
      void animate(tab, [{ width: `${width}px`, opacity: 1 }, { width: "0px", paddingLeft: "0px", paddingRight: "0px", borderRightWidth: "0px", opacity: 0 }], MOTION_MS, "forwards")
        .then(() => tab.remove());
    }
    let before: Element = this.newButton;
    for (const document of [...documents].reverse()) {
      let tab = this.elements.get(document);
      const fresh = !tab;
      if (!tab) {
        tab = this.makeTab(document);
        this.elements.set(document, tab);
      }
      tab.classList.add("doc-tab");
      tab.classList.toggle("active", document === active);
      tab.setAttribute("aria-selected", String(document === active));
      tab.tabIndex = document === active ? 0 : -1;
      tab.classList.toggle("dirty", !!document.dirty);
      tab.title = document.path ?? document.title ?? document.name;
      tab.setAttribute("aria-label", document.name);
      const name = tab.querySelector(".name")!;
      if (name.textContent !== document.name) name.textContent = document.name;
      // A tab whose place changed (a drag, or the app reordering its documents) moves to it; tabs that are leaving do
      // not count, and a moved tab keeps the keyboard focus.
      if (!fresh && nextLiveTab(tab) !== before) {
        const focused = tab.contains(window.document.activeElement) ? window.document.activeElement as HTMLElement : null;
        this.bar.insertBefore(tab, before);
        focused?.focus({ preventScroll: true });
        changedWidths = true;
      }
      if (fresh) {
        this.bar.insertBefore(tab, before);
        if (this.shown) {
          changedWidths = true;
          const width = tab.offsetWidth;
          tab.classList.add("anim");
          tab.style.width = `${width}px`;
          void animate(tab, [{ width: "0px", paddingLeft: "0px", paddingRight: "0px", borderRightWidth: "0px", opacity: 0 }, { width: `${width}px`, opacity: 1 }])
            .then(() => {
              if (tab.classList.contains("leaving")) return;
              tab.classList.remove("anim");
              tab.style.removeProperty("width");
            });
        }
      }
      before = tab;
    }
    if (changedWidths) this.followAccent();
    else this.placeAccent(this.shown);
    if (focusedTabWasRemoved) (active ? this.elements.get(active) : this.newButton)?.focus();
    this.shown = true;
  }
}

/** The next sibling of a tab that is not leaving: another tab or the new-tab control. */
function nextLiveTab(tab: Element): Element | null {
  let next = tab.nextElementSibling;
  while (next?.classList.contains("leaving")) next = next.nextElementSibling;
  return next;
}
