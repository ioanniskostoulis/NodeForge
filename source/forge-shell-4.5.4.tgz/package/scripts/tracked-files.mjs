// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The files git tracks in the current repository. The source shipped with an application is its tracked files, so a
// file kept only on the developer's disk never ships, whatever folder it is in.
import { spawnSync } from "node:child_process";

/** The tracked paths, with forward slashes, or null outside a git repository (then every file counts). */
export function trackedFiles(cwd = process.cwd()) {
  const result = spawnSync("git", ["ls-files", "-z"], { cwd, encoding: "utf8" });
  if (result.status !== 0) return null;
  return new Set(result.stdout.split("\0").filter(Boolean));
}

/** Whether `path` (a file or a folder, relative to the repository) is tracked or holds a tracked file. */
export function isTracked(tracked, path) {
  if (!tracked) return true;
  const clean = path.replaceAll("\\", "/").replace(/^\.\//, "").replace(/\/$/, "");
  if (tracked.has(clean)) return true;
  for (const file of tracked) if (file.startsWith(`${clean}/`)) return true;
  return false;
}
