import assert from "node:assert/strict";
import { test } from "node:test";
import { closeDocumentTab, confirmWindowClose, documentWindowTitle, hasUnsavedWork, initialDocumentFiles, insertDocument, openDocumentFiles, removeDocument, untitledName } from "../../source/app/documents.js";

test("startup files take priority over an example and a missing example opens the welcome screen", async () => {
  const file = { path: "/tmp/a.nfg", text: "content" };
  let examplesLoaded = 0;
  const options = {
    desktopFiles: async () => [file], examplePath: "example.nfg",
    fromDesktopFile: (opened: typeof file) => opened.path,
    loadExample: async (path: string) => { examplesLoaded++; return path; },
  };
  assert.deepEqual(await initialDocumentFiles(options), [file.path]);
  assert.equal(examplesLoaded, 0);
  assert.deepEqual(await initialDocumentFiles({ ...options, desktopFiles: async () => [] }), ["example.nfg"]);
  assert.deepEqual(await initialDocumentFiles({ ...options, desktopFiles: async () => [], loadExample: async () => { throw new Error("missing"); } }), []);
});

test("opening the same path activates its existing tab and keeps the document title", () => {
  const existing = { path: "/tmp/a.nfg", dirty: true, displayTitle: "A" };
  const documents = [existing];
  const events: string[] = [];
  openDocumentFiles(documents, [{ path: existing.path, text: "changed" }, { path: "/tmp/b.nfg", text: "new" }],
    (document) => events.push(`activate ${document.path}`),
    (file) => ({ path: file.path, dirty: false, displayTitle: "B" }),
    (document) => events.push(`open ${document.path}`));
  assert.deepEqual(events, ["activate /tmp/a.nfg", "open /tmp/b.nfg"]);
  assert.equal(documentWindowTitle("Example", existing), "• A: Example");
  assert.equal(documentWindowTitle("Example"), "Example");
});

test("new tabs reuse the lowest free Untitled number among open tabs", () => {
  assert.equal(untitledName([]), "Untitled 1");
  const open = [{ name: "Untitled 1" }, { name: "Untitled 3" }, { name: "Untitled 1.nfg" }];
  assert.equal(untitledName(open), "Untitled 2");
  open.push({ name: "Untitled 2" });
  assert.equal(untitledName(open), "Untitled 4");
  open.splice(3, 1);
  assert.equal(untitledName(open), "Untitled 2");
});

test("new tabs follow the active tab; Open replaces only a sole blank tab", () => {
  const first = { name: "Untitled 1" }, second = { name: "Untitled 2" }, third = { name: "Untitled 3" };
  const open = [first, third];
  insertDocument(open, first, second, false);
  assert.deepEqual(open, [first, second, third]);
  const loaded = { name: "saved.nfg" };
  insertDocument(open, second, loaded, false);
  assert.deepEqual(open, [first, second, loaded, third]);
  const blank = [first];
  insertDocument(blank, first, loaded, true);
  assert.deepEqual(blank, [loaded]);
});

test("closing selects the tab at that position or the preceding last tab", () => {
  const first = { name: "A" }, second = { name: "B" }, third = { name: "C" };
  const open = [first, second, third];
  assert.deepEqual(removeDocument(open, second, first), { removed: true, active: second });
  assert.deepEqual(open, [second, third]);
  assert.deepEqual(removeDocument(open, second, second), { removed: true, active: third });
  assert.deepEqual(open, [third]);
  assert.deepEqual(removeDocument(open, third, third), { removed: true, active: null });
  assert.deepEqual(open, []);
});

test("window close saves selected dirty documents and stops on a failed save", async () => {
  type Document = { dirty: boolean; displayTitle: string; path: string | null };
  const first: Document = { dirty: true, displayTitle: "One", path: "/tmp/one.nfg" };
  const second: Document = { dirty: true, displayTitle: "Two", path: null };
  const events: string[] = [];
  const options = {
    documents: [first, second],
    askToSaveAll: async () => ({ choice: "save" as const, save: [0, 1] }),
    activate: (document: Document) => { events.push(`activate ${document.displayTitle}`); },
    save: async (document: Document) => { events.push(`save ${document.displayTitle}`); return document === first; },
    closeWindow: () => { events.push("close"); },
    closeCancelled: () => { events.push("cancel"); },
  };
  await confirmWindowClose(options);
  assert.deepEqual(events, ["activate One", "save One", "activate Two", "save Two", "cancel"]);
  events.length = 0;
  first.dirty = second.dirty = false;
  await confirmWindowClose(options);
  assert.deepEqual(events, ["close"]);
});

test("closing an inactive dirty tab selects it for the prompt, then selects its neighbor", async () => {
  const first = { name: "A", dirty: false }, second = { name: "B", dirty: true }, third = { name: "C", dirty: false };
  const documents = [first, second, third];
  const selected: string[] = [];
  const disposed: string[] = [];
  const options = {
    documents, active: first, closing: second,
    needsPrompt: (document: typeof first) => document.dirty,
    askToSave: async () => "discard" as const,
    save: async () => true,
    activate: (document: typeof first) => { selected.push(document.name); },
    dispose: (document: typeof first) => { disposed.push(document.name); },
    emptyDocument: () => ({ name: "empty", dirty: false }),
    renderTabs: () => { throw new Error("active closing tab must be replaced"); },
    afterClose: () => {},
  };
  assert.equal(await closeDocumentTab(options), true);
  assert.deepEqual(documents, [first, third]);
  assert.deepEqual(selected, ["B", "C"]);
  assert.deepEqual(disposed, ["B"]);
});

test("an untitled document without real work closes without asking; a saved file asks while it is dirty", async () => {
  assert.equal(hasUnsavedWork({ path: null, dirty: true, text: "" }), false, "typed in, then emptied");
  assert.equal(hasUnsavedWork({ path: null, dirty: true, text: "\n  \n\t" }), false, "only blank lines");
  assert.equal(hasUnsavedWork({ path: null, dirty: true, text: "% template\n\n", startText: "% template\r\n" }), false, "the template, untouched");
  assert.equal(hasUnsavedWork({ path: null, dirty: true, text: "% template\nx", startText: "% template" }), true);
  assert.equal(hasUnsavedWork({ path: null, dirty: false, text: "work" }), false);
  assert.equal(hasUnsavedWork({ path: "/a.txt", dirty: true, text: "" }), true, "emptying a saved file is a change to it");
  const blank = { dirty: true, displayTitle: "Untitled 1", path: null, text: " " };
  const real = { dirty: true, displayTitle: "Untitled 2", path: null, text: "notes" };
  let listed: string[] = [];
  let closed = false;
  await confirmWindowClose({
    documents: [blank, real], hasWork: hasUnsavedWork,
    askToSaveAll: async (documents) => { listed = documents.map((document) => document.name); return { choice: "discard", save: [] }; },
    activate: () => {}, save: async () => true, closeWindow: () => { closed = true; }, closeCancelled: () => {},
  });
  assert.deepEqual(listed, ["Untitled 2"]);
  assert.equal(closed, true);
});
