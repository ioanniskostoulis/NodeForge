// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { showContextMenu, type MenuEntry } from "./context-menu";

export interface NameRules {
  /** Names already used in the same place. Compared without regard to case. */
  taken?: readonly string[];
  /** Characters that cannot appear in a name. Defaults to `/` and `\`. */
  illegal?: RegExp;
}

/** Check a proposed name. Returns the message to show, or null when the name is acceptable. */
export function validateName(name: string, rules: NameRules = {}): string | null {
  const trimmed = name.trim();
  if (!trimmed) return "Enter a name.";
  if ((rules.illegal ?? /[\\/]/).test(trimmed)) return "A name cannot contain / or \\.";
  if (rules.taken?.some((other) => other.toLowerCase() === trimmed.toLowerCase())) return `The name ${trimmed} is already used.`;
  return null;
}

/** End of the part of a file name that is selected when renaming: before the last dot, or the whole name. */
export function baseNameEnd(name: string): number {
  const dot = name.lastIndexOf(".");
  return dot > 0 ? dot : name.length;
}

export interface RenameOptions {
  current(): string;
  /** Return a message to reject the name, or null to accept it. The default checks `validateName`. */
  validate?(name: string): string | null;
  apply(name: string): void;
  /** Select only the base name (files); the extension stays. */
  selectBase?: boolean;
  /** Where a rejected name is reported, usually Messages and the status bar. */
  onError?(message: string): void;
  /** Accessible name of the field, such as `Document name`. */
  label?: string;
}

/**
 * Replace `target` with the shared text field. Return or leaving the field applies a valid, changed name; Escape,
 * or leaving with an unchanged or invalid name, cancels. A rejected name marks the field and keeps it open on Return.
 */
export function startRename(target: HTMLElement, options: RenameOptions): void {
  if (!target.isConnected || target.dataset.renaming === "true") return;
  const input = document.createElement("input");
  input.type = "text";
  input.className = "name-edit";
  input.spellcheck = false;
  input.value = options.current();
  input.setAttribute("aria-label", options.label ?? "Name");
  input.setAttribute("aria-invalid", "false");
  target.dataset.renaming = "true";
  target.replaceWith(input);
  input.focus();
  input.setSelectionRange(0, options.selectBase ? baseNameEnd(input.value) : input.value.length);

  const finish = (): void => { delete target.dataset.renaming; if (input.isConnected) input.replaceWith(target); target.focus?.(); };
  const problem = (): string | null => (options.validate ?? ((name) => validateName(name)))(input.value);
  const commit = (explicit: boolean): void => {
    if (!input.isConnected) return;
    const name = input.value.trim();
    if (name === options.current()) return finish();
    const message = problem();
    if (message) {
      if (!explicit) return finish();
      input.classList.add("invalid");
      input.setAttribute("aria-invalid", "true");
      options.onError?.(message);
      return;
    }
    finish();
    options.apply(name);
  };
  input.addEventListener("input", () => { input.classList.remove("invalid"); input.setAttribute("aria-invalid", "false"); });
  input.addEventListener("keydown", (event) => {
    event.stopPropagation();
    if (event.key === "Enter") { event.preventDefault(); commit(true); }
    else if (event.key === "Escape") { event.preventDefault(); finish(); }
  });
  input.addEventListener("blur", () => commit(false));
}

/**
 * Make an element renameable in place: double-click, F2 or Return while it has focus, and a Rename… entry in
 * its context menu. `menu` adds the element's own entries after Rename….
 */
export function attachRename(target: HTMLElement, options: RenameOptions & { menu?: () => MenuEntry[] }): void {
  const rename = (): void => startRename(target, options);
  if (!target.hasAttribute("tabindex")) target.tabIndex = 0;
  if (!target.title) target.title = "Double-click or press F2 to rename.";
  target.addEventListener("dblclick", rename);
  target.addEventListener("keydown", (event) => {
    if (event.target !== target || (event.key !== "F2" && event.key !== "Enter")) return;
    event.preventDefault();
    rename();
  });
  target.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    const extra = options.menu?.() ?? [];
    showContextMenu(event.clientX, event.clientY, [{ label: "Rename…", key: "F2", action: rename }, ...(extra.length ? [{ label: "", separator: true }, ...extra] : [])]);
  });
}
