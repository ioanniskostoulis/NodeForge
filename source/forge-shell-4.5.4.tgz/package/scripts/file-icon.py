#!/usr/bin/env python3
"""Build a Forge app's document icons from its profile and app icon. Requires Pillow."""

import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont


def build_document_icon(config_path="forge.config.json"):
    config = json.loads(Path(config_path).read_text())
    document = config["desktop"]["document"]
    stem = document["iconStem"]
    label = document["iconLabel"]
    ink_color = document["iconInk"]
    source_path = document.get("iconSource", "assets/icon.png")
    output = Path("assets/icon")

    size = 1024
    source = Image.open(source_path).convert("RGBA")
    red, _, _, alpha = source.split()
    ink = Image.eval(red, lambda value: min(255, (255 - value) * 3))
    ink = Image.composite(ink, Image.new("L", source.size, 0), alpha)
    color = tuple(bytes.fromhex(ink_color.removeprefix("#"))) + (255,)

    icon = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    left, top, right, bottom, fold = 170, 70, 854, 954, 210
    page = [(left, top), (right - fold, top), (right, top + fold), (right, bottom), (left, bottom)]
    shadow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ImageDraw.Draw(shadow).polygon([(x + 0, y + 14) for x, y in page], fill=(0, 0, 0, 90))
    icon.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(18)))
    draw = ImageDraw.Draw(icon)
    draw.polygon(page, fill=(255, 255, 255, 255), outline=(205, 210, 222, 255), width=4)
    draw.polygon([(right - fold, top), (right, top + fold), (right - fold, top + fold)], fill=(228, 232, 244, 255), outline=(205, 210, 222, 255), width=4)

    letter = ink.crop(ink.getbbox())
    letter_height = 380
    letter = letter.resize((round(letter.width * letter_height / letter.height), letter_height), Image.LANCZOS)
    layer = Image.new("RGBA", letter.size, color)
    layer.putalpha(letter)
    icon.alpha_composite(layer, ((left + right) // 2 - letter.width // 2, 330))

    font = None
    for path in ["/System/Library/Fonts/Supplemental/Arial Bold.ttf", "/System/Library/Fonts/Helvetica.ttc", "C:/Windows/Fonts/arialbd.ttf"]:
        if os.path.exists(path):
            font = ImageFont.truetype(path, 118)
            break
    if font:
        label_width = draw.textlength(label, font=font)
        draw.text(((left + right) / 2 - label_width / 2, 760), label, font=font, fill=color)

    output.mkdir(parents=True, exist_ok=True)
    icon.save(output / f"{stem}.png")
    with tempfile.TemporaryDirectory() as tmp:
        iconset = Path(tmp) / f"{stem}.iconset"
        iconset.mkdir()
        for icon_size in (16, 32, 128, 256, 512):
            icon.resize((icon_size, icon_size), Image.LANCZOS).save(iconset / f"icon_{icon_size}x{icon_size}.png")
            icon.resize((icon_size * 2, icon_size * 2), Image.LANCZOS).save(iconset / f"icon_{icon_size}x{icon_size}@2x.png")
        icns = output / f"{stem}.icns"
        if shutil.which("iconutil"):
            result = subprocess.run(["iconutil", "-c", "icns", str(iconset), "-o", str(icns)], capture_output=True)
            if result.returncode:
                icon.save(icns)
        else:
            icon.save(icns)
    icon.save(output / f"{stem}.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print(f"wrote {output / stem}.png, {output / stem}.icns, {output / stem}.ico")


if __name__ == "__main__":
    build_document_icon()
