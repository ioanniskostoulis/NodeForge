import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { workflowFiles } from "../../scripts/workflows.mjs";

const read = (path) => readFileSync(new URL(`../../${path}`, import.meta.url), "utf8");

test("each application action is its own self-contained workflow, named for the action", () => {
  const expected = { "build-desktop-apps.yml": "Build desktop apps", "build-for-mac.yml": "Build for mac", "build-for-windows.yml": "Build for windows", "clear-all.yml": "Clear all" };
  const files = workflowFiles();
  assert.deepEqual(Object.keys(files).sort(), Object.keys(expected).sort());
  for (const [file, name] of Object.entries(expected)) {
    assert.ok(files[file].startsWith(`name: ${name}\n`), `${file} is named ${name}`);
    assert.ok(files[file].includes("workflow_dispatch:"), `${name} can be run by hand`);
    assert.ok(!/^\s*uses:\s*\S+\/\S+\/\.github\/workflows\//m.test(files[file]), `${name} calls no workflow of another repository`);
  }
});

test("building one platform builds only that platform, and clearing builds nothing", () => {
  const files = workflowFiles();
  const jobs = (text) => [...text.split("\njobs:\n")[1].matchAll(/^  (\w[\w-]*):$/gm)].map((match) => match[1]);
  assert.deepEqual(jobs(files["build-desktop-apps.yml"]), ["checks", "macos", "windows", "publish"]);
  assert.deepEqual(jobs(files["build-for-mac.yml"]), ["checks", "macos", "publish"]);
  assert.deepEqual(jobs(files["build-for-windows.yml"]), ["checks", "windows", "publish"]);
  assert.deepEqual(jobs(files["clear-all.yml"]), ["clear"]);
  assert.match(files["build-desktop-apps.yml"], /push:\n    branches: \[main\]/);
  assert.ok(files["clear-all.yml"].includes('"clear all"'));
  // Clear all also deletes the run history, except its own run, and needs the right to.
  for (const text of [files["clear-all.yml"], read(".github/workflows/clear-all.yml")]) {
    assert.match(text, /permissions:\n  contents: write\n  actions: write/);
    assert.ok(text.includes('[ "$run" = "$GITHUB_RUN_ID" ] || gh api -X DELETE "repos/$GITHUB_REPOSITORY/actions/runs/$run"'));
  }
  assert.ok(files["build-for-mac.yml"].includes("npx forge-shell release-notes"));
  assert.ok(files["build-for-mac.yml"].includes("pattern: forge-*"));
});

test("a failed Windows installer check shows the setup log and keeps it with the crash dumps", () => {
  const windows = workflowFiles()["build-for-windows.yml"];
  assert.match(windows, /run: \.\/scripts\/check-windows-installer\.ps1/);
  assert.ok(windows.includes("FORGE_SETUP_LOG_DIR: ${{ github.workspace }}/build/release/setup-log"));
  assert.match(windows, /name: Show setup log\n        if: failure\(\)/);
  assert.match(windows, /if: failure\(\)\n        uses: actions\/upload-artifact@v4\n        with:\n          name: windows-setup-log\n          path: build\/release\/setup-log/);
});

test("the Windows job opens the interactive setup window and checks its screenshot before the silent installation", () => {
  const windows = workflowFiles()["build-for-windows.yml"];
  const opened = windows.indexOf("name: Open setup window and check screenshot");
  assert.ok(opened > 0 && opened < windows.indexOf("name: Check Windows installer upgrades"));
  assert.ok(windows.includes("FORGE_CAPTURE: ${{ github.workspace }}/build/release/setup-window.png"));
  assert.ok(windows.includes("throw 'The setup window screenshot is blank.'"));
  assert.match(windows, /path: \|\n            build\/release\/windows-launch\.png\*\n            build\/release\/setup-window\.png/);
});

test("installer artifacts are kept 1 day and check artifacts 7 days, so they do not fill the Actions storage", () => {
  for (const [file, text] of Object.entries(workflowFiles())) {
    for (const upload of text.split("uses: actions/upload-artifact@v4").slice(1)) {
      const name = /name: ([\w-]+)/.exec(upload)[1];
      const days = Number(/retention-days: (\d+)/.exec(upload)?.[1]);
      assert.equal(days, name.startsWith("forge-") ? 1 : 7, `${file} ${name}`);
    }
  }
});

test("the shell lists its own package builders as separate workflows", () => {
  const own = { "check-shell.yml": "Check shell", "build-package.yml": "Build package", "publish-release.yml": "Publish release", "clear-all.yml": "Clear all" };
  for (const [file, name] of Object.entries(own)) {
    const text = read(`.github/workflows/${file}`);
    assert.ok(text.startsWith(`name: ${name}\n`), `${file} is named ${name}`);
    assert.ok(text.includes("workflow_dispatch:"), `${name} can be run by hand`);
  }
  assert.ok(read(".github/workflows/clear-all.yml").includes('"clear all"'));
  assert.ok(read(".github/workflows/publish-release.yml").includes("release-notes"));
});
