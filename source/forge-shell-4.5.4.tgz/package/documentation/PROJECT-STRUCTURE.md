# Structure of a Forge application

This document gives the starting layout of a Forge desktop application. Every application implements the shell, appearance, motion, menu, Terminal, Help and message rules of [GUIDELINES.md](GUIDELINES.md); its product and domain values are recorded in `documentation/INTERFACE.md`. Folder names are written in full, a folder is added only when the application has content for it, and names required by tools (such as `node_modules`) are unchanged.

## Layout

```text
Forge/
├── source/
│   ├── app/                 # Renderer UI, state, commands and styles
│   ├── desktop/             # Electron main process and narrow preload API
│   ├── engine/              # Logic independent of Electron and the UI
│   └── cli/                 # Optional command-line entry point
├── public/                  # Files served or copied unchanged; center.html and panes.html fill the page slots of the shell
├── assets/                  # Source icons, images and packaging resources
├── tests/                   # Automated tests and representative input files
├── documentation/           # User guide, architecture, development, formats
│   └── INTERFACE.md         # Product and domain profile; the shared Forge rules remain mandatory
├── scripts/                 # Build, verification and release helpers
├── build/                   # Generated bundles, test output and installers
├── .github/workflows/       # Automated checks and platform builds
├── forge.config.json        # Identity, document, accents, page slots and packaging metadata read by forge-shell
├── package.json             # Scripts, dependencies and Electron metadata
├── package-lock.json        # Dependency lockfile
├── tsconfig.json            # TypeScript configuration
├── VERSION                  # Version, when the application keeps it by hand
├── README.md                # Short overview for users
├── CHANGELOG.md             # Versioned release notes
├── LICENSE
├── .env.example             # Only when local configuration is needed
└── .gitignore
```

| Directory | Role |
|---|---|
| `source/app` | May also run in a browser; privileged desktop features are reached through a typed preload API in `source/desktop` |
| `source/desktop` | Holds the file-system operations and operating-system integration of the main process |
| `source/engine` | Holds the document conversion, so that the interface and an optional command-line entry point share one implementation |
| `public` and `assets` | `public` holds runtime files copied unchanged; `assets` holds design and packaging inputs |
| `build`, `node_modules` | Generated and ignored by Git |

All builds emit the same paths: `build/app/index.html`, `build/app/app.js`, `build/app/app.css`, `build/desktop/main.cjs`, `build/desktop/preload.cjs` and `build/engine/index.cjs`. Only the engine implementation and the domain assets differ. The npm command block is given in section 11 of [GUIDELINES.md](GUIDELINES.md).

Tool files such as an Electron Builder configuration may remain at the root when a tool expects them there. New source files and folders use lowercase hyphenated names; root documents such as `README.md` and `VERSION` are uppercase. The application name is written in brand case (`ExampleForge`) in product text and in lowercase (`exampleforge`) in package identifiers and commands.

## Minimum checks

| Command | Purpose |
|---|---|
| `npm run check` | TypeScript typecheck |
| `npm test` | Engine and file-behaviour tests on representative fixtures |
| `npm run test:app` | Application workflows, including opening, saving and error handling; bundles `node_modules/forge-shell/tests/conformance`, so that an application runs the tests of its pinned shell version |
| `npm run test:shell` | Builds, then runs `forge-shell check-app` (page slots, product name, settings key, brand CSS, shared stylesheets and style lint against the profile and the installed package) |
| `npm run build` | Produces the renderer, main-process and preload bundles |
| `npm run web` | Builds and serves the browser preview on loopback for inspection; its default port and browser-only limits are recorded in `documentation/DEVELOPMENT.md` |
| `npm run dist` | Packages the desktop application for the current platform |

Windows is verified by automated checks on every eligible push: the x64 installer builds, the installer check passes and the packaged application launches with a screenshot. The inspection lists of stages 3 and 5 of the pipeline are carried out by hand in the served `build/app`, and anything not opened is recorded as not checked. A command-line entry point is added only when a headless workflow exists. Platform packaging, external runtime requirements and release steps are documented in `documentation/DEVELOPMENT.md`.

## Pipeline and shell

| Subject | Description |
|---|---|
| Shared interface code | The `forge-shell` package, described in sections 14 to 16 of [GUIDELINES.md](GUIDELINES.md). |
| Accent check | `scripts/theme.mjs`: `brandCss` rejects an accent below a contrast ratio of 4.5:1. |
| Conformance | `tests/conformance` |
| Windows setup | [INSTALLER.md](INSTALLER.md) |
| Update to a new shell version | [UPDATING.md](UPDATING.md) |
