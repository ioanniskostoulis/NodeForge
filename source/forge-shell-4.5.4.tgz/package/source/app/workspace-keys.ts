// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { matchesKey } from "./menus";

export interface WorkspaceKeysOptions {
  desktop: boolean;
  hasDocuments: () => boolean;
  typingInField: () => boolean;
  shortcuts: () => readonly { key: string; id: string }[];
  run: (id: string) => void;
  escape: () => void;
  domainKeyDown?: (event: KeyboardEvent) => boolean;
  domainKeyUp?: (event: KeyboardEvent) => void;
}

/** Two taps of Space closer than this fit the view. */
export const DOUBLE_SPACE_MS = 350;
/** Controls that Space presses, and the Terminal: a double tap there is theirs, not a fit. */
const SPACE_OWNERS = "button, a[href], summary, [role=button], [role=menuitem], [role=treeitem], [role=tab], [role=option], [role=checkbox], [role=switch], [contenteditable=true], #bottom";

/**
 * Route shell shortcuts while leaving domain keys to the app. Space tapped twice on the work surface runs `view.fit`
 * (the selection when there is one, else everything: the application's Fit decides, with `fitBounds`); each tap still
 * reaches `domainKeyDown`, so holding Space to pan works as before.
 */
export function installWorkspaceKeys(options: WorkspaceKeysOptions): () => void {
  let lastSpace = -Infinity;
  const doubleSpace = (e: KeyboardEvent): boolean => {
    if (e.key !== " " || e.repeat || e.metaKey || e.ctrlKey || e.altKey || e.shiftKey) { if (e.key !== " ") lastSpace = -Infinity; return false; }
    if (e.target instanceof Element && e.target.closest(SPACE_OWNERS)) return false;
    const now = performance.now();
    const second = now - lastSpace <= DOUBLE_SPACE_MS;
    lastSpace = second ? -Infinity : now;
    return second;
  };
  const keydown = (e: KeyboardEvent) => {
    const target = e.target;
    if (target instanceof HTMLElement && target.closest("input, textarea, select")) {
      if (e.key === "Escape") target.blur();
      else if (!options.desktop && !options.typingInField()) {
        const hit = options.shortcuts().find((shortcut) => /^edit\.(undo|redo)$/.test(shortcut.id) && matchesKey(e, shortcut.key));
        if (hit) { e.preventDefault(); options.run(hit.id); }
      }
      return;
    }
    const plain = !e.metaKey && !e.ctrlKey && !e.altKey;
    if (!options.hasDocuments() && plain) return;
    if (e.key === "Escape") { options.escape(); return; }
    const fit = doubleSpace(e);
    const handled = options.domainKeyDown?.(e) ?? false;
    if (fit) options.run("view.fit");
    if (handled || fit) { e.preventDefault(); return; }
    if (options.desktop) return;
    const hit = options.shortcuts().find((shortcut) => matchesKey(e, shortcut.key));
    if (hit) { e.preventDefault(); options.run(hit.id); }
  };
  const keyup = (e: KeyboardEvent) => { options.domainKeyUp?.(e); };
  document.addEventListener("keydown", keydown);
  document.addEventListener("keyup", keyup);
  return () => { document.removeEventListener("keydown", keydown); document.removeEventListener("keyup", keyup); };
}
