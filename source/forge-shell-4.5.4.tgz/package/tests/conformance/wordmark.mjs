import assert from "node:assert/strict";
import test from "node:test";
import { LETTER_GAP, familyG, renderWordmark, romanFont } from "../../scripts/wordmark.mjs";

// The rows of each letter of a word, rendered alone, give the columns where the letters come closest.
const font = romanFont();

test("a wordmark is the name in the Roman lettering, with no trailing blanks and no blank rows above or below", () => {
  const frog = renderWordmark("Frog");
  assert.equal(frog, [
    "oooooooooooo",
    "`888'     `8",
    " 888      oooo d8b  .ooooo.   .oooooooo",
    " 888oooo8 `888\"\"8P d88' `88b 888' `88b",
    " 888    \"  888     888   888 888   888",
    " 888       888     888   888 `88bod8P'",
    "o888o     d888b    `Y8bod8P' d\"     YD",
    "                             \"Y88888P'",
  ].join("\n"));
  for (const row of renderWordmark("Example").split("\n")) assert.equal(row, row.trimEnd());
});

test("the family's g is the font's g one line shorter: no row between the bowl and the tail", () => {
  const g = font.glyphs.get("g").map((row) => row.replace(/[$ ]+$/, ""));
  assert.ok(!g.includes("`8oooooo."));
  assert.deepEqual(g.filter(Boolean).slice(-3), ["`88bod8P'", 'd"     YD', '"Y88888P\'']);
  // the font's own g has the row, and the glyph keeps its height
  const original = ["          $", " .oooooooo$", "`88bod8P' $", "`8oooooo. $", 'd"     YD $'];
  assert.deepEqual(familyG(original), ["          $", " .oooooooo$", "`88bod8P' $", 'd"     YD $', " ".repeat(11)]);
});

test("neighbouring letters sit exactly one blank column apart where they come closest", () => {
  assert.equal(LETTER_GAP, 1);
  for (const word of ["Frog", "Shell", "Plot", "Lab", "Node", "Example"]) {
    const rows = renderWordmark(word).split("\n");
    // the narrowest gap between ink in any row is one column, and no two letters touch
    const gaps = rows.flatMap((row) => [...row.matchAll(/(?<=\S)( +)(?=\S)/g)].map((match) => match[1].length));
    assert.equal(Math.min(...gaps), 1, word);
  }
});

test("every letter, digit and common sign of ASCII renders; anything else is refused with a sentence", () => {
  for (const char of "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.&+") assert.ok(renderWordmark(char).length > 0, char);
  // a space is a gap between letters, not ink of its own
  assert.ok(renderWordmark("a b").split("\n").some((row) => /\S {3,}\S/.test(row)));
  assert.throws(() => renderWordmark("Frog–2"), /The wordmark font has no character "–"\./);
});
