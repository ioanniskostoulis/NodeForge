import assert from "node:assert/strict";
import { test } from "node:test";
import { dispatchShellAction } from "../../source/app/actions.js";

test("shared actions navigate documents and dispatch save and information commands", async () => {
  const documents = ["first", "second", "third"];
  let active = "second";
  const calls: string[] = [];
  const actions = {
    documents: () => documents,
    activeDocument: () => active,
    activate: (document: string) => { active = document; },
    createDocument: () => { calls.push("new"); },
    newWindow: () => { calls.push("window"); },
    open: () => { calls.push("open"); },
    save: async (as: boolean) => { calls.push(as ? "save as" : "save"); },
    close: (document: string) => { calls.push(`close ${document}`); },
    showAbout: () => { calls.push("about"); },
    showWhatsNew: () => { calls.push("news"); },
    showShortcuts: () => { calls.push("shortcuts"); },
    showLicenses: () => { calls.push("licenses"); },
  };
  assert.equal(await dispatchShellAction("tab.next", actions), true);
  assert.equal(active, "third");
  assert.equal(await dispatchShellAction("tab.next", actions), true);
  assert.equal(active, "first");
  assert.equal(await dispatchShellAction("file.saveAs", actions), true);
  assert.equal(await dispatchShellAction("file.close", actions), true);
  assert.equal(await dispatchShellAction("about.shortcuts", actions), true);
  assert.deepEqual(calls, ["save as", "close first", "shortcuts"]);
  assert.equal(await dispatchShellAction("domain.command", actions), false);
});
