// Licensed under the GNU General Public License v2 or later. See LICENSE.
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { isTracked, trackedFiles } from "./tracked-files.mjs";

const hash = (path) => createHash("sha256").update(readFileSync(path)).digest("hex");

export function sameReleaseFile(actual, copied) {
  assert.ok(existsSync(copied), `missing ${copied}`);
  assert.equal(hash(copied), hash(actual), `${copied} does not match ${actual}; rebuild before release`);
}

/** Check that the web and desktop release source is complete and current. */
export function checkReleaseSource({
  roots, files, releaseCopies = [], privatePaths = [], web = "build/app", expectedDependencies = null, bannedWebFiles = [],
}) {
  const source = join(web, "release-source");
  // The application's own files count only when tracked, as the build copies them; copied packages are not tracked.
  const tracked = trackedFiles();
  const walk = (path, copiedPackage = false) => readdirSync(path).flatMap((name) => {
    if (name === ".DS_Store") return [];
    if (!copiedPackage && !isTracked(tracked, join(path, name))) return [];
    if (copiedPackage && (name === "node_modules" || name === "build")) return [];
    const item = join(path, name);
    if (privatePaths.includes(item.replaceAll("\\", "/"))) return [];
    return statSync(item).isDirectory() ? walk(item, copiedPackage) : [item];
  });
  const paths = [...files, ...roots.flatMap((root) => walk(root))];
  const copies = releaseCopies.flatMap(({ from, to }) => walk(from, true).map((path) => [path, join(to, relative(from, path))]));
  for (const path of paths) sameReleaseFile(path, join(source, path));
  for (const [path, target] of copies) sameReleaseFile(path, join(source, target));
  for (const path of privatePaths) assert.ok(!existsSync(join(source, path)), `${path} is in the shipped source`);
  for (const path of ["LICENSE", "NOTICE.md", "CHANGELOG.md"]) sameReleaseFile(path, join(web, path));
  for (const path of bannedWebFiles) assert.ok(!existsSync(join(web, path)), `unused ${path} is still bundled`);
  const pkg = JSON.parse(readFileSync("package.json", "utf8"));
  assert.equal(pkg.version, readFileSync("VERSION", "utf8").trim());
  const lock = JSON.parse(readFileSync("package-lock.json", "utf8"));
  assert.equal(lock.version, pkg.version);
  assert.equal(lock.packages[""].version, pkg.version);
  if (expectedDependencies) assert.deepEqual(pkg.dependencies ?? {}, expectedDependencies, "production npm dependencies changed: review their notices");
  console.log(`Web build: license, notices and ${paths.length + copies.length} source files match.`);
  return { paths, copies, privatePaths, web, same: sameReleaseFile };
}
