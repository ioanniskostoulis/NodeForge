import assert from "node:assert/strict";
import test from "node:test";
import { createNativeMenuTemplate } from "../../source/desktop/native-menu";

test("native menus preserve commands and add the macOS app and Window menus", () => {
  const commands: string[] = [];
  const menu = createNativeMenuTemplate([
    { label: "File", submenu: [{ label: "New", id: "new", key: "CmdOrCtrl+N" }] },
    { label: "Help", submenu: [{ label: "Developer tools", role: "toggleDevTools" }] },
  ], { productName: "TestForge", isMac: true, isPackaged: true, onCommand: (id) => commands.push(id) });
  assert.deepEqual(menu.map((item) => item.label ?? item.role), ["TestForge", "File", "windowMenu", "Help"]);
  assert.deepEqual(menu[3].submenu, []);
  menu[0].submenu?.[0].click?.({}, {});
  menu[1].submenu?.[0].click?.({}, {});
  assert.deepEqual(commands, ["about", "new"]);
});
