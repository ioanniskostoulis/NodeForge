// The scrollbar rules of the shell, which the overlay module draws by. This test reads the shell's own files, so it runs
// in the shell only; applications bundle the portable .ts tests, which read no files.
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";

const css = readFileSync(new URL("../../source/styles/shell.css", import.meta.url), "utf8");
const rule = (selector) => {
  const start = css.indexOf(`${selector} {`);
  assert.ok(start >= 0, `missing ${selector}`);
  return css.slice(start, css.indexOf("}", start));
};

test("the browser's thin overlay bar stays the fallback, and a drawn pane gives up its own bar", () => {
  // The thin overlay bar takes no layout space, so the inspector keeps its 222 px of content in an application that has
  // not called `installScrollbars` yet; the shell's own bar needs the native one out of the way.
  assert.match(css, /^\* \{ scrollbar-color: [^;]+; scrollbar-width: thin; \}$/m);
  assert.match(rule("[data-shell-scrollbar]"), /scrollbar-width: none;/);
  assert.ok(css.includes("[data-shell-scrollbar]::-webkit-scrollbar { display: none; }"));
});

test("the overlay bar is 6 px at rest and widens to 10 px under the pointer, toward the pane", () => {
  const box = rule(".shell-scrollbar");
  assert.match(box, /width: 10px;/, "the grab area is the hover width");
  assert.match(box, /transition: opacity/);
  const bar = rule(".shell-scrollbar::before");
  assert.match(bar, /width: 6px;/);
  assert.match(bar, /right: 0;/, "it widens from the pane's edge inward");
  assert.match(bar, /transition: width 150ms/);
  assert.match(rule('.shell-scrollbar[data-hover="true"]::before'), /width: 10px;/);
  assert.match(rule('.shell-scrollbar[data-axis="x"][data-hover="true"]::before'), /height: 10px;/);
  assert.match(css, /@media \(prefers-reduced-motion: reduce\) \{ \.shell-scrollbar, \.shell-scrollbar::before \{ transition: none; \} \}/);
});
