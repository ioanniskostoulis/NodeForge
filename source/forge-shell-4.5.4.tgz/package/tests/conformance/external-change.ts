import assert from "node:assert/strict";
import { test } from "node:test";
import { externalAction } from "../../source/app/external-change";

test("an outside change is imported when the editor is unchanged and asked about when it has edits", () => {
  assert.equal(externalAction("a", "a", "b"), "none");
  assert.equal(externalAction("b", "a", "b"), "none");
  assert.equal(externalAction("c", "a", "a"), "import");
  assert.equal(externalAction("c", "a", "b"), "ask");
});
