// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Electron preload: exposes `window.forge`, the shell's desktop bridge, to the interface. Add the application's own
// calls beside the shared ones.
import { contextBridge, ipcRenderer } from "electron";
import { createDesktopBridge, type ForgeDesktopBridge } from "forge-shell/desktop/bridge";

const bridge: ForgeDesktopBridge<"__EXT__"> = createDesktopBridge<"__EXT__">(ipcRenderer, process.platform as ForgeDesktopBridge["platform"], require("../../package.json").version);

contextBridge.exposeInMainWorld("forge", bridge);
