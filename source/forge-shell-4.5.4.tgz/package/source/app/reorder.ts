// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Drag to rearrange a row or column of items (tabs, list rows). The item stays in place while it is dragged; a 2 px
// drop line in the accent shows where it will land, the list scrolls near its ends, and Esc cancels.
import { dragStarted, dropIndex } from "./content-selection";

export interface ReorderOptions {
  /** The items, in order; each must be a child of the container. */
  items(): HTMLElement[];
  /** Row of tabs (`x`) or column of rows (`y`). */
  axis: "x" | "y";
  /** Move the item at `from` to before the item at `to` (`to` may be the number of items). */
  onMove(from: number, to: number): void;
  /** Whether the item may be dragged; all may by default. */
  canDrag?(index: number): boolean;
}

// Within this distance of either end, in px, the container scrolls by this many px a frame.
const SCROLL_EDGE = 24, SCROLL_STEP = 8;

/** Make a row or column of items rearrangeable by dragging. Returns a function that removes the behaviour. */
export function attachReorder(container: HTMLElement, options: ReorderOptions): () => void {
  const line = Object.assign(document.createElement("div"), { className: `drop-line drop-line-${options.axis}` });
  line.setAttribute("aria-hidden", "true");
  let drag: { index: number; x: number; y: number; active: boolean; to: number; pointer: number } | null = null;
  let frame = 0;
  // Set when a drag ends, until the click that follows the pointer release has passed.
  let dragged = false;
  const spans = () => options.items().map((item) => {
    const box = item.getBoundingClientRect();
    return options.axis === "x" ? { start: box.left, end: box.right } : { start: box.top, end: box.bottom };
  });
  const place = (position: number) => {
    const all = spans(), items = options.items();
    drag!.to = dropIndex(all, position);
    const box = container.getBoundingClientRect();
    const edge = drag!.to < all.length ? all[drag!.to].start : all[all.length - 1].end;
    const across = items[0]?.getBoundingClientRect();
    if (options.axis === "x") Object.assign(line.style, { left: `${edge - box.left + container.scrollLeft - 1}px`, top: `${(across?.top ?? box.top) - box.top}px`, height: `${across?.height ?? box.height}px` });
    else Object.assign(line.style, { top: `${edge - box.top + container.scrollTop - 1}px`, left: `${(across?.left ?? box.left) - box.left}px`, width: `${across?.width ?? box.width}px` });
    // A drop that would not move the item shows no line.
    line.hidden = drag!.to === drag!.index || drag!.to === drag!.index + 1;
  };
  const scroll = (position: number) => {
    cancelAnimationFrame(frame);
    const box = container.getBoundingClientRect();
    const [start, end] = options.axis === "x" ? [box.left, box.right] : [box.top, box.bottom];
    const step = position < start + SCROLL_EDGE ? -SCROLL_STEP : position > end - SCROLL_EDGE ? SCROLL_STEP : 0;
    if (!step) return;
    frame = requestAnimationFrame(() => { if (options.axis === "x") container.scrollLeft += step; else container.scrollTop += step; place(position); scroll(position); });
  };
  const finish = (move: boolean) => {
    cancelAnimationFrame(frame);
    line.remove();
    container.classList.remove("reordering");
    const done = drag;
    drag = null;
    if (done?.active) { dragged = true; setTimeout(() => { dragged = false; }, 0); }
    if (move && done?.active && done.to !== done.index && done.to !== done.index + 1) options.onMove(done.index, done.to);
  };
  const down = (event: PointerEvent) => {
    if (event.button !== 0) return;
    const index = options.items().findIndex((item) => item.contains(event.target as Node));
    if (index < 0 || options.canDrag?.(index) === false || (event.target as HTMLElement).closest("button.close, input")) return;
    drag = { index, x: event.clientX, y: event.clientY, active: false, to: index, pointer: event.pointerId };
  };
  const move = (event: PointerEvent) => {
    if (!drag || event.pointerId !== drag.pointer) return;
    if (!drag.active) {
      if (!dragStarted(drag.x, drag.y, event.clientX, event.clientY)) return;
      drag.active = true;
      container.classList.add("reordering");
      container.append(line);
    }
    const position = options.axis === "x" ? event.clientX : event.clientY;
    place(position);
    scroll(position);
  };
  const up = (event: PointerEvent) => { if (drag && event.pointerId === drag.pointer) finish(true); };
  const key = (event: KeyboardEvent) => { if (drag?.active && event.key === "Escape") { event.preventDefault(); event.stopPropagation(); finish(false); } };
  // A click that ended a drag does not also activate the item.
  const click = (event: MouseEvent) => { if (dragged) { event.stopPropagation(); event.preventDefault(); } };
  container.addEventListener("pointerdown", down);
  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
  window.addEventListener("pointercancel", up);
  window.addEventListener("keydown", key, true);
  container.addEventListener("click", click, true);
  return () => {
    finish(false);
    container.removeEventListener("pointerdown", down);
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    window.removeEventListener("pointercancel", up);
    window.removeEventListener("keydown", key, true);
    container.removeEventListener("click", click, true);
  };
}
