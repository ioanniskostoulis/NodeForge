// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** The release file name of an app: `<Name>-v<version>.<ext>`, such as `Example-v1.2.3.dmg` or `Example-v1.2.3.exe`. */
export function artifactName(name, version, ext) {
  return `${name}-v${version}.${ext}`;
}

/** The same name as an electron-builder pattern, which fills in `${version}` and `${ext}` itself. */
export function artifactPattern(name) {
  return `${name}-v\${version}.\${ext}`;
}
