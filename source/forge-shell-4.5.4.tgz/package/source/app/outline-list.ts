// Licensed under the GNU General Public License v2 or later. See LICENSE.
// A document's structure as a list (sections, parts, steps): numbered by level, indented, the current one marked.

export interface OutlineItem { title: string; level: number; id: string }

/** The number of each item from its level ("1", "1.1", "1.2", "2"); a deeper level restarts when a shallower one advances. */
export function outlineNumbers(items: readonly Pick<OutlineItem, "level">[]): string[] {
  const counters: number[] = [];
  const top = Math.min(...items.map((item) => item.level));
  return items.map(({ level }) => {
    const depth = level - top;
    counters.length = depth + 1;
    for (let index = 0; index < depth; index++) counters[index] ??= 1;
    counters[depth] = (counters[depth] ?? 0) + 1;
    return counters.join(".");
  });
}

/** Draw the outline into `list`; a click or Return on a row calls `onSelect` with its id. */
export function renderOutline(list: HTMLElement, items: readonly OutlineItem[], current: string | null, onSelect: (id: string) => void, emptyText = "No sections."): void {
  list.className = "outline-list";
  list.setAttribute("role", "list");
  if (!items.length) { list.replaceChildren(Object.assign(document.createElement("div"), { className: "outline-empty", textContent: emptyText })); return; }
  const top = Math.min(...items.map((item) => item.level));
  const numbers = outlineNumbers(items);
  list.replaceChildren(...items.map((item, index) => {
    const row = document.createElement("button");
    row.type = "button";
    row.className = `outline-row${item.id === current ? " current" : ""}`;
    row.style.setProperty("--depth", String(item.level - top));
    row.setAttribute("role", "listitem");
    row.append(Object.assign(document.createElement("span"), { className: "outline-number", textContent: numbers[index] }), Object.assign(document.createElement("span"), { className: "outline-title", textContent: item.title }));
    row.addEventListener("click", () => onSelect(item.id));
    return row;
  }));
}
