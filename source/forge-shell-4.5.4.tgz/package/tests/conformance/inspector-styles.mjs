// The stylesheet rules of the inspector parts, whose behaviour inspector-parts.ts checks. This test reads the shell's
// own files, so it runs in the shell only; applications bundle the portable .ts tests, which read no files.
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { test } from "node:test";
import { contrastRatio } from "../../scripts/theme.mjs";

const read = (path) => readFileSync(new URL(`../../${path}`, import.meta.url), "utf8");
const css = read("source/styles/shell.css");
/** The declarations of the first rule whose selector list is exactly `selector`. */
const rule = (selector) => {
  const start = css.indexOf(`${selector} {`);
  assert.ok(start >= 0, `missing ${selector}`);
  return css.slice(start, css.indexOf("}", start));
};

test("the portable conformance tests read no files, so that an application can run them bundled", () => {
  // An application bundles tests/conformance/*.ts from node_modules into its own build, often as CommonJS, where
  // import.meta.url is empty and the shell's paths do not exist.
  const portable = readdirSync(new URL(".", import.meta.url)).filter((name) => name.endsWith(".ts"));
  assert.ok(portable.length > 10);
  for (const name of portable) {
    const source = read(`tests/conformance/${name}`);
    assert.doesNotMatch(source, /import\.meta|from "node:fs"|"\.\.\/\.\.\/scripts\//, `${name} reads files; move that check to an .mjs test`);
  }
});

test("info lines set the name in the UI font and the values in mono", () => {
  assert.match(rule(".info-lines"), /var\(--mono\)/);
  assert.match(rule(".info-lines .first"), /var\(--ui\)/);
});

test("buttons share a group's width at 24 px, and each kind shows whether it can be clicked", () => {
  assert.match(rule(".buttons"), /display: flex; gap: var\(--gap\);/);
  assert.match(rule(".panel-button"), /flex: 1;[\s\S]*height: calc\(var\(--control-height\) - 2px\);[\s\S]*border-radius: var\(--radius\);[\s\S]*background: var\(--control\);/);
  assert.match(rule(".panel-button.primary"), /background: var\(--accent-fill\); color: var\(--accent-foreground\);/);
  // hover changes only an enabled, idle button
  assert.ok(css.includes(".panel-button:hover:not(:disabled):not([aria-busy=\"true\"]) { background: var(--control-hover); }"));
  assert.ok(css.includes(".panel-button.primary:hover:not(:disabled):not([aria-busy=\"true\"]) { background: var(--accent-hover); }"));
  // a disabled button of either kind keeps its fill: the ordinary one dims its label to --text3, the primary one to the
  // foreground mixed into the accent fill
  assert.match(rule(".panel-button:disabled"), /color: var\(--text3\); cursor: default;/);
  assert.doesNotMatch(rule(".panel-button:disabled"), /background/, "the ordinary fill is kept");
  assert.match(rule(".panel-button.primary:disabled"), /color: color-mix\(in srgb, var\(--accent-foreground\) 55%, var\(--accent-fill\)\);/);
  assert.doesNotMatch(rule(".panel-button.primary:disabled"), /background/, "the accent fill is kept");
  assert.match(rule(".panel-button[aria-busy=\"true\"]"), /cursor: progress/);
  assert.match(rule(".panel-button:focus-visible"), /outline: 1px solid var\(--accent-light\)/);
});

test("a disabled primary label is the foreground 55 % into the accent fill: legible, and clearly dimmer than enabled", () => {
  /** `foreground` mixed into `fill` by `share`, as CSS color-mix in sRGB does. */
  const mix = (foreground, fill, share) => {
    const rgb = (hex) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
    const [f, b] = [rgb(foreground), rgb(fill)];
    return `#${f.map((value, i) => Math.round(value * share + b[i] * (1 - share)).toString(16).padStart(2, "0")).join("")}`;
  };
  // accent fills in use across the family, and the Pride purple
  for (const fill of ["#1e8052", "#2e7f4d", "#3c56aa", "#a82a2d", "#773c8d"]) {
    const disabled = contrastRatio(mix("#ffffff", fill, 0.55), fill), enabled = contrastRatio("#ffffff", fill);
    assert.ok(disabled >= 2.5, `${fill}: disabled label ${disabled.toFixed(2)}:1 is legible`);
    assert.ok(enabled - disabled >= 1.8, `${fill}: ${disabled.toFixed(2)}:1 against ${enabled.toFixed(2)}:1 enabled is clearly dimmer`);
  }
  // --text3 on the fill, the rule it replaces, all but disappears
  assert.ok(contrastRatio("#666666", "#2e7f4d") < 1.2);
});

test("chips are a button group: 24 px, radius 4, sharing the width, the chosen one in the accent fill", () => {
  assert.match(rule(".chips"), /display: flex; gap: var\(--gap\);/);
  const chip = rule(".chip");
  for (const part of ["flex: 1;", "height: calc(var(--control-height) - 2px);", "border-radius: var(--radius);", "background: var(--control);", "color: var(--text);"]) assert.ok(chip.includes(part), part);
  assert.doesNotMatch(chip, /border-radius: 11px|border: 1px/, "no pill and no outline");
  assert.match(rule(".chip[aria-checked=\"true\"]"), /background: var\(--accent-fill\); color: var\(--accent-foreground\);/);
  assert.match(rule(".chip:disabled"), /color: var\(--text3\)/);
  assert.match(rule(".chip[aria-checked=\"true\"]:disabled"), /color: color-mix\(in srgb, var\(--accent-foreground\) 55%, var\(--accent-fill\)\)/);
  assert.match(rule(".chip:focus-visible"), /outline: 1px solid var\(--accent-light\)/);
});

test("no stylesheet rule draws a status icon in the view header", () => {
  assert.doesNotMatch(css, /\.view-mode/);
});

test("a flyout's icon column fits its widest icon, never under 16 px, so a wide symbol does not run into its name", () => {
  assert.match(rule(".tool-flyout .flyout-icon"), /width: var\(--flyout-icon-width, 16px\)/);
  const source = read("source/app/tool-flyout.ts");
  assert.match(source, /Math\.max\(16, \.\.\.items\.map/);
  assert.match(source, /setProperty\("--flyout-icon-width"/);
});

test("a select is the shared 108 × 22 control outside a field row too, and a field row or the generator pane widens it", () => {
  const base = css.slice(css.indexOf(".select-control { width: 108px"));
  assert.match(base, /^\.select-control \{ width: 108px;[^}]*height: 22px;[^}]*border: 1px solid var\(--separator\);[^}]*background: var\(--well\)/);
  assert.match(css, /\.select-control:focus \{ outline: none; border-color: var\(--accent\); box-shadow: 0 0 0 1px var\(--accent\); \}/);
  assert.ok(css.indexOf(".select-control { width: 108px") < css.indexOf(".generator-input { width: 100%"), "the generator pane's full width wins");
  assert.match(rule(".field .select-control"), /width: 100%/);
});

test("the clickable pointer is only for links, checkboxes and sliders; a plain button or row keeps the arrow", () => {
  const pointers = [...css.matchAll(/([^{}]+)\{[^}]*cursor: pointer/g)].map((m) => m[1].trim().split("\n").pop().trim());
  assert.deepEqual(pointers.sort(), ["#statusbar .warn", ".link-button", ".message-subject", ".slider", ".t-link", 'input[type="checkbox"]'].sort());
});

test("the cursor modes: text over selectable text, progress while anything is busy, wait behind a shield", () => {
  assert.match(css, /#terminal-pane, #messages-pane, \.info-lines \{ cursor: text; \}/);
  assert.match(css, /:is\(\[aria-busy="true"\], :root\[data-busy="progress"\]\) :not\(input, textarea, \[contenteditable="true"\], \[contenteditable="true"\] \*, \.cm-editor, \.cm-editor \*, \.split, \.splitter, \.splitter-y\),\n\[aria-busy="true"\] \{ cursor: progress; \}/);
  assert.match(rule(".busy-shield"), /position: fixed; inset: 0;[^}]*cursor: wait/);
  assert.match(css, /:is\(\[aria-busy="true"\], :root\[data-busy="progress"\]\) :is\(\.cm-editor, \[contenteditable="true"\]\) \{ cursor: auto; \}/, "an editor keeps its text cursor");
  assert.match(css, /\.preview-stage \{[^}]*cursor: grab/);
  assert.match(css, /\.preview-stage\.panning \{ cursor: grabbing; \}/);
});

test("a text field in a dialog without a style of its own is the shared field, and any class wins", () => {
  assert.match(css, /:where\(\.modal-backdrop\) :where\(input:is\(\[type=text\], \[type=search\], \[type=url\], \[type=number\], :not\(\[type\]\)\)\) \{[^}]*height: 22px;[^}]*border: 1px solid var\(--separator\);[^}]*background: var\(--well\)/);
  assert.match(css, /:where\(\.modal-backdrop\) :where\(textarea\) \{/);
});
