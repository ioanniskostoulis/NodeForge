import assert from "node:assert/strict";
import { test } from "node:test";
import { EditorSelection, EditorState } from "@codemirror/state";
import { SearchQuery, search, setSearchQuery } from "@codemirror/search";
import { tags } from "@lezer/highlight";
import { SYNTAX_KINDS, SYNTAX_TAGS, shellHighlightStyle } from "../../source/app/code-editor";
import { matchFrom, searchCount } from "../../source/app/find-bar";

test("every syntax kind has highlighting tags, no tag has two colours, and each tag gets its kind's class", () => {
  assert.deepEqual([...SYNTAX_KINDS], ["keyword", "name", "string", "number", "comment", "type", "operator", "heading", "link", "invalid"]);
  const seen = new Set();
  for (const kind of SYNTAX_KINDS) {
    assert.ok(SYNTAX_TAGS[kind].length > 0, kind);
    for (const tag of SYNTAX_TAGS[kind]) { assert.ok(!seen.has(tag), `${kind} repeats a tag`); seen.add(tag); }
  }
  assert.equal(shellHighlightStyle.style([tags.keyword]), "syntax-keyword");
  assert.equal(shellHighlightStyle.style([tags.string]), "syntax-string");
  assert.equal(shellHighlightStyle.style([tags.lineComment]), "syntax-comment");
});

test("the find bar counts the matches of its query and which one is selected", () => {
  let state = EditorState.create({ doc: "one two one three one", extensions: [search()] });
  assert.deepEqual(searchCount(state), { total: 0, current: 0, valid: true }, "no query");
  state = state.update({ effects: setSearchQuery.of(new SearchQuery({ search: "one" })), selection: EditorSelection.single(8, 11) }).state;
  assert.deepEqual(searchCount(state), { total: 3, current: 2, valid: true });
  state = state.update({ effects: setSearchQuery.of(new SearchQuery({ search: "(", regexp: true })) }).state;
  assert.equal(searchCount(state).valid, false, "an invalid pattern is reported, not thrown");
});

test("a query typed in the find bar keeps the match under the selection as it grows, and wraps", () => {
  // "xx ab yy ab zz": typing "a" selects 3–4; typing on to "ab" keeps 3–5 instead of jumping to 9–11.
  let state = EditorState.create({ doc: "xx ab yy ab zz", extensions: [search()] });
  const typed = (text: string, from: number) => { state = state.update({ effects: setSearchQuery.of(new SearchQuery({ search: text })) }).state; return matchFrom(state, from); };
  assert.deepEqual(typed("a", 0), { from: 3, to: 4 });
  assert.deepEqual(typed("ab", 3), { from: 3, to: 5 });
  assert.deepEqual(typed("ab", 10), { from: 3, to: 5 }, "past the last match it wraps to the first");
  assert.equal(typed("q", 0), null);
  assert.equal(typed("", 0), null);
});
