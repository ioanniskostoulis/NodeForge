// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Saving, the same in every application: autosave as a preference, recovery of unsaved edits after a crash, and the
// File › Open recent list.
import { askToPick } from "./dialogs";
import type { MenuNode } from "./menus";

// MARK: autosave

/** Off (the default), after a pause since the last edit, or when the window loses the focus. */
export const AUTOSAVE_CHOICES = ["off", "1m", "5m", "focus"] as const;
export type AutosaveChoice = (typeof AUTOSAVE_CHOICES)[number];
export const AUTOSAVE_LABELS: Record<AutosaveChoice, string> = { off: "Off", "1m": "After 1 minute", "5m": "After 5 minutes", focus: "When the window loses focus" };

/** How long after the last edit a document is saved, in ms; null when the choice does not save on a timer. */
export function autosaveDelayMs(choice: AutosaveChoice): number | null {
  return choice === "1m" ? 60_000 : choice === "5m" ? 300_000 : null;
}

/** The choice a stored or typed value names (`off`, `1m`, `1 min`, `5m`, `focus`), or null. */
export function parseAutosave(value: unknown): AutosaveChoice | null {
  const text = String(value ?? "").trim().toLowerCase().replace(/\s+/g, "").replace(/(minutes?|mins?)$/, "m");
  return (AUTOSAVE_CHOICES as readonly string[]).includes(text) ? (text as AutosaveChoice) : null;
}

/** File › Autosave: the choices as a submenu, the current one checked; each sends `<idPrefix>.<choice>`. */
export function autosaveMenu(choice: AutosaveChoice, idPrefix = "file.autosave"): MenuNode {
  return { label: "Autosave", submenu: AUTOSAVE_CHOICES.map((value) => ({ id: `${idPrefix}.${value}`, label: AUTOSAVE_LABELS[value], checked: value === choice })) };
}

export interface AutosaveOptions<Doc> {
  choice(): AutosaveChoice;
  /** Only a document that has a file (it was saved once) is autosaved; an untitled one is left to recovery. */
  canSave(document: Doc): boolean;
  save(document: Doc): Promise<unknown> | void;
  /** Timers, replaceable in tests. */
  setTimer?(run: () => void, ms: number): unknown;
  clearTimer?(timer: unknown): void;
}

/**
 * Autosave for the open documents. Call `edited(document)` after each edit and `blurred(documents)` when the window
 * loses the focus. With a delay, a document is saved that long after its last edit; with `focus`, when the window is
 * left. Nothing is saved while the choice is `off`.
 */
export function createAutosave<Doc>(options: AutosaveOptions<Doc>) {
  const setTimer = options.setTimer ?? ((run: () => void, ms: number) => setTimeout(run, ms));
  const clearTimer = options.clearTimer ?? ((timer: unknown) => clearTimeout(timer as ReturnType<typeof setTimeout>));
  const timers = new Map<Doc, unknown>();
  const save = (document: Doc) => { timers.delete(document); if (options.canSave(document)) void options.save(document); };
  return {
    edited(document: Doc): void {
      const delay = autosaveDelayMs(options.choice());
      if (timers.has(document)) clearTimer(timers.get(document));
      timers.delete(document);
      // The choice is read again when the pause ends: a pause still running when autosave is turned off saves nothing.
      if (delay !== null && options.canSave(document)) timers.set(document, setTimer(() => { timers.delete(document); if (autosaveDelayMs(options.choice()) !== null) save(document); }, delay));
    },
    blurred(documents: readonly Doc[]): void { if (options.choice() === "focus") for (const document of documents) save(document); },
    /** Forget a closed or saved document's pending save. */
    forget(document: Doc): void { if (timers.has(document)) clearTimer(timers.get(document)); timers.delete(document); },
  };
}

// MARK: recovery of unsaved edits

/** One document's unsaved text, kept so that a crash does not lose it. */
export interface Draft { key: string; name: string; path: string | null; text: string; savedAt: number }

/** Drafts older than this are dropped, in ms (seven days). */
export const DRAFT_MAX_AGE_MS = 7 * 24 * 3600 * 1000;

export interface StorageLike { getItem(key: string): string | null; setItem(key: string, value: string): void; removeItem(key: string): void }

/**
 * The drafts of an application, in its storage under `storageKey`. Keep a document's draft while it has unsaved
 * edits and clear it when it is saved or discarded; after a crash, `list()` returns what was left, newest first.
 */
export function createRecovery(storageKey: string, storage: StorageLike = localStorage, now = () => Date.now()) {
  const read = (): Draft[] => {
    try {
      const drafts = JSON.parse(storage.getItem(storageKey) ?? "[]") as Draft[];
      return Array.isArray(drafts) ? drafts.filter((draft) => draft && typeof draft.text === "string" && now() - draft.savedAt < DRAFT_MAX_AGE_MS) : [];
    } catch { return []; }
  };
  const write = (drafts: Draft[]) => {
    try { if (drafts.length) storage.setItem(storageKey, JSON.stringify(drafts)); else storage.removeItem(storageKey); } catch { /* full or unavailable: the draft is lost, the document is not */ }
  };
  return {
    keep(draft: Omit<Draft, "savedAt">): void { write([...read().filter((item) => item.key !== draft.key), { ...draft, savedAt: now() }]); },
    clear(key: string): void { write(read().filter((item) => item.key !== key)); },
    list(): Draft[] { return read().sort((a, b) => b.savedAt - a.savedAt); },
    clearAll(): void { write([]); },
  };
}

/** When a draft was kept, for the restore dialog: "today 14:05", or the date and time. */
export function draftTime(savedAt: number, now = Date.now()): string {
  const at = new Date(savedAt), today = new Date(now);
  const time = at.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  return at.toDateString() === today.toDateString() ? `today ${time}` : `${at.toLocaleDateString()} ${time}`;
}

/**
 * After a crash, offer the drafts left behind, all ticked: Restore (Return) reopens the ticked ones, Cancel (Esc)
 * keeps them for the next launch. Resolves the keys to restore, or null.
 */
export function askToRecover(drafts: readonly Draft[], appName: string): Promise<string[] | null> {
  return askToPick({
    title: `${appName} closed with unsaved changes. Restore them?`,
    columns: ["Document", "Last change", "File"],
    rows: drafts.map((draft) => ({ id: draft.key, cells: [draft.name, draftTime(draft.savedAt), draft.path ?? "Not saved yet"] })),
    multiple: true, ticked: drafts.map((draft) => draft.key), action: "Restore", placeholder: "Search",
  });
}

// MARK: Open recent

/** The most recent files kept, newest first. */
export const RECENT_MAX = 10;

/** The list with `path` moved to the front, without duplicates, at most `max` long. */
export function addRecent(list: readonly string[], path: string, max = RECENT_MAX): string[] {
  return [path, ...list.filter((item) => item !== path)].slice(0, max);
}

/**
 * The label of each recent file: its name, and where two share a name, the name and its folder (`notes.txt — lab`),
 * as macOS and Windows show them.
 */
export function recentLabels(paths: readonly string[]): string[] {
  const parts = paths.map((path) => path.split(/[\\/]/).filter(Boolean));
  const name = (index: number) => parts[index].at(-1) ?? paths[index];
  return paths.map((_, index) => {
    const same = parts.some((_, other) => other !== index && name(other) === name(index));
    return same && parts[index].length > 1 ? `${name(index)} — ${parts[index].at(-2)}` : name(index);
  });
}

/** File › Open recent: the files (`<idPrefix>.<index>`), a separator and Clear menu (`<idPrefix>.clear`). */
export function recentMenu(paths: readonly string[], idPrefix = "file.recent"): MenuNode {
  const labels = recentLabels(paths);
  return {
    label: "Open recent",
    submenu: paths.length
      ? [...paths.map((_, index) => ({ id: `${idPrefix}.${index}`, label: labels[index] })), { separator: true }, { id: `${idPrefix}.clear`, label: "Clear menu" }]
      : [{ label: "No recent files", enabled: false }],
  };
}

/** The recent files of an application, in its storage under `storageKey`. */
export function createRecentFiles(storageKey: string, storage: StorageLike = localStorage, max = RECENT_MAX) {
  const read = (): string[] => { try { const list = JSON.parse(storage.getItem(storageKey) ?? "[]"); return Array.isArray(list) ? list.filter((item): item is string => typeof item === "string") : []; } catch { return []; } };
  const write = (list: string[]) => { try { storage.setItem(storageKey, JSON.stringify(list)); } catch { /* storage unavailable */ } };
  return {
    list: read,
    add(path: string): void { write(addRecent(read(), path, max)); },
    remove(path: string): void { write(read().filter((item) => item !== path)); },
    clear(): void { write([]); },
  };
}
