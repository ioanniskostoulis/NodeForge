import assert from "node:assert/strict";
import { test } from "node:test";
import { generalActionProblem } from "../../source/app/inspector-general";

test("the General section takes two or three actions, exactly one of them primary", () => {
  assert.equal(generalActionProblem([{ primary: true }, { primary: false }]), null);
  assert.equal(generalActionProblem([{ primary: true }, { primary: false }, { primary: false }]), null);
  assert.match(generalActionProblem([{ primary: true }]) ?? "", /not 1\./);
  assert.match(generalActionProblem([{ primary: true }, { primary: false }, { primary: false }, { primary: false }]) ?? "", /not 4\./);
  assert.match(generalActionProblem([{ primary: false }, { primary: false }]) ?? "", /exactly one primary action, not 0/);
  assert.match(generalActionProblem([{ primary: true }, { primary: true }]) ?? "", /exactly one primary action, not 2/);
});
