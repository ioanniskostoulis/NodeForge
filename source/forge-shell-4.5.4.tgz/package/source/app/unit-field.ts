// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** App-owned units and numeric rules, shown in the shared inspector field layout. */
export interface UnitFieldOptions {
  label: string;
  unit: string;
  value: number;
  format(value: number, unit: string): string;
  parse(text: string, unit: string): number;
  apply(value: number): void;
  reportError(message: string): void;
  invalidMessage: string;
}

export interface UnitField {
  row: HTMLLabelElement;
  input: HTMLInputElement;
  setValue(value: number): void;
}

/** Create a measurement field that displays its unit inside the editable value. */
export function createUnitField(options: UnitFieldOptions): UnitField {
  let value = options.value;
  const row = document.createElement("label");
  row.className = "field";
  const caption = document.createElement("span");
  caption.className = "label";
  caption.textContent = options.label;
  const input = document.createElement("input");
  input.type = "text";
  input.value = options.format(value, options.unit);
  row.append(caption, input);
  const commit = () => {
    const next = options.parse(input.value, options.unit);
    if (!Number.isFinite(next)) {
      input.classList.add("invalid");
      input.setAttribute("aria-invalid", "true");
      input.value = options.format(value, options.unit);
      options.reportError(options.invalidMessage);
      return;
    }
    input.classList.remove("invalid");
    input.setAttribute("aria-invalid", "false");
    value = next;
    input.value = options.format(value, options.unit);
    options.apply(value);
  };
  input.addEventListener("change", commit);
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.preventDefault(); input.blur(); }
    if (event.key === "Escape") { input.value = options.format(value, options.unit); input.blur(); }
  });
  return {
    row,
    input,
    setValue(next) { value = next; input.value = options.format(value, options.unit); input.classList.remove("invalid"); input.setAttribute("aria-invalid", "false"); },
  };
}
