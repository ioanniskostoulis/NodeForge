import assert from "node:assert/strict";
import { test } from "node:test";
import { applyDesktopClasses } from "../../source/app/desktop-classes";
import { forwardFullScreen } from "../../source/desktop/full-screen";

const body = () => { const set = new Set<string>(); return { set, classList: { toggle: (name: string, on?: boolean) => { if (on) set.add(name); else set.delete(name); return !!on; } } as unknown as DOMTokenList }; };

test("the page gets desktop-mac and follows full screen", () => {
  const target = body();
  let listener: (on: boolean) => void = () => {};
  applyDesktopClasses({ platform: "darwin", onFullScreen: (fn) => { listener = fn; } }, target);
  assert.deepEqual([...target.set], ["desktop-mac"]);
  listener(true);
  assert.ok(target.set.has("full-screen"));
  listener(false);
  assert.ok(!target.set.has("full-screen"));
  const other = body();
  applyDesktopClasses({ platform: "win32", onFullScreen: () => {} }, other);
  assert.equal(other.set.size, 0);
  assert.doesNotThrow(() => applyDesktopClasses(undefined, body()));
});

test("the window forwards enter, leave and its state after load", () => {
  const sent: boolean[] = [];
  const handlers: Record<string, () => void> = {};
  forwardFullScreen({
    isFullScreen: () => true,
    on: (event, listener) => { handlers[event] = listener; },
    webContents: { send: (channel, on) => { assert.equal(channel, "fullScreen"); sent.push(on as boolean); }, on: (event, listener) => { handlers[event] = listener; } },
  });
  handlers["enter-full-screen"](); handlers["leave-full-screen"](); handlers["did-finish-load"]();
  assert.deepEqual(sent, [true, false, true]);
});
