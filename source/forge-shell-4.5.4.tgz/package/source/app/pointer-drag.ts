// Licensed under the GNU General Public License v2 or later. See LICENSE.
// One drag, followed the same way by every control that is dragged: the slider, the range slider, the colour picker,
// splits and the preview stage. A press with another button is not a drag, and a release, a cancelled pointer or a
// lost capture each end the drag exactly once, so a drag that opened an undo group always closes it.

/** What a drag does while the pointer moves, and when it ends. */
export interface DragHandlers {
  move?(event: PointerEvent): void;
  end?(): void;
}

/** The element a drag follows: any event target, with pointer capture where the platform has it. */
export type DragTarget = EventTarget & { setPointerCapture?(pointerId: number): void };

/** The events that end a drag. */
export const DRAG_END_EVENTS = ["pointerup", "pointercancel", "lostpointercapture"] as const;

/**
 * Follow the pointer of `press` until it is released, cancelled or loses capture. Returns false, and follows nothing,
 * when the press was made with a button outside `buttons` (by default only the primary button drags).
 */
export function followPointer(target: DragTarget, press: Pick<PointerEvent, "button" | "pointerId">, handlers: DragHandlers, buttons: readonly number[] = [0]): boolean {
  if (!buttons.includes(press.button)) return false;
  // A synthetic press, or a pointer that has already ended, cannot be captured; the drag still follows its events.
  try { target.setPointerCapture?.(press.pointerId); } catch { /* nothing to capture */ }
  const done = new AbortController();
  target.addEventListener("pointermove", (event) => handlers.move?.(event as PointerEvent), { signal: done.signal });
  const end = () => {
    done.abort();
    handlers.end?.();
  };
  for (const type of DRAG_END_EVENTS) target.addEventListener(type, end, { signal: done.signal });
  return true;
}
