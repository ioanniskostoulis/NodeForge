// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { animate, reducedMotion } from "./motion";

export const SECTION_CHEVRON = `<svg class="chevron" viewBox="0 0 10 10" aria-hidden="true"><path d="M3.5 2 6.5 5 3.5 8"/></svg>`;

export interface SectionFoldOptions<Key extends string> {
  root: HTMLElement;
  keys: readonly Key[];
  isOpen: (key: Key) => boolean;
  setOpen: (key: Key, open: boolean) => void;
}

/** Shared inspector section buttons, Option-click grouping, and fold motion. */
export class InspectorSections<Key extends string> {
  constructor(private readonly options: SectionFoldOptions<Key>) {}

  create(title: string, key: Key): HTMLElement {
    const section = document.createElement("div");
    section.className = "section";
    section.dataset.section = key;
    const toggle = document.createElement("button");
    toggle.className = "section-title section-toggle";
    toggle.type = "button";
    toggle.innerHTML = SECTION_CHEVRON;
    const label = document.createElement("span");
    label.textContent = title;
    toggle.append(label);
    toggle.addEventListener("click", (event) => {
      const open = !this.options.isOpen(key);
      for (const sectionKey of event.altKey ? this.options.keys : [key]) this.options.setOpen(sectionKey, open);
      this.applyAll(true);
    });
    section.append(toggle);
    this.options.root.append(section);
    this.apply(section);
    return section;
  }

  apply(section: HTMLElement, smooth = false): void {
    const key = section.dataset.section as Key;
    const open = this.options.isOpen(key);
    section.firstElementChild!.setAttribute("aria-expanded", String(open));
    if (section.classList.contains("collapsed") === !open) return;
    if (!smooth || section.hidden || reducedMotion()) {
      section.classList.toggle("collapsed", !open);
      return;
    }
    const from = section.offsetHeight;
    section.classList.toggle("collapsed", !open);
    const to = section.offsetHeight;
    // Keep contents in view while the section closes over them.
    if (!open) section.classList.remove("collapsed");
    section.classList.add("folding");
    void animate(section, [{ height: `${from}px` }, { height: `${to}px` }]).then(() => {
      section.classList.remove("folding");
      section.classList.toggle("collapsed", !this.options.isOpen(key));
    });
  }

  applyAll(smooth = false): void {
    this.options.root.querySelectorAll<HTMLElement>(".section[data-section]").forEach((section) => this.apply(section, smooth));
  }
}
