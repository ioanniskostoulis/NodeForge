import assert from "node:assert/strict";
import { test } from "node:test";
import { buildTree, moveTarget, renameProblem, renameTarget, topLevel, type TreeFile } from "../../source/app/file-tree";

const files: TreeFile[] = [
  { path: "data", kind: "folder" }, { path: "data/a.csv", kind: "spreadsheet" }, { path: "notes.txt", kind: "text" },
  { path: ".git", kind: "folder", hidden: true }, { path: "b.txt", kind: "text" }, { path: "docs", kind: "folder" },
];

test("the tree lists folders before files, sorted, and hides hidden entries unless asked", () => {
  assert.deepEqual(buildTree(files, false).map((node) => node.name), ["data", "docs", "b.txt", "notes.txt"]);
  assert.deepEqual(buildTree(files, true).map((node) => node.name), ["data", "docs", "b.txt", "notes.txt", ".git"]);
  assert.deepEqual(buildTree(files, false)[0].children.map((node) => node.path), ["data/a.csv"]);
});

test("a bare name stays in the folder and a name with a slash moves", () => {
  assert.equal(renameTarget("data/a.csv", "b.csv"), "data/b.csv");
  assert.equal(renameTarget("data/a.csv", "docs/a.csv"), "docs/a.csv");
  assert.equal(renameTarget("data/a.csv", "a.csv"), null);
  assert.equal(renameTarget("x", "  "), null);
});

test("rename and move problems are sentences", () => {
  assert.equal(renameProblem("b.txt", "NOTES.txt", files), "The name NOTES.txt is already used.");
  assert.match(renameProblem("b.txt", "../c", files) ?? "", /cannot be \./);
  assert.equal(renameProblem("b.txt", "main.txt", files, (target) => (target === "main.txt" ? "main.txt is reserved." : null)), "main.txt is reserved.");
  assert.deepEqual(moveTarget("data", "data", files), { problem: "data cannot move into itself." });
  assert.deepEqual(moveTarget("b.txt", "docs", files), { target: "docs/b.txt" });
  assert.equal(moveTarget("b.txt", "", files), null);
  assert.deepEqual(moveTarget("b.txt", "docs", files, { blocked: () => "b.txt is locked." }), { problem: "b.txt is locked." });
});

test("a folder and its contents count once", () => {
  assert.deepEqual(topLevel(["data", "data/a.csv", "b.txt"]), ["data", "b.txt"]);
});

import { copyTarget, folderOf, newEntryName, treeCommands, treeKeyCommand } from "../../source/app/file-tree";

const press = (key: string, mods: Partial<{ meta: boolean; ctrl: boolean; alt: boolean; shift: boolean; code: string }> = {}) =>
  ({ key, code: mods.code, metaKey: !!mods.meta, ctrlKey: !!mods.ctrl, altKey: !!mods.alt, shiftKey: !!mods.shift });

test("the tree's commands carry the names and keys of Finder and File Explorer", () => {
  const mac = treeCommands(true), win = treeCommands(false);
  assert.equal(mac.delete.label, "Delete");
  assert.equal(win.delete.label, "Delete");
  assert.equal(mac.reveal.label, "Show in Finder");
  assert.equal(win.reveal.label, "Show in File Explorer");
  assert.deepEqual([mac.rename.key, win.rename.key], ["Enter", "F2"]);
  assert.deepEqual([mac.delete.key, win.delete.key], ["CmdOrCtrl+Backspace", "Delete"]);
  assert.deepEqual([mac.open.key, win.open.key], ["CmdOrCtrl+O", "Enter"]);
  assert.deepEqual([mac.copyPath.key, win.copyPath.key], ["CmdOrCtrl+Alt+C", "CmdOrCtrl+Shift+C"]);
  assert.equal(win.duplicate.key, undefined, "File Explorer has no Duplicate key");
  for (const command of Object.values(mac)) assert.ok(!/Trash|Recycle/.test(command.label), command.label);
});

test("keys map to the platform's commands", () => {
  // macOS: Return renames, Cmd+O and Cmd+Down open, Cmd+Delete deletes
  assert.equal(treeKeyCommand(press("Enter"), true), "rename");
  assert.equal(treeKeyCommand(press("F2"), true), "rename");
  assert.equal(treeKeyCommand(press("o", { meta: true }), true), "open");
  assert.equal(treeKeyCommand(press("ArrowDown", { meta: true }), true), "open");
  assert.equal(treeKeyCommand(press("Backspace", { meta: true }), true), "delete");
  assert.equal(treeKeyCommand(press("Backspace"), true), null, "a plain Delete key never deletes a file on macOS");
  assert.equal(treeKeyCommand(press("ç", { meta: true, alt: true, code: "KeyC" }), true), "copyPath");
  assert.equal(treeKeyCommand(press("d", { meta: true }), true), "duplicate");
  assert.equal(treeKeyCommand(press("N", { meta: true, shift: true }), true), "newFolder");
  // Windows: Enter opens, F2 renames, Delete deletes, Ctrl+Shift+C copies the path
  assert.equal(treeKeyCommand(press("Enter"), false), "open");
  assert.equal(treeKeyCommand(press("F2"), false), "rename");
  assert.equal(treeKeyCommand(press("Delete"), false), "delete");
  assert.equal(treeKeyCommand(press("C", { ctrl: true, shift: true }), false), "copyPath");
  assert.equal(treeKeyCommand(press("v", { ctrl: true }), false), "paste");
  assert.equal(treeKeyCommand(press("d", { ctrl: true }), false), null);
  assert.equal(treeKeyCommand(press("a", { ctrl: true }), false), "selectAll");
});

test("copies take the platform's copy names, and new entries the first free name", () => {
  assert.equal(copyTarget("notes.txt", "", files, true), "notes copy.txt");
  assert.equal(copyTarget("notes.txt", "", [...files, { path: "notes copy.txt", kind: "text" }], true), "notes copy 2.txt");
  assert.equal(copyTarget("notes.txt", "", files, false), "notes - Copy.txt");
  assert.equal(copyTarget("notes.txt", "", [...files, { path: "notes - Copy.txt", kind: "text" }], false), "notes - Copy (2).txt");
  // pasted into another folder, the name is kept when it is free; a folder has no extension
  assert.equal(copyTarget("notes.txt", "docs", files, true), "docs/notes.txt");
  assert.equal(copyTarget("data", "", files, true), "data copy");
  assert.equal(newEntryName("untitled.txt", "docs", files), "docs/untitled.txt");
  assert.equal(newEntryName("notes.txt", "", files), "notes 2.txt");
  assert.equal(folderOf("data/a.csv", files), "data");
  assert.equal(folderOf("data", files), "data");
  assert.equal(folderOf("", files), "");
});
