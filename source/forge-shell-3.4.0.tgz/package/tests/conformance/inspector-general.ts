import assert from "node:assert/strict";
import { test } from "node:test";
import { FIRST_SECTION_TITLE, generalActionProblem } from "../../source/app/inspector-general";

test("the first section takes two or three actions, exactly one of them primary, and is General by default", () => {
  assert.equal(FIRST_SECTION_TITLE, "General");
  assert.equal(generalActionProblem([{ primary: true }, { primary: false }]), null);
  assert.equal(generalActionProblem([{ primary: true }, { primary: false }, { primary: false }]), null);
  assert.match(generalActionProblem([{ primary: true }]) ?? "", /not 1\./);
  assert.match(generalActionProblem([{ primary: true }, { primary: false }, { primary: false }, { primary: false }]) ?? "", /not 4\./);
  assert.match(generalActionProblem([{ primary: false }, { primary: false }]) ?? "", /exactly one primary action, not 0/);
  assert.match(generalActionProblem([{ primary: true }, { primary: true }]) ?? "", /exactly one primary action, not 2/);
});
