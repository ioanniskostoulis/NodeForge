import assert from "node:assert/strict";
import { test } from "node:test";
import { registerShellMainIpc, type ShellIpcEvent } from "../../source/desktop/ipc-main.js";
import { DesktopWindowState } from "../../source/desktop/window-state.js";

test("main-process shell IPC routes each window's menu, title, edits, close and files", async () => {
  const events = new Map<string, (event: ShellIpcEvent, ...args: any[]) => void>();
  const handlers = new Map<string, (event: ShellIpcEvent, ...args: any[]) => unknown>();
  const log: string[] = [];
  const windows = new DesktopWindowState<string>();
  windows.setStartupFiles(1, ["one"]);
  const window = { setTitle: (title: string) => { log.push(`title ${title}`); }, setDocumentEdited: (value: boolean) => { log.push(`edited ${value}`); }, close: () => { log.push("close"); } };
  registerShellMainIpc({
    on: (channel, fn) => { events.set(channel, fn); },
    handle: (channel, fn) => { handlers.set(channel, fn); },
  }, {
    windows,
    windowFor: (event) => event.sender.id === 1 ? window : null,
    focusedWindow: () => window,
    installMenu: () => { log.push("menu"); },
    newWindow: () => { log.push("new window"); },
    canWriteFile: (event, path) => event.sender.id === 1 && path === "/tmp/example",
    writeFile: async (path, text) => { log.push(`write ${path} ${text}`); },
  });
  const event = { sender: { id: 1 } };
  assert.deepEqual(handlers.get("initialFiles")!(event), ["one"]);
  assert.deepEqual(handlers.get("initialFiles")!(event), []);
  events.get("setMenu")!(event, []);
  events.get("setMenu")!({ sender: { id: 2 } }, []);
  events.get("setTitle")!(event, "Example");
  events.get("setEdited")!(event, true);
  assert.equal(windows.needsClosePrompt(1), true);
  events.get("closeWindow")!(event);
  assert.equal(windows.needsClosePrompt(1), false);
  events.get("newWindow")!(event);
  await handlers.get("writeFile")!(event, "/tmp/example", "content");
  assert.throws(() => handlers.get("writeFile")!(event, "/tmp/other", "content"), /Save permission required/);
  assert.throws(() => handlers.get("writeFile")!({ sender: { id: 2 } }, "/tmp/example", "content"), /Save permission required/);
  assert.deepEqual(log, ["menu", "title Example", "edited true", "close", "new window", "write /tmp/example content"]);
});
