import assert from "node:assert/strict";
import { test } from "node:test";
import { setWindowBusy, whileBusy } from "../../source/app/busy-cursor";

class Node_ {
  className = ""; attributes: Record<string, string> = {}; children: Node_[] = []; parent: Node_ | null = null; dataset: Record<string, string> = {};
  setAttribute(name: string, value: string) { this.attributes[name] = value; }
  append(child: Node_) { child.parent = this; this.children.push(child); }
  remove() { if (this.parent) this.parent.children = this.parent.children.filter((c) => c !== this); this.parent = null; }
}
const fakeDocument = () => {
  const root = new Node_(), body = new Node_();
  root.append(body);
  return { documentElement: root, body, createElement: () => new Node_(), querySelector: (s: string) => body.children.find((c) => `.${c.className}` === s) ?? null } as unknown as Document;
};

test("progress marks the window busy and keeps it usable; wait adds one shield that takes the clicks; null clears both", () => {
  const doc = fakeDocument();
  setWindowBusy("progress", doc);
  assert.equal(doc.documentElement.dataset.busy, "progress");
  assert.equal(doc.querySelector(".busy-shield"), null, "progress never blocks the window");
  setWindowBusy("wait", doc);
  setWindowBusy("wait", doc);
  assert.equal(doc.documentElement.dataset.busy, "wait");
  assert.equal((doc.body as unknown as Node_).children.filter((c) => c.className === "busy-shield").length, 1, "one shield, however often wait is set");
  setWindowBusy(null, doc);
  assert.equal(doc.documentElement.dataset.busy, undefined);
  assert.equal(doc.querySelector(".busy-shield"), null);
});

test("whileBusy restores the window when the work fails", async () => {
  const doc = fakeDocument();
  await assert.rejects(whileBusy("wait", async () => { assert.equal(doc.documentElement.dataset.busy, "wait"); throw new Error("failed"); }, doc));
  assert.equal(doc.documentElement.dataset.busy, undefined);
  assert.equal(doc.querySelector(".busy-shield"), null);
  assert.equal(await whileBusy("progress", async () => 7, doc), 7);
});
