// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { STATUS_ICONS } from "./tool-icons";

export interface StatusBarState {
  stateLabel: string;
  stateColor: string;
  summary: string;
  detail: string;
  hint: string | null;
  unseenProblems: number;
  /** The worst kind among the unseen problems; `warning` when omitted. */
  problemKind?: "warning" | "error";
  readouts: readonly string[];
}

/** Shared chrome for app-supplied state, readouts, and transient action results. */
export class StatusBar {
  private readonly state: HTMLElement;
  private readonly summary: HTMLElement;
  private readonly dot: HTMLElement;
  private readonly detail: HTMLElement;
  private readonly warning: HTMLButtonElement;
  private readonly readouts: HTMLElement;

  constructor(host: HTMLElement, onWarnings: () => void) {
    host.innerHTML = `
      <span><span class="dot"></span><span class="state"></span> <span class="summary"></span></span>
      <span class="grow"></span>
      <button class="warn" hidden></button>
      <span class="readouts"></span>`;
    const item = (selector: string) => host.querySelector<HTMLElement>(selector)!;
    this.dot = item(".dot");
    this.state = item(".state");
    this.summary = item(".summary");
    this.detail = item(".grow");
    this.detail.setAttribute("aria-live", "polite");
    this.warning = host.querySelector<HTMLButtonElement>(".warn")!;
    this.readouts = item(".readouts");
    this.warning.addEventListener("click", onWarnings);
  }

  render(value: StatusBarState): void {
    this.dot.style.background = value.stateColor;
    this.state.textContent = value.stateLabel;
    this.summary.textContent = value.summary;
    this.detail.className = value.hint ? "grow hint" : "grow";
    this.detail.textContent = value.hint ?? value.detail;
    const count = value.unseenProblems;
    this.warning.hidden = !count;
    const kind = value.problemKind ?? "warning";
    this.warning.className = `warn ${kind}`;
    this.warning.innerHTML = `${STATUS_ICONS[kind]}<span class="count"></span>`;
    this.warning.querySelector(".count")!.textContent = String(count);
    const tip = `${count} new problem${count === 1 ? "" : "s"}. Click to show Messages.`;
    this.warning.title = tip;
    this.warning.setAttribute("aria-label", tip);
    while (this.readouts.children.length < value.readouts.length) {
      const span = document.createElement("span");
      span.className = "dim";
      this.readouts.append(span);
    }
    while (this.readouts.children.length > value.readouts.length) this.readouts.lastElementChild?.remove();
    value.readouts.forEach((readout, index) => {
      this.readouts.children[index].textContent = readout;
    });
  }
}
