// Licensed under the GNU General Public License v2 or later. See LICENSE.
import type { MenuNode } from "../app/menus";

/** Structural menu template, converted to Electron's MenuItemConstructorOptions by the app. */
export interface NativeMenuItem {
  type?: "separator" | "checkbox";
  role?: string;
  label?: string;
  accelerator?: string;
  registerAccelerator?: boolean;
  enabled?: boolean;
  checked?: boolean;
  submenu?: NativeMenuItem[];
  click?: (_item: unknown, window: unknown) => void;
}

export interface NativeMenuOptions {
  productName: string;
  isMac: boolean;
  isPackaged: boolean;
  onCommand: (id: string, window: unknown) => void;
}

/** Convert the renderer's menu definitions to a native template, including the macOS app menu. */
export function createNativeMenuTemplate(nodes: MenuNode[], options: NativeMenuOptions): NativeMenuItem[] {
  const convert = (items: MenuNode[]): NativeMenuItem[] => items
    .filter((item) => !(item.role === "toggleDevTools" && options.isPackaged))
    .map((item): NativeMenuItem => {
      if (item.separator) return { type: "separator" };
      if (item.role) return { role: item.role, label: item.label };
      const native: NativeMenuItem = {
        label: item.label,
        accelerator: item.key ?? item.hint,
        ...(!item.key && item.hint ? { registerAccelerator: false } : {}),
        enabled: item.enabled !== false && (!!item.id || !!item.submenu),
      };
      if (item.submenu) native.submenu = convert(item.submenu);
      if (item.checked !== undefined) {
        native.type = "checkbox";
        native.checked = item.checked;
      }
      if (item.id) native.click = (_item, window) => options.onCommand(item.id!, window);
      return native;
    });
  const template = convert(nodes);
  if (options.isMac) {
    const name = options.productName;
    template.unshift({
      label: name,
      submenu: [
        { label: `About ${name}`, click: (_item, window) => options.onCommand("about", window) },
        { type: "separator" },
        { role: "services" },
        { type: "separator" },
        { role: "hide" },
        { role: "hideOthers" },
        { role: "unhide" },
        { type: "separator" },
        { role: "quit" },
      ],
    });
    template.splice(template.length - 1, 0, { role: "windowMenu" });
  }
  return template;
}
