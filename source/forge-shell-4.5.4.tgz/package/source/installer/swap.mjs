// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { access, mkdir, readdir, rename, rm } from "node:fs/promises";
import { basename, join } from "node:path";

const exists = (path) => access(path).then(() => true, () => false);

/**
 * Rename, again while Windows says the folder is busy (EBUSY, EPERM, EACCES): an indexer, an antivirus scan or a
 * process that just quit can hold it for a moment. `tries` attempts, `wait` ms apart; the last error is thrown.
 */
export async function renameRetrying(from, to, { tries = 5, wait = 400, move = rename } = {}) {
  for (let attempt = 1; ; attempt++) {
    try { return await move(from, to); }
    catch (error) {
      if (attempt >= tries || !["EBUSY", "EPERM", "EACCES"].includes(error?.code)) throw error;
      await new Promise((resolve) => setTimeout(resolve, wait));
    }
  }
}

/**
 * Put the staged folder at the app path. The old folder is moved aside first and moved back if the
 * switch fails, so an interrupted or refused swap leaves the previous version in place.
 * A locked file (the app is running) surfaces as code BUSY.
 */
export async function swapIn({ layout, oldVersion, keepPrevious }) {
  const name = basename(layout.app);
  let aside = null;
  if (await exists(layout.app)) {
    if (keepPrevious && oldVersion) {
      await mkdir(layout.previous, { recursive: true });
      for (const entry of await readdir(layout.previous)) if (entry.startsWith(`${name}-`)) await rm(join(layout.previous, entry), { recursive: true, force: true });
      aside = join(layout.previous, `${name}-${oldVersion}`);
    } else {
      await rm(layout.trash, { recursive: true, force: true });
      aside = layout.trash;
    }
    try {
      await renameRetrying(layout.app, aside);
    } catch (error) {
      throw Object.assign(new Error(`${name} is in use. Close it, then try again.`), { code: "BUSY", cause: error });
    }
  }
  try {
    await renameRetrying(layout.staging, layout.app);
  } catch (error) {
    if (aside) await rename(aside, layout.app).catch(() => {});
    throw Object.assign(new Error(`Could not switch to the new files: ${error.message}`), { code: error.code === "EBUSY" || error.code === "EPERM" ? "BUSY" : "SWITCH", cause: error });
  }
  if (aside === layout.trash) await rm(aside, { recursive: true, force: true });
  return { previous: aside !== layout.trash ? aside : null };
}
